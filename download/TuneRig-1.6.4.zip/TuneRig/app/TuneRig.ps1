﻿# ============================================================================
#  TuneRig (portabel) - Hauptprogramm mit grafischer Oberfläche
#  Start: Doppelklick auf "TuneRig starten.bat"
# ============================================================================

param([switch]$DebugMode)

$ErrorActionPreference = 'Continue'
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DebugArg = if ($DebugMode) { ' -DebugMode' } else { '' }
$WinStyle = if ($DebugMode) { '-NoExit' } else { '-WindowStyle Hidden' }

# Jeder unerwartete Fehler beim Start wird angezeigt und protokolliert (sonst bliebe das Fenster einfach aus)
trap {
    try { if ($script:Splash) { $script:Splash.Close() } } catch {}
    $ex = $_.Exception; $detail = $ex.Message
    while ($ex.InnerException) { $ex = $ex.InnerException; $detail += "`n-> " + $ex.Message }
    $msg = "TuneRig konnte nicht gestartet werden:`n`n$detail`n`n$($_.InvocationInfo.PositionMessage)"
    try { $msg | Out-File -FilePath (Join-Path $AppDir 'fehler.log') -Append -Encoding UTF8 } catch {}
    try { Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show($msg, 'TuneRig - Fehler') | Out-Null } catch {}
    exit 1
}

# --- Administratorrechte anfordern -------------------------------------------
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA $WinStyle -File `"$($MyInvocation.MyCommand.Path)`"$DebugArg"
    } catch {
        Add-Type -AssemblyName PresentationFramework
        [System.Windows.MessageBox]::Show('TuneRig braucht Administratorrechte, um Treiber, Energieoptionen und Programme zu verwalten.', 'TuneRig') | Out-Null
    }
    exit
}

# --- WPF braucht einen STA-Thread ---------------------------------------------
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA $WinStyle -File `"$($MyInvocation.MyCommand.Path)`"$DebugArg"
    exit
}

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Get-ChildItem -LiteralPath $AppDir -Filter *.ps1 | Unblock-File -ErrorAction SilentlyContinue

$CorePath = Join-Path $AppDir 'Core.ps1'
$script:CoreText = [IO.File]::ReadAllText($CorePath, [Text.Encoding]::UTF8)
. $CorePath
if (-not $DebugMode) { [PCO.Native]::HideConsole() }

# --- Corporate Design laden (zentrale Theme-Datei) ----------------------------
. (Join-Path $AppDir 'Theme.ps1')
[TuneRig.Win]::SetAppId('TuneRig.PCOptimierung')
$script:SettingsPath = Join-Path $env:LOCALAPPDATA 'TuneRig\settings.json'
$script:StartSettings = try { Get-Content -LiteralPath $script:SettingsPath -Raw -ErrorAction Stop | ConvertFrom-Json } catch { $null }
Initialize-Theme $(if ($script:StartSettings -and $script:StartSettings.Theme -eq 'light') { 'light' } else { 'dark' })
. (Join-Path $AppDir 'Updater.ps1')
$script:AppVersion = (Get-TuneRigVersionInfo).Version

# ============================================================================
#  Ladesequenz: erscheint sofort; währenddessen wird die Oberfläche aufgebaut
#  und der Systemzustand für die Startseite ermittelt.
# ============================================================================
$splashXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TuneRig" Width="560" Height="340" WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        ResizeMode="NoResize" WindowStartupLocation="CenterScreen" ShowInTaskbar="True" UseLayoutRounding="True"
        TextOptions.TextFormattingMode="Display" FontFamily="{DynamicResource FontSans}">
  <Border Background="{DynamicResource Ground}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="14" Padding="40,28,40,24">
    <DockPanel>
      <DockPanel DockPanel.Dock="Bottom">
        <TextBlock x:Name="SplashVersion" DockPanel.Dock="Right" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}"/>
        <TextBlock x:Name="SplashCopy" Style="{StaticResource Label}" Tag="caps" Text="PC-Optimierung"/>
      </DockPanel>
      <StackPanel VerticalAlignment="Center">
        <Image Source="{DynamicResource LogoImage}" Height="112" HorizontalAlignment="Left" Margin="-10,0,0,0" RenderOptions.BitmapScalingMode="HighQuality"
               AutomationProperties.Name="TuneRig PC-Optimierung"/>
        <StackPanel x:Name="SplashSegments" Orientation="Horizontal" Margin="0,24,0,0"/>
        <StackPanel Orientation="Horizontal" Margin="0,14,0,0">
          <Grid Width="20" Height="20" Margin="0,0,12,0" VerticalAlignment="Center">
            <Ellipse Stroke="{DynamicResource Line}" StrokeThickness="3" StrokeDashArray="1.4 0.9"/>
            <Path Stroke="{DynamicResource Accent}" StrokeThickness="3" StrokeDashArray="1.4 0.9" Data="M10,1.5 A8.5,8.5 0 0 1 18.5,10" RenderTransformOrigin="0.5,0.5">
              <Path.RenderTransform><RotateTransform Angle="0"/></Path.RenderTransform>
              <Path.Triggers>
                <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                  <BeginStoryboard><Storyboard>
                    <DoubleAnimation Storyboard.TargetProperty="(UIElement.RenderTransform).(RotateTransform.Angle)" From="0" To="360" Duration="0:0:1.2" RepeatBehavior="Forever"/>
                  </Storyboard></BeginStoryboard>
                </EventTrigger>
              </Path.Triggers>
            </Path>
          </Grid>
          <TextBlock x:Name="SplashStatus" Style="{StaticResource Small}" VerticalAlignment="Center" Text="Starte TuneRig …"/>
        </StackPanel>
      </StackPanel>
    </DockPanel>
  </Border>
</Window>
'@
$script:Splash = [Windows.Markup.XamlReader]::Parse($splashXaml)
Set-WindowBranding $script:Splash
Set-CapsLabels $script:Splash
$script:Splash.FindName('SplashVersion').Text = "Version $script:AppVersion"
$script:SplashSegs = 24
for ($i = 0; $i -lt $script:SplashSegs; $i++) {
    $b = New-Object Windows.Controls.Border
    $b.Width = 16; $b.Height = 6; $b.Margin = New-Object Windows.Thickness(0, 0, 3, 0); $b.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $b Background 'line'
    [void]$script:Splash.FindName('SplashSegments').Children.Add($b)
}
$script:SplashStart = Get-Date
$script:SplashLevel = 0

function Update-SplashUi {
    try { [Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Background) } catch {}
}
# Segmentierte Fortschrittsanzeige (Motiv aus dem Logo)
function Set-SplashProgress([double]$Fraction, [string]$Text = '') {
    if (-not $script:Splash) { return }
    $n = [math]::Min($script:SplashSegs, [math]::Round($script:SplashSegs * $Fraction))
    $segs = $script:Splash.FindName('SplashSegments').Children
    for ($i = $script:SplashLevel; $i -lt $n; $i++) { Set-ThemeRef $segs[$i] Background 'accent' }
    $script:SplashLevel = [math]::Max($script:SplashLevel, $n)
    if ($Text) { $script:Splash.FindName('SplashStatus').Text = $Text }
    Update-SplashUi
}

# Schnellcheck in einem eigenen Hintergrund-Thread (Ergebnis für die Startseite)
function New-QuickHealthJob {
    $rs = [runspacefactory]::CreateRunspace(); $rs.ApartmentState = 'STA'; $rs.Open()
    $rs.SessionStateProxy.SetVariable('Sync', [hashtable]::Synchronized(@{ Status = '' }))
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript($script:CoreText + "`r`nGet-QuickHealth")
    return @{ PS = $ps; Handle = $ps.BeginInvoke(); Done = $false }
}

$script:Splash.Show()
Set-SplashProgress 0.08 'Lade Oberfläche …'
$script:HealthJob = New-QuickHealthJob

# ============================================================================
#  Oberfläche (XAML)
# ============================================================================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TuneRig" Height="800" Width="1200" MinHeight="600" MinWidth="1120"
        WindowStartupLocation="CenterScreen" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <DockPanel>
    <!-- ===================== STATUSLEISTE ===================== -->
    <Border x:Name="StatusBar" DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="24,6">
      <DockPanel>
        <Button x:Name="BtnCheckUpdate" DockPanel.Dock="Right" Content="Nach Updates suchen" MinHeight="28" Padding="12,3,12,4" Margin="12,0,0,0" FontSize="12"/>
        <TextBlock x:Name="StatusVersion" DockPanel.Dock="Right" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Margin="16,0,0,0"/>
        <Button x:Name="BtnCancel" DockPanel.Dock="Right" Content="Abbrechen" Visibility="Collapsed" MinHeight="32" Margin="12,0,0,0"/>
        <ProgressBar x:Name="BusyBar" DockPanel.Dock="Right" Width="160" IsIndeterminate="True" Visibility="Collapsed" VerticalAlignment="Center"/>
        <TextBlock x:Name="StatusText" Style="{StaticResource Small}" Text="Bereit." VerticalAlignment="Center" TextTrimming="CharacterEllipsis" TextWrapping="NoWrap"/>
      </DockPanel>
    </Border>

    <!-- ===================== KOPFLEISTE: Symbol + Wortmarke oben links ===================== -->
    <Border x:Name="HeaderBar" DockPanel.Dock="Top" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Height="72" Padding="16,0,24,0">
      <DockPanel>
        <StackPanel x:Name="HeaderNav" DockPanel.Dock="Right" Orientation="Horizontal">
          <Button x:Name="BtnNavHome" Style="{StaticResource TopNav}" Content="STARTSEITE" ToolTip="Zurück zur Auswahl"/>
          <Button x:Name="BtnNavGuided" Style="{StaticResource TopNav}" ToolTip="Prüft und verbessert deinen PC Schritt für Schritt">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavGuidedIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="REGULÄRER CHECK" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavBoost" Style="{StaticResource TopNav}" ToolTip="Mehr Leistung für Spiele – mit sicheren Einstellungen">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavBoostIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="PERFORMANCE BOOST" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavOverdrive" Style="{StaticResource TopNav}" ToolTip="Übertakten und Tuning – auf eigenes Risiko">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavOverdriveIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="OVERDRIVE" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavExpert" Style="{StaticResource TopNav}" Content="ALLE WERKZEUGE" ToolTip="Alle Funktionen in Reitern"/>
          <Button x:Name="BtnNavHelp" Style="{StaticResource TopNav}" Content="HILFE"/>
          <Button x:Name="BtnBackups" Content="Sicherungen" MinHeight="32" Margin="16,0,0,0" VerticalAlignment="Center" ToolTip="Wiederherstellungspunkte und Dateisicherungen verwalten"/>
          <Button x:Name="BtnTheme" Content="Hell" MinHeight="32" Margin="8,0,0,0" VerticalAlignment="Center" ToolTip="Zwischen dunklem und hellem Design wechseln"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Image x:Name="Logo" Source="{DynamicResource LogoImage}" Height="64" Stretch="Uniform" RenderOptions.BitmapScalingMode="HighQuality"
                 AutomationProperties.Name="TuneRig PC-Optimierung"/>
          <Border Width="1" Height="28" Background="{DynamicResource Line}" Margin="12,0,16,0" Visibility="Collapsed"/>
          <TextBlock x:Name="ModeLabel" Style="{StaticResource Label}" VerticalAlignment="Center" Visibility="Collapsed"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <Grid>
      <!-- ===================== STARTSEITE ===================== -->
      <DockPanel x:Name="WelcomePage" Background="{DynamicResource Ground}">
        <!-- Wechselnde Tipps -->
        <Border x:Name="TipBar" DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="48,12">
          <DockPanel MaxWidth="1120">
            <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
              <Button x:Name="TipAction" Visibility="Collapsed" MinHeight="32" Margin="16,0,16,0"/>
              <TextBlock x:Name="TipCounter" FontFamily="{DynamicResource FontMono}" FontSize="14" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Margin="0,0,12,0"/>
              <Button x:Name="TipPrev" Content="‹" MinWidth="36" MinHeight="32" Padding="0" Margin="0,0,4,0" ToolTip="Vorheriger Tipp"/>
              <Button x:Name="TipNext" Content="›" MinWidth="36" MinHeight="32" Padding="0" Margin="0" ToolTip="Nächster Tipp"/>
            </StackPanel>
            <ContentControl x:Name="TipIcon" DockPanel.Dock="Left" VerticalAlignment="Center" Margin="0,0,12,0"/>
            <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Tipp" VerticalAlignment="Center" Margin="0,0,16,0"/>
            <TextBlock x:Name="TipText" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" VerticalAlignment="Center"/>
          </DockPanel>
        </Border>
        <ScrollViewer VerticalScrollBarVisibility="Auto">
        <StackPanel MaxWidth="1120" Margin="48,32,48,32">
          <TextBlock Style="{StaticResource H1}" Text="Hol mehr aus deinem PC heraus."/>
          <TextBlock Style="{StaticResource Body}" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,24"
                     Text="TuneRig findet, was deinen PC bremst, und behebt es. Nichts ändert sich ohne deine Zustimmung."/>
          <!-- Update-Hinweis (nur sichtbar, wenn eine neuere Version bereitsteht) -->
          <Border x:Name="UpdateCard" Style="{StaticResource Card}" Visibility="Collapsed" Margin="0,0,0,16">
            <DockPanel>
              <ContentControl x:Name="UpdateIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Center"/>
              <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
                <Button x:Name="BtnUpdateNow" Content="Jetzt aktualisieren" Margin="16,0,8,0"/>
                <Button x:Name="BtnUpdateLater" Content="Später" Margin="0"/>
              </StackPanel>
              <StackPanel VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Update verfügbar"/>
                <TextBlock x:Name="UpdateTitle" Style="{StaticResource H3}" FontSize="16" LineHeight="22" Margin="0,4,0,0"/>
                <TextBlock x:Name="UpdateText" Style="{StaticResource Small}"/>
              </StackPanel>
            </DockPanel>
          </Border>
          <!-- Gesamtwertung -->
          <Border x:Name="HealthCard" Style="{StaticResource Card}" Padding="24" Margin="0,0,0,24">
            <Grid>
              <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <ContentControl x:Name="HealthGauge" Width="160" Height="140" VerticalAlignment="Center"/>
              <StackPanel Grid.Column="1" Margin="24,0,24,0" VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Systemzustand"/>
                <StackPanel Orientation="Horizontal" Margin="0,8,0,0">
                  <TextBlock x:Name="HealthScore" Style="{StaticResource Metric}" Text="–"/>
                  <TextBlock x:Name="HealthMax" FontFamily="{DynamicResource FontMono}" FontSize="14" Foreground="{DynamicResource InkMuted}" Text=" / 100" VerticalAlignment="Bottom" Margin="4,0,16,6"/>
                  <TextBlock x:Name="HealthRating" Style="{StaticResource H3}" VerticalAlignment="Center" Text="Wird bewertet …"/>
                </StackPanel>
                <TextBlock x:Name="HealthSummary" Style="{StaticResource Small}" Margin="0,4,0,0" Text="Der Schnellcheck läuft im Hintergrund und dauert nur wenige Sekunden."/>
                <StackPanel x:Name="HealthItems" Margin="0,8,0,0"/>
              </StackPanel>
              <StackPanel Grid.Column="2" VerticalAlignment="Center">
                <Button x:Name="BtnHealthCheck" Style="{StaticResource Primary}" Content="JETZT PRÜFEN" Margin="0,0,0,8" ToolTip="Startet den Regulären Check"/>
                <Button x:Name="BtnHealthRefresh" Content="Neu bewerten" Margin="0" ToolTip="Schnellcheck erneut ausführen"/>
              </StackPanel>
            </Grid>
          </Border>
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="24"/><ColumnDefinition Width="*"/><ColumnDefinition Width="24"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
            <!-- Regulärer Check -->
            <Border Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartGuided" DockPanel.Dock="Bottom" Content="Regulären Check starten" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardGuidedIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource InkMuted}" Tag="caps" Text="Empfohlen für alle" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Regulärer Check" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Prüft und verbessert deinen PC Schritt für Schritt. Oben steht immer, was als Nächstes zu tun ist – meist reicht ein Klick."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainGuided" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="5 Schritte · 5–10 Minuten"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Treiber, Leistung, Aufräumen"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Jede Änderung nur nach Rückfrage"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
            <!-- Performance Boost -->
            <Border Grid.Column="2" Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartGaming" DockPanel.Dock="Bottom" Content="Performance Boost starten" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardBoostIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Mehr FPS · weniger Ruckler" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Performance Boost" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Holt deutlich mehr Leistung für Spiele heraus: Bildwiederholrate, Prozessor, Autostart und Ping. Alles mit bewährten, sicheren Einstellungen."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainBoost" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Bildwiederholrate, Maus, Prozessor"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Autostart, Ping und DNS"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Wirkung und Nebenwirkung bei jedem Punkt"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
            <!-- Overdrive: nur auf eigenes Risiko -->
            <Border Grid.Column="4" Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartOverdrive" DockPanel.Dock="Bottom" Content="Overdrive öffnen" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardOverdriveIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource Warning}" Tag="caps" Text="Übertakten · auf eigenes Risiko" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Overdrive" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Zum Übertakten: stellt Windows in 3 Stufen kompromisslos auf Leistung und zeigt dir, wie du Prozessor, Grafikkarte und Arbeitsspeicher übertaktest. Dafür mehr Wärme, Stromverbrauch und teils weniger Schutz."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainOverdrive" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Übertakten von CPU, GPU und RAM – mit Anleitung"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="3 Stufen, nur nach ausdrücklicher Bestätigung"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Jederzeit komplett zurücksetzbar"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
          </Grid>
          <!-- Alle Werkzeuge: schmale Leiste -->
          <Border Style="{StaticResource Card}" Padding="24,16" Margin="0,24,0,0">
            <DockPanel>
              <Button x:Name="BtnStartExpert" DockPanel.Dock="Right" Content="Alle Werkzeuge öffnen" VerticalAlignment="Center" Margin="16,0,0,0"/>
              <ContentControl x:Name="CardExpertIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Center"/>
              <StackPanel VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Body}" FontWeight="SemiBold" Text="Alle Werkzeuge – für Erfahrene"/>
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" Margin="0,4,0,0" TextWrapping="Wrap" Text="Alle Funktionen in Reitern, ohne Assistent: Treiber, Energiesparpläne, Grafikkarte pro Spiel, Junk-Dateien auf allen Laufwerken, Deinstallation mit Rückstandssuche."/>
              </StackPanel>
            </DockPanel>
          </Border>
          <Border Style="{StaticResource Card}" Margin="0,24,0,0">
            <DockPanel>
              <ContentControl x:Name="SafetyIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Top"/>
              <StackPanel>
                <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Sicherheit"/>
                <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Vor jeder Änderung legt TuneRig einen Wiederherstellungspunkt an – damit lässt sich alles rückgängig machen."/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Programmreste landen im Papierkorb, Registry-Einträge werden vorher gesichert."/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Persönliche Dateien, Passwörter und Browser-Verlauf bleiben unangetastet."/>
                    </DockPanel>
                  </StackPanel>
              </StackPanel>
            </DockPanel>
          </Border>
          <CheckBox x:Name="ChkSkipWelcome" Margin="0,24,0,0" Content="Beim nächsten Start direkt die zuletzt gewählte Ansicht öffnen"/>
        </StackPanel>
        </ScrollViewer>
      </DockPanel>

      <!-- ===================== GEFÜHRTER CHECK ===================== -->
      <Grid x:Name="WizardPage" Visibility="Collapsed" Background="{DynamicResource Ground}">
        <Grid.ColumnDefinitions><ColumnDefinition Width="280"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <Border Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,1,0">
          <DockPanel Margin="24,32,16,24">
            <TextBlock DockPanel.Dock="Top" x:Name="WizSideTitle" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}"/>
            <TextBlock DockPanel.Dock="Top" x:Name="WizProgressText" Style="{StaticResource Small}" Margin="0,8,0,8"/>
            <StackPanel DockPanel.Dock="Top" x:Name="WizProgressSegments" Orientation="Horizontal" Margin="0,0,0,24"/>
            <TextBlock x:Name="WizSideLegend" DockPanel.Dock="Bottom" Style="{StaticResource Small}" Margin="0,16,0,0"
                       Text="Erledigte Schritte kannst du jederzeit wieder öffnen."/>
            <StackPanel x:Name="WizSidebar" Margin="-24,0,0,0"/>
          </DockPanel>
        </Border>
        <DockPanel Grid.Column="1">
          <Border DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="48,12">
            <DockPanel x:Name="WizNav">
              <Button x:Name="WizNext" DockPanel.Dock="Right" Content="Weiter" MinWidth="140" Margin="8,0,0,0"/>
              <Button x:Name="WizBack" DockPanel.Dock="Right" Content="Zurück" MinWidth="110" Margin="8,0,0,0"/>
              <Button x:Name="WizRecheck" DockPanel.Dock="Right" Content="Erneut prüfen" Margin="8,0,0,0" ToolTip="Diesen Schritt noch einmal prüfen, z. B. nachdem du etwas geändert hast"/>
              <Button x:Name="WizExit" DockPanel.Dock="Left" Content="Check beenden" Margin="0"/>
              <StackPanel Orientation="Horizontal" VerticalAlignment="Center" Margin="16,0,8,0">
                <ContentControl x:Name="WizNavIcon" Margin="0,0,8,0" VerticalAlignment="Center"/>
                <TextBlock x:Name="WizNavHint" Style="{StaticResource Small}" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" TextWrapping="NoWrap"/>
              </StackPanel>
            </DockPanel>
          </Border>
          <StackPanel DockPanel.Dock="Top" Margin="48,32,48,0" MaxWidth="1000" HorizontalAlignment="Left">
            <TextBlock x:Name="WizStepNo" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}"/>
            <TextBlock x:Name="WizTitle" Style="{StaticResource H2}" Margin="0,8,0,0"/>
            <TextBlock x:Name="WizSub" Style="{StaticResource Body}" Foreground="{DynamicResource InkMuted}" Margin="0,4,0,0"/>
            <Expander x:Name="WizIntroExp" Header="Worum geht es in diesem Schritt?" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock x:Name="WizIntro" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}"/>
              </Border>
            </Expander>
            <Border x:Name="WizBusy" Style="{StaticResource Card}" Visibility="Collapsed" Margin="0,16,0,0">
              <DockPanel>
                <!-- Segmentierter Fortschrittsring (Motiv aus dem Logo) -->
                <Grid DockPanel.Dock="Left" Width="40" Height="40" Margin="0,0,16,0" VerticalAlignment="Center">
                  <Ellipse Stroke="{DynamicResource Line}" StrokeThickness="4" StrokeDashArray="1.6 0.9"/>
                  <Path Stroke="{DynamicResource Accent}" StrokeThickness="4" StrokeDashArray="1.6 0.9" Data="M20,2 A18,18 0 0 1 38,20" RenderTransformOrigin="0.5,0.5">
                    <Path.RenderTransform><RotateTransform Angle="0"/></Path.RenderTransform>
                    <Path.Triggers>
                      <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                        <BeginStoryboard>
                          <Storyboard>
                            <DoubleAnimation Storyboard.TargetProperty="(UIElement.RenderTransform).(RotateTransform.Angle)" From="0" To="360" Duration="0:0:1.6" RepeatBehavior="Forever"/>
                          </Storyboard>
                        </BeginStoryboard>
                      </EventTrigger>
                    </Path.Triggers>
                  </Path>
                </Grid>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock x:Name="WizBusyText" Style="{StaticResource Body}" FontWeight="Medium"/>
                  <TextBlock x:Name="WizBusyHint" Style="{StaticResource Small}" Margin="0,4,0,0" Text="TuneRig arbeitet. Du musst nichts tun."/>
                </StackPanel>
              </DockPanel>
            </Border>
          </StackPanel>
          <ScrollViewer x:Name="WizScroll" VerticalScrollBarVisibility="Auto" Margin="0,16,0,0">
            <StackPanel x:Name="WizContent" Margin="48,8,48,32" MaxWidth="1000" HorizontalAlignment="Left"/>
          </ScrollViewer>
        </DockPanel>
      </Grid>

      <!-- ===================== ALLE WERKZEUGE ===================== -->
      <Grid x:Name="ExpertPage" Visibility="Collapsed" Background="{DynamicResource Ground}">
    <TabControl x:Name="Tabs" Padding="32,24">

      <!-- ===================== ÜBERSICHT ===================== -->
      <TabItem Header="Übersicht">
        <DockPanel>
          <StackPanel DockPanel.Dock="Top">
            <TextBlock Style="{StaticResource H3}" Text="Systemanalyse"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Hier prüft TuneRig deinen ganzen PC auf einmal: Hardware, Treiber, Grafikkarten und Windows-Einstellungen. Die Analyse startet beim ersten Öffnen von selbst, liest nur und ändert nichts. Die Statusspalte zeigt OK, Hinweis, Empfehlung oder Problem. In der Spalte »Was tun?« steht, wie du vorgehst. Einfacher geht es mit dem Regulären Check."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,16" Text="Die Analyse startet automatisch und ändert nichts. Änderungen machst du in den einzelnen Reitern. Sicherungen verwaltest du oben rechts unter »Sicherungen«."/>
            <WrapPanel>
              <Button x:Name="BtnAnalyze" Content="Neu analysieren" ToolTip="Prüft alles noch einmal. Ändert nichts."/>
            </WrapPanel>
          </StackPanel>
          <Grid Margin="0,16,0,0">
            <Grid.ColumnDefinitions><ColumnDefinition Width="320"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
            <Border Style="{StaticResource Card}" Margin="0,0,16,0">
              <ScrollViewer VerticalScrollBarVisibility="Auto">
                <StackPanel x:Name="SummaryPanel">
                  <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Dein System"/>
                  <TextBlock Style="{StaticResource Small}" Text="Noch nicht analysiert." Margin="0,8,0,0"/>
                </StackPanel>
              </ScrollViewer>
            </Border>
            <DataGrid x:Name="GridFindings" Grid.Column="1" IsReadOnly="True">
              <DataGrid.Columns>
                <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="120" ElementStyle="{StaticResource LevelText}"/>
                <DataGridTextColumn Header="Bereich" Binding="{Binding B}" Width="100" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Ergebnis" Binding="{Binding C}" Width="230" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Details" Binding="{Binding D}" Width="*" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Was tun?" Binding="{Binding E}" Width="*" ElementStyle="{StaticResource Wrap}"/>
              </DataGrid.Columns>
            </DataGrid>
          </Grid>
        </DockPanel>
      </TabItem>

      <!-- ===================== TREIBER & UPDATES ===================== -->
      <TabItem Header="Treiber &amp; Updates">
        <DockPanel>
          <Border DockPanel.Dock="Top" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Margin="0,0,0,16">
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnDrvViewDrivers" Style="{StaticResource TopNav}" Content="TREIBER" Height="40" Margin="0"/>
              <Button x:Name="BtnDrvViewUpdates" Style="{StaticResource TopNav}" Content="WINDOWS-UPDATES" Height="40"/>
            </StackPanel>
          </Border>
          <Grid>
            <!-- Treiber -->
            <Grid x:Name="DrvViewDrivers">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel>
                <Expander Header="Erklärung für Einsteiger">
                  <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                    <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Treiber sind kleine Programme, mit denen Windows deine Hardware steuert (Grafikkarte, Netzwerk, Sound …). Fehlende oder veraltete Treiber kosten Leistung oder verursachen Fehler. Beim Öffnen prüft TuneRig alle Treiber automatisch – Probleme stehen oben. Neuere Treiber von Microsoft findest du unter »Windows-Updates«, für Grafikkarten ist die Software des Herstellers meist aktueller. Grafikkarten im Detail siehst du unter Leistung › Verwendete Grafikkarte."/>
                  </Border>
                </Expander>
                <Border Style="{StaticResource Card}" Margin="0,8,0,8">
                  <DockPanel>
                    <ContentControl x:Name="DriverWarnIcon" DockPanel.Dock="Left" Margin="0,0,12,0" VerticalAlignment="Top"/>
                    <StackPanel>
                      <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource Warning}" Tag="caps" Text="Nur originale Treiber"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Margin="0,4,0,0" Text="Installiere Treiber nur über Windows Update oder direkt beim Hersteller (NVIDIA, AMD, Intel, PC- oder Mainboard-Hersteller). Treiber-Updater und Download-Seiten von Drittanbietern liefern oft falsche, veraltete oder veränderte Treiber – mit Leistungseinbußen, Abstürzen oder Schadsoftware als Folge."/>
                    </StackPanel>
                  </DockPanel>
                </Border>
                <WrapPanel>
                  <Button x:Name="BtnDrivers" Content="Neu prüfen"/>
                  <Button x:Name="BtnDevMgr" Content="Geräte-Manager öffnen"/>
                  <TextBlock Style="{StaticResource Small}" Text="Hersteller-Software:" VerticalAlignment="Center" Margin="12,0,8,8"/>
                  <Button x:Name="BtnNvidia" Content="NVIDIA App"/>
                  <Button x:Name="BtnAmd" Content="AMD Software"/>
                  <Button x:Name="BtnIntel" Content="Intel Driver &amp; Support Assistant"/>
                </WrapPanel>
              </StackPanel>
              <DataGrid x:Name="GridDrivers" Grid.Row="1" IsReadOnly="True" Margin="0,8,0,0">
                <DataGrid.Columns>
                  <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="240" ElementStyle="{StaticResource LevelText}"/>
                  <DataGridTextColumn Header="Gerät" Binding="{Binding B}" Width="*"/>
                  <DataGridTextColumn Header="Hardware" Binding="{Binding C}" Width="200"/>
                  <DataGridTextColumn Header="Anbieter" Binding="{Binding D}" Width="150"/>
                  <DataGridTextColumn Header="Version" Binding="{Binding E}" Width="130"/>
                  <DataGridTextColumn Header="Datum" Binding="{Binding F}" Width="100"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
            <!-- Windows-Updates -->
            <Grid x:Name="DrvViewUpdates" Visibility="Collapsed">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel>
                <TextBlock Style="{StaticResource Small}" Margin="0,0,0,12" TextWrapping="Wrap" Text="Fragt Windows Update nach neueren Treibern. Die Suche dauert 1–3 Minuten und installiert noch nichts. Für Grafikkarten bietet die Software des Herstellers meist neuere Treiber."/>
                <WrapPanel>
                  <Button x:Name="BtnSearchUpdates" Style="{StaticResource Primary}" Content="WINDOWS-UPDATES SUCHEN"/>
                  <Button x:Name="BtnInstallUpdates" Content="Ausgewählte installieren"/>
                </WrapPanel>
              </StackPanel>
              <DataGrid x:Name="GridUpdates" Grid.Row="1" Margin="0,8,0,0">
                <DataGrid.Columns>
                  <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
                  <DataGridTextColumn Header="Update" Binding="{Binding A}" Width="*" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Hersteller" Binding="{Binding B}" Width="160" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Klasse" Binding="{Binding C}" Width="120" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Datum" Binding="{Binding D}" Width="100" IsReadOnly="True"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
          </Grid>
        </DockPanel>
      </TabItem>

      <!-- ===================== LEISTUNG ===================== -->
      <TabItem Header="Leistung">
        <DockPanel>
          <Border DockPanel.Dock="Top" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Margin="0,0,0,16">
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnPerfViewSettings" Style="{StaticResource TopNav}" Content="EINSTELLUNGEN" Height="40" Margin="0"/>
              <Button x:Name="BtnPerfViewGames" Style="{StaticResource TopNav}" Content="VERWENDETE GRAFIKKARTE" Height="40"/>
              <Button x:Name="BtnPerfViewStartup" Style="{StaticResource TopNav}" Content="AUTOSTART" Height="40"/>
            </StackPanel>
          </Border>
          <Grid>
            <!-- Alle Einstellungen in einer Liste -->
            <Grid x:Name="PerfViewSettings">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel>
                <Expander Header="Erklärung für Einsteiger">
                  <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                    <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Alle Windows-Einstellungen für mehr Leistung in einer Liste: Energie, Spiele und Grafik, Prozessor, Bild und Internet. »Empfohlen« ist unbedenklich und vorausgewählt. »Optional« hat eine Nebenwirkung (rechte Spalte), »Experimentell« eine umstrittene Wirkung. »Zurücksetzen« stellt genau den Wert wieder her, den du vorher hattest. Einfacher geht es mit dem Performance Boost auf der Startseite."/>
                  </Border>
                </Expander>
                <DockPanel Margin="0,12,0,0">
                  <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Top">
                    <TextBlock Style="{StaticResource Small}" Text="Energiesparplan:" VerticalAlignment="Center" Margin="16,0,8,8"/>
                    <ComboBox x:Name="ComboPlans" Width="260" Margin="0,0,8,8" DisplayMemberPath="A"/>
                    <Button x:Name="BtnSetPlan" Content="Aktivieren" Margin="0,0,0,8"/>
                  </StackPanel>
                  <WrapPanel>
                    <Button x:Name="BtnSetApply" Style="{StaticResource Primary}" Content="JETZT ANWENDEN" ToolTip="Ändert alle angehakten Einstellungen."/>
                    <Button x:Name="BtnSetRevert" Content="Ausgewählte zurücksetzen"/>
                    <Button x:Name="BtnSetCheck" Content="Neu prüfen"/>
                  </WrapPanel>
                </DockPanel>
                <StackPanel Orientation="Horizontal" Margin="0,4,0,0">
                  <TextBlock Style="{StaticResource Small}" Text="Anzeigen:" VerticalAlignment="Center" Margin="0,0,8,0"/>
                  <RadioButton x:Name="RbSetAll" GroupName="SetFilter" Content="Alle" IsChecked="True" Margin="0,0,16,0" VerticalAlignment="Center"/>
                  <RadioButton x:Name="RbSetOpen" GroupName="SetFilter" Content="Nur offene" Margin="0,0,16,0" VerticalAlignment="Center"/>
                  <RadioButton x:Name="RbSetRec" GroupName="SetFilter" Content="Empfohlen" Margin="0,0,16,0" VerticalAlignment="Center"/>
                  <RadioButton x:Name="RbSetOpt" GroupName="SetFilter" Content="Optional und experimentell" VerticalAlignment="Center"/>
                </StackPanel>
              </StackPanel>
              <DataGrid x:Name="GridSettings" Grid.Row="1" Margin="0,12,0,0">
                <DataGrid.Columns>
                  <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
                  <DataGridTextColumn Header="Bereich" Binding="{Binding A}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Einstellung" Binding="{Binding B}" Width="220" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Status" Binding="{Binding C}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
                  <DataGridTextColumn Header="Aktuell" Binding="{Binding D}" Width="210" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Empfohlen" Binding="{Binding E}" Width="160" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Wirkung / Nebenwirkung" Binding="{Binding F}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
            <!-- Verwendete Grafikkarte: welche Karte die Spiele nutzen; die Grafikkarten selbst aufklappbar -->
            <Grid x:Name="PerfViewGames" Visibility="Collapsed">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*" MinHeight="160"/></Grid.RowDefinitions>
              <Expander x:Name="GpuExpander" Header="Erkannte Grafikkarten">
                <StackPanel Margin="0,8,0,0">
                  <WrapPanel>
                    <Button x:Name="BtnGpu" Content="Neu prüfen"/>
                    <Button x:Name="BtnGfxSettings" Content="Windows-Grafikeinstellungen öffnen"/>
                  </WrapPanel>
                  <DataGrid x:Name="GridGpus" IsReadOnly="True" MaxHeight="130" Margin="0,4,0,0">
                    <DataGrid.Columns>
                      <DataGridTextColumn Header="Grafikkarte" Binding="{Binding A}" Width="*"/>
                      <DataGridTextColumn Header="Typ" Binding="{Binding B}" Width="200"/>
                      <DataGridTextColumn Header="Speicher" Binding="{Binding C}" Width="100"/>
                      <DataGridTextColumn Header="Treiber" Binding="{Binding D}" Width="140"/>
                      <DataGridTextColumn Header="vom" Binding="{Binding E}" Width="100"/>
                      <DataGridTextColumn Header="Monitor" Binding="{Binding F}" Width="200"/>
                    </DataGrid.Columns>
                  </DataGrid>
                  <DataGrid x:Name="GridGpuFindings" IsReadOnly="True" Margin="0,8,0,0" MaxHeight="130">
                    <DataGrid.Columns>
                      <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="120" ElementStyle="{StaticResource LevelText}"/>
                      <DataGridTextColumn Header="Ergebnis" Binding="{Binding C}" Width="260" ElementStyle="{StaticResource Wrap}"/>
                      <DataGridTextColumn Header="Details" Binding="{Binding D}" Width="*" ElementStyle="{StaticResource Wrap}"/>
                      <DataGridTextColumn Header="Was tun?" Binding="{Binding E}" Width="*" ElementStyle="{StaticResource Wrap}"/>
                    </DataGrid.Columns>
                  </DataGrid>
                </StackPanel>
              </Expander>
              <StackPanel Grid.Row="1" Margin="0,16,0,0">
                <TextBlock Style="{StaticResource Small}" Margin="0,0,0,12" TextWrapping="Wrap" Text="Viele PCs und fast alle Gaming-Laptops haben zwei Grafikkarten: eine stromsparende und eine leistungsstarke. Mit »Hohe Leistung« startet Windows ein Spiel immer auf der leistungsstarken Karte. Gefunden werden Spiele aus Steam, Epic Games und GOG, andere fügst du über »Programm hinzufügen« hinzu."/>
                <WrapPanel>
                  <Button x:Name="BtnHighPerf" Style="{StaticResource Primary}" Content="JETZT UMSTELLEN" ToolTip="Windows startet die angehakten Spiele immer auf der leistungsstarken Grafikkarte."/>
                  <Button x:Name="BtnAddGame" Content="Programm hinzufügen …"/>
                  <Button x:Name="BtnGames" Content="Spiele neu suchen"/>
                  <TextBlock x:Name="GamesCount" Style="{StaticResource Small}" VerticalAlignment="Center" Margin="8,0,0,8"/>
                </WrapPanel>
              </StackPanel>
              <DataGrid x:Name="GridGames" Grid.Row="2" Margin="0,8,0,0">
                <DataGrid.Columns>
                  <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
                  <DataGridTextColumn Header="Spiel" Binding="{Binding A}" Width="240" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Quelle" Binding="{Binding B}" Width="100" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Verwendete Grafikkarte" Binding="{Binding C}" Width="190" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
                  <DataGridTextColumn Header="Programmdatei" Binding="{Binding D}" Width="*" IsReadOnly="True"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
            <!-- Autostart -->
            <Grid x:Name="PerfViewStartup" Visibility="Collapsed">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel>
                <TextBlock Style="{StaticResource Small}" Margin="0,0,0,12" TextWrapping="Wrap" Text="Programme, die mit Windows starten, verlängern den Start und laufen im Hintergrund mit. Abschalten löscht nichts – du kannst sie hier jederzeit wieder einschalten."/>
                <WrapPanel>
                  <Button x:Name="BtnStartupDisable" Style="{StaticResource Primary}" Content="AUSGEWÄHLTE ABSCHALTEN"/>
                  <Button x:Name="BtnStartupEnable" Content="Ausgewählte einschalten"/>
                  <Button x:Name="BtnStartupCheck" Content="Neu prüfen"/>
                </WrapPanel>
              </StackPanel>
              <DataGrid x:Name="GridStartup" Grid.Row="1" Margin="0,8,0,0">
                <DataGrid.Columns>
                  <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
                  <DataGridTextColumn Header="Programm" Binding="{Binding A}" Width="200" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Status" Binding="{Binding B}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
                  <DataGridTextColumn Header="Empfehlung" Binding="{Binding C}" Width="190" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Für" Binding="{Binding D}" Width="140" IsReadOnly="True"/>
                  <DataGridTextColumn Header="Befehl" Binding="{Binding E}" Width="*" IsReadOnly="True"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
          </Grid>
        </DockPanel>
      </TabItem>

      <!-- ===================== SPEICHERPLATZ ===================== -->
      <TabItem Header="Speicherplatz">
        <DockPanel>
          <Border DockPanel.Dock="Top" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Margin="0,0,0,16">
            <DockPanel>
              <TextBlock DockPanel.Dock="Right" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Text="Gelöscht wird nur, was du selbst auswählst."/>
              <StackPanel Orientation="Horizontal">
                <Button x:Name="BtnStoViewClean" Style="{StaticResource TopNav}" Content="SCHNELL AUFRÄUMEN" Height="40" Margin="0"/>
                <Button x:Name="BtnStoViewDrive" Style="{StaticResource TopNav}" Content="LAUFWERK ANALYSIEREN" Height="40"/>
              </StackPanel>
            </DockPanel>
          </Border>
          <Grid>
            <!-- Schnell aufräumen: Windows-Bereinigung und Junk-Dateien in einer Liste -->
            <Grid x:Name="StoViewClean">
              <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
              <StackPanel>
                <Expander Header="Erklärung für Einsteiger">
                  <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                    <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Windows und Programme legen ständig Zwischendateien an, die später niemand mehr braucht. Beim Öffnen berechnet TuneRig, wie viel Platz frei werden kann. Die letzte Zeile sucht auf allen Laufwerken nach typischem Datenmüll (*.tmp, *.dmp, Thumbs.db …) – das dauert einige Minuten und startet erst, wenn du sie anhakst. Persönliche Dateien, Passwörter und Browser-Verlauf bleiben unangetastet."/>
                  </Border>
                </Expander>
                <WrapPanel Margin="0,12,0,0">
                  <Button x:Name="BtnCleanRun" Style="{StaticResource Primary}" Content="JETZT AUFRÄUMEN"/>
                  <Button x:Name="BtnCleanScan" Content="Neu berechnen" ToolTip="Berechnet, wie viel Platz frei werden kann. Löscht noch nichts."/>
                  <Button x:Name="BtnJunkShow" Content="Gefundene Junk-Dateien anzeigen …"/>
                  <TextBlock x:Name="CleanTotal" Style="{StaticResource Metric}" FontSize="14" LineHeight="20" VerticalAlignment="Center" Margin="8,0,0,8"/>
                </WrapPanel>
              </StackPanel>
              <DataGrid x:Name="GridClean" Grid.Row="1" Margin="0,8,0,0">
                <DataGrid.Columns>
                  <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
                  <DataGridTextColumn Header="Bereich" Binding="{Binding A}" Width="300" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Größe" Binding="{Binding B}" Width="200" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                  <DataGridTextColumn Header="Beschreibung" Binding="{Binding C}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
                </DataGrid.Columns>
              </DataGrid>
            </Grid>
            <!-- Laufwerk analysieren -->
            <Grid x:Name="StoViewDrive" Visibility="Collapsed">
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Was belegt deinen Speicherplatz?"/>
            <WrapPanel x:Name="StorageDrives" Margin="0,12,0,0"/>
            <StackPanel x:Name="StorageProgress" Visibility="Collapsed" Margin="0,4,0,0">
              <ProgressBar x:Name="StorageProgressBar" Height="6" Minimum="0" Maximum="100" IsIndeterminate="False"/>
              <TextBlock x:Name="StorageProgressText" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,0" TextTrimming="CharacterEllipsis"/>
            </StackPanel>
          </StackPanel>
          <!-- Vor der ersten Analyse -->
          <Border x:Name="StorageEmpty" Grid.Row="1" Style="{StaticResource Card}" Margin="0,8,0,0" Padding="32">
            <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" MaxWidth="560">
              <ContentControl x:Name="StorageEmptyIcon" HorizontalAlignment="Center"/>
              <TextBlock Style="{StaticResource Body}" FontWeight="SemiBold" HorizontalAlignment="Center" Margin="0,16,0,8" Text="Klick oben auf ein Laufwerk, um es zu analysieren."/>
              <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" TextAlignment="Center" TextWrapping="Wrap" Text="Danach siehst du eine Rangliste deiner größten Spiele, Programme, Ordner und Dateien – mit Größe, zuletzt gespielt und dem passenden Button zum Entfernen. Die Analyse dauert je nach Laufwerk 10 Sekunden bis wenige Minuten und lässt sich abbrechen."/>
            </StackPanel>
          </Border>

          <!-- Ergebnis -->
          <Border x:Name="StorageResult" Grid.Row="1" Style="{StaticResource Card}" Margin="0,8,0,0" Padding="0" Visibility="Collapsed">
            <DockPanel>
              <Border DockPanel.Dock="Top" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Padding="20,12,12,0">
                <DockPanel>
                  <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Bottom">
                    <Button x:Name="BtnStorageViewBig" Style="{StaticResource TopNav}" Content="WAS DU LÖSCHEN KANNST" Height="40"/>
                    <Button x:Name="BtnStorageViewTree" Style="{StaticResource TopNav}" Content="ORDNER" Height="40"/>
                    <Button x:Name="BtnStorageViewTypes" Style="{StaticResource TopNav}" Content="DATEITYPEN" Height="40"/>
                  </StackPanel>
                  <StackPanel Margin="0,0,16,12">
                    <TextBlock x:Name="StorageHeadline" Style="{StaticResource Metric}" FontSize="18" LineHeight="24"/>
                    <TextBlock x:Name="StorageSubline" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" TextWrapping="Wrap" Margin="0,4,0,0"/>
                  </StackPanel>
                </DockPanel>
              </Border>
              <Grid>
                <!-- Ansicht 1: Rangliste -->
                <ScrollViewer x:Name="StorageViewBig" VerticalScrollBarVisibility="Auto" Padding="12,8,12,12">
                  <StackPanel x:Name="StorageBig"/>
                </ScrollViewer>
                <!-- Ansicht 2: Ordnerbaum -->
                <DockPanel x:Name="StorageViewTree" Visibility="Collapsed" Margin="20,12,12,12">
                  <StackPanel DockPanel.Dock="Top">
                    <DockPanel>
                      <StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
                        <Button x:Name="BtnStorageUp" Content="Eine Ebene höher" MinHeight="32" Padding="12,4,12,5" Margin="8,0,0,0"/>
                        <Button x:Name="BtnStorageOpen" Content="Im Explorer öffnen" MinHeight="32" Padding="12,4,12,5" Margin="8,0,0,0"/>
                      </StackPanel>
                      <WrapPanel x:Name="StorageCrumbs" VerticalAlignment="Center"/>
                    </DockPanel>
                    <TextBlock x:Name="StorageFolderInfo" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,8"/>
                    <Border Height="1" Background="{DynamicResource Line}"/>
                  </StackPanel>
                  <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,4,0,0">
                    <StackPanel x:Name="StorageList"/>
                  </ScrollViewer>
                </DockPanel>
                <!-- Ansicht 3: Dateitypen -->
                <ScrollViewer x:Name="StorageViewTypes" Visibility="Collapsed" VerticalScrollBarVisibility="Auto" Padding="20,12,12,12">
                  <StackPanel x:Name="StorageTypes"/>
                </ScrollViewer>
              </Grid>
            </DockPanel>
          </Border>
            </Grid>
          </Grid>
        </DockPanel>
      </TabItem>

      <!-- ===================== PROGRAMME ===================== -->
      <TabItem Header="Programme">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition x:Name="ProgRowTop" Height="*" MinHeight="140"/><RowDefinition Height="Auto"/><RowDefinition x:Name="ProgRowLo" Height="*"/></Grid.RowDefinitions>
          <Border BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Margin="0,0,0,16">
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnProgViewInstalled" Style="{StaticResource TopNav}" Content="INSTALLIERTE PROGRAMME" Height="40" Margin="0"/>
              <Button x:Name="BtnProgViewOrphans" Style="{StaticResource TopNav}" Content="RESTE ALTER PROGRAMME" Height="40"/>
            </StackPanel>
          </Border>
          <!-- Installierte Programme -->
          <Grid x:Name="ProgViewInstalled" Grid.Row="1">
            <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
            <StackPanel>
              <Expander Header="Erklärung für Einsteiger">
                <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Normale Deinstallationen lassen oft Ordner und Registry-Einträge zurück. So gehst du vor: 1. Programm in der Liste anklicken. 2. »Jetzt deinstallieren« klicken und dem Fenster des Programms folgen. 3. Unten erscheinen die gefundenen Reste. 4. Liste prüfen und »Ausgewählte Reste löschen« klicken. »Erzwungen entfernen« ist nur für Programme gedacht, deren Deinstallation nicht funktioniert."/>
                </Border>
              </Expander>
              <DockPanel Margin="0,12,0,0">
                <WrapPanel DockPanel.Dock="Right">
                  <Button x:Name="BtnUninstall" Style="{StaticResource Primary}" Content="JETZT DEINSTALLIEREN" ToolTip="Startet das Deinstallationsprogramm des Herstellers und sucht danach nach Resten."/>
                  <Button x:Name="BtnForce" Content="Erzwungen entfernen" ToolTip="Für Programme, deren Deinstallationsprogramm fehlt oder nicht funktioniert"/>
                  <Button x:Name="BtnPrograms" Content="Liste aktualisieren"/>
                </WrapPanel>
                <TextBlock Style="{StaticResource Small}" Text="Suchen:" VerticalAlignment="Center" Margin="0,0,8,8"/>
                <TextBox x:Name="TxtSearch" Width="220" Margin="0,0,0,8"/>
                <CheckBox x:Name="ChkStore" Content="Store-Apps anzeigen" VerticalAlignment="Center" Margin="16,0,0,8"/>
                <TextBlock x:Name="ProgramCount" Style="{StaticResource Small}" VerticalAlignment="Center" Margin="16,0,0,8"/>
              </DockPanel>
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Padding="16,10" Margin="0,4,0,0">
                <DockPanel>
                  <ContentControl x:Name="ProgramSelectedIcon" DockPanel.Dock="Left" Margin="0,0,12,0" VerticalAlignment="Center"/>
                  <TextBlock x:Name="ProgramSelected" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" Text="Klick ein Programm in der Liste an."/>
                </DockPanel>
              </Border>
            </StackPanel>
            <DataGrid x:Name="GridPrograms" Grid.Row="1" IsReadOnly="True" Margin="0,8,0,0">
              <DataGrid.Columns>
                <DataGridTextColumn Header="Programm" Binding="{Binding A}" Width="*"/>
                <DataGridTextColumn Header="Version" Binding="{Binding B}" Width="120"/>
                <DataGridTextColumn Header="Hersteller" Binding="{Binding C}" Width="200"/>
                <DataGridTextColumn Header="Installiert" Binding="{Binding D}" Width="110"/>
                <DataGridTextColumn Header="Größe" Binding="{Binding E}" Width="100" SortMemberPath="N1"/>
                <DataGridTextColumn Header="Typ" Binding="{Binding F}" Width="90"/>
              </DataGrid.Columns>
            </DataGrid>
          </Grid>
          <!-- Reste alter Programme -->
          <StackPanel x:Name="ProgViewOrphans" Grid.Row="1" Visibility="Collapsed">
            <Expander Header="Erklärung für Einsteiger">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Auch nach einer Deinstallation bleiben oft Ordner, Registry-Einträge, Verknüpfungen oder Dienste zurück. Diese Suche findet solche Reste auf allen Laufwerken – aber nur mit Beleg, nie nach ähnlichen Namen: Einträge, deren Programm nicht mehr existiert, Spieleordner, die Steam, Epic oder GOG nicht mehr kennen, Reste früherer Deinstallationen mit TuneRig und Datenordner, die nur noch auf entfernte Programme verweisen. Die Spalte »Beleg« zeigt jeweils, woher TuneRig das weiß."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,12,0,12" TextWrapping="Wrap" Text="Die Suche ändert nichts und dauert einige Minuten. Mögliche Spielstände und eigene Dateien werden nie vorausgewählt."/>
            <WrapPanel>
              <Button x:Name="BtnRestScan" Style="{StaticResource Primary}" Content="RESTE SUCHEN"/>
            </WrapPanel>
          </StackPanel>
          <!-- Gemeinsame Reste-Liste -->
          <StackPanel x:Name="LoPanel" Grid.Row="2" Margin="0,16,0,8">
            <TextBlock x:Name="LeftoverHeading" Style="{StaticResource H3}" Text="Gefundene Reste"/>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnLoDelete" Content="Ausgewählte Reste löschen"/>
              <Button x:Name="BtnLoOpen" Content="Speicherort öffnen" ToolTip="Öffnet den markierten Eintrag im Explorer bzw. im Registrierungs-Editor (auch per Doppelklick)."/>
              <Button x:Name="BtnLoAll" Content="Alle auswählen"/>
              <Button x:Name="BtnLoNone" Content="Keine auswählen"/>
              <Button x:Name="BtnLoRescan" Content="Erneut nach Resten suchen" ToolTip="Sucht noch einmal nach Resten des zuletzt deinstallierten Programms – z. B. wenn das Deinstallationsprogramm länger gebraucht hat."/>
            </WrapPanel>
            <TextBlock Style="{StaticResource Small}" Text="Angezeigt wird nur, was TuneRig nachweislich zuordnen kann – nie nach ähnlichen Namen. Die Spalte »Beleg« zeigt, woher TuneRig das weiß." TextWrapping="Wrap" Margin="0,4,0,0"/>
          </StackPanel>
          <DataGrid x:Name="GridLeftovers" Grid.Row="3">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Typ" Binding="{Binding B}" Width="170" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Pfad" Binding="{Binding C}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Beleg" Binding="{Binding D}" Width="320" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Größe" Binding="{Binding E}" Width="90" IsReadOnly="True" SortMemberPath="N1"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <!-- ===================== OVERDRIVE ===================== -->
      <TabItem Header="Overdrive">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Overdrive: Tuning über die sicheren Empfehlungen hinaus"/>
            <Border Style="{StaticResource Card}" Margin="0,12,0,8">
              <DockPanel>
                <ContentControl x:Name="OdWarnIcon" DockPanel.Dock="Left" Margin="0,0,12,0" VerticalAlignment="Top"/>
                <StackPanel>
                  <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource Warning}" Tag="caps" Text="Auf eigenes Risiko"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Margin="0,4,0,0" TextWrapping="Wrap" Text="Overdrive hebt Grenzen auf, die Windows für Stromverbrauch, Temperatur und Sicherheit setzt. Stufe 1 ist sanft, Stufe 3 schaltet auch Schutzfunktionen ab. Spannungen und BIOS-Takte ändert TuneRig nie. Jeder ursprüngliche Wert wird gesichert, »Zurücksetzen« stellt ihn wieder her. Geführt geht es mit Overdrive auf der Startseite."/>
                  <CheckBox x:Name="ChkOdAccept" Margin="0,12,0,0" Content="Ich kenne die Risiken und übernehme die Verantwortung."/>
                </StackPanel>
              </DockPanel>
            </Border>
            <WrapPanel>
              <Button x:Name="BtnOdApply" Style="{StaticResource Primary}" Content="JETZT ANWENDEN" IsEnabled="False"/>
              <Button x:Name="BtnOdRevert" Content="Ausgewählte zurücksetzen"/>
              <TextBlock Style="{StaticResource Small}" Text="Auswählen bis Stufe:" VerticalAlignment="Center" Margin="12,0,8,8"/>
              <Button x:Name="BtnOdLvl1" Content="1 · Sanft"/>
              <Button x:Name="BtnOdLvl2" Content="2 · Spürbar"/>
              <Button x:Name="BtnOdLvl3" Content="3 · Maximal"/>
              <Button x:Name="BtnOdCheck" Content="Neu prüfen"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridOverdrive" Grid.Row="1" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Stufe" Binding="{Binding A}" Width="100" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Einstellung" Binding="{Binding B}" Width="220" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Status" Binding="{Binding C}" Width="140" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Aktuell" Binding="{Binding D}" Width="200" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Wirkung / Risiko" Binding="{Binding F}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>
    </TabControl>
      </Grid>
    </Grid>
  </DockPanel>
</Window>
'@

$window = [Windows.Markup.XamlReader]::Parse($xaml)
Set-SplashProgress 0.3 'Lade Oberfläche …'
# Fenster an kleine Bildschirme anpassen (z. B. Laptops mit 1366 x 768)
$wa = [Windows.SystemParameters]::WorkArea
$window.Width = [Math]::Min(1240, $wa.Width * 0.95); $window.Height = [Math]::Min(820, $wa.Height * 0.95)
$window.MinWidth = [Math]::Min(1120, $wa.Width * 0.95); $window.MinHeight = [Math]::Min(600, $wa.Height * 0.95)
$ui = @{}
foreach ($n in [regex]::Matches($xaml, 'x:Name="(\w+)"') | ForEach-Object { $_.Groups[1].Value }) { $ui[$n] = $window.FindName($n) }
Set-WindowBranding $window
Set-CapsLabels $window
$ui.SafetyIcon.Content = New-LineIcon 'shield' 'success' 24
# Startseite: Symbole der drei Checks und Leistungsgewinn als Segmentanzeige
# Jeder Check hat eine eigene Kennfarbe: Regulär neutral, Boost Signal-Orange, Overdrive Warnfarbe (Risiko)
$ui.CardGuidedIcon.Content = New-LineIcon 'check' 'ink' 22
$ui.CardBoostIcon.Content = New-LineIcon 'flame' 'accent' 24
$ui.NavBoostIcon.Content = New-LineIcon 'flame' 'accent' 14
$ui.NavGuidedIcon.Content = New-LineIcon 'check' 'ink' 14
# Buttons der Karten: Text mit Pfeil (führt zum Check)
foreach ($b in @(@($ui.BtnStartGuided, 'Regulären Check starten'), @($ui.BtnStartGaming, 'Performance Boost starten'), @($ui.BtnStartOverdrive, 'Overdrive öffnen'), @($ui.BtnStartExpert, 'Alle Werkzeuge öffnen'))) {
    $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'
    $t = New-Object Windows.Controls.TextBlock; $t.Text = $b[1]; $t.VerticalAlignment = 'Center'; [void]$sp.Children.Add($t)
    $a = New-LineIcon 'arrow' 'ink' 16; $a.Margin = New-Object Windows.Thickness(10, 0, 0, 0); $a.VerticalAlignment = 'Center'; [void]$sp.Children.Add($a)
    $b[0].Content = $sp
    [Windows.Automation.AutomationProperties]::SetName($b[0], $b[1])
}
$ui.NavOverdriveIcon.Content = New-LineIcon 'bolt' 'warning' 14
$ui.CardOverdriveIcon.Content = New-LineIcon 'bolt' 'warning' 22
$ui.CardExpertIcon.Content = New-LineIcon 'grid' 'ink-muted' 24
$ui.GainGuided.Content = New-SegmentMeter 1 3 'ink'
$ui.GainBoost.Content = New-SegmentMeter 2 3 'accent'
$ui.GainOverdrive.Content = New-SegmentMeter 3 3 'warning'
$ui.DriverWarnIcon.Content = New-LineIcon 'warning' 'warning' 24
$ui.BtnTheme.Content = if ($script:ThemeMode -eq 'dark') { 'Hell' } else { 'Dunkel' }
$ui.BtnTheme.Add_Click({
    Set-ThemeMode $(if ($script:ThemeMode -eq 'dark') { 'light' } else { 'dark' })
    Update-TitleBar $window
    $ui.BtnTheme.Content = if ($script:ThemeMode -eq 'dark') { 'Hell' } else { 'Dunkel' }
    Save-AppSettings $(if ($script:State.Page -ne 'welcome') { $script:State.Page } else { (Get-AppSettings).LastMode })
})

# ============================================================================
#  Zustand und Hilfsfunktionen der Oberfläche
# ============================================================================
$script:Sync = [hashtable]::Synchronized(@{ Status = '' })
$script:Job = $null
$script:State = @{ TweakBefore = @{}; IsLaptop = (Test-IsLaptop); LastRestore = $null; Programs = @(); Current = $null; Then = $null; Pending = $null; GpuCount = 0; Page = 'welcome'; LoadId = ''; Previous = '' }

function Set-Status([string]$t) { $script:Sync.Status = $t; $ui.StatusText.Text = $t }
function Show-Info([string]$t, [string]$title = 'TuneRig') { [void][Windows.MessageBox]::Show($window, $t, $title, 'OK', 'Information') }
function Show-Error([string]$t) { [void][Windows.MessageBox]::Show($window, $t, 'Fehler', 'OK', 'Error') }
function Confirm-Action([string]$t, [string]$title = 'Bitte bestätigen') { [Windows.MessageBox]::Show($window, $t, $title, 'YesNo', 'Question') -eq 'Yes' }

function New-Row {
    param($A = '', $B = '', $C = '', $D = '', $E = '', $F = '', [int]$Level = 0, [bool]$Selected = $false, $Tag = $null, [long]$N1 = 0)
    $r = New-Object PCO.Row
    $r.A = [string]$A; $r.B = [string]$B; $r.C = [string]$C; $r.D = [string]$D; $r.E = [string]$E; $r.F = [string]$F
    $r.Level = $Level; $r.IsSelected = $Selected; $r.Tag = $Tag; $r.N1 = $N1
    return $r
}

function Set-Items($grid, $rows) {
    $c = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
    foreach ($r in @($rows)) { if ($null -ne $r) { $c.Add($r) } }
    $grid.ItemsSource = $c
}

function Get-Rows($grid) { if ($grid.ItemsSource) { @($grid.ItemsSource) } else { @() } }

function Get-LevelText([int]$l) { switch ($l) { 0 { 'OK' } 1 { 'Hinweis' } 2 { 'Empfehlung' } default { 'Problem' } } }

function ConvertTo-FindingRows($findings) {
    @($findings) | Where-Object { $_ } | Sort-Object @{ e = { $_.Level }; Descending = $true }, Category |
        ForEach-Object { New-Row -A (Get-LevelText $_.Level) -B $_.Category -C $_.Title -D $_.Detail -E $(if ($_.Do) { $_.Do + $(if ($_.Benefit) { '  →  ' + $_.Benefit } else { '' }) } else { $_.Help }) -Level $_.Level }
}

function Set-Busy([bool]$busy, [bool]$cancellable = $false) {
    $ui.Tabs.IsEnabled = -not $busy
    foreach ($n in 'WizNav', 'WizSidebar', 'WizContent', 'HeaderNav', 'WelcomePage') { $ui[$n].IsEnabled = -not $busy }
    $ui.WizBusy.Visibility = if ($busy -and $script:State.Page -eq 'wizard') { 'Visible' } else { 'Collapsed' }
    $ui.WizBusyText.Text = $script:Sync.Status
    $ui.BusyBar.Visibility = if ($busy) { 'Visible' } else { 'Collapsed' }
    $ui.BtnCancel.Visibility = if ($busy -and $cancellable) { 'Visible' } else { 'Collapsed' }
}

# Führt Kernfunktionen in einem Hintergrund-Thread aus, damit das Fenster bedienbar bleibt.
# Im Skript stehen alle Funktionen aus Core.ps1 und die Argumente als $A[0], $A[1] ... bereit.
function Start-Work {
    param([string]$Status, [scriptblock]$Script, [object[]]$Arguments = @(), [scriptblock]$OnDone, [scriptblock]$OnCancel, [switch]$Cancellable)
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $rs = [runspacefactory]::CreateRunspace()
    $rs.ApartmentState = 'STA'; $rs.ThreadOptions = 'ReuseThread'; $rs.Open()
    $rs.SessionStateProxy.SetVariable('Sync', $script:Sync)
    $rs.SessionStateProxy.SetVariable('A', $Arguments)
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript($script:CoreText + "`r`n" + $Script.ToString())
    Set-Status $Status
    $script:Job = @{ PS = $ps; Handle = $ps.BeginInvoke(); OnDone = $OnDone; OnCancel = $OnCancel; Cancelled = $false }
    Set-Busy $true $Cancellable.IsPresent
}

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(250)
$timer.Add_Tick({
    if ($ui.StatusText.Text -ne $script:Sync.Status) { $ui.StatusText.Text = $script:Sync.Status; $ui.WizBusyText.Text = $script:Sync.Status }
    $j = $script:Job
    if (-not $j -or -not $j.Handle.IsCompleted) { return }

    $result = $null; $err = $null
    try { $result = $j.PS.EndInvoke($j.Handle) }
    catch { if (-not $j.Cancelled) { $err = if ($_.Exception.InnerException) { $_.Exception.InnerException.Message } else { $_.Exception.Message } } }
    try { $j.PS.Runspace.Close(); $j.PS.Dispose() } catch {}
    $script:Job = $null
    Set-Busy $false

    if ($j.Cancelled) {
        if ($j.OnCancel) { & $j.OnCancel } else { Set-Status 'Abgebrochen.' }
        return
    }
    if ($err) { Set-Status "Fehler: $err"; Show-Error $err; return }
    if ($j.OnDone) {
        try { & $j.OnDone @($result) }
        catch { Set-Status ('Fehler: ' + $_.Exception.Message); Show-Error ($_.Exception.Message + "`n`n" + $_.ScriptStackTrace) }
    }
})
$timer.Start()

$ui.BtnCancel.Add_Click({
    if ($script:Job) { $script:Job.Cancelled = $true; [TuneRig.DiskScan]::Cancel = $true; [void]$script:Job.PS.BeginStop($null, $null); Set-Status 'Breche ab ...' }
})

# Wiederherstellungspunkt vor Änderungen; scheitert er, wird gefragt, ob trotzdem fortgefahren wird.
function Invoke-WithRestorePoint([string]$Description, [scriptblock]$Then) {
    $script:State.Then = $Then
    $script:State.Backup = $true
    if ($script:State.LastRestore -and ((Get-Date) - $script:State.LastRestore).TotalMinutes -lt 30) { & $Then; return }
    # Sicherung anlegen? (Einstellung unter »Sicherungen verwalten«: fragen / immer / nie)
    $mode = Get-BackupMode
    if ($mode -eq 'ask') { $mode = Show-BackupChoice $Description; if (-not $mode) { Set-Status 'Abgebrochen.'; return } }
    if ($mode -eq 'never') {
        $script:State.Backup = $false
        Add-WizLog 'Ohne Sicherung fortgefahren'
        & $Then; return
    }
    Start-Work -Status 'Erstelle Wiederherstellungspunkt ... (kann bis zu einer Minute dauern)' -Arguments @($Description) -Script { New-PCORestorePoint $A[0] } -OnDone {
        param($r)
        $res = @($r)[-1]
        if ($res.Ok) {
            $script:State.LastRestore = Get-Date
            Add-WizLog 'Wiederherstellungspunkt erstellt'
            Add-WizChange 'Windows-Sicherung' 'Wiederherstellungspunkt erstellt' 'Alle Änderungen lassen sich rückgängig machen.' -1
            Set-Status $res.Message
            & $script:State.Then
        } elseif (Confirm-Action ($res.Message + "`n`nTrotzdem ohne Wiederherstellungspunkt fortfahren?") 'Wiederherstellungspunkt') {
            & $script:State.Then
        } else { Set-Status 'Abgebrochen.' }
    }
}

function Open-Target([string]$t) { try { Start-Process $t } catch { Show-Error $_.Exception.Message } }

# ============================================================================
#  Anzeige-Funktionen
# ============================================================================
function Show-Summary($summary) {
    $p = $ui.SummaryPanel; $p.Children.Clear()
    [void]$p.Children.Add((New-Label 'Dein System'))
    foreach ($s in @($summary)) {
        $l = New-Label $s.Label; $l.Margin = New-Object Windows.Thickness(0, 16, 0, 4); [void]$p.Children.Add($l)
        $v = New-Object Windows.Controls.TextBlock; $v.Text = $(if ($s.Value) { [string]$s.Value } else { '-' }); $v.TextWrapping = [Windows.TextWrapping]::Wrap
        Set-TypeRole $v 'small'; Set-ThemeRef $v Foreground 'ink'
        [void]$p.Children.Add($v)
    }
}

function Show-Drivers($drivers) {
    Set-Items $ui.GridDrivers (@($drivers) | ForEach-Object { New-Row -A $_.Status -B $_.Device -C $_.Category -D $_.Provider -E $_.Version -F $_.Date -Level $_.Level })
}

function Show-Gpu($gpu) {
    $script:State.GpuCount = @($gpu.Gpus).Count
    Set-Items $ui.GridGpus (@($gpu.Gpus) | ForEach-Object {
        New-Row -A $_.Name -B $(if ($_.Discrete) { 'Dediziert (leistungsstark)' } else { 'Integriert (stromsparend)' }) -C $(if ($_.Vram -gt 0) { Format-Bytes $_.Vram } else { '-' }) `
                -D $_.Driver -E $_.DriverDate -F $(if ($_.Display) { "Ja ($($_.Resolution))" } else { 'Nein' })
    })
    Set-Items $ui.GridGpuFindings (ConvertTo-FindingRows $gpu.Findings)
    $warn = @($gpu.Findings | Where-Object { $_.Level -ge 2 }).Count
    $ui.GpuExpander.Header = "Erkannte Grafikkarten ($(@($gpu.Gpus).Count))" + $(if ($warn) { " · $warn Befund(e) – aufklappen" } else { ' · alles in Ordnung' })
    if ($warn) { $ui.GpuExpander.IsExpanded = $true }
}

# Merkt sich beim ersten Prüfen den ursprünglichen Zustand jeder Einstellung (für "vorher / jetzt")
function Register-TweakBefore($tweaks) {
    foreach ($t in @($tweaks)) { if ($t -and -not $script:State.TweakBefore.ContainsKey($t.Id)) { $script:State.TweakBefore[$t.Id] = $t.State } }
}
function Get-TweakBefore($t) {
    $b = $script:State.TweakBefore[$t.Id]
    if ($b -and $b -ne $t.State) { return $b } else { return $null }
}

function Show-Plans($plans) {
    $planRows = @($plans) | ForEach-Object { New-Row -A $(if ($_.Active) { "$($_.Name) (aktiv)" } else { $_.Name }) -Tag $_.Guid -Selected $_.Active }
    $ui.ComboPlans.ItemsSource = @($planRows)
    $ui.ComboPlans.SelectedItem = @($planRows) | Where-Object { $_.IsSelected } | Select-Object -First 1
}

function Show-Games($games) {
    Set-Items $ui.GridGames (@($games) | ForEach-Object {
        $high = $_.Preference -eq 'Hohe Leistung'
        New-Row -A $_.Name -B $_.Source -C $_.Preference -D $_.Exe -Level $(if ($high) { 0 } else { 2 }) -Selected (-not $high) -Tag $_.Exe
    })
    Update-ListCount $ui.GridGames $ui.GamesCount 'Spiel' 'Spiele'
}

# Zeigt neben einer Liste, wie viele Einträge sie hat - und dass man scrollen kann, wenn nicht alle zu sehen sind
function Update-ListCount($Grid, $Label, [string]$One, [string]$Many) {
    if (-not $Grid -or -not $Label) { return }
    $n = @(Get-Rows $Grid).Count
    $txt = if ($n -eq 1) { "1 $One" } else { "$n $Many" }
    # Passt nicht alles hinein? Dann ausdrücklich auf das Scrollen hinweisen
    try {
        if ($n -gt 0 -and $Grid.IsVisible) {
            $Grid.UpdateLayout()
            $sv = Get-GridScroller $Grid
            if ($sv -and $sv.ScrollableHeight -gt 0) { $txt += ' · weitere unten, bitte scrollen' }
        }
    } catch {}
    $Label.Text = $txt
}
function Get-GridScroller($Grid) {
    if (-not $Grid) { return $null }
    $q = New-Object System.Collections.Queue; $q.Enqueue($Grid)
    while ($q.Count) {
        $d = $q.Dequeue()
        if (-not ($d -is [Windows.Media.Visual])) { continue }
        if ($d -is [Windows.Controls.ScrollViewer]) { return $d }
        for ($i = 0; $i -lt [Windows.Media.VisualTreeHelper]::GetChildrenCount($d); $i++) { $q.Enqueue([Windows.Media.VisualTreeHelper]::GetChild($d, $i)) }
    }
    return $null
}

# ============================================================================
#  Übersicht
# ============================================================================
$ui.BtnAnalyze.Add_Click({
    Start-Work -Status 'Analysiere System ...' -Script {
        Report 'Lese Hardware-Informationen ...'; $sys = Get-SystemAnalysis
        Report 'Prüfe Treiber ... (dauert etwas)'; $drv = Get-DriverAnalysis
        Report 'Prüfe Grafikkarten ...'; $gpu = Get-GpuAnalysis $sys.IsLaptop
        Report 'Prüfe Energie- und Windows-Einstellungen ...'; $tw = @(Get-Tweaks $sys.IsLaptop)
        Report 'Suche Spiele ...'; $games = @(Find-Games)
        [pscustomobject]@{ Sys = $sys; Drv = $drv; Gpu = $gpu; Tweaks = $tw; Games = $games; Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r)
        $r = @($r)[-1]
        $script:State.IsLaptop = $r.Sys.IsLaptop
        Show-Summary $r.Sys.Summary
        Show-Drivers $r.Drv.Drivers
        Show-Gpu $r.Gpu
        Show-Plans $r.Plans
        Show-Games $r.Games

        $all = @()
        $all += @($r.Sys.Findings); $all += @($r.Drv.Findings); $all += @($r.Gpu.Findings)
        foreach ($t in @($r.Tweaks | Where-Object { -not $_.Optional })) {
            $all += New-Finding $(if ($t.Optimal) { 0 } else { 2 }) 'Einstellungen' $t.Name $(if ($t.Optimal) { $t.State } else { "Aktuell: $($t.State). $($t.Desc)" })
        }
        $notHigh = @($r.Games | Where-Object { $_.Preference -ne 'Hohe Leistung' }).Count
        if (@($r.Gpu.Gpus | Where-Object { $_.Discrete }).Count -ge 1 -and @($r.Gpu.Gpus).Count -gt 1 -and $notHigh -gt 0) {
            $all += New-Finding 2 'Grafik' "$notHigh Spiel(e) nicht auf 'Hohe Leistung' eingestellt" 'Diese Spiele könnten auf der schwächeren, integrierten Grafik laufen. Unter Leistung › Verwendete Grafikkarte mit einem Klick ändern.'
        }
        Set-Items $ui.GridFindings (ConvertTo-FindingRows $all)

        $p = @($all | Where-Object { $_.Level -eq 3 }).Count; $w = @($all | Where-Object { $_.Level -eq 2 }).Count
        if ($p + $w -eq 0) { Set-Status 'Analyse abgeschlossen – dein System ist gut eingestellt.' }
        else { Set-Status "Analyse abgeschlossen: $p Problem(e), $w Empfehlung(en). Details in den einzelnen Reitern." }
    }
})

$ui.BtnBackups.Add_Click({ Show-RestorePointManager })

# ============================================================================
#  Treiber
# ============================================================================
$ui.BtnDrivers.Add_Click({
    Start-Work -Status 'Prüfe Treiber ...' -Script { Get-DriverAnalysis } -OnDone {
        param($r) $r = @($r)[-1]
        Show-Drivers $r.Drivers
        $n = @($r.Findings | Where-Object { $_.Level -ge 2 }).Count
        Set-Status $(if ($n -eq 0) { 'Keine Treiberprobleme gefunden.' } else { "$n Treiberproblem(e) gefunden." })
    }
})
$ui.BtnDevMgr.Add_Click({ Open-Target 'devmgmt.msc' })
# Hersteller-Buttons nur für eingebaute Grafikkarten zeigen (alle, falls nichts erkannt wurde)
$gpuNames = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ' '
if ($gpuNames -match 'NVIDIA|AMD|Radeon|Intel') {
    if ($gpuNames -notmatch 'NVIDIA') { $ui.BtnNvidia.Visibility = 'Collapsed' }
    if ($gpuNames -notmatch 'AMD|Radeon') { $ui.BtnAmd.Visibility = 'Collapsed' }
    if ($gpuNames -notmatch 'Intel') { $ui.BtnIntel.Visibility = 'Collapsed' }
}
$ui.BtnNvidia.Add_Click({ Open-Target 'https://www.nvidia.com/de-de/software/nvidia-app/' })
$ui.BtnAmd.Add_Click({ Open-Target 'https://www.amd.com/de/support/download/drivers.html' })
$ui.BtnIntel.Add_Click({ Open-Target 'https://www.intel.de/content/www/de/de/support/detect.html' })

$ui.BtnSearchUpdates.Add_Click({
    Start-Work -Status 'Suche bei Windows Update nach Treibern ... (1-3 Minuten)' -Script { Search-DriverUpdates } -OnDone {
        param($r)
        $list = @($r | Where-Object { $_ })
        Set-Items $ui.GridUpdates ($list | ForEach-Object { New-Row -A $_.Title -B $_.Manufacturer -C $_.Class -D $_.Date -Selected $true -Tag $_.Id })
        Set-Status $(if ($list.Count -eq 0) { 'Windows Update bietet keine neueren Treiber an.' } else { "$($list.Count) Treiber-Update(s) verfügbar." })
    }
})

$ui.BtnInstallUpdates.Add_Click({
    $sel = @(Get-Rows $ui.GridUpdates | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte zuerst nach Updates suchen und welche auswählen.'; return }
    if (-not (Confirm-Action "$($sel.Count) Treiber werden über Windows Update installiert.`n`nVorher wird ein Wiederherstellungspunkt erstellt. Während der Installation kann der Bildschirm kurz flackern.`n`nFortfahren?")) { return }
    $script:State.Pending = @($sel | ForEach-Object { [string]$_.Tag })
    Invoke-WithRestorePoint 'Treiber-Updates' {
        Start-Work -Status 'Installiere Treiber ...' -Arguments @(, $script:State.Pending) -Script { Install-DriverUpdates $A[0] } -OnDone {
            param($r) $msg = [string](@($r)[-1])
            Set-Status $msg; Show-Info $msg 'Treiber-Updates'
            Set-Items $ui.GridUpdates @()
        }
    }
})

# ============================================================================
#  Leistung › Einstellungen: Grund-, Gaming- und Netzwerk-Einstellungen in einer Liste
# ============================================================================
$script:SetGroupName = @{ power = 'Energie'; gaming = 'Spiele & Grafik'; display = 'Bild & Steuerung'; system = 'Prozessor & System'; network = 'Internet' }
$script:SetGroupOrder = @{ power = 0; gaming = 1; display = 2; system = 3; network = 4 }
$script:State.Settings = @()

function Show-SettingsGrid {
    $all = @($script:State.Settings)
    Register-TweakBefore $all
    $f = if ($ui.RbSetOpen.IsChecked) { 'open' } elseif ($ui.RbSetRec.IsChecked) { 'rec' } elseif ($ui.RbSetOpt.IsChecked) { 'opt' } else { 'all' }
    $list = @($all | Where-Object {
        switch ($f) { 'open' { -not $_.Optimal } 'rec' { $_.Mode -eq 'recommended' } 'opt' { $_.Mode -ne 'recommended' } default { $true } } })
    Set-Items $ui.GridSettings (@($list) | Sort-Object @{ e = { $script:SetGroupOrder[$_.Group] } }, @{ e = { @{ recommended = 0; optional = 1; experimental = 2 }[$_.Mode] } } | ForEach-Object {
        $status = if ($_.Optimal) { 'Aktiv' } elseif ($_.Mode -eq 'recommended') { 'Empfohlen' } elseif ($_.Mode -eq 'optional') { 'Optional' } else { 'Experimentell' }
        $lvl = if ($_.Optimal) { 0 } elseif ($_.Mode -eq 'recommended') { 2 } else { 1 }
        $before = Get-TweakBefore $_
        $now = if ($before) { "$($_.State)`n(vorher: $before)" } else { $_.State }
        $eff = "Wirkung: $($script:ImpactText[[int]$_.Impact]) - $($_.Benefit)" + $(if ($_.Risk) { "`nNebenwirkung: $($_.Risk)" } else { '' })
        New-Row -A $script:SetGroupName[$_.Group] -B $_.Title -C $status -D $now -E $_.Target -F $eff -Level $lvl -Selected (-not $_.Optimal -and $_.Mode -eq 'recommended') -Tag $_
    })
    $open = @($all | Where-Object { -not $_.Optimal -and $_.Mode -eq 'recommended' }).Count
    return $open
}
foreach ($rb in @($ui.RbSetAll, $ui.RbSetOpen, $ui.RbSetRec, $ui.RbSetOpt)) { $rb.Add_Checked({ if (@($script:State.Settings).Count) { [void](Show-SettingsGrid) } }) }

$script:LoadSettings = {
    Start-Work -Status 'Prüfe alle Leistungs-Einstellungen ... (bis zu einer Minute)' -Script {
        $l = Test-IsLaptop
        [pscustomobject]@{ Settings = @(Get-AllSettings $l); Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $script:State.Settings = @($r.Settings | Where-Object { $_ })
        Show-Plans $r.Plans
        $open = Show-SettingsGrid
        Set-Status ("{0} Einstellungen geprüft, {1} empfohlene noch offen." -f @($script:State.Settings).Count, $open)
    }
}
$ui.BtnSetCheck.Add_Click({ & $script:LoadSettings })

function Invoke-SettingsFromGrid([bool]$Revert) {
    $sel = @(Get-Rows $ui.GridSettings | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Hake zuerst die gewünschten Zeilen an.'; return }
    if ($Revert) {
        $sel = @($sel | Where-Object { $_.Tag.CanRevert })
        if ($sel.Count -eq 0) { Show-Info 'Die ausgewählten Einstellungen lassen sich nicht zurücksetzen – sie entsprechen bereits dem Windows-Standard.'; return }
    }
    $risky = @($sel | Where-Object { -not $Revert -and $_.Tag.Risk })
    $unknown = @($sel | Where-Object { $Revert -and -not $_.Tag.ByTuneRig })
    $list = ($sel | ForEach-Object { '- ' + $_.B }) -join "`n"
    $warn = if ($risky.Count) { "`n`nNebenwirkungen:`n" + (($risky | ForEach-Object { '- ' + $_.B + ': ' + $_.Tag.Risk }) -join "`n") } else { '' }
    if ($unknown.Count) { $warn += "`n`nFür diese Einstellungen kennt TuneRig deinen früheren Wert nicht (vor Version 1.6.0 geändert oder nie von TuneRig geändert). Sie werden auf den Windows-Standard gesetzt – oder bleiben unverändert, wenn er nicht eindeutig ist:`n" + (($unknown | ForEach-Object { '- ' + $_.B }) -join "`n") }
    $head = if ($Revert) { 'Diese Einstellungen werden auf deinen früheren Wert zurückgesetzt:' } else { 'Diese Einstellungen werden geändert:' }
    if (-not (Confirm-Action "$head`n`n$list$warn`n`nFortfahren?")) { return }
    $script:State.Pending = @{ Ids = @($sel | ForEach-Object { $_.Tag.Id }); Revert = $Revert; Restart = [bool]($sel | Where-Object { $_.Tag.Restart }) }
    Invoke-WithRestorePoint $(if ($Revert) { 'Einstellungen zurücksetzen' } else { 'Leistungs-Einstellungen' }) {
        Start-Work -Status 'Ändere Einstellungen ...' -Arguments @(@($script:State.Pending.Ids), $script:State.Pending.Revert) -Script {
            $e = @(Invoke-AllSettings $A[0] -Revert:$A[1])
            [pscustomobject]@{ Errors = $e; Settings = @(Get-AllSettings (Test-IsLaptop)); Plans = @(Get-PowerPlans) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            $script:State.Settings = @($r.Settings | Where-Object { $_ })
            Show-Plans $r.Plans
            [void](Show-SettingsGrid)
            $errs = @($r.Errors | Where-Object { $_ })
            $msg = if ($errs.Count) { "Erledigt, mit Hinweisen:`n" + ($errs -join "`n") } else { 'Alle Einstellungen wurden übernommen.' }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen wirken erst nach einem Neustart." }
            Set-Status (($msg -split "`n")[0]); Show-Info $msg
        }
    }
}
$ui.BtnSetApply.Add_Click({ Invoke-SettingsFromGrid $false })
$ui.BtnSetRevert.Add_Click({ Invoke-SettingsFromGrid $true })

$ui.BtnSetPlan.Add_Click({
    $p = $ui.ComboPlans.SelectedItem
    if (-not $p) { & $script:LoadSettings; return }
    Start-Work -Status 'Aktiviere Energiesparplan ...' -Arguments @([string]$p.Tag) -Script {
        powercfg.exe /setactive $A[0] | Out-Null
        [pscustomobject]@{ Settings = @(Get-AllSettings (Test-IsLaptop)); Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $script:State.Settings = @($r.Settings | Where-Object { $_ })
        Show-Plans $r.Plans; [void](Show-SettingsGrid)
        Set-Status ('Aktiver Energiesparplan: ' + (@($r.Plans | Where-Object { $_.Active })[0].Name))
    }
})

# ============================================================================
#  Grafikkarten
# ============================================================================
$ui.BtnGpu.Add_Click({
    Start-Work -Status 'Prüfe Grafikkarten ...' -Script { Get-GpuAnalysis (Test-IsLaptop) } -OnDone {
        param($r) $r = @($r)[-1]; Show-Gpu $r; Set-Status "$(@($r.Gpus).Count) Grafikkarte(n) erkannt."
    }
})
$ui.BtnGfxSettings.Add_Click({ Open-Target 'ms-settings:display-advancedgraphics' })

$ui.GridGames.Add_SizeChanged({ try { if (@(Get-Rows $ui.GridGames).Count) { Update-ListCount $ui.GridGames $ui.GamesCount 'Spiel' 'Spiele' } } catch {} })
$ui.BtnGames.Add_Click({
    Start-Work -Status 'Suche installierte Spiele ...' -Script { @(Find-Games) } -OnDone {
        param($r)
        $g = @($r | Where-Object { $_ })
        Show-Games $g
        $msg = "$($g.Count) Spiel(e) gefunden."
        if ($script:State.GpuCount -eq 1) { $msg += ' Hinweis: Es ist nur eine Grafikkarte vorhanden - die Einstellung pro Spiel hat dann keine Wirkung.' }
        Set-Status $msg
    }
})

$ui.BtnAddGame.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = 'Spiel oder Programm auswählen'; $dlg.Filter = 'Programme (*.exe)|*.exe'; $dlg.Multiselect = $true
    if (-not $dlg.ShowDialog($window)) { return }
    $rows = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
    foreach ($r in @(Get-Rows $ui.GridGames)) { $rows.Add($r) }
    foreach ($file in $dlg.FileNames) {
        if ($rows | Where-Object { $_.Tag -ieq $file }) { continue }
        $name = (Get-Item -LiteralPath $file).VersionInfo.ProductName
        if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($file) }
        $pref = Get-GpuPreference $file
        $rows.Add((New-Row -A $name -B 'Manuell' -C $pref -D $file -Level $(if ($pref -eq 'Hohe Leistung') { 0 } else { 2 }) -Selected $true -Tag $file))
    }
    $ui.GridGames.ItemsSource = $rows
    Update-ListCount $ui.GridGames $ui.GamesCount 'Spiel' 'Spiele'
})

$ui.BtnHighPerf.Add_Click({
    $sel = @(Get-Rows $ui.GridGames | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens ein Spiel auswählen.'; return }
    if (-not (Confirm-Action "$($sel.Count) Programm(e) werden in Windows auf 'Hohe Leistung' (dedizierte Grafikkarte) eingestellt.`n`nDie Änderung kann jederzeit unter Einstellungen > System > Anzeige > Grafik zurückgenommen werden. Fortfahren?")) { return }
    $ok = 0
    foreach ($g in $sel) {
        try {
            Set-GpuHighPerformance $g.Tag
            $g.C = Get-GpuPreference $g.Tag
            $g.Level = 0; $g.IsSelected = $false; $ok++
        } catch { Set-Status "$($g.A): $($_.Exception.Message)" }
    }
    Set-Status "$ok Programm(e) nutzen jetzt die leistungsstarke Grafikkarte. Bereits laufende Spiele bitte neu starten."
})

# ============================================================================
#  Bereinigung
# ============================================================================
# Letzte Zeile: Junk-Dateien auf allen Laufwerken (Suche erst, wenn angehakt)
$script:State.Junk = $null      # $null = noch nicht gesucht, sonst Liste @{ Path; Size; Modified; Keep }
function New-JunkRow {
    $j = $script:State.Junk
    $b = if ($null -eq $j) { 'Noch nicht gesucht – anhaken und »Neu berechnen«' } else {
        $use = @($j | Where-Object { -not $_.Keep }); $sum = 0L; foreach ($x in $use) { $sum += [long]$x.Size }
        "{0} ({1} Dateien)" -f (Format-Bytes $sum), $use.Count }
    $n = if ($null -eq $j) { 0L } else { $t = 0L; foreach ($x in @($j | Where-Object { -not $_.Keep })) { $t += [long]$x.Size }; $t }
    New-Row -A 'Junk-Dateien auf allen Laufwerken' -B $b -C 'Typischer Datenmüll (*.tmp, *.chk, *.dmp, *._mp, Thumbs.db …), älter als 7 Tage. System- und Programmordner bleiben außen vor. Die Suche dauert einige Minuten. Gelöschtes landet im Papierkorb.' -N1 $n -Selected $false -Tag 'junk'
}
Set-Items $ui.GridClean (@(Get-CleanupDefs | ForEach-Object { New-Row -A $_.Name -B '-' -C $_.Desc -Selected $_.Sel -Tag $_.Id }) + @(New-JunkRow))

function Update-CleanTotal {
    $sum = (@(Get-Rows $ui.GridClean | Where-Object { $_.IsSelected }) | Measure-Object -Property N1 -Sum).Sum
    $ui.CleanTotal.Text = 'Ausgewählt: ' + (Format-Bytes ([double]$sum))
}
function Update-JunkRow {
    $row = Get-Rows $ui.GridClean | Where-Object { $_.Tag -eq 'junk' } | Select-Object -First 1
    if (-not $row) { return }
    $n = New-JunkRow
    $row.B = $n.B; $row.N1 = $n.N1
    Update-CleanTotal
}

function Apply-Measures($measures) {
    foreach ($m in @($measures)) {
        $row = Get-Rows $ui.GridClean | Where-Object { $_.Tag -eq $m.Id } | Select-Object -First 1
        if ($row) {
            $row.N1 = [long]$m.Size
            $row.B = if ($m.Id -eq 'winsxs') { 'erst nach Bereinigung messbar' } else { "{0} ({1} Dateien)" -f (Format-Bytes $m.Size), $m.Count }
        }
    }
    Update-CleanTotal
}

# Berechnet die Größen; ist »Junk-Dateien« angehakt, wird auch danach gesucht. $Then läuft danach (z. B. Aufräumen)
function Start-CleanMeasure([scriptblock]$Then) {
    $script:State.CleanThen = $Then
    $ids = @(Get-Rows $ui.GridClean | Where-Object { $_.Tag -ne 'junk' } | ForEach-Object { $_.Tag })
    $junk = [bool](Get-Rows $ui.GridClean | Where-Object { $_.Tag -eq 'junk' -and $_.IsSelected })
    Start-Work -Cancellable -Status $(if ($junk) { 'Berechne Platz und suche Junk-Dateien auf allen Laufwerken ... (einige Minuten)' } else { 'Berechne, wie viel Platz frei werden kann ...' }) -Arguments @(, $ids) -Script {
        $m = foreach ($id in $A[0]) { Report "Analysiere: $id ..."; Measure-Cleanup $id }
        [pscustomobject]@{ Measures = @($m); Junk = $null }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Apply-Measures $r.Measures
        $needJunk = [bool](Get-Rows $ui.GridClean | Where-Object { $_.Tag -eq 'junk' -and $_.IsSelected })
        if ($needJunk) { Start-JunkSearch $script:State.CleanThen }
        else { Set-Status 'Berechnung abgeschlossen.'; if ($script:State.CleanThen) { & $script:State.CleanThen } }
    }
}
function Start-JunkSearch([scriptblock]$Then) {
    $script:State.JunkThen = $Then
    Start-Work -Cancellable -Status 'Suche Junk-Dateien auf allen Laufwerken ... (einige Minuten, abbrechbar)' -Script { @(Find-JunkFiles) } -OnDone {
        param($r)
        $script:State.Junk = @($r | Where-Object { $_ } | ForEach-Object { [pscustomobject]@{ Path = $_.Path; Size = [long]$_.Size; Modified = $_.Modified; Keep = $false } })
        Update-JunkRow
        Set-Status "$(@($script:State.Junk).Count) Junk-Dateien gefunden."
        if ($script:State.JunkThen) { & $script:State.JunkThen }
    }
}
$ui.BtnCleanScan.Add_Click({ Start-CleanMeasure $null })
$ui.GridClean.Add_CurrentCellChanged({ Update-CleanTotal })

$ui.BtnCleanRun.Add_Click({
    $sel = @(Get-Rows $ui.GridClean | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens einen Bereich auswählen.'; return }
    # Junk angehakt, aber noch nicht gesucht: erst suchen, dann weiter
    if (($sel | Where-Object { $_.Tag -eq 'junk' }) -and $null -eq $script:State.Junk) {
        if (-not (Confirm-Action "Für »Junk-Dateien« durchsucht TuneRig zuerst alle Laufwerke (einige Minuten). Danach fragt TuneRig noch einmal, bevor etwas gelöscht wird.`n`nJetzt suchen?" 'Junk-Dateien')) { return }
        Start-JunkSearch { Invoke-ButtonClick $ui.BtnCleanRun }
        return
    }
    if ($sel | Where-Object { $_.Tag -like 'browser-*' }) {
        $running = @(Get-RunningBrowsers)
        if ($running.Count -gt 0 -and -not (Confirm-Action ("Folgende Browser sind geöffnet: {0}.`nIhr Cache lässt sich dann nur teilweise löschen. Schließ die Browser für ein besseres Ergebnis.`n`nTrotzdem fortfahren?" -f ($running -join ', ')))) { return }
    }
    $list = ($sel | ForEach-Object { '- ' + $_.A + $(if ($_.B -and $_.B -ne '-') { "  ($($_.B))" } else { '' }) }) -join "`n"
    if (-not (Confirm-Action "Folgende Bereiche werden aufgeräumt:`n`n$list`n`nZwischendateien von Windows werden endgültig gelöscht, Junk-Dateien kommen in den Papierkorb. Fortfahren?" 'Aufräumen')) { return }
    $ids = @($sel | Where-Object { $_.Tag -ne 'junk' } | ForEach-Object { $_.Tag })
    $junk = if ($sel | Where-Object { $_.Tag -eq 'junk' }) { @($script:State.Junk | Where-Object { -not $_.Keep } | ForEach-Object { $_.Path }) } else { @() }
    Start-Work -Status 'Räume auf ...' -Arguments @(@($ids), @($junk)) -Script {
        $freed = 0L
        foreach ($id in $A[0]) { Report "Bereinige: $id ..."; $freed += [long](@(Invoke-Cleanup $id)[-1]) }
        $done = @(); $locked = 0
        foreach ($p in $A[1]) {
            Report "Junk: $p"
            $sz = try { (Get-Item -LiteralPath $p -Force -ErrorAction Stop).Length } catch { 0 }
            $res = Remove-PathHard $p -RecycleOnly
            if ($res.Status -eq 'ok') { $done += $p; $freed += [long]$sz } else { $locked++ }
        }
        [pscustomobject]@{ Freed = $freed; Done = $done; Locked = $locked; Measures = @(foreach ($id in $A[0]) { Measure-Cleanup $id }) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Apply-Measures $r.Measures
        if ($null -ne $script:State.Junk -and @($r.Done).Count) { $d = @($r.Done); $script:State.Junk = @($script:State.Junk | Where-Object { $d -notcontains $_.Path }); Update-JunkRow }
        $msg = "Fertig! $(Format-Bytes $r.Freed) freigegeben. Dateien, die gerade verwendet werden, wurden übersprungen."
        if ($r.Locked) { $msg += " $($r.Locked) Junk-Datei(en) waren gesperrt oder passten nicht in den Papierkorb." }
        Set-Status $msg; Show-Info $msg 'Aufräumen'
    }
})

# Liste der gefundenen Junk-Dateien: einzelne abwählen
$script:JunkXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Gefundene Junk-Dateien" Width="900" Height="600" MinWidth="600" MinHeight="400"
        WindowStartupLocation="CenterOwner" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <DockPanel Margin="32,24">
    <TextBlock DockPanel.Dock="Top" Style="{StaticResource H3}" Text="Gefundene Junk-Dateien"/>
    <TextBlock DockPanel.Dock="Top" Style="{StaticResource Small}" Margin="0,8,0,12" TextWrapping="Wrap" Text="Angehakte Dateien kommen beim Aufräumen in den Papierkorb. Entferne den Haken bei allem, was du behalten willst. Doppelklick zeigt die Datei im Explorer."/>
    <DockPanel DockPanel.Dock="Bottom" Margin="0,16,0,0">
      <Button x:Name="JkClose" DockPanel.Dock="Right" Style="{StaticResource Primary}" Content="ÜBERNEHMEN" Margin="0"/>
      <WrapPanel>
        <Button x:Name="JkAll" Content="Alle"/>
        <Button x:Name="JkNone" Content="Keine"/>
      </WrapPanel>
    </DockPanel>
    <DataGrid x:Name="JkGrid">
      <DataGrid.Columns>
        <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
        <DataGridTextColumn Header="Datei" Binding="{Binding A}" Width="*" IsReadOnly="True"/>
        <DataGridTextColumn Header="Größe" Binding="{Binding B}" Width="110" IsReadOnly="True" SortMemberPath="N1"/>
        <DataGridTextColumn Header="Geändert" Binding="{Binding C}" Width="110" IsReadOnly="True"/>
      </DataGrid.Columns>
    </DataGrid>
  </DockPanel>
</Window>
'@
$ui.BtnJunkShow.Add_Click({
    if ($null -eq $script:State.Junk) { Show-Info 'Noch nicht gesucht. Hake »Junk-Dateien auf allen Laufwerken« an und klick auf »Neu berechnen«.'; return }
    if (@($script:State.Junk).Count -eq 0) { Show-Info 'Es wurden keine Junk-Dateien gefunden.'; return }
    $script:JkDlg = [Windows.Markup.XamlReader]::Parse($script:JunkXaml)
    $script:JkDlg.Owner = $window; Set-WindowBranding $script:JkDlg; Set-CapsLabels $script:JkDlg
    $g = $script:JkDlg.FindName('JkGrid')
    Set-Items $g (@($script:State.Junk) | ForEach-Object { New-Row -A $_.Path -B (Format-Bytes $_.Size) -C $_.Modified -N1 $_.Size -Selected (-not $_.Keep) -Tag $_ })
    $script:JkDlg.FindName('JkAll').Add_Click({ foreach ($r in @(Get-Rows ($script:JkDlg.FindName('JkGrid')))) { $r.IsSelected = $true } })
    $script:JkDlg.FindName('JkNone').Add_Click({ foreach ($r in @(Get-Rows ($script:JkDlg.FindName('JkGrid')))) { $r.IsSelected = $false } })
    $script:JkDlg.FindName('JkClose').Add_Click({ $script:JkDlg.Close() })
    $g.Add_MouseDoubleClick({ param($s) $r = $s.SelectedItem; if ($r) { try { Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $r.Tag.Path) } catch {} } })
    [void]$script:JkDlg.ShowDialog()
    foreach ($r in @(Get-Rows $g)) { $r.Tag.Keep = -not $r.IsSelected }
    Update-JunkRow
})

# ============================================================================
#  Deinstallation
# ============================================================================
function Update-ProgramView {
    $q = $ui.TxtSearch.Text.Trim()
    $prev = if ($ui.GridPrograms.SelectedItem) { $ui.GridPrograms.SelectedItem.Tag } else { $null }
    $rows = @($script:State.Programs)
    # IndexOf statt -like: Sonderzeichen wie [ ] * ? im Suchtext sind kein Fehler
    if ($q) { $rows = @($rows | Where-Object { ([string]$_.A).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or ([string]$_.C).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 }) }
    Set-Items $ui.GridPrograms $rows
    $ui.ProgramCount.Text = "$($rows.Count) Programme"
    # Auswahl erhalten; bei genau einem Treffer automatisch auswählen
    $sel = $null
    if ($prev) { $sel = @($rows | Where-Object { $_.Tag.Name -eq $prev.Name -and $_.Tag.Version -eq $prev.Version })[0] }
    if (-not $sel -and $rows.Count -eq 1) { $sel = $rows[0] }
    if ($sel) { $ui.GridPrograms.SelectedItem = $sel; $ui.GridPrograms.ScrollIntoView($sel) }
    Update-ProgramSelection
}

function Update-ProgramSelection {
    $row = $ui.GridPrograms.SelectedItem
    $has = [bool]$row
    $ui.BtnUninstall.IsEnabled = $has; $ui.BtnForce.IsEnabled = $has
    if ($has) {
        $p = $row.Tag
        $ui.ProgramSelected.Text = 'Ausgewählt: ' + $p.Name + $(if ($p.Version) { "  ·  $($p.Version)" } else { '' }) + $(if ($p.Publisher) { "  ·  $($p.Publisher)" } else { '' }) + $(if ($p.InstallLocation) { "  ·  $($p.InstallLocation)" } else { '' })
        Set-ThemeRef $ui.ProgramSelected Foreground 'ink'
        $ui.ProgramSelectedIcon.Content = New-LineIcon 'check' 'accent' 18
    } else {
        $ui.ProgramSelected.Text = 'Klick ein Programm in der Liste an.'
        Set-ThemeRef $ui.ProgramSelected Foreground 'ink-muted'
        $ui.ProgramSelectedIcon.Content = New-LineIcon 'info' 'ink-muted' 18
    }
}
$ui.GridPrograms.Add_SelectionChanged({ Update-ProgramSelection })
Update-ProgramSelection

$script:LoadPrograms = {
    Start-Work -Status 'Lade installierte Programme ...' -Arguments @([bool]$ui.ChkStore.IsChecked) -Script { @(Get-InstalledPrograms $A[0]) } -OnDone {
        param($r)
        $script:State.Programs = @($r | Where-Object { $_ } | ForEach-Object {
            New-Row -A $_.Name -B $_.Version -C $_.Publisher -D $_.InstallDate -E $(if ($_.Size -gt 0) { Format-Bytes $_.Size } else { '' }) -F $_.TypeText -N1 $_.Size -Tag $_
        })
        Update-ProgramView
        Set-Status "$(@($script:State.Programs).Count) Programme gefunden."
    }
}
$ui.BtnPrograms.Add_Click({ & $script:LoadPrograms })
$ui.ChkStore.Add_Click({ & $script:LoadPrograms })
$ui.TxtSearch.Add_TextChanged({ Update-ProgramView })

# Zeile der Restetabelle: Zugehörigkeit | Typ | Pfad | Beleg | Größe
function New-LeftoverRow($It) {
    $lvl = switch ($It.Confidence) { 'sicher' { 0 } 'wahrscheinlich' { 1 } default { 2 } }
    $conf = switch ($It.Confidence) { 'sicher' { 'Nachgewiesen' } 'wahrscheinlich' { 'Wahrscheinlich' } default { 'Unsicher' } }
    if ($It.Shared) { $conf += ' · geteilt' }
    $what = "$($It.Type)`n$($It.Reason)" + $(if ($It.Owner) { "`nvon: $($It.Owner)" } else { '' })
    New-Row -A $conf -B $what -C $It.Path -D $It.Proof -E $(if ($It.Size -gt 0) { Format-Bytes $It.Size } else { '' }) -N1 $It.Size -Selected $It.Selected -Level $lvl -Tag $It
}

# Hält vor der Deinstallation fest, was nachweislich zum Programm gehört (danach ist z. B. die Windows-Installer-Liste weg)
function Start-ProgramFootprint([scriptblock]$Then) {
    $script:State.FootprintThen = $Then
    $script:State.Footprint = $null; $script:State.FootprintFor = ''
    if ($script:State.Current.Source -eq 'Store') { & $Then; return }
    $all = @($script:State.Programs | ForEach-Object { $_.Tag })
    Start-Work -Status "Erfasse, was nachweislich zu $($script:State.Current.Name) gehört ... (bis zu zwei Minuten)" -Arguments @($script:State.Current, $all) -Script { Get-ProgramFootprint $A[0] $A[1] } -OnDone {
        param($r)
        $script:State.Footprint = @($r)[-1]; $script:State.FootprintFor = $script:State.Current.Name
        Save-Footprint $script:State.Current $script:State.Footprint    # für spätere Restesuchen
        $cnt = @($script:State.Footprint.Items).Count
        Set-LoHead 'installed' "Erfasst: $cnt Einträge gehören nachweislich zu $($script:State.Current.Name)"
        Set-Status "$cnt Einträge gehören nachweislich zu $($script:State.Current.Name). Jetzt startet die Deinstallation." 
        & $script:State.FootprintThen
    }
}

# Öffnet den Speicherort eines Rests: Explorer, Registrierungs-Editor, Dienste oder Aufgabenplanung
function Open-LeftoverLocation($It) {
    if (-not $It) { Show-Info 'Markiere zuerst einen Eintrag in der Liste.'; return }
    switch ($It.Type) {
        'Ordner' {
            if (Test-Path -LiteralPath $It.Path) { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $It.Path) }
            else { Show-Info "Der Ordner existiert nicht mehr:`n$($It.Path)" }
        }
        'Datei' {
            if (Test-Path -LiteralPath $It.Path) { Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $It.Path) }
            else { Show-Info "Die Datei existiert nicht mehr:`n$($It.Path)" }
        }
        { $_ -in 'Registry-Schlüssel', 'Registry-Wert' } {
            # Der Registrierungs-Editor öffnet den zuletzt gemerkten Schlüssel – den setzen wir vorher
            $disp = Get-RegDisplayPath $It.Hive $It.View $It.SubKey
            $full = 'Computer\' + ($disp -replace '^HKLM\\', 'HKEY_LOCAL_MACHINE\' -replace '^HKCU\\', 'HKEY_CURRENT_USER\')
            try {
                $k = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Applets\Regedit')
                $k.SetValue('LastKey', $full); $k.Close()
                Start-Process regedit.exe -ArgumentList '-m'
                if ($It.Type -eq 'Registry-Wert') { Set-Status "Im Registrierungs-Editor rechts den Wert »$($It.ValueName)« suchen." }
            } catch { Show-Error $_.Exception.Message }
        }
        'Dienst' { Start-Process services.msc; Set-Status "In der Diensteliste nach »$($It.Service)« suchen." }
        'Aufgabe' { Start-Process taskschd.msc; Set-Status "In der Aufgabenplanung unter »$($It.TaskPath)« nach »$($It.Task)« suchen." }
        'Firewall-Regel' { Start-Process wf.msc; Set-Status "In der Firewall unter eingehenden bzw. ausgehenden Regeln nach »$($It.Path)« suchen." }
    }
}
$ui.BtnLoOpen.Add_Click({ $r = $ui.GridLeftovers.SelectedItem; Open-LeftoverLocation $(if ($r) { $r.Tag } else { $null }) })
$ui.GridLeftovers.Add_MouseDoubleClick({
    param($s, $e)
    $dep = $e.OriginalSource
    try { while ($dep -and -not ($dep -is [Windows.Controls.DataGridRow])) { if ($dep -is [Windows.Controls.CheckBox]) { return }; $dep = [Windows.Media.VisualTreeHelper]::GetParent($dep) } } catch { $dep = $null }
    if ($dep) { Open-LeftoverLocation $dep.Item.Tag }
})

function Start-LeftoverScan([string]$Previous, [switch]$Forced) {
    $script:State.LeftoverMode = 'program'
    $script:State.Previous = $Previous
    $p = $script:State.Current
    if (-not $p) { Show-Info 'Wähl zuerst ein Programm aus und deinstalliere es.'; return }
    $all = @($script:State.Programs | ForEach-Object { $_.Tag })
    $fp = if ($script:State.FootprintFor -eq $p.Name) { $script:State.Footprint } else { $null }
    Start-Work -Status "Suche Reste von $($p.Name) ..." -Arguments @($p, $all, [bool]$Forced, $fp) -Script {
        if (-not $A[2]) { Start-Sleep -Seconds 2 }   # manche Deinstallationsprogramme löschen ihre letzten Dateien kurz nach dem Beenden
        $still = if ($A[2]) { $false } else { Test-ProgramStillInstalled $A[0] }
        [pscustomobject]@{ Still = $still; Items = $(if ($still) { @() } else { @(Find-Leftovers $A[0] $A[1] $A[3]) }) }
    } -OnDone {
        param($r)
        $res = @($r)[-1]
        $name = $script:State.Current.Name
        if ($res.Still) {
            Set-LoResult 'installed' @() "$name ist noch installiert"
            Set-Status "$($script:State.Previous) $name ist noch installiert."
            Show-Info ("$($script:State.Previous)`n`n$name ist noch installiert. Entweder wurde die Deinstallation abgebrochen, oder sie läuft noch im Hintergrund.`n`n" +
                       "Läuft sie noch: warte, bis sie fertig ist, und klick dann auf »Erneut nach Resten suchen«.`n" +
                       "Lässt sich das Programm gar nicht deinstallieren: »Erzwungen entfernen«.") 'Deinstallation'
            return
        }
        $items = @($res.Items | Where-Object { $_ })
        $selCount = @($items | Where-Object { $_.Selected }).Count
        Set-LoResult 'installed' @($items | ForEach-Object { New-LeftoverRow $_ }) "Nachgewiesene Reste von $name ($($items.Count))"
        if ($items.Count -eq 0) {
            Set-Status "$($script:State.Previous) Keine Reste gefunden – das Programm wurde sauber entfernt."
            Show-Info "$($script:State.Previous)`n`nEs wurden keine Reste gefunden." 'Deinstallation'
            & $script:LoadPrograms
        } else {
            Set-Status "$($script:State.Previous) $($items.Count) Reste gefunden, $selCount davon vorausgewählt. Prüfen und auf »Ausgewählte Reste löschen« klicken."
        }
    }
}

$script:UninstallSelected = {
    $row = $ui.GridPrograms.SelectedItem
    if (-not $row) { Show-Info 'Wähl zuerst ein Programm aus der Liste.'; return }
    $p = $row.Tag
    if (-not (Confirm-Action ("{0} deinstallieren?`n`n1. TuneRig legt einen Wiederherstellungspunkt an.`n2. Das Deinstallationsprogramm des Herstellers startet – folge seinen Anweisungen.`n3. Danach sucht TuneRig nach Resten, die du prüfen und löschen kannst." -f $p.Name) 'Deinstallieren')) { return }
    $script:State.Current = $p
    Set-LoResult 'installed' @() 'Gefundene Reste'
    Invoke-WithRestorePoint "Deinstallation $($p.Name)" {
        Start-ProgramFootprint {
            Start-Work -Cancellable -Status "Deinstalliere $($script:State.Current.Name) ... (Abbrechen = nicht länger warten)" -Arguments @($script:State.Current) -Script { Invoke-Uninstaller $A[0] } -OnDone {
                param($r) $msg = [string](@($r)[-1])
                Set-Status $msg
                if ($script:State.Current.Source -eq 'Store') { Show-Info $msg; & $script:LoadPrograms }
                else { Start-LeftoverScan $msg }
            } -OnCancel { Start-LeftoverScan 'Warten auf das Deinstallationsprogramm wurde beendet.' }
        }
    }
}
$ui.BtnUninstall.Add_Click({ & $script:UninstallSelected })
$ui.GridPrograms.Add_MouseDoubleClick({
    param($s, $e)
    $dep = $e.OriginalSource
    try {
        while ($dep -and -not ($dep -is [Windows.Controls.DataGridRow])) { $dep = [Windows.Media.VisualTreeHelper]::GetParent($dep) }
    } catch { $dep = $null }
    if ($dep) { & $script:UninstallSelected }
})

$ui.BtnForce.Add_Click({
    $row = $ui.GridPrograms.SelectedItem
    if (-not $row) { Show-Info 'Wähl zuerst ein Programm aus der Liste.'; return }
    if ($row.Tag.Source -eq 'Store') { & $script:UninstallSelected; return }
    if (-not (Confirm-Action ("{0} erzwungen entfernen?`n`nDas Deinstallationsprogramm wird nicht ausgeführt. Stattdessen werden alle gefundenen Spuren (Ordner, Registry, Verknüpfungen, Dienste) angezeigt und können gelöscht werden.`n`nNutze das nur, wenn die normale Deinstallation nicht funktioniert." -f $row.Tag.Name) 'Erzwungene Deinstallation')) { return }
    $script:State.Current = $row.Tag
    Set-LoResult 'installed' @() 'Gefundene Reste'
    Invoke-WithRestorePoint "Erzwungene Deinstallation $($row.Tag.Name)" { Start-ProgramFootprint { Start-LeftoverScan 'Erzwungene Deinstallation.' -Forced } }
})
$ui.BtnLoRescan.Add_Click({ Start-LeftoverScan 'Erneute Suche.' })

# Reste von Programmen und Spielen, die nicht mehr installiert sind
$script:State.OrphanP = [pscustomobject]@{ Name = 'Reste nicht mehr installierter Programme'; Source = 'Orphan'; SubKey = '' }
function Start-OrphanScan {
    Set-LoResult 'orphans' @() 'Suche läuft ... (einige Minuten)'
    Start-Work -Cancellable -Status 'Durchsuche alle Laufwerke nach Resten nicht mehr installierter Programme ... (einige Minuten)' -Script { @(Find-OrphanLeftovers) } -OnDone {
        param($r)
        $items = @($r | Where-Object { $_ })
        $size = 0L; foreach ($i in $items) { $size += [long]$i.Size }
        $owners = @($items | Where-Object { $_.Owner } | ForEach-Object { $_.Owner } | Sort-Object -Unique)
        Set-LoResult 'orphans' @($items | ForEach-Object { New-LeftoverRow $_ }) ("{0} nachgewiesene Reste · {1} · von {2} Programmen bzw. Spielen" -f $items.Count, (Format-Bytes $size), $owners.Count)
        if ($items.Count -eq 0) { Set-Status 'Keine Reste nicht mehr installierter Programme gefunden.'; Show-Info 'Es wurden keine nachweisbaren Reste nicht mehr installierter Programme gefunden.' 'Restesuche' }
        else { Set-Status ("{0} Reste gefunden ({1}), davon {2} Programme bzw. Spiele erkennbar. Prüfen und auf »Ausgewählte Reste löschen« klicken." -f $items.Count, (Format-Bytes $size), $owners.Count) }
    } -OnCancel { Set-LoHead 'orphans' 'Suche abgebrochen.'; Set-Status 'Suche abgebrochen.' }
}
$ui.BtnRestScan.Add_Click({
    if (-not (Confirm-Action ("TuneRig durchsucht jetzt alle Laufwerke nach Resten von Programmen und Spielen, die nicht mehr installiert sind.`n`n" +
            "Gefunden wird nur, was sich belegen lässt: Einträge, deren Programm nicht mehr existiert, Spieleordner, die kein Launcher mehr kennt, Reste früherer Deinstallationen mit TuneRig und Datenordner, die nur noch auf entfernte Programme verweisen.`n`n" +
            "Die Suche ändert nichts und dauert einige Minuten. Starten?") 'Reste alter Programme')) { return }
    Start-OrphanScan
})

# Eine Reste-Liste für beide Ansichten: Ergebnisse der jeweils anderen Ansicht werden zwischengespeichert
$script:LoCache = @{ installed = @{ Rows = @(); Head = 'Gefundene Reste' }; orphans = @{ Rows = @(); Head = 'Noch nicht gesucht.' } }
function Get-LoMode { if ($script:SubCurrent['prog'] -eq 'orphans') { 'orphans' } else { 'installed' } }
function Get-LoRows([string]$Mode) { if ((Get-LoMode) -eq $Mode) { @(Get-Rows $ui.GridLeftovers) } else { @($script:LoCache[$Mode].Rows) } }
function Set-LoResult([string]$Mode, $Rows, [string]$Head) {
    $script:LoCache[$Mode] = @{ Rows = @($Rows); Head = $Head }
    if ((Get-LoMode) -eq $Mode) { Set-Items $ui.GridLeftovers @($Rows); $ui.LeftoverHeading.Text = $Head; Update-LoLayout }
}
function Set-LoHead([string]$Mode, [string]$Head) {
    $script:LoCache[$Mode].Head = $Head
    if ((Get-LoMode) -eq $Mode) { $ui.LeftoverHeading.Text = $Head; Update-LoLayout }
}
# Bei den installierten Programmen bekommt die Programmliste den ganzen Platz, solange es keine Reste gibt
function Update-LoLayout {
    $inst = (Get-LoMode) -eq 'installed'
    $has = @(Get-Rows $ui.GridLeftovers).Count -gt 0 -or $ui.LeftoverHeading.Text -ne 'Gefundene Reste'
    $show = -not $inst -or $has
    $ui.LoPanel.Visibility = if ($show) { 'Visible' } else { 'Collapsed' }
    $ui.GridLeftovers.Visibility = if ($show) { 'Visible' } else { 'Collapsed' }
    $ui.ProgRowTop.Height = if ($inst) { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { [Windows.GridLength]::Auto }
    $ui.ProgRowLo.Height = if ($show) { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { New-Object Windows.GridLength(0) }
}
function Switch-LeftoverMode([string]$Prev, [string]$Next) {
    if ($Prev -and $Prev -ne $Next) {
        $script:LoCache[$Prev] = @{ Rows = @(Get-Rows $ui.GridLeftovers); Head = $ui.LeftoverHeading.Text }
    }
    Set-Items $ui.GridLeftovers @($script:LoCache[$Next].Rows); $ui.LeftoverHeading.Text = $script:LoCache[$Next].Head
    $ui.BtnLoRescan.Visibility = if ($Next -eq 'installed') { 'Visible' } else { 'Collapsed' }
    Update-LoLayout
}

$ui.BtnLoAll.Add_Click({ foreach ($r in @(Get-Rows $ui.GridLeftovers)) { $r.IsSelected = $true } })
$ui.BtnLoNone.Add_Click({ foreach ($r in @(Get-Rows $ui.GridLeftovers)) { $r.IsSelected = $false } })

# Löscht die ausgewählten Reste einer Liste (Deinstallation oder Reste-Suche)
function Remove-SelectedLeftovers([string]$Mode, $P) {
    $rows = @(Get-LoRows $Mode)
    if (-not $P -or $rows.Count -eq 0) { Show-Info 'Es gibt keine Reste zum Löschen.'; return }
    $sel = @($rows | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Wähl die Einträge aus, die gelöscht werden sollen.'; return }
    $warn = ''
    $noProof = @($sel | Where-Object { $_.Tag.Confidence -ne 'sicher' })
    if ($noProof.Count) { $warn += "`n`nAchtung: $($noProof.Count) ausgewählte Einträge sind NICHT nachweislich Teil des Programms (»Wahrscheinlich« oder »Unsicher«). Prüfe sie mit »Speicherort öffnen«, bevor du sie löschst." }
    if ($sel | Where-Object { $_.Tag.Shared }) { $warn += "`n`nAchtung: Du hast Einträge ausgewählt, die auch andere Programme nutzen." }
    if (-not (Confirm-Action ("$($sel.Count) Einträge werden entfernt.`n`n" +
            "–  Auf Wunsch werden Registry-Einträge und geplante Aufgaben vorher gesichert.`n" +
            "–  Dateien und Ordner landen im Papierkorb. Was nicht hineinpasst, wird direkt gelöscht.`n" +
            "–  Programme, die noch aus diesen Ordnern laufen, werden beendet.`n" +
            "–  Gesperrte Dateien werden beim nächsten Neustart gelöscht.$warn`n`nFortfahren?") 'Reste löschen')) { return }
    $items = @($sel | ForEach-Object { $_.Tag })
    $script:State.RemoveCtx = @{ Mode = $Mode; P = $P; Items = $items }
    # Vorher Wiederherstellungspunkt (zusätzlich zu den Registry-Sicherungen und dem Papierkorb)
    Invoke-WithRestorePoint "Reste entfernen: $($P.Name)" { Start-LeftoverRemoval }
}

function Start-LeftoverRemoval {
    $ctx = $script:State.RemoveCtx
    Start-Work -Status 'Entferne Reste ... (jeder Eintrag wird vorher noch einmal gegengeprüft)' -Arguments @($ctx.P, $ctx.Items, [bool]$script:State.Backup) -Script { Remove-Leftovers $A[0] $A[1] $A[2] } -OnDone {
        param($r) $res = @($r)[-1]
        $ctx = $script:State.RemoveCtx
        # Entfernte Zeilen verschwinden; Gesperrtes, Zurückgehaltenes und Fehlgeschlagenes bleibt mit Grund stehen
        $byPath = @{}; foreach ($x in @($res.Results)) { $byPath[$x.Item.Type + '|' + $x.Item.Path] = $x }
        $keep = foreach ($row in @(Get-LoRows $ctx.Mode)) {
            $x = $byPath[$row.Tag.Type + '|' + $row.Tag.Path]
            if (-not $x) { $row; continue }
            if ($x.Status -in 'ok', 'deleted') { continue }
            $row.IsSelected = $false
            if ($x.Status -eq 'reboot') { $row.A = 'Beim Neustart'; $row.Level = 1 } elseif ($x.Status -eq 'skipped') { $row.A = 'Zurückgehalten'; $row.Level = 2 } else { $row.A = 'Fehlgeschlagen'; $row.Level = 3 }
            $row.D = $x.Note
            $row
        }
        Set-LoResult $ctx.Mode @($keep) "$($ctx.P.Name): $(@($keep).Count) Einträge übrig"
        if ($res.Reboot) {
            if (Confirm-Action ($res.Message + "`n`nJetzt neu starten, damit die gesperrten Dateien gelöscht werden? (Speichere vorher offene Dateien.)") 'Reste gelöscht') {
                shutdown.exe /r /t 10 /c "TuneRig: Neustart, um gesperrte Reste zu löschen."
            }
        } else { Show-Info $res.Message 'Reste gelöscht' }
        & $script:LoadPrograms
    }
}

$ui.BtnLoDelete.Add_Click({ $m = Get-LoMode; Remove-SelectedLeftovers $m $(if ($m -eq 'orphans') { $script:State.OrphanP } else { $script:State.Current }) })

# ============================================================================
#  Overdrive (Werkzeug-Ansicht): nur mit bestätigtem Risiko
# ============================================================================
$ui.OdWarnIcon.Content = New-LineIcon 'warning' 'warning' 24
$script:OdLevelName = @{ 1 = '1 · Sanft'; 2 = '2 · Spürbar'; 3 = '3 · Maximal' }
function Show-OverdriveGrid($tweaks) {
    Set-Items $ui.GridOverdrive (@($tweaks) | Sort-Object Level, Title | ForEach-Object {
        $status = if ($_.Optimal -and $_.ByTuneRig) { 'Aktiv (TuneRig)' } elseif ($_.Optimal) { 'Bereits so' } else { 'Nicht aktiv' }
        $lvl = if ($_.Optimal) { 0 } else { 1 }
        $eff = "Wirkung: $($script:ImpactText[[int]$_.Impact]) - $($_.Benefit)`nRisiko: $($_.Risk)"
        New-Row -A $script:OdLevelName[[int]$_.Level] -B $_.Title -C $status -D $_.State -F $eff -Level $lvl -Selected $false -Tag $_
    })
}
$script:LoadOverdrive = {
    Start-Work -Status 'Prüfe Overdrive-Einstellungen ...' -Script { @(Get-GamingTweaks 'overdrive' (Test-IsLaptop)) } -OnDone {
        param($r) $t = @($r | Where-Object { $_ }); Show-OverdriveGrid $t
        Set-Status ("{0} Overdrive-Einstellungen geprüft, {1} davon aktiv." -f $t.Count, @($t | Where-Object { $_.Optimal }).Count)
    }
}
$ui.BtnOdCheck.Add_Click({ & $script:LoadOverdrive })
$ui.ChkOdAccept.Add_Click({ $ui.BtnOdApply.IsEnabled = [bool]$ui.ChkOdAccept.IsChecked })
foreach ($b in @(@($ui.BtnOdLvl1, 1), @($ui.BtnOdLvl2, 2), @($ui.BtnOdLvl3, 3))) { $b[0].CommandParameter = $b[1] }
$script:OdSelectLevel = { param($s) $n = [int]$s.CommandParameter; foreach ($r in @(Get-Rows $ui.GridOverdrive)) { $r.IsSelected = (-not $r.Tag.Optimal) -and [int]$r.Tag.Level -le $n } }
$ui.BtnOdLvl1.Add_Click($script:OdSelectLevel); $ui.BtnOdLvl2.Add_Click($script:OdSelectLevel); $ui.BtnOdLvl3.Add_Click($script:OdSelectLevel)

function Invoke-OverdriveFromGrid([bool]$Revert) {
    if (-not $Revert -and -not $ui.ChkOdAccept.IsChecked) { Show-Info 'Bestätige zuerst, dass du die Risiken kennst.'; return }
    $sel = @(Get-Rows $ui.GridOverdrive | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Hake zuerst die gewünschten Zeilen an.'; return }
    $list = ($sel | ForEach-Object { '- ' + $_.B + $(if (-not $Revert) { "`n   Risiko: " + $_.Tag.Risk } else { '' }) }) -join "`n"
    $head = if ($Revert) { 'Diese Overdrive-Einstellungen werden auf deinen früheren Wert zurückgesetzt:' } else { 'Diese Overdrive-Einstellungen werden angewendet:' }
    if (-not (Confirm-Action "$head`n`n$list`n`nFortfahren?" 'Overdrive')) { return }
    $script:State.Pending = @{ Ids = @($sel | ForEach-Object { $_.Tag.Id }); Revert = $Revert; Restart = [bool]($sel | Where-Object { $_.Tag.Restart }) }
    Invoke-WithRestorePoint $(if ($Revert) { 'Overdrive zurücksetzen' } else { 'TuneRig Overdrive' }) {
        Start-Work -Status 'Ändere Overdrive-Einstellungen ...' -Arguments @(@($script:State.Pending.Ids), $script:State.Pending.Revert) -Script {
            $e = @(Invoke-AllSettings $A[0] -Revert:$A[1])
            [pscustomobject]@{ Errors = $e; Tweaks = @(Get-GamingTweaks 'overdrive' (Test-IsLaptop)) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            Show-OverdriveGrid $r.Tweaks
            $errs = @($r.Errors | Where-Object { $_ })
            $msg = if ($errs.Count) { "Erledigt, mit Hinweisen:`n" + ($errs -join "`n") } else { 'Fertig.' }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen wirken erst nach einem Neustart." }
            Set-Status (($msg -split "`n")[0]); Show-Info $msg 'Overdrive'
        }
    }
}
$ui.BtnOdApply.Add_Click({ Invoke-OverdriveFromGrid $false })
$ui.BtnOdRevert.Add_Click({ Invoke-OverdriveFromGrid $true })

function Show-StartupGrid($items) {
    Set-Items $ui.GridStartup (@($items) | ForEach-Object {
        $status = if ($_.Enabled) { 'Aktiv' } else { 'Abgeschaltet' }
        $rec = switch ($_.Class) { 'off' { 'Abschalten empfohlen' } 'keep' { 'Eingeschaltet lassen' } default { 'Nur bei Bedarf' } }
        New-Row -A $_.Name -B $status -C $rec -D $_.Who -E $_.Command -Level $(if ($_.Enabled -and $_.Class -eq 'off') { 2 } elseif ($_.Enabled) { 0 } else { 1 }) `
                -Selected ($_.Enabled -and $_.Class -eq 'off') -Tag $_
    })
}
$script:LoadStartup = {
    Start-Work -Status 'Lese die Autostart-Programme ...' -Script { @(Get-StartupItems) } -OnDone {
        param($r) $i = @($r | Where-Object { $_ }); Show-StartupGrid $i
        Set-Status ("{0} Autostart-Einträge, davon {1} aktiv." -f $i.Count, @($i | Where-Object { $_.Enabled }).Count)
    }
}
$ui.BtnStartupCheck.Add_Click({ & $script:LoadStartup })

function Set-StartupFromGrid([bool]$Enable) {
    $sel = @(Get-Rows $ui.GridStartup | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Hake zuerst die gewünschten Programme an.'; return }
    $keep = @($sel | Where-Object { -not $Enable -and $_.Tag.Class -eq 'keep' })
    $warn = if ($keep.Count) { "`n`nAchtung: Darunter sind Programme für Treiber, Sicherheit oder Geräte:`n" + (($keep | ForEach-Object { '- ' + $_.A }) -join "`n") } else { '' }
    if (-not (Confirm-Action ("{0} Programm(e) werden {1}.{2}`n`nFortfahren?" -f $sel.Count, $(if ($Enable) { 'beim Windows-Start wieder gestartet' } else { 'beim Windows-Start nicht mehr gestartet' }), $warn))) { return }
    Start-Work -Status 'Ändere Autostart ...' -Arguments @(@($sel | ForEach-Object { $_.Tag.Id }), $Enable) -Script {
        foreach ($id in $A[0]) { Set-StartupItemState $id $A[1] }
        @(Get-StartupItems)
    } -OnDone { param($r) Show-StartupGrid @($r | Where-Object { $_ }); Set-Status 'Autostart geändert. Wirkt beim nächsten Windows-Start.' }
}
$ui.BtnStartupDisable.Add_Click({ Set-StartupFromGrid $false })
$ui.BtnStartupEnable.Add_Click({ Set-StartupFromGrid $true })

# ============================================================================
#  Startseite und geführter Check
# ============================================================================
. (Join-Path $AppDir 'Wizard.ps1')
. (Join-Path $AppDir 'Storage.ps1')
Set-SplashProgress 0.5 'Prüfe den Systemzustand …'
$ui.StatusVersion.Text = "TuneRig $script:AppVersion"
$ui.BtnCheckUpdate.Add_Click({ Start-UpdateCheck -Manual })
$ui.BtnUpdateNow.Add_Click({ Start-TuneRigUpdate })
$ui.BtnUpdateLater.Add_Click({ $ui.UpdateCard.Visibility = 'Collapsed' })
$ui.UpdateIcon.Content = New-LineIcon 'download' 'accent-text' 24

# ============================================================================
#  Alle Werkzeuge: Jeder Reiter prüft beim ersten Öffnen automatisch
#  (außer Übersicht - dort startet man die Analyse bewusst selbst).
#  Mehrere Prüfungen eines Reiters laufen nacheinander über eine Warteschlange.
# ============================================================================
function Invoke-ButtonClick($b) { $b.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent))) }
# Reiter: 0 Übersicht, 1 Treiber & Updates, 2 Leistung, 3 Speicherplatz, 4 Programme, 5 Overdrive
# Übersicht: Analyse startet beim ersten Öffnen von selbst
$script:TabLoaders = @{ 0 = @({ Invoke-ButtonClick $ui.BtnAnalyze }); 5 = @({ & $script:LoadOverdrive }) }
$script:TabGroups = @{ 1 = 'drv'; 2 = 'perf'; 3 = 'sto'; 4 = 'prog' }
# Unteransichten der Reiter (Button BtnXxxView<Name>, Bereich XxxView<Name>)
$script:SubViews = @{
    drv  = [ordered]@{ drivers = 'Drivers'; updates = 'Updates' }
    perf = [ordered]@{ settings = 'Settings'; games = 'Games'; startup = 'Startup' }
    sto  = [ordered]@{ clean = 'Clean'; drive = 'Drive' }
    prog = [ordered]@{ installed = 'Installed'; orphans = 'Orphans' }
}
$script:SubPrefix = @{ drv = 'Drv'; perf = 'Perf'; sto = 'Sto'; prog = 'Prog' }
$script:SubCurrent = @{}
$script:SubLoaders = @{
    'drv.drivers'    = @({ Invoke-ButtonClick $ui.BtnDrivers })
    'perf.settings'  = @({ & $script:LoadSettings })
    'perf.games'     = @({ Invoke-ButtonClick $ui.BtnGpu }, { Invoke-ButtonClick $ui.BtnGames })
    'perf.startup'   = @({ & $script:LoadStartup })
    'sto.clean'      = @({ Invoke-ButtonClick $ui.BtnCleanScan })
    'sto.drive'      = @({ Update-StorageDrives })
    'prog.installed' = @({ if (@($script:State.Programs).Count -eq 0) { & $script:LoadPrograms } })
}
$script:SubLoaded = @{}
$script:TabLoaded = @{}
$script:AutoQueue = New-Object System.Collections.Queue

function Request-SubAnalysis([string]$Group) {
    if (-not $ui.ExpertPage.IsVisible) { return }
    $key = "$Group.$($script:SubCurrent[$Group])"
    if ($script:SubLoaded[$key] -or -not $script:SubLoaders.ContainsKey($key)) { return }
    $script:SubLoaded[$key] = $true
    foreach ($l in $script:SubLoaders[$key]) { $script:AutoQueue.Enqueue($l) }
}
function Set-SubView([string]$Group, [string]$Name) {
    $prev = $script:SubCurrent[$Group]
    $p = $script:SubPrefix[$Group]
    foreach ($k in @($script:SubViews[$Group].Keys)) {
        $x = $script:SubViews[$Group][$k]
        $on = $k -eq $Name
        $ui["${p}View$x"].Visibility = if ($on) { 'Visible' } else { 'Collapsed' }
        $ui["Btn${p}View$x"].Tag = if ($on) { 'active' } else { $null }
    }
    $script:SubCurrent[$Group] = $Name
    if ($Group -eq 'prog') { Switch-LeftoverMode $prev $Name }
    if ($ui.Tabs.SelectedIndex -ge 0 -and $script:TabGroups[$ui.Tabs.SelectedIndex] -eq $Group) { Request-SubAnalysis $Group }
}
foreach ($g in @($script:SubViews.Keys)) {
    foreach ($k in @($script:SubViews[$g].Keys)) {
        $btn = $ui["Btn$($script:SubPrefix[$g])View$($script:SubViews[$g][$k])"]
        $btn.CommandParameter = "$g.$k"
        $btn.Add_Click({ param($s) $x = ([string]$s.CommandParameter).Split('.'); Set-SubView $x[0] $x[1] })
    }
    Set-SubView $g @($script:SubViews[$g].Keys)[0]
}

function Request-TabAnalysis {
    if (-not $ui.ExpertPage.IsVisible) { return }
    $i = $ui.Tabs.SelectedIndex
    if ($script:TabGroups.ContainsKey($i)) { Request-SubAnalysis $script:TabGroups[$i]; return }
    if ($script:TabLoaded[$i] -or -not $script:TabLoaders.ContainsKey($i)) { return }
    $script:TabLoaded[$i] = $true
    foreach ($l in $script:TabLoaders[$i]) { $script:AutoQueue.Enqueue($l) }
}

# Springt zu einem Werkzeug (Reiter und Unteransicht)
function Show-Tool([string]$Area) {
    $map = @{ overview = @(0); drivers = @(1, 'drv', 'drivers'); updates = @(1, 'drv', 'updates'); gpu = @(2, 'perf', 'games')
              settings = @(2, 'perf', 'settings'); gaming = @(2, 'perf', 'settings'); games = @(2, 'perf', 'games'); startup = @(2, 'perf', 'startup')
              cleanup = @(3, 'sto', 'clean'); junk = @(3, 'sto', 'clean'); storage = @(3, 'sto', 'drive')
              uninstall = @(4, 'prog', 'installed'); leftovers = @(4, 'prog', 'orphans'); overdrive = @(5) }
    if (-not $map.ContainsKey($Area)) { return }
    $m = $map[$Area]
    Show-Page 'expert'
    if ($m.Count -gt 1) { Set-SubView $m[1] $m[2] }
    $ui.Tabs.SelectedIndex = $m[0]
    Request-TabAnalysis
}
$ui.Tabs.Add_SelectionChanged({ param($sender, $e) if ($e.OriginalSource -eq $ui.Tabs) { Request-TabAnalysis } })
$ui.ExpertPage.Add_IsVisibleChanged({ Request-TabAnalysis })
# Startet die nächste Prüfung, sobald nichts anderes läuft
$script:AutoTimer = New-Object Windows.Threading.DispatcherTimer
$script:AutoTimer.Interval = [TimeSpan]::FromMilliseconds(300)
$script:AutoTimer.Add_Tick({ if (-not $script:Job -and $script:AutoQueue.Count -gt 0) { & ($script:AutoQueue.Dequeue()) } })
$script:AutoTimer.Start()

# ============================================================================
#  Start
# ============================================================================
$settings = Get-AppSettings
$ui.ChkSkipWelcome.IsChecked = [bool]$settings.SkipWelcome
$ui.ChkSkipWelcome.Add_Click({ Save-AppSettings $(if ($script:State.Page -ne 'welcome') { $script:State.Page } else { (Get-AppSettings).LastMode }) })
if ($settings.SkipWelcome -and $settings.LastMode -eq 'expert') { Show-Page 'expert' }
elseif ($settings.SkipWelcome -and $settings.LastMode -eq 'wizard') { Show-Page 'wizard'; Show-WizStep 0 }
else { Show-Page 'welcome' }

$window.Add_Closing({ if ($script:Job) { try { $script:Job.PS.Stop() } catch {} } })
Start-BrandFontDownload

# Ladesequenz: warten, bis der Systemzustand feststeht (mindestens 1,5 s, höchstens 20 s)
$frame = New-Object Windows.Threading.DispatcherFrame
$splashTimer = New-Object Windows.Threading.DispatcherTimer
$splashTimer.Interval = [TimeSpan]::FromMilliseconds(120)
$splashTimer.Add_Tick({
    $elapsed = ((Get-Date) - $script:SplashStart).TotalSeconds
    $done = $script:HealthJob.Handle.IsCompleted
    # Fortschritt läuft gleichmäßig weiter, bis das Ergebnis da ist
    if (-not $done) { Set-SplashProgress ([math]::Min(0.9, 0.5 + $elapsed / 30)) }
    if (($done -and $elapsed -ge 1.5) -or $elapsed -ge 20) { $splashTimer.Stop(); $frame.Continue = $false }
})
$splashTimer.Start()
[Windows.Threading.Dispatcher]::PushFrame($frame)
if (-not (Receive-QuickHealth)) { Start-QuickHealth }
Set-SplashProgress 1.0 'Bereit'
Start-Sleep -Milliseconds 250
$window.Add_ContentRendered({ if ($script:Splash) { $script:Splash.Close(); $script:Splash = $null; $window.Activate() | Out-Null }; Start-UpdateCheck })
[void]$window.ShowDialog()
$timer.Stop(); $script:TipTimer.Stop(); $script:AutoTimer.Stop(); if ($script:HealthTimer) { $script:HealthTimer.Stop() }
