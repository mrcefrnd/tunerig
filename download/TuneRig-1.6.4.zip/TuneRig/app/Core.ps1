﻿# ============================================================================
#  TuneRig (portabel) - Kernfunktionen
#  Diese Datei enthält die gesamte Logik ohne Oberfläche. Sie wird sowohl im
#  Hauptfenster als auch in den Hintergrund-Threads geladen.
# ============================================================================

$ErrorActionPreference = 'Continue'

# ---------------------------------------------------------------------------
#  Native Hilfsfunktionen (Papierkorb, Energiemodus, Konsolenfenster)
# ---------------------------------------------------------------------------
if (-not ('PCO.Native' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace PCO
{
    /// Universelle Tabellenzeile mit Änderungsbenachrichtigung (für Checkboxen in DataGrids)
    public class Row : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void N(string n) { var h = PropertyChanged; if (h != null) h(this, new PropertyChangedEventArgs(n)); }

        private bool _sel; private int _lvl;
        private string _a, _b, _c, _d, _e, _f;
        public bool IsSelected { get { return _sel; } set { _sel = value; N("IsSelected"); } }
        public int Level { get { return _lvl; } set { _lvl = value; N("Level"); } }
        public string A { get { return _a; } set { _a = value; N("A"); } }
        public string B { get { return _b; } set { _b = value; N("B"); } }
        public string C { get { return _c; } set { _c = value; N("C"); } }
        public string D { get { return _d; } set { _d = value; N("D"); } }
        public string E { get { return _e; } set { _e = value; N("E"); } }
        public string F { get { return _f; } set { _f = value; N("F"); } }
        public long N1 { get; set; }
        public object Tag { get; set; }
    }

    public static class Native
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEOPSTRUCT
        {
            public IntPtr hwnd; public uint wFunc; public string pFrom; public string pTo;
            public ushort fFlags; public bool fAnyOperationsAborted; public IntPtr hNameMappings; public string lpszProgressTitle;
        }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHFileOperation(ref SHFILEOPSTRUCT op);

        /// Verschiebt Datei oder Ordner in den Papierkorb
        public static bool Recycle(string path)
        {
            if (!System.IO.File.Exists(path) && !System.IO.Directory.Exists(path)) return true;
            var op = new SHFILEOPSTRUCT();
            op.wFunc = 3; // FO_DELETE
            op.pFrom = path + "\0\0";
            op.fFlags = 0x0040 | 0x0010 | 0x0004 | 0x0400; // ALLOWUNDO | NOCONFIRMATION | SILENT | NOERRORUI
            int r = SHFileOperation(ref op);
            return r == 0 && !op.fAnyOperationsAborted && !System.IO.File.Exists(path) && !System.IO.Directory.Exists(path);
        }

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool MoveFileEx(string existing, string newName, int flags);
        public static bool DeleteOnReboot(string path) { return MoveFileEx(path, null, 4); }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        private struct SHQUERYRBINFO { public int cbSize; public long i64Size; public long i64NumItems; }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHQueryRecycleBin(string root, ref SHQUERYRBINFO info);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHEmptyRecycleBin(IntPtr hwnd, string root, uint flags);

        public static long[] QueryRecycleBin()
        {
            var i = new SHQUERYRBINFO(); i.cbSize = Marshal.SizeOf(typeof(SHQUERYRBINFO));
            if (SHQueryRecycleBin(null, ref i) != 0) return new long[] { 0, 0 };
            return new long[] { i.i64Size, i.i64NumItems };
        }
        public static void EmptyRecycleBin() { SHEmptyRecycleBin(IntPtr.Zero, null, 0x7); }

        [DllImport("powrprof.dll")] private static extern uint PowerGetEffectiveOverlayScheme(out Guid g);
        [DllImport("powrprof.dll")] private static extern uint PowerSetActiveOverlayScheme(Guid g);
        public static string GetOverlay()
        {
            try { Guid g; return PowerGetEffectiveOverlayScheme(out g) == 0 ? g.ToString() : ""; } catch { return ""; }
        }
        public static bool SetOverlay(string guid)
        {
            try { return PowerSetActiveOverlayScheme(new Guid(guid)) == 0; } catch { return false; }
        }

        [DllImport("srclient.dll")] private static extern int SRRemoveRestorePoint(int sequenceNumber);
        /// Löscht einen Wiederherstellungspunkt anhand seiner Nummer (0 = Erfolg)
        public static int RemoveRestorePoint(int sequenceNumber) { try { return SRRemoveRestorePoint(sequenceNumber); } catch { return -1; } }


        // ---- Bildschirme: Bildwiederholrate erkennen und einstellen ----
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DISPLAY_DEVICE
        {
            public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DEVMODE
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
            public short dmSpecVersion; public short dmDriverVersion; public short dmSize; public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX; public int dmPositionY; public int dmDisplayOrientation; public int dmDisplayFixedOutput;
            public short dmColor; public short dmDuplex; public short dmYResolution; public short dmTTOption; public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel; public int dmPelsWidth; public int dmPelsHeight; public int dmDisplayFlags; public int dmDisplayFrequency;
            public int dmICMMethod; public int dmICMIntent; public int dmMediaType; public int dmDitherType;
            public int dmReserved1; public int dmReserved2; public int dmPanningWidth; public int dmPanningHeight;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int ChangeDisplaySettingsEx(string lpszDeviceName, ref DEVMODE lpDevMode, IntPtr hwnd, uint dwflags, IntPtr lParam);

        private static DEVMODE NewDevMode() { var d = new DEVMODE(); d.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE)); return d; }

        /// Pro aktivem Bildschirm: "Gerät|Monitor|Breite|Höhe|Hz|MaxHz|Grafikkarte"
        public static string[] GetDisplays()
        {
            var list = new System.Collections.Generic.List<string>();
            for (uint i = 0; i < 16; i++)
            {
                var dd = new DISPLAY_DEVICE(); dd.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
                if ((dd.StateFlags & 1) == 0) continue; // nicht mit dem Desktop verbunden
                var cur = NewDevMode();
                if (!EnumDisplaySettings(dd.DeviceName, -1, ref cur)) continue;
                int max = cur.dmDisplayFrequency;
                var m = NewDevMode();
                for (int k = 0; EnumDisplaySettings(dd.DeviceName, k, ref m); k++)
                {
                    if (m.dmPelsWidth == cur.dmPelsWidth && m.dmPelsHeight == cur.dmPelsHeight &&
                        m.dmBitsPerPel == cur.dmBitsPerPel && m.dmDisplayFrequency > max && m.dmDisplayFrequency < 1000)
                        max = m.dmDisplayFrequency;
                    m = NewDevMode();
                }
                string mon = "";
                var md = new DISPLAY_DEVICE(); md.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                if (EnumDisplayDevices(dd.DeviceName, 0, ref md, 0)) mon = md.DeviceString;
                list.Add(dd.DeviceName + "|" + mon + "|" + cur.dmPelsWidth + "|" + cur.dmPelsHeight + "|" +
                         cur.dmDisplayFrequency + "|" + max + "|" + dd.DeviceString);
            }
            return list.ToArray();
        }

        /// Stellt die Bildwiederholrate bei gleicher Auflösung um (0 = Erfolg)
        public static int SetRefreshRate(string deviceName, int hz)
        {
            var dm = NewDevMode();
            if (!EnumDisplaySettings(deviceName, -1, ref dm)) return -99;
            dm.dmDisplayFrequency = hz;
            dm.dmFields = 0x400000; // DM_DISPLAYFREQUENCY
            int r = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 2, IntPtr.Zero); // CDS_TEST
            if (r != 0) return r;
            return ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 1, IntPtr.Zero); // CDS_UPDATEREGISTRY
        }

        // ---- Mausbeschleunigung sofort übernehmen ----
        [DllImport("user32.dll", SetLastError = true)] private static extern bool SystemParametersInfo(uint action, uint param, int[] vparam, uint winIni);
        public static bool SetMouseAcceleration(bool on)
        {
            int[] v = on ? new int[] { 6, 10, 1 } : new int[] { 0, 0, 0 };
            return SystemParametersInfo(0x0004, 0, v, 3); // SPI_SETMOUSE, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
        }

        [DllImport("kernel32.dll")] private static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr h, int cmd);
        public static void HideConsole() { var h = GetConsoleWindow(); if (h != IntPtr.Zero) ShowWindow(h, 0); }
    }
}
'@
}

# ---------------------------------------------------------------------------
#  Speicherplatz-Analyse: schneller Durchlauf über ein Laufwerk (FindFirstFileEx)
#  Liefert Ordnerbaum mit Größen, Dateitypen und die größten Dateien.
#  Verknüpfungen (Junctions) werden nicht doppelt gezählt, reine Cloud-Dateien
#  (OneDrive »Nur online«) belegen keinen Platz und werden getrennt ausgewiesen.
# ---------------------------------------------------------------------------
if (-not ('TuneRig.DiskScan' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace TuneRig
{
    public class DirNode
    {
        public string Name;
        public DirNode Parent;
        public long Size;
        public long Files;
        public long OwnSize;
        public long OwnFiles;
        public bool Denied;
        public List<DirNode> Children = new List<DirNode>();
        public string Path
        {
            get
            {
                if (Parent == null) return Name;
                string p = Parent.Path;
                return p.EndsWith("\\") ? p + Name : p + "\\" + Name;
            }
        }
        public DirNode Find(string name)
        {
            foreach (DirNode c in Children) if (string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase)) return c;
            return null;
        }
    }

    public class FileEntry { public string Path; public long Size; public DateTime Modified; }
    public class ExtStat { public string Ext; public long Size; public long Count; }

    public class DiskScanResult
    {
        public DirNode Root;
        public List<FileEntry> Largest;
        public List<ExtStat> Extensions;
        public long Files;
        public long Dirs;
        public long DeniedDirs;
        public long CloudBytes;
        public long CloudFiles;
        public double Seconds;
        public bool Cancelled;
    }

    public static class DiskScan
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct WIN32_FIND_DATAW
        {
            public uint dwFileAttributes;
            public System.Runtime.InteropServices.ComTypes.FILETIME ftCreationTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME ftLastAccessTime;
            public System.Runtime.InteropServices.ComTypes.FILETIME ftLastWriteTime;
            public uint nFileSizeHigh;
            public uint nFileSizeLow;
            public uint dwReserved0;
            public uint dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public string cAlternateFileName;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern IntPtr FindFirstFileExW(string lpFileName, int fInfoLevelId, out WIN32_FIND_DATAW lpFindFileData, int fSearchOp, IntPtr lpSearchFilter, int dwAdditionalFlags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool FindNextFileW(IntPtr hFindFile, out WIN32_FIND_DATAW lpFindFileData);
        [DllImport("kernel32.dll")]
        static extern bool FindClose(IntPtr hFindFile);

        static readonly IntPtr Invalid = new IntPtr(-1);
        const uint AttrDirectory = 0x10, AttrReparse = 0x400, AttrOffline = 0x1000, AttrRecallOnOpen = 0x40000, AttrRecallOnAccess = 0x400000;

        // Fortschritt - wird von der Oberfläche gelesen
        public static volatile bool Cancel;
        public static long ScannedFiles;
        public static long ScannedBytes;
        public static volatile string Current = "";

        static List<FileEntry> largest;
        static long minLargest;
        static int topN;
        static Dictionary<string, ExtStat> ext;
        static DiskScanResult res;

        static int BySizeDesc(FileEntry a, FileEntry b) { return b.Size.CompareTo(a.Size); }
        static int ExtBySizeDesc(ExtStat a, ExtStat b) { return b.Size.CompareTo(a.Size); }

        public static DiskScanResult Scan(string root, int top)
        {
            Cancel = false; ScannedFiles = 0; ScannedBytes = 0; Current = root;
            topN = Math.Max(1, top); largest = new List<FileEntry>(); minLargest = 0;
            ext = new Dictionary<string, ExtStat>(StringComparer.OrdinalIgnoreCase);
            res = new DiskScanResult();
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
            string path = root.TrimEnd('\\');
            DirNode node = new DirNode();
            node.Name = path + "\\";
            Walk(node, path);
            largest.Sort(BySizeDesc);
            if (largest.Count > topN) largest.RemoveRange(topN, largest.Count - topN);
            res.Root = node;
            res.Largest = largest;
            res.Extensions = new List<ExtStat>(ext.Values);
            res.Extensions.Sort(ExtBySizeDesc);
            res.Files = ScannedFiles;
            res.Seconds = sw.Elapsed.TotalSeconds;
            res.Cancelled = Cancel;
            return res;
        }

        static void Walk(DirNode node, string path)
        {
            if (Cancel) return;
            Current = path;
            WIN32_FIND_DATAW d;
            // 1 = FindExInfoBasic (ohne 8.3-Namen), 2 = FIND_FIRST_EX_LARGE_FETCH; \\?\ erlaubt lange Pfade
            IntPtr h = FindFirstFileExW("\\\\?\\" + path + "\\*", 1, out d, 0, IntPtr.Zero, 2);
            if (h == Invalid) { node.Denied = true; res.DeniedDirs++; return; }
            try
            {
                do
                {
                    string n = d.cFileName;
                    if (n == "." || n == "..") continue;
                    uint a = d.dwFileAttributes;
                    if ((a & AttrDirectory) != 0)
                    {
                        if ((a & AttrReparse) != 0) continue;   // Junction/Verknüpfung: Ziel wird woanders gezählt
                        DirNode c = new DirNode();
                        c.Name = n; c.Parent = node;
                        node.Children.Add(c);
                        res.Dirs++;
                        Walk(c, path + "\\" + n);
                        node.Size += c.Size; node.Files += c.Files;
                        if (Cancel) return;
                    }
                    else
                    {
                        long s = ((long)d.nFileSizeHigh << 32) | d.nFileSizeLow;
                        if ((a & (AttrOffline | AttrRecallOnOpen | AttrRecallOnAccess)) != 0) { res.CloudBytes += s; res.CloudFiles++; continue; }
                        node.OwnSize += s; node.OwnFiles++;
                        ScannedFiles++; ScannedBytes += s;
                        int dot = n.LastIndexOf('.');
                        string e = (dot > 0 && dot < n.Length - 1 && n.Length - dot <= 12) ? n.Substring(dot + 1).ToLowerInvariant() : "";
                        ExtStat es;
                        if (!ext.TryGetValue(e, out es)) { es = new ExtStat(); es.Ext = e; ext[e] = es; }
                        es.Size += s; es.Count++;
                        if (largest.Count < topN || s > minLargest)
                        {
                            FileEntry fe = new FileEntry();
                            fe.Path = path + "\\" + n; fe.Size = s;
                            long ft = ((long)(uint)d.ftLastWriteTime.dwHighDateTime << 32) | (long)(uint)d.ftLastWriteTime.dwLowDateTime;
                            try { fe.Modified = DateTime.FromFileTime(ft); } catch { }
                            largest.Add(fe);
                            if (largest.Count >= topN * 4)
                            {
                                largest.Sort(BySizeDesc);
                                largest.RemoveRange(topN, largest.Count - topN);
                                minLargest = largest[largest.Count - 1].Size;
                            }
                        }
                    }
                } while (FindNextFileW(h, out d));
            }
            finally { FindClose(h); }
            node.Size += node.OwnSize; node.Files += node.OwnFiles;
        }
    }
}
'@
}

# Laufwerke für die Speicherplatz-Analyse (fest eingebaut und Wechseldatenträger)
function Get-StorageDrives {
    @(Get-CimInstance Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object { $_.DriveType -in 2, 3 -and $_.Size -gt 0 } | Sort-Object DeviceID | ForEach-Object {
        [pscustomobject]@{ Drive = [string]$_.DeviceID; Label = [string]$_.VolumeName; Size = [long]$_.Size; Free = [long]$_.FreeSpace
                           System = ($_.DeviceID -eq $env:SystemDrive); Removable = ($_.DriveType -eq 2) }
    })
}

# Spiele und Programme mit Namen: Steam- und Epic-Manifeste, installierte Programme
function Get-StorageApps([string]$Drive, $Root) {
    $apps = New-Object System.Collections.ArrayList
    # Steam: jede Bibliothek hat steamapps\appmanifest_<id>.acf mit Name, Ordner und »zuletzt gespielt«
    $stack = New-Object System.Collections.Stack
    $stack.Push(@($Root, 0))
    while ($stack.Count -gt 0) {
        $e = $stack.Pop(); $n = $e[0]; $depth = $e[1]
        if ($n.Name -eq 'steamapps') {
            foreach ($f in @(Get-ChildItem -LiteralPath $n.Path -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue)) {
                try {
                    $t = [IO.File]::ReadAllText($f.FullName)
                    $get = { param($k) if ($t -match ('"' + $k + '"\s+"([^"]*)"')) { $Matches[1] } else { '' } }
                    $dir = & $get 'installdir'; if (-not $dir) { continue }
                    $lp = 0L; [void][long]::TryParse((& $get 'LastPlayed'), [ref]$lp)
                    [void]$apps.Add([pscustomobject]@{ Kind = 'steam'; Path = (Join-Path (Join-Path $n.Path 'common') $dir); Name = (& $get 'name'); Id = (& $get 'appid')
                                                       LastPlayed = $(if ($lp -gt 0) { [DateTimeOffset]::FromUnixTimeSeconds($lp).LocalDateTime } else { $null }); Uninstall = '' })
                } catch {}
            }
            continue
        }
        if ($depth -lt 5 -and $n.Name -notin 'Windows', 'WinSxS', 'AppData') { foreach ($c in $n.Children) { $stack.Push(@($c, $depth + 1)) } }
    }
    # Epic Games: Manifeste des Launchers
    $epic = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    foreach ($f in @(Get-ChildItem -LiteralPath $epic -Filter '*.item' -ErrorAction SilentlyContinue)) {
        try {
            $j = Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json
            if ($j.InstallLocation -and ([string]$j.InstallLocation).StartsWith($Drive, [StringComparison]::OrdinalIgnoreCase)) {
                [void]$apps.Add([pscustomobject]@{ Kind = 'epic'; Path = ([string]$j.InstallLocation).TrimEnd('\'); Name = [string]$j.DisplayName; Id = [string]$j.AppName; LastPlayed = $null; Uninstall = '' })
            }
        } catch {}
    }
    # Installierte Programme mit Installationsordner auf diesem Laufwerk
    foreach ($p in @(try { Get-InstalledPrograms $false } catch { })) {
        if ($p.InstallLocation -and $p.InstallLocation.Length -gt 3 -and $p.InstallLocation.StartsWith($Drive, [StringComparison]::OrdinalIgnoreCase)) {
            [void]$apps.Add([pscustomobject]@{ Kind = 'program'; Path = $p.InstallLocation; Name = $p.Name; Id = ''; LastPlayed = $null; Uninstall = $p.Name; Publisher = $p.Publisher })
        }
    }
    return $apps
}

# Analysiert ein Laufwerk; ergänzt belegten Platz laut Windows und Wiederherstellungspunkte
function Invoke-StorageScan([string]$Drive) {
    $drv = $Drive.Substring(0, 2)
    $scan = [TuneRig.DiskScan]::Scan($drv + '\', 400)
    Report 'Ordne Spiele und Programme zu …'
    $apps = @(Get-StorageApps $drv $scan.Root)
    $ld = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$drv'" -ErrorAction SilentlyContinue
    $shadow = 0L
    try {
        $vol = Get-CimInstance Win32_Volume -Filter "DriveLetter='$drv'" -ErrorAction Stop
        foreach ($s in @(Get-CimInstance Win32_ShadowStorage -ErrorAction Stop)) { if ($s.Volume.DeviceID -eq $vol.DeviceID) { $shadow += [long]$s.UsedSpace } }
    } catch {}
    [pscustomobject]@{ Drive = $drv; Label = [string]$ld.VolumeName; Size = [long]$ld.Size; Free = [long]$ld.FreeSpace; Shadow = $shadow
                       System = ($drv -eq $env:SystemDrive); Scan = $scan; Apps = $apps }
}

# ---------------------------------------------------------------------------
#  Allgemeine Helfer
# ---------------------------------------------------------------------------
function Report([string]$Text) { if ($Sync) { $Sync.Status = $Text } }

# Einfache Erklärungen ("Was kann ich tun?") und passende Aktionen für jedes Prüfergebnis.
# Aktionsziele: open:<Programm/URI>  goto:<Schritt>  web:<URL>  search:<Suchbegriff>  wu (Windows Update)  vendor (Grafik-Hersteller)  recheck
$script:FindingHelp = @(
    @{ P = '^Veraltete Windows-Version'; D = 'Windows Update öffnen und alle Updates installieren.'; B = 'Mehr Sicherheit, neue Funktionen und Leistungsverbesserungen.'; H = 'Öffne Windows Update und installiere alle angebotenen Updates. Ein großes Funktionsupdate (z. B. auf Windows 11) wird dort ebenfalls angeboten. Sichere vorher deine wichtigen Daten.'
       A = @(@{ L = 'Windows Update öffnen'; T = 'open:ms-settings:windowsupdate' }) }
    @{ P = '^Wenig Arbeitsspeicher'; D = 'Weniger Programme gleichzeitig öffnen. Dauerhaft hilft nur mehr RAM (16 GB).'; B = 'Der PC bleibt auch mit vielen offenen Programmen flüssig.'; H = 'Der Arbeitsspeicher (RAM) ist das Kurzzeitgedächtnis des PCs. Ist er voll, wird alles langsam. Sofort hilft: weniger Programme und Browser-Tabs gleichzeitig öffnen. Dauerhaft hilft: RAM aufrüsten. Welcher passt, steht im Handbuch deines PCs oder Mainboards.'
       A = @(@{ L = 'Task-Manager öffnen (zeigt die RAM-Auslastung)'; T = 'open:taskmgr.exe' }) }
    @{ P = '^Nur ein RAM-Modul'; D = 'Ein zweites, baugleiches RAM-Modul einbauen lassen.'; B = 'Bis zu doppelte Speichergeschwindigkeit – spürbar mehr FPS in Spielen.'; H = 'Ein zweites, baugleiches Modul einsetzen (gleiche Größe und Geschwindigkeit). Das ist eine Hardware-Änderung; ein PC-Fachhändler hilft gerne. Nicht dringend – der PC funktioniert auch so.'; A = @() }
    @{ P = '^Arbeitsspeicher läuft evtl'; D = 'Im BIOS das Speicherprofil XMP bzw. EXPO einschalten (nur für Erfahrene).'; B = 'Der Arbeitsspeicher läuft mit seiner vollen Geschwindigkeit.'; H = 'Im BIOS/UEFI (Einstellungsmenü beim Einschalten des PCs) kann das Speicherprofil XMP bzw. EXPO aktiviert werden. Wenn du unsicher bist, lass es einfach so – das ist nur eine Optimierung.'; A = @() }
    @{ P = '^BIOS/UEFI ist älter'; D = 'Nur bei Problemen: neuestes BIOS von der Herstellerseite installieren.'; B = 'Mehr Stabilität und Sicherheit.'; H = 'Such auf der Support-Seite des Mainboard- bzw. PC-Herstellers nach dem neuesten BIOS und befolge die Anleitung genau. Läuft dein PC stabil, ist das nicht dringend.'; A = @() }
    @{ P = '^Laufwerk meldet Probleme'; D = 'Sofort wichtige Dateien sichern und das Laufwerk tauschen lassen.'; B = 'Schutz vor Datenverlust.'; H = 'Sichere jetzt deine wichtigen Dateien (Fotos, Dokumente) auf einen USB-Stick, eine externe Festplatte oder in die Cloud. Lass das Laufwerk danach austauschen.'; A = @() }
    @{ P = 'Festplatte \(HDD\)'; D = 'Eine SSD einbauen lassen (z. B. beim PC-Fachhändler).'; B = 'Start und Programme werden um ein Vielfaches schneller.'; H = 'Eine SSD einbauen und Windows darauf umziehen. SSDs mit 500 GB sind heute günstig. Ein PC-Fachhändler übernimmt Einbau und Umzug auf Wunsch.'; A = @() }
    @{ P = '^Systemlaufwerk fast voll'; D = 'Im Schritt Aufräumen Platz schaffen und nicht genutzte Programme entfernen.'; B = 'Windows bleibt schnell und kann Updates installieren.'; H = 'Im Schritt Aufräumen löschst du unnötige Dateien mit einem Klick. Entferne außerdem Programme, die du nicht mehr nutzt, und verschiebe große Videos auf eine externe Festplatte.'
       A = @(@{ L = 'Zum Aufräumen'; T = 'goto:cleanup' }, @{ L = 'Programme deinstallieren'; T = 'goto:uninstall' }) }
    @{ P = '^(Fehlender Treiber|Geräteproblem)'; D = 'Bei Windows Update nach Treibern suchen.'; B = 'Das Gerät funktioniert wieder vollständig.'; H = 'Meist hilft eine Suche bei Windows Update. Findet Windows nichts, gibt es den Treiber auf der Webseite des Geräte- oder PC-Herstellers. Im Geräte-Manager ist das Gerät mit einem gelben Warnzeichen markiert.'
       A = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) }
    @{ P = '^(Kein Grafiktreiber|Grafiktreiber veraltet|Grafikkarte ohne Treiber)'; D = 'Das Treiber-Programm des Grafikkarten-Herstellers installieren.'; B = 'Volle Grafikleistung, richtige Auflösung, flüssige Spiele.'; H = 'Lade das kostenlose Treiber-Programm des Grafikkarten-Herstellers herunter. Es erkennt deine Grafikkarte automatisch, installiert den passenden Treiber und meldet künftige Updates von selbst.'
       A = @(@{ L = 'Treiber-Seite des Herstellers öffnen'; T = 'vendor' }) }
    @{ P = '^Nur integrierte Grafik'; D = 'Nichts nötig. In Spielen niedrigere Grafikdetails wählen.'; B = ''; H = 'Für einfache Spiele und Videos reicht das. In Spielen hilft es, niedrigere Grafikdetails und eine geringere Auflösung einzustellen. Für aktuelle 3D-Spiele wäre eine dedizierte Grafikkarte nötig.'; A = @() }
    @{ P = '^Monitor ist vermutlich am Mainboard'; D = 'Monitorkabel hinten am PC in die Grafikkarte stecken (die unteren Anschlüsse).'; B = 'Spiele nutzen die volle Grafikkarte - oft ein Vielfaches an FPS.'; H = 'PC herunterfahren, das Monitorkabel hinten abziehen und in einen Anschluss der Grafikkarte stecken. Das sind die waagerecht angeordneten Anschlüsse weiter unten am Gehäuse. PC wieder starten und hier auf Erneut prüfen klicken.'
       A = @(@{ L = 'Erneut prüfen'; T = 'recheck' }) }
    @{ P = '^(Hybrid-Grafik|Mehrere Grafikkarten)'; D = 'Spiele auf Hohe Leistung stellen.'; B = 'Spiele laufen auf der starken Grafikkarte.'; H = 'Stell deine Spiele auf Hohe Leistung. Im geführten Check geht das im Schritt Leistung mit einem Klick, unter Alle Werkzeuge › Leistung › Verwendete Grafikkarte.'; A = @() }
)

function New-Finding([int]$Level, [string]$Category, [string]$Title, [string]$Detail, [string]$Help = '', $Actions = $null, [string]$Do = '', [string]$Benefit = '') {
    foreach ($h in $script:FindingHelp) {
        if ($Title -match $h.P) {
            if (-not $Help) { $Help = $h.H }
            if ($null -eq $Actions) { $Actions = $h.A }
            if (-not $Do) { $Do = $h.D }
            if (-not $Benefit) { $Benefit = $h.B }
            break
        }
    }
    if ($null -eq $Actions) { $Actions = @() }
    [pscustomobject]@{ Level = $Level; Category = $Category; Title = $Title; Detail = $Detail; Help = $Help; Actions = @($Actions); Do = $Do; Benefit = $Benefit }
}

function Format-Bytes([double]$Bytes) {
    $u = 'B', 'KB', 'MB', 'GB', 'TB'; $i = 0
    while ($Bytes -ge 1024 -and $i -lt 4) { $Bytes /= 1024; $i++ }
    '{0:0.##} {1}' -f $Bytes, $u[$i]
}

function Get-RegValue([string]$Hive, [string]$Path, [string]$Name, $Default = $null) {
    try {
        $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
        $k = $root.OpenSubKey($Path)
        if (-not $k) { return $Default }
        $v = $k.GetValue($Name, $Default); $k.Close(); return $v
    } catch { return $Default }
}

function Set-RegDword([string]$Hive, [string]$Path, [string]$Name, [int]$Value) {
    $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
    $k = $root.CreateSubKey($Path)
    $k.SetValue($Name, $Value, [Microsoft.Win32.RegistryValueKind]::DWord); $k.Close()
}

function Set-RegString([string]$Hive, [string]$Path, [string]$Name, [string]$Value) {
    $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
    $k = $root.CreateSubKey($Path)
    $k.SetValue($Name, $Value, [Microsoft.Win32.RegistryValueKind]::String); $k.Close()
}

function Test-IsLaptop {
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
    $bat = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
    return (($cs -and $cs.PCSystemType -eq 2) -or $bat.Count -gt 0)
}

# ---------------------------------------------------------------------------
#  Wiederherstellungspunkt
# ---------------------------------------------------------------------------
function New-PCORestorePoint([string]$Description) {
    try {
        # Windows erlaubt sonst nur einen Punkt pro 24 Stunden
        Set-RegDword 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' 'SystemRestorePointCreationFrequency' 0
        try { Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue } catch {}
        Checkpoint-Computer -Description ("TuneRig: " + $Description) -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        return [pscustomobject]@{ Ok = $true; Message = 'Wiederherstellungspunkt wurde erstellt.' }
    } catch {
        return [pscustomobject]@{ Ok = $false; Message = 'Wiederherstellungspunkt konnte nicht erstellt werden: ' + $_.Exception.Message }
    }
}

function Get-PCORestorePoints {
    $types = @{ 0 = 'Programm installiert'; 1 = 'Programm deinstalliert'; 6 = 'Wiederherstellung'; 7 = 'Prüfpunkt'; 10 = 'Treiber installiert'; 12 = 'Einstellungen geändert'; 13 = 'Abgebrochen' }
    $list = @()
    foreach ($rp in @(Get-ComputerRestorePoint -ErrorAction SilentlyContinue)) {
        $date = $null
        try { $date = [Management.ManagementDateTimeConverter]::ToDateTime($rp.CreationTime) } catch {}
        $t = [int]$rp.RestorePointType
        $list += [pscustomobject]@{
            Sequence = [int]$rp.SequenceNumber; Description = [string]$rp.Description; Date = $date
            DateText = $(if ($date) { $date.ToString('dd.MM.yyyy  HH:mm') } else { '-' })
            Type = $(if ($types.ContainsKey($t)) { $types[$t] } else { "Typ $t" })
            ByUs = ([string]$rp.Description) -match '^(TuneRig|PC Optimizer)'
        }
    }
    $list | Sort-Object Sequence -Descending
}

function Remove-PCORestorePoints([int[]]$Sequences) {
    $ok = 0; $fail = 0
    foreach ($n in $Sequences) { if ([PCO.Native]::RemoveRestorePoint($n) -eq 0) { $ok++ } else { $fail++ } }
    [pscustomobject]@{ Ok = $ok; Failed = $fail }
}

# ---------------------------------------------------------------------------
#  System & Hardware
# ---------------------------------------------------------------------------
function Get-SystemAnalysis {
    $f = New-Object System.Collections.ArrayList
    $sum = New-Object System.Collections.ArrayList
    function S($l, $v) { [void]$sum.Add([pscustomobject]@{ Label = $l; Value = $v }) }

    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $cs = Get-CimInstance Win32_ComputerSystem
    $mem = @(Get-CimInstance Win32_PhysicalMemory)
    $board = Get-CimInstance Win32_BaseBoard
    $bios = Get-CimInstance Win32_BIOS
    $gpus = @(Get-CimInstance Win32_VideoController)
    $isLaptop = Test-IsLaptop

    S 'Betriebssystem' ("{0} ({1}), Build {2}" -f $os.Caption, $os.OSArchitecture, $os.BuildNumber)
    S 'Gerätetyp' $(if ($isLaptop) { 'Laptop' } else { 'Desktop-PC' })
    S 'Prozessor' ("{0} - {1} Kerne / {2} Threads" -f $cpu.Name.Trim(), $cpu.NumberOfCores, $cpu.NumberOfLogicalProcessors)

    $ramTotal = [long]$cs.TotalPhysicalMemory
    $speed = ($mem | Measure-Object -Property ConfiguredClockSpeed -Maximum).Maximum
    S 'Arbeitsspeicher' ("{0} in {1} Modul(en){2}" -f (Format-Bytes $ramTotal), $mem.Count, $(if ($speed) { ", $speed MT/s" } else { '' }))
    S 'Grafik' (($gpus | ForEach-Object { $_.Name }) -join "`n")
    S 'Mainboard' ("{0} {1}" -f $board.Manufacturer, $board.Product)
    S 'BIOS/UEFI' ("{0} vom {1:dd.MM.yyyy}" -f $bios.SMBIOSBIOSVersion, $bios.ReleaseDate)

    if ([int]$os.BuildNumber -lt 19045) {
        [void]$f.Add((New-Finding 2 'System' 'Veraltete Windows-Version' "Build $($os.BuildNumber) erhält keine Updates mehr. Ein Upgrade auf eine aktuelle Windows-Version wird empfohlen."))
    }
    if ($ramTotal -gt 0 -and $ramTotal -lt 8GB) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Wenig Arbeitsspeicher' 'Weniger als 8 GB RAM. Für Spiele und moderne Anwendungen sind 16 GB empfehlenswert.'))
    }
    if ($mem.Count -eq 1 -and $ramTotal -ge 8GB) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Nur ein RAM-Modul (Single-Channel)' 'Mit zwei gleichen Modulen (Dual-Channel) steigt die Speicherbandbreite deutlich. Das bringt vor allem bei integrierter Grafik und in Spielen mehr Leistung.'))
    }
    if (-not $isLaptop -and @(2133, 2400, 4800) -contains [int]$speed) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Arbeitsspeicher läuft evtl. nur mit Basistakt' "Der RAM läuft mit $speed MT/s (Standardtakt). Falls die Module schneller spezifiziert sind, kann im BIOS das Profil XMP (Intel) bzw. EXPO/DOCP (AMD) aktiviert werden. Das sollten nur erfahrene Nutzer tun."))
    }
    if ($bios.ReleaseDate -and $bios.ReleaseDate -lt (Get-Date).AddYears(-3)) {
        [void]$f.Add((New-Finding 1 'Treiber' 'BIOS/UEFI ist älter als 3 Jahre' ("Das BIOS stammt vom {0:dd.MM.yyyy}. Updates gibt es auf der Support-Seite von {1}. Achtung: Ein BIOS-Update darf nicht unterbrochen werden." -f $bios.ReleaseDate, $board.Manufacturer) '' @(@{ L = 'Support-Seite suchen'; T = ('search:' + $board.Manufacturer + ' ' + $board.Product + ' BIOS Download') })))
    }

    # Laufwerke
    $disks = @(Get-CimInstance -Namespace 'root\Microsoft\Windows\Storage' -ClassName MSFT_PhysicalDisk -ErrorAction SilentlyContinue)
    $diskText = @()
    foreach ($d in $disks) {
        $type = switch ([int]$d.MediaType) { 3 { 'HDD' } 4 { 'SSD' } default { 'Laufwerk' } }
        if ([int]$d.BusType -eq 17) { $type = 'NVMe-SSD' }
        $diskText += "{0} - {1}, {2}" -f $d.FriendlyName, $type, (Format-Bytes $d.Size)
        if (@(1, 2) -contains [int]$d.HealthStatus) {
            [void]$f.Add((New-Finding 3 'Hardware' 'Laufwerk meldet Probleme' "$($d.FriendlyName) meldet einen Warnstatus. Sichere deine wichtigen Daten so bald wie möglich."))
        }
    }
    S 'Laufwerke' ($diskText -join "`n")
    if ($diskText.Count -gt 0 -and -not ($diskText | Where-Object { $_ -notmatch 'HDD' })) {
        [void]$f.Add((New-Finding 2 'Hardware' 'Windows läuft auf einer Festplatte (HDD)' 'Eine SSD ist der größte einzelne Leistungsgewinn für ältere PCs: Start, Programme und Ladezeiten werden um ein Vielfaches schneller.'))
    }

    # Freier Speicher
    $sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'"
    if ($sys -and $sys.Size -gt 0) {
        $pct = [double]$sys.FreeSpace / $sys.Size * 100
        if ($pct -lt 10) {
            [void]$f.Add((New-Finding 2 'System' 'Systemlaufwerk fast voll' ("Auf {0} sind nur noch {1} ({2:0} %) frei. Unter 10 % wird Windows langsamer. Nutze die Bereinigung oder deinstalliere nicht benötigte Programme." -f $env:SystemDrive, (Format-Bytes $sys.FreeSpace), $pct)))
        } else {
            [void]$f.Add((New-Finding 0 'System' 'Genügend freier Speicher' ("{0} frei auf {1}" -f (Format-Bytes $sys.FreeSpace), $env:SystemDrive)))
        }
    }

    [pscustomobject]@{ Summary = $sum.ToArray(); Findings = $f.ToArray(); IsLaptop = $isLaptop }
}

# ---------------------------------------------------------------------------
#  Treiber
# ---------------------------------------------------------------------------
$script:DeviceErrors = @{
    1 = 'Gerät ist nicht richtig konfiguriert'; 3 = 'Treiber ist beschädigt'; 10 = 'Gerät kann nicht gestartet werden'
    12 = 'Nicht genügend freie Ressourcen'; 14 = 'Neustart erforderlich'; 18 = 'Treiber muss neu installiert werden'
    19 = 'Registrierungsfehler'; 21 = 'Gerät wird entfernt'; 22 = 'Gerät ist deaktiviert'
    24 = 'Gerät nicht vorhanden oder funktioniert nicht'; 28 = 'Kein Treiber installiert'; 29 = 'In der Firmware deaktiviert'
    31 = 'Treiber konnte nicht geladen werden'; 32 = 'Treiberdienst ist deaktiviert'; 37 = 'Treiber konnte nicht initialisiert werden'
    39 = 'Treiber fehlt oder ist beschädigt'; 43 = 'Gerät hat Probleme gemeldet'; 48 = 'Treiber wurde blockiert'; 52 = 'Treibersignatur ungültig'
}

# Hardware-Kategorien für die Treiberübersicht (Reihenfolge = Anzeige)
$script:DriverCategories = [ordered]@{
    DISPLAY     = 'Grafikkarte'
    MEDIA       = 'Sound / Audio'
    NET         = 'Netzwerk und WLAN'
    BLUETOOTH   = 'Bluetooth'
    SCSIADAPTER = 'Speicher-Controller (SSD / Festplatte)'
    HDC         = 'Speicher-Controller (SSD / Festplatte)'
    DISKDRIVE   = 'Laufwerke'
    SYSTEM      = 'Chipsatz und Mainboard'
    USB         = 'USB-Anschlüsse'
    CAMERA      = 'Kamera'
    IMAGE       = 'Kamera'
    BIOMETRIC   = 'Anmeldung (Fingerabdruck / Gesicht)'
    KEYBOARD    = 'Tastatur'
    MOUSE       = 'Maus und Touchpad'
    SENSOR      = 'Sensoren'
    SMARTCARDREADER = 'Kartenleser'
    SDHOST      = 'Kartenleser'
}

# Virtuelle bzw. reine Software-Geräte, die keinen eigenen Hardware-Treiber brauchen
$script:VirtualDeviceRx = 'WAN Miniport|Virtual|Virtuell|VPN|Hyper-V|Kernel Debug|Teredo|ISATAP|6to4|Wi-Fi Direct|TAP-|Loopback|RAS Async|Microsoft ISATAP|Remote NDIS|Bluetooth Device \(Personal|Bluetooth-Gerät \(PAN|Enumerator|RFCOMM|Root Hub|Stammhub|Generic USB Hub|Generischer USB-Hub|USB-Verbundgerät|USB Composite|Composite Device'

function Get-DriverAnalysis {
    $devices = New-Object System.Collections.ArrayList   # Übersicht aller Hardware-Komponenten
    $todo = New-Object System.Collections.ArrayList      # was der Nutzer tun muss
    $f = New-Object System.Collections.ArrayList         # Ergebnisse für die Übersicht / Expertenansicht

    Report 'Lese alle Geräte und ihre Treiber ... (dauert etwa 20 bis 60 Sekunden)'
    $drvById = @{}
    foreach ($d in @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue)) {
        if ($d.DeviceID) { $drvById[[string]$d.DeviceID] = $d }
    }

    foreach ($e in @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue)) {
        $id = [string]$e.DeviceID
        $cls = ([string]$e.PNPClass).ToUpper()
        $code = [int]$e.ConfigManagerErrorCode
        $name = if ($e.Name) { [string]$e.Name } else { 'Unbekanntes Gerät' }
        if ($code -eq 45) { continue }                                   # nicht angeschlossen
        $isHardware = $id -match '^(PCI|USB|HDAUDIO|INTELAUDIO|ACPI|SCSI|NVME|SD|HID)\\'
        $known = $script:DriverCategories.Contains($cls)

        # Geräte mit Problem immer aufnehmen; sonst nur echte Hardware der bekannten Kategorien
        if ($code -eq 0) {
            if (-not $known -or -not $isHardware) { continue }
            if ($name -match $script:VirtualDeviceRx) { continue }
            if ($cls -eq 'SYSTEM' -and $id -notmatch '^PCI\\') { continue }      # nur Chipsatz-Bauteile
            if ($cls -eq 'USB' -and $name -notmatch 'Controller|xHCI|eXtensible') { continue }
            if ($id -match '^HID\\' -and @('KEYBOARD', 'MOUSE') -notcontains $cls) { continue }
        }

        $cat = if ($known) { $script:DriverCategories[$cls] } else { 'Sonstige Geräte' }
        $drv = $drvById[$id]
        $ver = if ($drv) { [string]$drv.DriverVersion } else { '' }
        $prov = if ($drv) { [string]$drv.DriverProviderName } else { '' }
        $date = if ($drv -and $drv.DriverDate) { $drv.DriverDate } else { $null }
        $dateText = if ($date) { $date.ToString('dd.MM.yyyy') } else { '' }
        $lvl = 0; $status = ''

        if ($code -eq 28 -or $code -eq 1 -or $code -eq 18 -or $code -eq 39) {
            $lvl = 3; $status = 'Treiber fehlt'
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = "Treiber für $name installieren"; Kind = 'wu'; Device = $name; DeviceId = $id; Benefit = 'Das Gerät funktioniert wieder vollständig.'
                Detail = ("Für dieses Gerät fehlt der Treiber (Fehlercode $code). Es funktioniert deshalb nicht oder nur eingeschränkt." +
                          $(if ($name -match 'SM-?Bus|PCI-Gerät|PCI Device|PCI-Datenerfassung|PCI Simple|Coprocessor|Koprozessor|Unbekannt|Unknown') { ' Solche Geräte gehören meist zum Chipsatz: Dann hilft der Chipsatztreiber von AMD bzw. Intel oder von der Support-Seite deines Mainboard- bzw. PC-Herstellers.' } else { '' }))
                Actions = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) })
        } elseif ($code -eq 22) {
            $lvl = 1; $status = 'Gerät ist deaktiviert'
        } elseif ($code -ne 0) {
            $txt = if ($script:DeviceErrors.ContainsKey($code)) { $script:DeviceErrors[$code] } else { 'Unbekannter Fehler' }
            $lvl = 3; $status = "Fehler: $txt"
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = "Problem mit $name beheben"; Kind = 'wu'; Device = $name; DeviceId = $id; Benefit = 'Das Gerät funktioniert wieder zuverlässig.'
                Detail = "Das Gerät meldet: $txt (Code $code). Meist hilft es, den Treiber über Windows Update neu zu installieren und den PC neu zu starten."
                Actions = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) })
        } elseif ($cls -eq 'DISPLAY' -and $name -match 'Basic Display|Basisanzeige|Standard-VGA') {
            $lvl = 3; $status = 'Nur Windows-Standardtreiber - Grafiktreiber fehlt'
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = 'Grafiktreiber installieren'; Kind = 'vendor'; Device = $name; DeviceId = $id; Benefit = 'Volle Grafikleistung, richtige Auflösung, flüssige Spiele.'
                Detail = 'Die Grafikkarte läuft nur mit dem Microsoft-Standardtreiber. Spiele und Videos laufen so extrem langsam, oft ist nicht einmal die richtige Auflösung möglich.'
                Actions = @(@{ L = 'Treiber-Seite des Herstellers öffnen'; T = 'vendor' }) })
        } else {
            $status = 'Treiber installiert'
            $inbox = $prov -eq 'Microsoft' -or ($date -and $date.Year -le 2006)
            if ($inbox -and @('MEDIA', 'NET', 'BLUETOOTH') -contains $cls) {
                $lvl = 1; $status = 'Windows-Standardtreiber (funktioniert)'
            } elseif ($date -and -not $inbox -and ((Get-Date) - $date).TotalDays -gt 365 * 5) {
                $lvl = 1; $status = 'Treiber installiert (älter als 5 Jahre)'
            }
        }
        [void]$devices.Add([pscustomobject]@{ Category = $cat; Device = $name; Status = $status; Level = $lvl; Provider = $prov; Version = $ver; Date = $dateText; Class = $cls })
    }

    Report 'Prüfe, ob die Software der Grafikkarte installiert ist ...'
    $software = @(Get-GpuSoftwareCheck)
    foreach ($sw in $software) {
        [void]$devices.Add([pscustomobject]@{ Category = 'Grafikkarte'; Device = "Software: $($sw.Product)"; Status = $sw.Status; Level = $sw.Level; Provider = $sw.Vendor; Version = ''; Date = ''; Class = 'SOFTWARE' })
        if ($sw.Level -ge 2) {
            [void]$todo.Add([pscustomobject]@{ Level = $sw.Level; Title = "$($sw.Product) installieren"; Kind = 'software'; Device = $sw.Device; DeviceId = ''; Detail = $sw.Finding.Detail; Actions = $sw.Finding.Actions
                Benefit = 'Grafiktreiber bleiben automatisch aktuell; Einstellungen wie G-Sync/FreeSync und Spielprofile werden verfügbar.' })
        }
    }

    # Ergebnisse für Übersicht und Expertenansicht: ein Eintrag je Aufgabe, sonst eine Erfolgsmeldung
    foreach ($t in $todo) {
        [void]$f.Add((New-Finding $t.Level 'Treiber' $t.Title $t.Detail 'Nutze die Buttons bzw. den Reiter Treiber & Updates. Installiere Treiber nur aus offiziellen Quellen (Windows Update oder Hersteller).' $t.Actions ([string](@($t.Actions)[0].L)) ([string]$t.Benefit)))
    }
    if ($todo.Count -eq 0) {
        $okSw = @($software | Where-Object { $_.Level -eq 0 } | ForEach-Object { $_.Product })
        $extra = if ($okSw.Count) { ' Die Software der Grafikkarte ist ebenfalls installiert (' + ($okSw -join ', ') + ').' } else { '' }
        [void]$f.Add((New-Finding 0 'Treiber' 'Kein Handlungsbedarf bei den Treibern' ("Alle $(@($devices | Where-Object { $_.Class -ne 'SOFTWARE' }).Count) geprüften Hardware-Komponenten haben einen funktionierenden Treiber.$extra") '' @()))
    }

    # Gleichnamige Einträge zusammenfassen (z. B. mehrere 'HID-Tastatur'-Einträge einer Gaming-Tastatur)
    $grouped = foreach ($g in ($devices | Group-Object Category, Device, Status)) {
        $first = $g.Group[0]
        if ($g.Count -gt 1) { $first | Add-Member -NotePropertyName Device -NotePropertyValue ("{0}  ({1}x)" -f $first.Device, $g.Count) -Force }
        $first
    }
    $devices = @($grouped)
    $order = @{}; $n = 0; foreach ($v in $script:DriverCategories.Values) { if (-not $order.ContainsKey($v)) { $order[$v] = $n++ } }; $order['Sonstige Geräte'] = 99
    $sorted = @($devices | Sort-Object @{ e = { $order[$_.Category] } }, @{ e = { $_.Class -eq 'SOFTWARE' } }, Device)
    [pscustomobject]@{ Drivers = $sorted; Todo = $todo.ToArray(); Software = $software; Findings = $f.ToArray() }
}

# Herstellersoftware, die zu einer Grafikkarte gehört
$script:GpuSoftware = @(
    @{ Vendor = 'NVIDIA'; Ven = 'VEN_10DE'; Product = 'NVIDIA App'
       Names = '^NVIDIA App|GeForce Experience|NVIDIA Control Panel|NVIDIA Systemsteuerung'; Appx = 'NVIDIACorp\.NVIDIAControlPanel'
       Actions = @(@{ L = 'NVIDIA App herunterladen (offizielle Seite)'; T = 'web:https://www.nvidia.com/de-de/software/nvidia-app/' },
                   @{ L = 'NVIDIA Systemsteuerung (Microsoft Store)'; T = 'web:https://apps.microsoft.com/detail/9nf8h0h7wmlt' }) }
    @{ Vendor = 'AMD'; Ven = 'VEN_1002'; Product = 'AMD Software: Adrenalin Edition'
       Names = 'AMD Software|Radeon Software|AMD Radeon Settings|Adrenalin'; Appx = 'AMDRadeonSoftware'
       Actions = @(@{ L = 'AMD Software herunterladen (offizielle Seite)'; T = 'web:https://www.amd.com/de/support/download/drivers.html' }) }
    @{ Vendor = 'Intel'; Ven = 'VEN_8086'; Product = 'Intel Graphics Software bzw. Intel Graphics Command Center'
       Names = 'Intel.*(Graphics Command Center|Arc Control|Graphics Software)'; Appx = 'IntelGraphicsExperience|IntelArcSoftware|IntelGraphicsSoftware'
       Actions = @(@{ L = 'Intel Driver & Support Assistant (offizielle Seite)'; T = 'web:https://www.intel.de/content/www/de/de/support/detect.html' },
                   @{ L = 'Intel Graphics Command Center (Microsoft Store)'; T = 'web:https://apps.microsoft.com/detail/9plfnlnt3g5g' }) }
)

function Get-InstalledDisplayNames {
    $names = New-Object System.Collections.ArrayList
    foreach ($src in @(@('HKLM', '64'), @('HKLM', '32'), @('HKCU', 'Default'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]; $root = $bk.OpenSubKey($script:UninstallPath)
            if ($root) {
                foreach ($sub in $root.GetSubKeyNames()) {
                    $k = $root.OpenSubKey($sub)
                    if ($k) { $n = $k.GetValue('DisplayName'); if ($n) { [void]$names.Add([string]$n) }; $k.Close() }
                }
                $root.Close()
            }
            $bk.Close()
        } catch {}
    }
    return $names.ToArray()
}

# Prüft für jede Grafikkarte, ob die zugehörige Software des Herstellers installiert ist
function Get-GpuSoftwareCheck {
    $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object {
        ([string]$_.PNPDeviceID).ToUpper().StartsWith('PCI\') -and $_.Name -notmatch 'Basic Display|Basisanzeige|Standard-VGA' })
    if ($gpus.Count -eq 0) { return }
    $installed = @(Get-InstalledDisplayNames)
    $appx = @(Get-AppxPackage -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
    $done = @{}
    foreach ($g in $gpus) {
        $def = $script:GpuSoftware | Where-Object { ([string]$g.PNPDeviceID).ToUpper().Contains($_.Ven) } | Select-Object -First 1
        if (-not $def -or $done.ContainsKey($def.Vendor)) { continue }
        $done[$def.Vendor] = $true
        $hit = @($installed | Where-Object { $_ -match $def.Names }) + @($appx | Where-Object { $_ -match $def.Appx })
        if ($hit.Count -gt 0) {
            $what = ($hit | Select-Object -Unique | Select-Object -First 2) -join ', '
            [pscustomobject]@{ Vendor = $def.Vendor; Product = $def.Product; Device = $g.Name; Level = 0; Status = "Installiert: $what"
                Finding = (New-Finding 0 'Treiber' "Grafik-Software installiert ($($def.Vendor))" "$what - passend zu $($g.Name)." '' @()) }
        } else {
            $dedicated = $def.Vendor -ne 'Intel' -or $g.Name -match 'Arc(\(TM\))?\s+[AB]\d{3}'
            $lvl = if ($dedicated) { 3 } else { 2 }
            $detail = "Für deine Grafikkarte $($g.Name) ist die Software des Herstellers ($($def.Product)) zwingend erforderlich, sie ist aber nicht installiert. " +
                      'Ohne sie fehlen wichtige Einstellungen (z. B. Bildwiederholrate, G-Sync/FreeSync, Spielprofile), und neue Grafiktreiber werden nicht automatisch angeboten.'
            $help = 'Lade die Software ausschließlich über die Buttons bzw. die offizielle Seite des Herstellers herunter. Bei AMD und NVIDIA ist der passende Treiber im Installationspaket bereits enthalten. Starte den PC nach der Installation neu.'
            [pscustomobject]@{ Vendor = $def.Vendor; Product = $def.Product; Device = $g.Name; Level = $lvl; Status = 'Nicht installiert - erforderlich'
                Finding = (New-Finding $lvl 'Treiber' "Grafik-Software fehlt: $($def.Product)" $detail $help $def.Actions) }
        }
    }
}

function New-UpdateSearcher {
    $s = New-Object -ComObject Microsoft.Update.Session
    $s.ClientApplicationID = 'TuneRig'
    $q = $s.CreateUpdateSearcher()
    $q.Online = $true
    $q.ServerSelection = 2   # direkt bei Microsoft (auch wenn WSUS konfiguriert ist)
    return @($s, $q)
}

function Search-DriverUpdates {
    Report 'Suche bei Windows Update nach Treibern ... (1-3 Minuten)'
    $s, $q = New-UpdateSearcher
    $r = $q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
    $list = @()
    for ($i = 0; $i -lt $r.Updates.Count; $i++) {
        $u = $r.Updates.Item($i)
        $date = try { ([datetime]$u.DriverVerDate).ToString('dd.MM.yyyy') } catch { '-' }
        $list += [pscustomobject]@{ Id = $u.Identity.UpdateID; Title = $u.Title; Manufacturer = $u.DriverManufacturer; Class = $u.DriverClass; Date = $date }
    }
    return $list
}

function Install-DriverUpdates([string[]]$Ids) {
    Report 'Bereite Installation vor ...'
    $s, $q = New-UpdateSearcher
    $r = $q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
    $coll = New-Object -ComObject Microsoft.Update.UpdateColl
    for ($i = 0; $i -lt $r.Updates.Count; $i++) {
        $u = $r.Updates.Item($i)
        if ($Ids -contains $u.Identity.UpdateID) {
            if (-not $u.EulaAccepted) { $u.AcceptEula() }
            [void]$coll.Add($u)
        }
    }
    if ($coll.Count -eq 0) { return 'Die ausgewählten Updates werden nicht mehr angeboten.' }

    Report "Lade $($coll.Count) Treiber herunter ..."
    $dl = $s.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()

    Report 'Installiere Treiber ... (das kann einige Minuten dauern)'
    $inst = $s.CreateUpdateInstaller(); $inst.Updates = $coll
    $res = $inst.Install()
    $ok = 0
    for ($i = 0; $i -lt $coll.Count; $i++) { if (@(2, 3) -contains [int]$res.GetUpdateResult($i).ResultCode) { $ok++ } }
    $msg = "$ok von $($coll.Count) Treibern installiert."
    if ($res.RebootRequired) { $msg += ' Starte den PC neu.' }
    return $msg
}

# ---------------------------------------------------------------------------
#  Energiesparpläne
# ---------------------------------------------------------------------------
$script:PlanGuid = @{
    Balanced = '381b4222-f694-41f0-9685-ff5bb260df2e'
    High     = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
    Ultimate = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
}
$script:Overlay = @{
    Best     = 'ded574b5-45a0-4f42-8737-46345c09c238'
    Better   = '3af9b8d9-7c97-431d-ad78-34a8bfea439f'
    Balanced = '00000000-0000-0000-0000-000000000000'
    Battery  = '961cc777-2547-4f9d-8174-7d86181b8a7a'
}
$script:GuidRx = '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'

function Get-PowerPlans {
    $plans = @()
    foreach ($line in @(powercfg.exe /list)) {
        if ($line -match ($script:GuidRx + '\s+\((.+?)\)(\s*\*)?')) {
            $plans += [pscustomobject]@{ Guid = $Matches[1].ToLower(); Name = $Matches[2].Trim(); Active = [bool]$Matches[3] }
        }
    }
    return $plans
}

function Get-ActivePlan { Get-PowerPlans | Where-Object { $_.Active } | Select-Object -First 1 }

function Get-OverlayName {
    $g = [PCO.Native]::GetOverlay()
    if ($g -eq $script:Overlay.Best) { return 'Beste Leistung' }
    if ($g -eq $script:Overlay.Better) { return 'Bessere Leistung' }
    if ($g -eq $script:Overlay.Battery) { return 'Bessere Akkuleistung' }
    if ($g -eq $script:Overlay.Balanced) { return 'Ausbalanciert' }
    return 'unbekannt'

}

function Test-HighPerfPlan($p) {
    if (-not $p) { return $false }
    return ($p.Guid -eq $script:PlanGuid.High -or $p.Guid -eq $script:PlanGuid.Ultimate -or
            $p.Name -match 'Höchstleistung|Ultimat|High performance|Ultimate' -or
            ($p.Name -match 'Performance' -and $p.Name -notmatch 'Balanced'))
}

function Set-MaxPerformance {
    $plans = @(Get-PowerPlans)
    $ult = $plans | Where-Object { $_.Guid -eq $script:PlanGuid.Ultimate -or $_.Name -match 'Ultimat' } | Select-Object -First 1
    if (-not $ult) {
        $dup = (powercfg.exe -duplicatescheme $script:PlanGuid.Ultimate) -join ' '
        if ($dup -match $script:GuidRx) { $ult = [pscustomobject]@{ Guid = $Matches[1] } }
    }
    if ($ult) {
        powercfg.exe /setactive $ult.Guid | Out-Null
        if ((Get-ActivePlan).Guid -eq $ult.Guid.ToLower()) {
            [void][PCO.Native]::SetOverlay($script:Overlay.Best)
            return 'Energiesparplan Ultimative Leistung ist jetzt aktiv.'
        }
    }
    $high = $plans | Where-Object { $_.Guid -eq $script:PlanGuid.High } | Select-Object -First 1
    if (-not $high) {
        $dup = (powercfg.exe -duplicatescheme $script:PlanGuid.High) -join ' '
        if ($dup -match $script:GuidRx) { $high = [pscustomobject]@{ Guid = $Matches[1] } }
    }
    if ($high) {
        powercfg.exe /setactive $high.Guid | Out-Null
        if ((Get-ActivePlan).Guid -eq $high.Guid.ToLower()) {
            [void][PCO.Native]::SetOverlay($script:Overlay.Best)
            return 'Energiesparplan Höchstleistung ist jetzt aktiv.'
        }
    }
    # Modern-Standby-Geräte haben nur "Ausbalanciert" - dort den Energiemodus nutzen
    if ([PCO.Native]::SetOverlay($script:Overlay.Best)) {
        return 'Dieses Gerät unterstützt nur den Plan Ausbalanciert. Der Energiemodus wurde auf Beste Leistung gestellt.'
    }
    throw 'Der Energiesparplan konnte nicht geändert werden.'
}

# Wert einer Energieplan-Einstellung (Netzbetrieb) - sprachunabhängig:
# die letzten beiden 0x-Zeilen der Ausgabe sind "aktueller Wert Netz" und "aktueller Wert Akku"
function Get-PowerValue([string]$Sub, [string]$Setting) {
    $hex = @(powercfg.exe /query SCHEME_CURRENT $Sub $Setting | Where-Object { $_ -match ':\s*0x[0-9a-fA-F]+\s*$' })
    if ($hex.Count -lt 2) { return -1 }
    if ($hex[$hex.Count - 2] -match '0x([0-9a-fA-F]+)') { return [Convert]::ToInt32($Matches[1], 16) }
    return -1
}

function Set-PowerValue([string]$Sub, [string]$Setting, [int]$Value) {
    powercfg.exe /setacvalueindex SCHEME_CURRENT $Sub $Setting $Value | Out-Null
    powercfg.exe /setdcvalueindex SCHEME_CURRENT $Sub $Setting $Value | Out-Null
    powercfg.exe /setactive SCHEME_CURRENT | Out-Null
}

# ---------------------------------------------------------------------------
#  Windows-Einstellungen (Tweaks)
# ---------------------------------------------------------------------------
$script:PcieSub = '501a4d13-42af-4429-9fd1-a8218c268e20'; $script:PcieAspm = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
$script:UsbSub = '2a737441-1930-4402-8d77-b2bebba308a3'; $script:UsbSusp = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
$script:DxKey = 'Software\Microsoft\DirectX\UserGpuPreferences'

function Get-DxGlobal { [string](Get-RegValue 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' '') }

function Set-DxGlobalValue([string]$Key, [string]$Value) {
    $parts = [ordered]@{}
    foreach ($p in ((Get-DxGlobal) -split ';')) { if ($p -match '^(.+?)=(.*)$') { $parts[$Matches[1]] = $Matches[2] } }
    $parts[$Key] = $Value
    Set-RegString 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' ((($parts.Keys | ForEach-Object { "$_=$($parts[$_])" }) -join ';') + ';')
}

function Get-TweakDefs([bool]$IsLaptop) {
    $akku = if ($IsLaptop) { ' Hinweis Laptop: Der Akku hält damit spürbar kürzer.' } else { '' }
    @(
        @{ Id = 'power'; Target = 'Höchstleistung (Energiemodus: Beste Leistung)'; Title = 'Energiesparplan'; Problem = 'Der Prozessor drosselt sich, um Strom zu sparen.'; Benefit = 'Prozessor arbeitet mit voller Kraft - Programme und Spiele reagieren schneller.'; Fix = 'Auf Höchstleistung stellen'; Name = 'Energiesparplan: Maximale Leistung'; Optional = $false; Restart = $false
           Desc = 'Aktiviert Ultimative Leistung bzw. Höchstleistung und stellt den Energiemodus auf Beste Leistung. Der Prozessor taktet nicht mehr herunter.' + $akku
           Read = { $p = Get-ActivePlan; "Energiesparplan: $($p.Name)  ·  Energiemodus: $(Get-OverlayName)" }
           Check = {
               $p = Get-ActivePlan
               if (Test-HighPerfPlan $p) { return $true }
               return ($p.Guid -eq $script:PlanGuid.Balanced -and [PCO.Native]::GetOverlay() -eq $script:Overlay.Best -and @(Get-PowerPlans).Count -eq 1)
           }
           Apply = { Save-OdValue 'power|plan' ([string](Get-ActivePlan).Guid); Save-OdValue 'power|overlay' ([string][PCO.Native]::GetOverlay()); Set-MaxPerformance }
           Revert = {
               $h = Get-OdBackup
               $plan = if ($h.ContainsKey('power|plan')) { [string](Pop-OdValue 'power|plan') } else { $script:PlanGuid.Balanced }
               $ov = if ($h.ContainsKey('power|overlay')) { [string](Pop-OdValue 'power|overlay') } else { $script:Overlay.Balanced }
               if ($plan) { powercfg.exe /setactive $plan | Out-Null }
               if ($ov) { [void][PCO.Native]::SetOverlay($ov) } } }

        @{ Id = 'gamemode'; Target = 'Spielmodus einschalten'; Title = 'Spielmodus'; Problem = 'Windows bevorzugt laufende Spiele nicht.'; Benefit = 'Spiele bekommen Vorrang, Updates stören nicht beim Spielen.'; Fix = 'Einschalten'; Name = 'Spielmodus'; Optional = $false; Restart = $false
           Desc = 'Windows priorisiert laufende Spiele und unterdrückt Updates und Hintergrundaufgaben während des Spielens.'
           Read = { if ((Get-RegValue 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1) -eq 1) { 'Spielmodus ist eingeschaltet' } else { 'Spielmodus ist ausgeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1) -eq 1 }
           Apply = { Save-OrigReg 'gamemode|a' 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled'; Save-OrigReg 'gamemode|b' 'HKCU' 'Software\Microsoft\GameBar' 'AllowAutoGameMode'
                     Set-RegDword 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1; Set-RegDword 'HKCU' 'Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 }
           Revert = { Restore-OrigReg 'gamemode|a' 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' '__delete__'; Restore-OrigReg 'gamemode|b' 'HKCU' 'Software\Microsoft\GameBar' 'AllowAutoGameMode' '__delete__' } }

        @{ Id = 'hags'; Target = 'GPU-Planung einschalten'; Title = 'GPU-Planung (Grafikkarte)'; Problem = 'Windows verwaltet den Speicher der Grafikkarte selbst.'; Benefit = 'Etwas weniger Verzögerung in Spielen; nötig für DLSS Frame Generation.'; Fix = 'Einschalten'; Name = 'Hardwarebeschleunigte GPU-Planung (HAGS)'; Optional = $false; Restart = $true
           Desc = 'Die Grafikkarte verwaltet ihren Speicher selbst. Senkt die Latenz und ist Voraussetzung für DLSS Frame Generation. Benötigt einen Neustart.'
           Read = { switch (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0) { 2 { 'GPU-Planung ist eingeschaltet' } 1 { 'GPU-Planung ist ausgeschaltet' } default { 'Nicht festgelegt (der Treiber entscheidet)' } } }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0) -eq 2 }
           Apply = { Save-OrigReg 'hags' 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode'; Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2 }
           Revert = { Restore-OrigReg 'hags' 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' '__delete__' } }

        @{ Id = 'windowed'; Target = 'Optimierung einschalten'; Title = 'Spiele im Fenstermodus'; Problem = 'Spiele im Fenster nutzen eine ältere, langsamere Darstellung.'; Benefit = 'Weniger Verzögerung im Fenster- und randlosen Modus.'; Fix = 'Einschalten'; Name = 'Optimierungen für Spiele im Fenstermodus'; Optional = $false; Restart = $false
           Desc = 'Spiele im Fenster- oder randlosen Modus nutzen die moderne Darstellungsart: geringere Latenz, Auto-HDR und VRR möglich.'
           Read = { if ((Get-DxGlobal) -match 'SwapEffectUpgradeEnable=1;') { 'Optimierung ist eingeschaltet' } else { 'Optimierung ist ausgeschaltet (Windows-Standard)' } }
           Check = { (Get-DxGlobal) -match 'SwapEffectUpgradeEnable=1;' }
           Apply = { Save-OrigDx 'windowed' 'SwapEffectUpgradeEnable'; Set-DxGlobalValue 'SwapEffectUpgradeEnable' '1' }
           Revert = { Restore-OrigDx 'windowed' 'SwapEffectUpgradeEnable' } }

        @{ Id = 'gamedvr'; Target = 'Hintergrundaufnahme ausschalten'; Title = 'Xbox-Hintergrundaufnahme'; Problem = 'Windows nimmt beim Spielen ständig im Hintergrund auf.'; Benefit = 'Mehr Leistung in Spielen, weniger Last auf der Festplatte.'; Fix = 'Ausschalten'; Name = 'Hintergrundaufnahme der Xbox Game Bar'; Optional = $false; Restart = $false
           Desc = 'Die automatische Hintergrundaufnahme kostet dauerhaft Leistung. Wird deaktiviert; manuelle Aufnahmen bleiben möglich.'
           Read = { if ((Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0) -eq 1) { 'Hintergrundaufnahme ist eingeschaltet (kostet Leistung)' } else { 'Hintergrundaufnahme ist ausgeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0) -eq 0 }
           Apply = { Save-OrigReg 'gamedvr' 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled'; Set-RegDword 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0 }
           Revert = { Restore-OrigReg 'gamedvr' 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' '__delete__' } }

        @{ Id = 'pcie'; Target = 'Stromsparen ausschalten (volle Leistung)'; Title = 'Stromsparen von Grafikkarte und SSD'; Problem = 'Grafikkarte und SSD schalten zeitweise in einen Sparzustand.'; Benefit = 'Weniger Mikroruckler, schnellere Reaktion.'; Fix = 'Stromsparen ausschalten'; Name = 'PCI-Express-Energiesparmodus'; Optional = $false; Restart = $false
           Desc = 'Verhindert, dass Grafikkarte und NVMe-SSD im aktiven Energiesparplan in Stromsparzustände wechseln (vermeidet Mikroruckler).'
           Read = { switch (Get-PowerValue $script:PcieSub $script:PcieAspm) { 0 { 'Energiesparen ist ausgeschaltet (volle Leistung)' } 1 { 'Mittlere Energieeinsparung ist eingeschaltet' } 2 { 'Maximale Energieeinsparung ist eingeschaltet' } default { 'unbekannt' } } }
           Check = { (Get-PowerValue $script:PcieSub $script:PcieAspm) -eq 0 }
           Apply = { Save-OrigPower 'pcie' $script:PcieSub $script:PcieAspm; Set-PowerValue $script:PcieSub $script:PcieAspm 0 }
           Revert = { Restore-OrigPower 'pcie' $script:PcieSub $script:PcieAspm $null } }

        @{ Id = 'usb'; Target = 'USB-Energiesparen ausschalten'; Title = 'Stromsparen bei USB-Geräten'; Problem = 'USB-Geräte (z. B. Maus, Headset usw.) werden zeitweise abgeschaltet.'; Benefit = 'Keine Aussetzer oder Verbindungsabbrüche bei USB-Geräten.'; Fix = 'Stromsparen ausschalten'; Name = 'USB: Selektives Energiesparen'; Optional = $false; Restart = $false
           Desc = 'Verhindert, dass USB-Geräte (z. B. Maus, Headset usw.) zum Stromsparen abgeschaltet werden. Vermeidet Aussetzer und Verbindungsabbrüche.'
           Read = { switch (Get-PowerValue $script:UsbSub $script:UsbSusp) { 0 { 'USB-Energiesparen ist ausgeschaltet' } -1 { 'unbekannt' } default { 'USB-Energiesparen ist eingeschaltet' } } }
           Check = { (Get-PowerValue $script:UsbSub $script:UsbSusp) -eq 0 }
           Apply = { Save-OrigPower 'usb' $script:UsbSub $script:UsbSusp; Set-PowerValue $script:UsbSub $script:UsbSusp 0 }
           Revert = { Restore-OrigPower 'usb' $script:UsbSub $script:UsbSusp $null } }

        @{ Id = 'visual'; Target = 'Für optimale Leistung'; Title = 'Windows-Animationen'; Problem = 'Animationen und Schatten kosten etwas Leistung.'; Benefit = 'Etwas schnellere Bedienung auf schwachen PCs - sieht dafür schlichter aus.'; Fix = 'Auf Leistung stellen'; Name = 'Visuelle Effekte auf Leistung optimieren'; Optional = $true; Restart = $false
           Desc = 'Optional: Schaltet Animationen und Schatten von Windows ab. Bringt auf schwachen PCs etwas, sieht aber schlichter aus.'
           Read = { switch (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) { 2 { 'Eingestellt auf: Für optimale Leistung' } 1 { 'Eingestellt auf: Für optimale Darstellung' } 3 { 'Eingestellt auf: Benutzerdefiniert' } default { 'Eingestellt auf: Automatisch (Windows-Standard)' } } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) -eq 2 }
           Apply = { Save-OrigReg 'visual' 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting'; Set-RegDword 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 2 }
           Revert = { Restore-OrigReg 'visual' 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' '__delete__' } }
    )
}

function Get-Tweaks([bool]$IsLaptop) {
    foreach ($t in Get-TweakDefs $IsLaptop) {
        $state = try { [string](& $t.Read) } catch { 'Fehler: ' + $_.Exception.Message }
        $ok = try { [bool](& $t.Check) } catch { $false }
        [pscustomobject]@{ Id = $t.Id; Name = $t.Name; Title = $t.Title; Problem = $t.Problem; Benefit = $t.Benefit; Fix = $t.Fix; Target = $t.Target
                           Desc = $t.Desc; State = $state; Optimal = $ok; Optional = $t.Optional; Restart = $t.Restart }
    }
}

function Invoke-Tweaks([string[]]$Ids) { Invoke-AllSettings $Ids }

# ---------------------------------------------------------------------------
#  Grafikkarten
# ---------------------------------------------------------------------------
function Get-VramMap {
    $map = @{}
    $cls = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    foreach ($k in @(Get-ChildItem $cls -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' })) {
        try {
            $p = Get-ItemProperty $k.PSPath -ErrorAction Stop
            $desc = $p.DriverDesc
            if (-not $desc) { continue }
            $v = $p.'HardwareInformation.qwMemorySize'
            if ($null -eq $v) { $v = $p.'HardwareInformation.MemorySize' }
            $size = 0
            if ($v -is [byte[]]) { $size = if ($v.Length -ge 8) { [BitConverter]::ToInt64($v, 0) } else { [BitConverter]::ToUInt32($v, 0) } }
            elseif ($v -is [int]) { $size = [long][BitConverter]::ToUInt32([BitConverter]::GetBytes($v), 0) }
            elseif ($null -ne $v) { $size = [long]$v }
            if ($size -gt 0 -and (-not $map.ContainsKey($desc) -or $map[$desc] -lt $size)) { $map[$desc] = $size }
        } catch {}
    }
    return $map
}

function Get-GpuAnalysis([bool]$IsLaptop) {
    $gpus = @(); $f = New-Object System.Collections.ArrayList
    $vram = Get-VramMap
    foreach ($v in @(Get-CimInstance Win32_VideoController)) {
        $pnp = [string]$v.PNPDeviceID
        if (-not $pnp.ToUpper().StartsWith('PCI\')) { continue }   # virtuelle Adapter überspringen
        $vendor = if ($pnp -match 'VEN_10DE') { 'NVIDIA' } elseif ($pnp -match 'VEN_1002') { 'AMD' } elseif ($pnp -match 'VEN_8086') { 'Intel' } else { 'Unbekannt' }
        $mem = if ($vram.ContainsKey($v.Name)) { $vram[$v.Name] } else { [long]$v.AdapterRAM }
        $basic = $v.Name -match 'Basic Display|Basisanzeige|Standard-VGA'
        $discrete = ($vendor -eq 'NVIDIA') -or ($v.Name -match 'Arc(\(TM\))?\s+[AB]\d{3}') -or
                    ($vendor -eq 'AMD' -and $v.Name -match '\bRX\s?\d{3,4}|Radeon\s?Pro') -or
                    ($vendor -ne 'Intel' -and $mem -ge 2GB)
        $w = [int]$v.CurrentHorizontalResolution
        $gpus += [pscustomobject]@{
            Name = $v.Name; Vendor = $vendor; Discrete = [bool]$discrete; Vram = $mem
            Driver = $v.DriverVersion; DriverDate = $(if ($v.DriverDate) { $v.DriverDate.ToString('dd.MM.yyyy') } else { '-' })
            Display = ($w -gt 0); Resolution = $(if ($w -gt 0) { "{0}x{1} @ {2} Hz" -f $w, $v.CurrentVerticalResolution, $v.CurrentRefreshRate } else { '' })
            HasDriver = -not $basic
        }
    }

    $ded = @($gpus | Where-Object { $_.Discrete }); $int = @($gpus | Where-Object { -not $_.Discrete })
    foreach ($g in @($gpus | Where-Object { -not $_.HasDriver })) {
        [void]$f.Add((New-Finding 3 'Grafik' 'Grafikkarte ohne Treiber' "$($g.Name) läuft mit dem Windows-Standardtreiber. Installiere den Treiber des Herstellers."))
    }
    if ($gpus.Count -eq 0) {
        [void]$f.Add((New-Finding 2 'Grafik' 'Keine Grafikkarte erkannt' 'Die Grafikkarten konnten nicht ausgelesen werden.'))
    } elseif ($ded.Count -eq 0) {
        [void]$f.Add((New-Finding 1 'Grafik' 'Nur integrierte Grafik vorhanden' 'Es wurde keine dedizierte Grafikkarte gefunden. Für anspruchsvolle Spiele ist die Leistung begrenzt.'))
    } elseif ($gpus.Count -eq 1) {
        [void]$f.Add((New-Finding 0 'Grafik' 'Eine dedizierte Grafikkarte' "$($ded[0].Name) wird für alle Anwendungen genutzt."))
    } elseif (-not $IsLaptop -and ($int | Where-Object { $_.Display }) -and -not ($ded | Where-Object { $_.Display })) {
        [void]$f.Add((New-Finding 3 'Grafik' 'Monitor ist vermutlich am Mainboard angeschlossen' ("Das Bild wird über die integrierte Grafik ({0}) ausgegeben, nicht über {1}. Steck das Monitorkabel hinten am PC in die Anschlüsse der Grafikkarte (meist weiter unten, waagerecht angeordnet) – nicht in die Anschlüsse neben USB/LAN. Das ist einer der häufigsten Gründe für schlechte Spieleleistung." -f $int[0].Name, $ded[0].Name)))
    } else {
        $t = if ($IsLaptop) { 'Hybrid-Grafik (Laptop)' } else { 'Mehrere Grafikkarten' }
        [void]$f.Add((New-Finding 1 'Grafik' $t ("Leistungsstark: {0}; stromsparend: {1}. Windows entscheidet pro Programm, welche Karte genutzt wird. Stell deine Spiele auf Hohe Leistung (geführter Check: Schritt Leistung)." -f (($ded | ForEach-Object Name) -join ', '), (($int | ForEach-Object Name) -join ', '))))
    }
    [pscustomobject]@{ Gpus = $gpus; Findings = $f.ToArray() }
}

$script:JunkExe = '^(unins|uninstall|setup|install|vcredist|vc_redist|dxsetup|dxwebsetup|crash|report|ue4prereq|easyanticheat|eac|be(service)?_|battleye|launcherpatcher|redist|dotnet|oalinst|physx|touchup|cleanup|activation|update)'

function Find-MainExe([string]$Folder) {
    if (-not $Folder -or -not (Test-Path -LiteralPath $Folder)) { return $null }
    $exe = Get-ChildItem -LiteralPath $Folder -Filter *.exe -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notmatch $script:JunkExe -and $_.FullName -notmatch '\\(_|redist|support|directx|vcredist)[^\\]*\\' } |
        Sort-Object Length -Descending | Select-Object -First 1
    if ($exe) { return $exe.FullName } else { return $null }
}

function Get-GpuPreference([string]$Exe) {
    $data = [string](Get-RegValue 'HKCU' $script:DxKey $Exe '')
    if ($data -match 'GpuPreference=(\d)') {
        switch ($Matches[1]) { '2' { return 'Hohe Leistung' } '1' { return 'Energiesparen' } }
    }
    return 'Windows entscheidet'
}

function Set-GpuHighPerformance([string]$Exe) {
    $existing = [string](Get-RegValue 'HKCU' $script:DxKey $Exe '')
    $parts = @('GpuPreference=2') + @(($existing -split ';') | Where-Object { $_ -and $_ -notmatch '^GpuPreference=' })
    Set-RegString 'HKCU' $script:DxKey $Exe (($parts -join ';') + ';')
}

function Find-Games {
    $games = @()
    # Steam
    $steam = Get-RegValue 'HKCU' 'Software\Valve\Steam' 'SteamPath' $null
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $libs = @($steam)
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"(.+?)"')) { $libs += $m.Groups[1].Value -replace '\\\\', '\' }
        }
        foreach ($lib in ($libs | Select-Object -Unique)) {
            $apps = Join-Path $lib 'steamapps'
            foreach ($acf in @(Get-ChildItem -LiteralPath $apps -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue)) {
                $txt = Get-Content -LiteralPath $acf.FullName -Raw -ErrorAction SilentlyContinue
                if ($txt -notmatch '"name"\s+"(.+?)"') { continue }; $name = $Matches[1]
                if ($txt -notmatch '"installdir"\s+"(.+?)"') { continue }; $dir = $Matches[1]
                if ($name -match 'Redistributable|^Steamworks|^Proton|SteamVR') { continue }
                Report "Suche Spiele: $name"
                $exe = Find-MainExe (Join-Path $apps "common\$dir")
                if ($exe) { $games += [pscustomobject]@{ Name = $name; Source = 'Steam'; Exe = $exe } }
            }
        }
    }
    # Epic Games
    $epic = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    foreach ($item in @(Get-ChildItem -LiteralPath $epic -Filter *.item -ErrorAction SilentlyContinue)) {
        try {
            $j = Get-Content -LiteralPath $item.FullName -Raw | ConvertFrom-Json
            $exe = Join-Path $j.InstallLocation $j.LaunchExecutable
            if (-not (Test-Path -LiteralPath $exe)) { $exe = Find-MainExe $j.InstallLocation }
            if ($exe) { $games += [pscustomobject]@{ Name = $j.DisplayName; Source = 'Epic Games'; Exe = $exe } }
        } catch {}
    }
    # GOG
    foreach ($k in @(Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games' -ErrorAction SilentlyContinue)) {
        $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
        if ($p.exe -and (Test-Path -LiteralPath $p.exe)) { $games += [pscustomobject]@{ Name = $p.gameName; Source = 'GOG'; Exe = $p.exe } }
    }

    $games | Sort-Object Exe -Unique | Sort-Object Name | ForEach-Object {
        $_ | Add-Member -NotePropertyName Preference -NotePropertyValue (Get-GpuPreference $_.Exe) -PassThru
    }
}

# ---------------------------------------------------------------------------
#  Bereinigung
# ---------------------------------------------------------------------------
function Get-OldFiles([string]$Dir, [string]$Filter = '*', [double]$MinAgeHours = 0, [switch]$NoRecurse) {
    if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return }
    $cut = (Get-Date).AddHours(-$MinAgeHours)
    Get-ChildItem -LiteralPath $Dir -Filter $Filter -File -Force -Recurse:(-not $NoRecurse) -ErrorAction SilentlyContinue |
        Where-Object { $MinAgeHours -le 0 -or $_.LastWriteTime -lt $cut }
}

function Get-ChromiumCache([string]$UserData) {
    if (-not (Test-Path -LiteralPath $UserData)) { return }
    foreach ($p in @(Get-ChildItem -LiteralPath $UserData -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })) {
        Get-OldFiles (Join-Path $p.FullName 'Cache'); Get-OldFiles (Join-Path $p.FullName 'Code Cache'); Get-OldFiles (Join-Path $p.FullName 'GPUCache')
    }
}

# Nur anzeigen, was diesen PC betrifft: Browser-Caches nur für installierte Browser,
# Shader-Caches nur für den Hersteller der eingebauten Grafikkarte
function Test-CleanupRelevant([string]$Id) {
    $local = $env:LOCALAPPDATA
    if ($null -eq $script:GpuNamesCache) {
        $script:GpuNamesCache = (@(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ' ')
    }
    $r = switch ($Id) {
        'browser-chrome'  { Test-Path -LiteralPath "$local\Google\Chrome\User Data" }
        'browser-edge'    { Test-Path -LiteralPath "$local\Microsoft\Edge\User Data" }
        'browser-brave'   { Test-Path -LiteralPath "$local\BraveSoftware\Brave-Browser\User Data" }
        'browser-firefox' { Test-Path -LiteralPath "$local\Mozilla\Firefox\Profiles" }
        'shader-nvidia'   { $script:GpuNamesCache -match 'NVIDIA' }
        'shader-amd'      { $script:GpuNamesCache -match 'AMD|Radeon' }
        default           { $true }
    }
    return [bool]$r
}

function Get-CleanupDefs { @(Get-AllCleanupDefs | Where-Object { Test-CleanupRelevant $_.Id }) }

function Get-AllCleanupDefs {
    @(
        [pscustomobject]@{ Id = 'usertemp'; Sel = $true;  Name = 'Temporäre Dateien (Benutzer)'; Desc = 'Reste von Installationen und Programmen im Benutzer-Temp-Ordner (älter als 24 Std.).' }
        [pscustomobject]@{ Id = 'wintemp';  Sel = $true;  Name = 'Temporäre Dateien (Windows)'; Desc = 'Inhalt von C:\Windows\Temp (älter als 24 Std.).' }
        [pscustomobject]@{ Id = 'wudl';     Sel = $true;  Name = 'Windows-Update-Downloads'; Desc = 'Bereits installierte Update-Pakete. Der Update-Dienst wird dafür kurz angehalten.' }
        [pscustomobject]@{ Id = 'do';       Sel = $true;  Name = 'Übermittlungsoptimierung'; Desc = 'Zwischenspeicher, mit dem Windows Updates an andere PCs verteilt.' }
        [pscustomobject]@{ Id = 'wer';      Sel = $true;  Name = 'Fehlerberichte und Speicherabbilder'; Desc = 'Windows-Fehlerberichte, Minidumps und Absturzabbilder von Programmen.' }
        [pscustomobject]@{ Id = 'thumbs';   Sel = $true;  Name = 'Miniaturansichten-Cache'; Desc = 'Vorschaubilder des Explorers. Werden bei Bedarf automatisch neu erstellt.' }
        [pscustomobject]@{ Id = 'logs';     Sel = $true;  Name = 'Alte Windows-Protokolle'; Desc = 'Log-Dateien in C:\Windows\Logs, die älter als 14 Tage sind.' }
        [pscustomobject]@{ Id = 'browser-chrome';  Group = 'browser'; Sel = $true; Short = 'Google Chrome'; Name = 'Browser-Cache: Google Chrome'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Chrome.' }
        [pscustomobject]@{ Id = 'browser-edge';    Group = 'browser'; Sel = $true; Short = 'Microsoft Edge'; Name = 'Browser-Cache: Microsoft Edge'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Edge.' }
        [pscustomobject]@{ Id = 'browser-brave';   Group = 'browser'; Sel = $true; Short = 'Brave'; Name = 'Browser-Cache: Brave'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Brave.' }
        [pscustomobject]@{ Id = 'browser-firefox'; Group = 'browser'; Sel = $true; Short = 'Mozilla Firefox'; Name = 'Browser-Cache: Mozilla Firefox'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Firefox.' }
        [pscustomobject]@{ Id = 'recycle';  Sel = $false; Name = 'Papierkorb'; Desc = 'Leert den Papierkorb aller Laufwerke.' }
        [pscustomobject]@{ Id = 'shader-dx';     Group = 'shader'; Sel = $false; Short = 'DirectX (Windows)'; Name = 'Shader-Cache: DirectX (Windows)'; Desc = 'Vorbereitete Grafikdaten von DirectX-Spielen.' }
        [pscustomobject]@{ Id = 'shader-nvidia'; Group = 'shader'; Sel = $false; Short = 'NVIDIA'; Name = 'Shader-Cache: NVIDIA'; Desc = 'Vorbereitete Grafikdaten des NVIDIA-Treibers.' }
        [pscustomobject]@{ Id = 'shader-amd';    Group = 'shader'; Sel = $false; Short = 'AMD'; Name = 'Shader-Cache: AMD'; Desc = 'Vorbereitete Grafikdaten des AMD-Treibers.' }
        [pscustomobject]@{ Id = 'winsxs';   Sel = $false; Name = 'Komponentenspeicher (WinSxS) bereinigen'; Desc = 'Optional: entfernt alte Versionen von Windows-Komponenten mit DISM. Dauert 5-20 Minuten.' }
    )
}

# Beschreibung der Cache-Gruppen (im geführten Check als aufklappbare Gruppe mit Unterpunkten)
$script:CleanupGroups = @{
    browser = @{ Name = 'Browser-Cache'; Desc = 'Nur zwischengespeicherte Webseiten-Dateien. Passwörter, Verlauf und Cookies bleiben erhalten. Am besten die Browser vorher schließen.' }
    shader  = @{ Name = 'Shader-Cache (Spiele)'; Desc = 'Spiele speichern hier vorbereitete Grafikdaten, damit sie flüssiger laufen. Löschen nur bei Problemen: wenn ein Spiel nach einem Spiel- oder Treiber-Update bzw. nach Abstürzen dauerhaft ruckelt oder Grafikfehler zeigt. Danach ruckeln Spiele beim ersten Start kurz, bis der Cache neu aufgebaut ist.' }
}

function Get-CleanupFiles([string]$Id) {
    $local = $env:LOCALAPPDATA; $win = $env:windir
    switch ($Id) {
        'usertemp' { Get-OldFiles $env:TEMP -MinAgeHours 24 }
        'wintemp'  { Get-OldFiles "$win\Temp" -MinAgeHours 24 }
        'wudl'     { Get-OldFiles "$win\SoftwareDistribution\Download" }
        'do'       { Get-OldFiles "$win\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache" }
        'wer'      {
            Get-OldFiles "$env:ProgramData\Microsoft\Windows\WER\ReportArchive"
            Get-OldFiles "$env:ProgramData\Microsoft\Windows\WER\ReportQueue"
            Get-OldFiles "$local\Microsoft\Windows\WER"
            Get-OldFiles "$local\CrashDumps"
            Get-OldFiles "$win\Minidump"
            if (Test-Path -LiteralPath "$win\MEMORY.DMP") { Get-Item -LiteralPath "$win\MEMORY.DMP" -Force }
        }
        'thumbs'   { Get-OldFiles "$local\Microsoft\Windows\Explorer" 'thumbcache_*.db' -NoRecurse; Get-OldFiles "$local\Microsoft\Windows\Explorer" 'iconcache_*.db' -NoRecurse }
        'logs'     { Get-OldFiles "$win\Logs" '*.log' (24 * 14); Get-OldFiles "$win\Logs" '*.etl' (24 * 14); Get-OldFiles "$win\Logs\CBS" '*.cab' (24 * 14) }
        'browser-chrome'  { Get-ChromiumCache "$local\Google\Chrome\User Data" }
        'browser-edge'    { Get-ChromiumCache "$local\Microsoft\Edge\User Data" }
        'browser-brave'   { Get-ChromiumCache "$local\BraveSoftware\Brave-Browser\User Data" }
        'browser-firefox' { foreach ($p in @(Get-ChildItem "$local\Mozilla\Firefox\Profiles" -Directory -ErrorAction SilentlyContinue)) { Get-OldFiles (Join-Path $p.FullName 'cache2') } }
        'shader-dx'       { Get-OldFiles "$local\D3DSCache" }
        'shader-nvidia'   { Get-OldFiles "$local\NVIDIA\DXCache"; Get-OldFiles "$local\NVIDIA\GLCache"; Get-OldFiles "$local\NVIDIA Corporation\NV_Cache" }
        'shader-amd'      { Get-OldFiles "$local\AMD\DxCache"; Get-OldFiles "$local\AMD\DxcCache"; Get-OldFiles "$local\AMD\VkCache" }
    }
}

function Measure-Cleanup([string]$Id) {
    if ($Id -eq 'recycle') { $r = [PCO.Native]::QueryRecycleBin(); return [pscustomobject]@{ Id = $Id; Size = $r[0]; Count = $r[1] } }
    if ($Id -eq 'winsxs') { return [pscustomobject]@{ Id = $Id; Size = 0; Count = 0 } }
    $m = Get-CleanupFiles $Id | Measure-Object -Property Length -Sum
    [pscustomobject]@{ Id = $Id; Size = [long]$m.Sum; Count = [int]$m.Count }
}

function Remove-EmptyDirs([string]$Root) {
    if (-not (Test-Path -LiteralPath $Root)) { return }
    Get-ChildItem -LiteralPath $Root -Directory -Recurse -Force -ErrorAction SilentlyContinue |
        Sort-Object { $_.FullName.Length } -Descending |
        ForEach-Object { try { if (-not (Get-ChildItem -LiteralPath $_.FullName -Force -ErrorAction Stop)) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } } catch {} }
}

function Invoke-Cleanup([string]$Id) {
    $win = $env:windir
    switch ($Id) {
        'recycle' { $r = [PCO.Native]::QueryRecycleBin(); [PCO.Native]::EmptyRecycleBin(); return [long]$r[0] }
        'winsxs' {
            $before = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace
            dism.exe /Online /Cleanup-Image /StartComponentCleanup | Out-Null
            $after = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace
            return [Math]::Max(0, [long]$after - [long]$before)
        }
        'do' {
            $before = (Measure-Cleanup 'do').Size
            try { Delete-DeliveryOptimizationCache -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
            return [Math]::Max(0, $before - (Measure-Cleanup 'do').Size)
        }
    }
    if ($Id -eq 'wudl') { Stop-Service wuauserv, bits -Force -ErrorAction SilentlyContinue }
    $freed = 0L
    try {
        foreach ($file in @(Get-CleanupFiles $Id)) {
            try {
                $len = $file.Length
                if ($file.IsReadOnly) { $file.IsReadOnly = $false }
                $file.Delete()
                $freed += $len
            } catch {}   # Datei in Benutzung - überspringen
        }
        switch ($Id) {
            'usertemp' { Remove-EmptyDirs $env:TEMP }
            'wintemp'  { Remove-EmptyDirs "$win\Temp" }
            'wudl'     { Remove-EmptyDirs "$win\SoftwareDistribution\Download" }
        }
    } finally {
        if ($Id -eq 'wudl') { Start-Service bits, wuauserv -ErrorAction SilentlyContinue }
    }
    return $freed
}

function Get-RunningBrowsers {
    $map = @{ chrome = 'Google Chrome'; msedge = 'Microsoft Edge'; brave = 'Brave'; firefox = 'Mozilla Firefox' }
    foreach ($k in $map.Keys) { if (Get-Process -Name $k -ErrorAction SilentlyContinue) { $map[$k] } }
}

# Junk-Dateien auf allen Laufwerken
function Find-JunkFiles {
    $junkRx = New-Object regex '(\.(tmp|temp|_mp|~mp|gid|chk|dmp|\$\$\$|---)$)|(^thumbs\.db$)', 'IgnoreCase'
    $cut = (Get-Date).AddDays(-7)
    $excludeFull = @($env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData) | Where-Object { $_ }
    $excludeNames = '$Recycle.Bin', 'System Volume Information', 'Recovery', '$WinREAgent', 'Windows.old', 'WindowsApps', 'steamapps', 'Epic Games', 'node_modules', '.git'
    $result = New-Object System.Collections.ArrayList

    foreach ($drive in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        $stack = New-Object System.Collections.Stack
        $stack.Push($drive.DeviceID + '\')
        while ($stack.Count -gt 0) {
            $dir = $stack.Pop()
            Report "Durchsuche $dir"
            try { $files = [IO.Directory]::GetFiles($dir) } catch { $files = @() }
            foreach ($fp in $files) {
                if (-not $junkRx.IsMatch([IO.Path]::GetFileName($fp))) { continue }
                try {
                    $fi = New-Object IO.FileInfo $fp
                    if ($fi.LastWriteTime -gt $cut) { continue }
                    [void]$result.Add([pscustomobject]@{ Path = $fi.FullName; Size = $fi.Length; Modified = $fi.LastWriteTime.ToString('dd.MM.yyyy') })
                } catch {}
            }
            try { $subs = [IO.Directory]::GetDirectories($dir) } catch { continue }
            foreach ($s in $subs) {
                try {
                    $di = New-Object IO.DirectoryInfo $s
                    if ($di.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                    if ($excludeNames -contains $di.Name) { continue }
                    if ($excludeFull | Where-Object { $_ -ieq $s }) { continue }
                    $stack.Push($s)
                } catch {}
            }
        }
    }
    $result | Sort-Object Path -Unique | Sort-Object Size -Descending
}

# ---------------------------------------------------------------------------
#  Deinstallation mit Rückstandssuche
# ---------------------------------------------------------------------------
$script:UninstallPath = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
$script:BackupRoot = Join-Path $env:LOCALAPPDATA 'TuneRig\Backups'

function Open-BaseKey([string]$Hive, [string]$View) {
    $h = if ($Hive -eq 'HKLM') { [Microsoft.Win32.RegistryHive]::LocalMachine } else { [Microsoft.Win32.RegistryHive]::CurrentUser }
    $v = switch ($View) { '32' { [Microsoft.Win32.RegistryView]::Registry32 } '64' { [Microsoft.Win32.RegistryView]::Registry64 } default { [Microsoft.Win32.RegistryView]::Default } }
    [Microsoft.Win32.RegistryKey]::OpenBaseKey($h, $v)
}

function Get-InstalledPrograms([bool]$IncludeStore) {
    $list = New-Object System.Collections.ArrayList
    foreach ($src in @(@('HKLM', '64'), @('HKLM', '32'), @('HKCU', 'Default'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]
            $root = $bk.OpenSubKey($script:UninstallPath)
            if (-not $root) { continue }
            foreach ($sub in $root.GetSubKeyNames()) {
                try {
                    $k = $root.OpenSubKey($sub); if (-not $k) { continue }
                    $name = [string]$k.GetValue('DisplayName')
                    if (-not $name.Trim()) { continue }
                    if ($k.GetValue('SystemComponent') -eq 1) { continue }
                    if ($k.GetValue('ParentKeyName')) { continue }
                    if ([string]$k.GetValue('ReleaseType') -match 'Update|Hotfix') { continue }
                    $un = [string]$k.GetValue('UninstallString')
                    $isGuid = $sub -match '^\{[0-9A-Fa-f\-]{36}\}$'
                    $isMsi = ($k.GetValue('WindowsInstaller') -eq 1) -and $isGuid
                    if (-not $un -and -not $isMsi) { continue }
                    $date = $null; $ds = [string]$k.GetValue('InstallDate')
                    if ($ds -match '^\d{8}$') { try { $date = [datetime]::ParseExact($ds, 'yyyyMMdd', $null) } catch {} }
                    $size = 0L; $es = $k.GetValue('EstimatedSize'); if ($es -is [int]) { $size = [long]$es * 1024 }
                    $icon = [string]$k.GetValue('DisplayIcon')
                    $loc = ([string]$k.GetValue('InstallLocation')).Trim().Trim('"').TrimEnd('\')
                    $locGuessed = $false
                    if (-not $loc) { $loc = Get-GuessedInstallDir $icon $un; $locGuessed = [bool]$loc }
                    [void]$list.Add([pscustomobject]@{
                        Name = $name.Trim(); Version = [string]$k.GetValue('DisplayVersion'); Publisher = ([string]$k.GetValue('Publisher')).Trim()
                        InstallDate = $(if ($date) { $date.ToString('dd.MM.yyyy') } else { '' }); Size = $size
                        InstallLocation = $loc; LocationGuessed = $locGuessed; MainExe = (Get-ExeFromCommand $icon)
                        UninstallString = $un; IsMsi = $isMsi; ProductCode = $(if ($isGuid) { $sub } else { '' })
                        Hive = $src[0]; View = $src[1]; SubKey = "$($script:UninstallPath)\$sub"; KeyName = $sub
                        Source = 'Win32'; PackageFullName = ''
                        TypeText = $(if ($src[1] -eq '32') { '32-Bit' } elseif ($src[0] -eq 'HKCU') { 'Benutzer' } else { '64-Bit' })
                    })
                    $k.Close()
                } catch {}
            }
            $root.Close(); $bk.Close()
        } catch {}
    }
    if ($IncludeStore) {
        foreach ($a in @(Get-AppxPackage -PackageTypeFilter Main -ErrorAction SilentlyContinue | Where-Object { -not $_.IsFramework -and -not $_.NonRemovable -and $_.SignatureKind -eq 'Store' })) {
            $friendly = if ($a.Name -match '\.') { $a.Name.Substring($a.Name.LastIndexOf('.') + 1) } else { $a.Name }
            [void]$list.Add([pscustomobject]@{
                Name = "$friendly (Store)"; Version = $a.Version.ToString(); Publisher = $a.Name.Split('.')[0]; InstallDate = ''; Size = 0L
                InstallLocation = $a.InstallLocation; UninstallString = ''; IsMsi = $false; ProductCode = ''; Hive = ''; View = ''; SubKey = ''; KeyName = ''
                Source = 'Store'; PackageFullName = $a.PackageFullName; TypeText = 'Store-App'
            })
        }
    }
    $list | Sort-Object @{ e = { $_.Name.ToLower() + '|' + $_.Version } } -Unique | Sort-Object Name
}

# Pfad der .exe aus einer Befehlszeile oder einem DisplayIcon-Wert ("C:\x\a.exe",0 bzw. C:\x\a.exe /arg)
function Get-ExeFromCommand([string]$Cmd) {
    $c = [Environment]::ExpandEnvironmentVariables($Cmd).Trim()
    if (-not $c) { return '' }
    if ($c.StartsWith('"')) { $e = $c.IndexOf('"', 1); if ($e -gt 1) { $c = $c.Substring(1, $e - 1) } }
    $i = $c.ToLower().IndexOf('.exe')
    if ($i -gt 0) { return $c.Substring(0, $i + 4) }
    return ''
}

# Viele Installer tragen keinen Installationsordner ein: aus Programm-Symbol bzw. Deinstallationsprogramm ableiten
function Get-GuessedInstallDir([string]$Icon, [string]$Uninstall) {
    foreach ($c in @($Icon, $Uninstall)) {
        $exe = Get-ExeFromCommand $c
        if (-not $exe -or $exe -match '(?i)\\(msiexec|rundll32|cmd|powershell)\.exe$' -or -not [IO.Path]::IsPathRooted($exe)) { continue }
        $dir = Split-Path $exe -Parent
        $leaf = if ($dir) { Split-Path $dir -Leaf } else { '' }
        if ($leaf -and ((ConvertTo-Token $leaf) -in 'uninstall', 'uninst', 'installer', 'bin', 'bin64', 'setup', 'x64', 'x86', 'application' -or $leaf -match '^app-\d')) { $dir = Split-Path $dir -Parent }
        if (-not $dir -or $dir -match '(?i)\\(Windows|Package Cache|Installer|Temp|Common Files)(\\|$)' -or (Test-ProtectedPath $dir)) { continue }
        return $dir.TrimEnd('\')
    }
    return ''
}

function Get-UninstallCommand($P) {
    if ($P.IsMsi -and $P.ProductCode) { return @('msiexec.exe', "/x $($P.ProductCode)") }
    $cmd = [Environment]::ExpandEnvironmentVariables([string]$P.UninstallString).Trim()
    if (-not $cmd) { return @('', '') }
    if ($cmd -match 'msiexec(\.exe)?\s+/[ix]\s*(\{[0-9A-Fa-f\-]+\})') { return @('msiexec.exe', "/x $($Matches[2])") }
    if ($cmd.StartsWith('"')) {
        $end = $cmd.IndexOf('"', 1)
        if ($end -gt 0) { return @($cmd.Substring(1, $end - 1), $cmd.Substring($end + 1).Trim()) }
    }
    $i = $cmd.ToLower().IndexOf('.exe')
    if ($i -gt 0) { return @($cmd.Substring(0, $i + 4), $cmd.Substring($i + 4).Trim()) }
    $sp = $cmd.IndexOf(' ')
    if ($sp -gt 0) { return @($cmd.Substring(0, $sp), $cmd.Substring($sp + 1)) }
    return @($cmd, '')
}

# Startet den Uninstaller und wartet, bis er UND alle nachgestarteten Kopien (z. B. NSIS "Au_.exe") beendet sind
function Invoke-Uninstaller($P) {
    if ($P.Source -eq 'Store') {
        Report 'Entferne Store-App ...'
        try { Remove-AppxPackage -Package $P.PackageFullName -ErrorAction Stop; return 'Store-App wurde entfernt.' }
        catch { return 'Fehler: ' + $_.Exception.Message }
    }
    $exe, $arg = Get-UninstallCommand $P
    if (-not $exe) { return 'Kein Deinstallationsprogramm gefunden – nutze »Erzwungen entfernen«.' }
    if ($exe -ne 'msiexec.exe' -and [IO.Path]::IsPathRooted($exe) -and -not (Test-Path -LiteralPath $exe)) {
        return 'Das Deinstallationsprogramm existiert nicht mehr – nutze »Erzwungen entfernen«.'
    }
    Report 'Deinstallationsprogramm läuft … Folge den Anweisungen im Fenster des Programms.'
    $start = Get-Date
    # Manche Deinstallationsprogramme erwarten ihren eigenen Ordner als Arbeitsverzeichnis
    $wd = if ([IO.Path]::IsPathRooted($exe)) { Split-Path $exe -Parent } else { $env:SystemRoot }
    $proc = if ($arg) { Start-Process -FilePath $exe -ArgumentList $arg -WorkingDirectory $wd -PassThru } else { Start-Process -FilePath $exe -WorkingDirectory $wd -PassThru }
    $null = $proc.Handle   # nötig, damit der Exit-Code später lesbar ist

    $tracked = New-Object 'System.Collections.Generic.HashSet[int]'
    [void]$tracked.Add($proc.Id)
    $loc = [string]$P.InstallLocation; if ($loc.Length -le 8) { $loc = '' }
    $temp = [IO.Path]::GetTempPath().TrimEnd('\')
    $quiet = 0
    while ($true) {
        $procs = @(Get-CimInstance Win32_Process -Property ProcessId, ParentProcessId, Name, CreationDate, ExecutablePath -ErrorAction SilentlyContinue)
        $alive = @{}
        foreach ($x in $procs) {
            $alive[[int]$x.ProcessId] = $true
            if ($x.CreationDate -ge $start.AddSeconds(-1)) {
                $path = [string]$x.ExecutablePath
                $related = $tracked.Contains([int]$x.ParentProcessId) -or $x.Name -match '^(au_|un_a|un_|unins|uninst|_iu14d2n|_un|uninstall|msiexec)' -or
                           ($loc -and $path.StartsWith($loc, [StringComparison]::OrdinalIgnoreCase)) -or
                           ($path.StartsWith($temp, [StringComparison]::OrdinalIgnoreCase) -and $x.Name -match '(?i)(un|setup|install|\.tmp)')
                if ($related) { [void]$tracked.Add([int]$x.ProcessId) }
            }
        }
        $any = $false; foreach ($id in $tracked) { if ($alive.ContainsKey($id)) { $any = $true; break } }
        if ($any) { $quiet = 0 } elseif (++$quiet -ge 6) { break }
        Start-Sleep -Milliseconds 500
    }
    $code = try { $proc.ExitCode } catch { $null }
    $txt = switch ($code) { 0 { 'Deinstallationsprogramm beendet.' } 1602 { 'Deinstallation abgebrochen (Code 1602).' } 1605 { 'Das Programm war bereits entfernt (Code 1605).' } 3010 { 'Deinstallation beendet – ein Neustart ist nötig.' } default { "Deinstallationsprogramm beendet (Code $code)." } }
    return $txt
}

$script:GenericNames = @(
    'microsoft', 'windows', 'commonfiles', 'common', 'intel', 'nvidia', 'nvidiacorporation', 'amd', 'google', 'mozilla', 'programs', 'program',
    'temp', 'packages', 'default', 'drivers', 'system', 'system32', 'update', 'updater', 'app', 'apps', 'application', 'applications',
    'software', 'tools', 'games', 'steam', 'data', 'cache', 'config', 'settings', 'user', 'users', 'public', 'shared', 'runtime', 'framework',
    'uninstall', 'installer', 'setup', 'launcher', 'client', 'service', 'services', 'helper', 'classes', 'policies', 'wow6432node', 'clients',
    'registeredapplications', 'microsoftcorporation', 'inc', 'corporation', 'gmbh', 'ltd', 'llc', 'desktop', 'documents', 'downloads',
    'startmenu', 'startup', 'local', 'roaming', 'locallow', 'appdata', 'programdata', 'programfiles', 'net', 'dotnet', 'java', 'python',
    'vulkan', 'directx', 'realtek', 'logitech', 'adobe', 'apple', 'oracle', 'valve', 'epicgames'
)

function ConvertTo-Token([string]$s) { ($s.ToLower() -replace '[^a-z0-9äöüß]', '') }

function Get-CleanName([string]$n) {
    $n = $n -replace '\((x64|x86|64[\s-]?bit|32[\s-]?bit|amd64)\)', ''
    $n = $n -replace '\b(x64|x86|64[\s-]?bit|32[\s-]?bit)\b', ''
    $n = $n -replace '\s+v?\d+([.,]\d+)+.*$', ''
    $n = $n -replace '\s*[-–]\s*(de|en|deutsch|english|de-de|en-us)\s*$', ''
    $n = $n -replace '\s*\(.*?\)\s*$', ''
    return $n.Trim(' ', '-', '_')
}

function Test-ProtectedPath([string]$Path) {
    $p = $Path.TrimEnd('\')
    if ($p.Length -le 3) { return $true }
    $prot = @(
        $env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramW6432, $env:CommonProgramFiles, ${env:CommonProgramFiles(x86)},
        $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA, $env:USERPROFILE, (Split-Path $env:USERPROFILE -Parent),
        "$env:LOCALAPPDATA\Programs", "$env:USERPROFILE\AppData\LocalLow",
        [Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
        [Environment]::GetFolderPath('StartMenu'), [Environment]::GetFolderPath('CommonStartMenu'), [Environment]::GetFolderPath('Programs'),
        [Environment]::GetFolderPath('CommonPrograms'), [Environment]::GetFolderPath('Startup'), [Environment]::GetFolderPath('CommonStartup'),
        [Environment]::GetFolderPath('MyPictures'), [Environment]::GetFolderPath('MyVideos'), [Environment]::GetFolderPath('MyMusic'),
        "$env:USERPROFILE\Downloads", "$env:ProgramFiles\WindowsApps", "$env:ProgramData\Microsoft", "$env:SystemDrive\Users", "$env:SystemDrive\Recovery",
        "$env:SystemDrive\System Volume Information", "$env:SystemDrive\`$Recycle.Bin"
    ) | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') }
    # geschützt: der Ordner selbst und jeder Ordner, der einen geschützten Ordner enthält (z. B. ...\AppData)
    if ($prot | Where-Object { ($_ + '\').StartsWith($p + '\', [StringComparison]::OrdinalIgnoreCase) }) { return $true }
    foreach ($inner in @("$env:ProgramFiles\WindowsApps", "$env:ProgramData\Microsoft\Windows", "$env:SystemDrive\System Volume Information")) {
        if ($p.StartsWith($inner + '\', [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $p.StartsWith($env:windir + '\', [StringComparison]::OrdinalIgnoreCase)
}

function Get-DirSize([string]$Dir) {
    [long](Get-ChildItem -LiteralPath $Dir -File -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
}

function New-Leftover([string]$Type, [string]$Path, [string]$Reason, [hashtable]$Extra = @{}) {
    $o = [ordered]@{ Type = $Type; Path = $Path; Reason = $Reason; Size = 0L; Selected = $true; Shared = $false; Hive = ''; View = ''; SubKey = ''; ValueName = ''; Service = ''; Task = ''; TaskPath = ''; Confidence = ''; Proof = ''; NameKind = ''; DocsFolder = $false; Rule = ''; Owner = ''; Target = '' }
    foreach ($k in $Extra.Keys) { $o[$k] = $Extra[$k] }
    if ($Type -eq 'Ordner') { if (-not $script:LeftoverNoSize) { $o.Size = Get-DirSize $Path }; $o.Selected = -not (Test-ProtectedPath $Path) }
    elseif ($Type -eq 'Datei') { try { $o.Size = (Get-Item -LiteralPath $Path -Force).Length } catch {} }
    [pscustomobject]$o
}

function Get-RegDisplayPath([string]$Hive, [string]$View, [string]$Sub) {
    if ($Hive -eq 'HKLM' -and $View -eq '32') { $Sub = $Sub -replace '^SOFTWARE\\', 'SOFTWARE\WOW6432Node\' }
    "$Hive\$Sub"
}

function New-RegLeftover([string]$Hive, [string]$View, [string]$Sub, [string]$Reason) {
    New-Leftover 'Registry-Schlüssel' (Get-RegDisplayPath $Hive $View $Sub) $Reason @{ Hive = $Hive; View = $View; SubKey = $Sub }
}

# ===========================================================================
#  RESTE NUR MIT BELEG
#  Vor der Deinstallation liest TuneRig alles aus, was nachweislich zum Programm
#  gehört (»Fußabdruck«) - ausschließlich über Pfade und Daten, die Windows zum
#  Programm speichert, nie über ähnliche Namen. Nach der Deinstallation wird nur
#  geprüft, welche dieser Einträge noch existieren.
# ===========================================================================

# Ist das Programm noch installiert? (Deinstallationseintrag vorhanden und Installationsordner mit Programmdateien)
function Test-ProgramStillInstalled($P) {
    if ($P.Source -ne 'Win32' -or -not $P.SubKey) { return $false }
    $exists = $false
    try { $bk = Open-BaseKey $P.Hive $P.View; $k = $bk.OpenSubKey($P.SubKey); if ($k) { $exists = $true; $k.Close() }; $bk.Close() } catch {}
    if (-not $exists) { return $false }
    $loc = [string]$P.InstallLocation
    if ($loc.Length -gt 3 -and -not (Test-ProtectedPath $loc)) {
        return [bool](Get-ChildItem -LiteralPath $loc -Filter *.exe -File -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 1)
    }
    return $true
}

# {12345678-ABCD-EF01-2345-6789ABCDEF01} -> gepackte Form, wie sie Windows Installer in der Registry ablegt
function ConvertTo-PackedGuid([string]$Guid) {
    $g = $Guid.Trim('{', '}').Replace('-', '').ToUpper()
    if ($g.Length -ne 32) { return '' }
    $r = { param($s) -join ($s.ToCharArray()[($s.Length - 1)..0]) }
    $p = (& $r $g.Substring(0, 8)) + (& $r $g.Substring(8, 4)) + (& $r $g.Substring(12, 4))
    for ($i = 16; $i -lt 32; $i += 2) { $p += $g[$i + 1].ToString() + $g[$i].ToString() }
    return $p
}

# Dateien und Registry-Pfade, die Windows Installer für dieses MSI-Produkt eingetragen hat
function Get-MsiOwnedPaths([string]$ProductCode) {
    $packed = ConvertTo-PackedGuid $ProductCode
    $files = New-Object System.Collections.Generic.List[string]
    $keys = New-Object System.Collections.ArrayList
    if (-not $packed) { return [pscustomobject]@{ Files = @(); Keys = @(); Packed = '' } }
    try {
        $bk = Open-BaseKey 'HKLM' '64'
        $ud = $bk.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData')
        foreach ($sid in @($ud.GetSubKeyNames())) {
            $ck = $ud.OpenSubKey("$sid\Components"); if (-not $ck) { continue }
            foreach ($c in $ck.GetSubKeyNames()) {
                $k = $ck.OpenSubKey($c); if (-not $k) { continue }
                $v = [string]$k.GetValue($packed)
                # Gemeinsam genutzte Komponente (weitere Programme eingetragen) oder dauerhafte Komponente (00000…): gehört nicht allein diesem Programm
                $shared = $false
                if ($v) { foreach ($vn in $k.GetValueNames()) { if ($vn -and $vn -ne $packed) { $shared = $true; break } } }
                $k.Close()
                if (-not $v -or $shared) { continue }
                if ($v -match '^[A-Za-z]:\\') { $files.Add($v) }
                elseif ($v -match '^(0|2)([0-3])[:\\]+(.+)$') {
                    # Präfix: 00 = HKCR, 01 = HKCU, 02 = HKLM (20-23 = 64-Bit-Ansicht). Endet der Pfad mit \, ist es ein Schlüssel, sonst ein Wert.
                    $is64 = $Matches[1] -eq '2'; $root = $Matches[2]; $raw = $Matches[3]
                    $hive = switch ($root) { '0' { 'HKLM' } '1' { 'HKCU' } '2' { 'HKLM' } default { '' } }
                    if (-not $hive) { continue }
                    $path = if ($root -eq '0') { 'SOFTWARE\Classes\' + $raw } else { $raw }
                    $view = if ($hive -eq 'HKCU') { 'Default' } elseif ($is64) { '64' } else { '32' }
                    $keys.Add([pscustomobject]@{ Hive = $hive; View = $view; Path = $path.TrimEnd('\'); IsKey = $path.EndsWith('\') })
                }
            }
            $ck.Close()
        }
        $ud.Close(); $bk.Close()
    } catch {}
    [pscustomobject]@{ Files = @($files); Keys = @($keys); Packed = $packed }
}

function Test-PathUnder([string]$Path, $Dirs) {
    if (-not $Path) { return $null }
    $p = $Path.Trim('"').TrimEnd('\') + '\'
    foreach ($d in @($Dirs)) {
        if (-not $d -or $d.Length -le 3) { continue }
        if ($p.StartsWith($d.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { return $d }
    }
    return $null
}

# Kommt einer der Programmpfade in diesem Text vor? (auch mit / oder doppelten \\ wie in JSON)
function Find-Needle([string]$Text, $Needles) {
    if (-not $Text) { return $null }
    foreach ($n in $Needles) {
        # Pfad als Ganzes: danach muss ein Trennzeichen oder das Ende kommen (»VLC« passt nicht auf »VLC2«)
        foreach ($form in @($n, $n.Replace('\', '/'), $n.Replace('\', '\\'))) {
            if ($Text.IndexOf($form, [StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
            if ([regex]::IsMatch($Text, [regex]::Escape($form) + '(?=$|[\\/"''\s,;:|<>\]\)\}])', 'IgnoreCase')) { return $n }
        }
    }
    return $null
}

function Get-RegString($Key, [string]$Name = '') {
    try { $v = $Key.GetValue($Name, $null, 'DoNotExpandEnvironmentNames') } catch { return '' }
    if ($null -eq $v) { return '' }
    $s = if ($v -is [array]) { ($v | ForEach-Object { [string]$_ }) -join ' ' } else { [string]$v }
    return [Environment]::ExpandEnvironmentVariables($s)
}

# Sucht in einem Registry-Schlüssel (bis Tiefe 4) nach Werten, die auf das Programm verweisen
function Find-RegNeedle($Key, $Needles, [int]$Budget = 600) {
    $queue = New-Object System.Collections.Queue; $queue.Enqueue(@($Key, 0, '')); $seen = 0
    while ($queue.Count -gt 0 -and $seen -lt $Budget) {
        $e = $queue.Dequeue(); $k = $e[0]
        try {
            foreach ($vn in $k.GetValueNames()) {
                $seen++
                $hit = Find-Needle (Get-RegString $k $vn) $Needles
                if ($hit) { return [pscustomobject]@{ Value = $vn; Needle = $hit; Rel = $e[2] } }
            }
            if ($e[1] -lt 4) { foreach ($sn in $k.GetSubKeyNames()) { $sk = $k.OpenSubKey($sn); if ($sk) { $queue.Enqueue(@($sk, $e[1] + 1, $(if ($e[2]) { "$($e[2])\$sn" } else { $sn }))) } } }
        } catch {}
    }
    return $null
}

function Get-FileVendor([string]$File) {
    try { $vi = [Diagnostics.FileVersionInfo]::GetVersionInfo($File); return [pscustomobject]@{ Company = ([string]$vi.CompanyName).Trim(); Product = ([string]$vi.ProductName).Trim() } } catch { return $null }
}

function Get-SignerThumb([string]$File) {
    try {
        $s = Get-AuthenticodeSignature -LiteralPath $File -ErrorAction Stop
        if ($s.SignerCertificate -and $s.Status -eq 'Valid' -and $s.SignerCertificate.Subject -notmatch 'O=Microsoft') { return $s.SignerCertificate.Thumbprint }
    } catch {}
    return ''
}

# Darf ein ganzer Registry-Schlüssel einem Programm zugeordnet werden? Nie gemeinsam genutzte Windows-Schlüssel.
function Test-OwnableKey([string]$Sub) {
    $s = $Sub.Trim('\')
    $parts = @($s.Split('\') | Where-Object { $_ })
    if ($parts.Count -lt 3) { return $false }                                                  # mindestens Software\Hersteller\Produkt
    if ($s -match '^(?i)software\\classes\\(wow6432node\\)?clsid\\\{[0-9a-f\-]+\}$') { return $true }   # COM-Klasse des Programms
    if ($s -match '^(?i)software\\classes\\(clsid|interface|typelib|appid|installer|wow6432node|\*|directory|drive|folder|allfilesystemobjects|systemfileassociations)(\\|$)') { return $false }
    if ($s -match '^(?i)software\\classes\\applications\\[^\\]+$') { return $true }      # »Öffnen mit«-Eintrag einer Programmdatei
    if ($s -match '^(?i)software\\classes\\[^\\]+$') { return -not $parts[2].StartsWith('.') }   # ProgID ja, Dateiendung nein
    if ($s -match '^(?i)software\\microsoft\\windows\\currentversion\\(uninstall|app paths)\\[^\\]+$') { return $true }
    if ($s -match '^(?i)software\\(microsoft|policies|classes|wow6432node|clients|registeredapplications)(\\|$)') { return $false }
    return $true
}

# Datenordner, die mehreren Programmen gehören - werden nie als Ganzes einem Programm zugeordnet
$script:SharedDataFolders = @('microsoft', 'packages', 'temp', 'programs', 'comms', 'connecteddevicesplatform', 'crashdumps', 'd3dscache', 'peerdistrepub',
    'publishers', 'packagecache', 'nvidia', 'nvidiacorporation', 'amd', 'ati', 'intel', 'steam', 'valve', 'epic', 'epicgames', 'epicgameslauncher', 'battlenet',
    'blizzardentertainment', 'origin', 'eadesktop', 'electronicarts', 'ubisoftgamelauncher', 'gogcom', 'razer', 'logitech', 'corsair', 'google', 'mozilla',
    'apple', 'applecomputer', 'adobe', 'oracle', 'java', 'package cache', 'ssh', 'regid', 'softwaredistribution', 'usoshared', 'usoprivate', 'windows', 'windowsapps')

# ---------------------------------------------------------------------------
#  Fußabdruck: alles, was nachweislich zum Programm gehört (VOR der Deinstallation)
# ---------------------------------------------------------------------------
function Get-ProgramFootprint($P, $AllPrograms) {
    $script:LeftoverNoSize = $true      # Ordnergrößen erst nach der Deinstallation berechnen
    try { Get-ProgramFootprintCore $P $AllPrograms } finally { $script:LeftoverNoSize = $false }
}

function Get-ProgramFootprintCore($P, $AllPrograms) {
    $items = New-Object System.Collections.ArrayList
    $keySeen = @{}
    function Add-Fp($It, [string]$Proof) { if (Test-WindowsOwned $It) { return }; $It.Proof = $Proof; $It.Confidence = 'sicher'; [void]$items.Add($It) }
    function Add-FpKey([string]$Hive, [string]$View, [string]$Sub, [string]$Reason, [string]$Proof) {
        $id = "$Hive|$View|$Sub".ToLower(); if ($keySeen.ContainsKey($id)) { return }; $keySeen[$id] = $true
        Add-Fp (New-RegLeftover $Hive $View $Sub $Reason) $Proof
    }
    $others = @($AllPrograms | Where-Object { $_ -and $_.Name -ne $P.Name -and $_.Source -eq 'Win32' -and ([string]$_.InstallLocation).Length -gt 3 } | ForEach-Object { $_.InstallLocation.TrimEnd('\') })
    $isShared = { param($dir) $d = $dir.TrimEnd('\') + '\'; [bool]($others | Where-Object { ($_ + '\').StartsWith($d, [StringComparison]::OrdinalIgnoreCase) -or $d.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }) }

    # --- 1) Programmordner: laut Windows-Eintrag, Programmdatei, Deinstallationsprogramm, Windows Installer
    Report "Lese den Windows-Eintrag von $($P.Name) ..."
    $dirs = New-Object System.Collections.Generic.List[string]; $dirProof = @{}
    $addDir = {
        param($d, $why)
        if (-not $d -or $d.Length -le 3 -or (Test-ProtectedPath $d) -or (& $isShared $d)) { return }
        if (Test-PathUnder $d $dirs) { return }
        # Unterordner eines schon bekannten Ordners ersetzen
        foreach ($x in @($dirs)) { if (Test-PathUnder $x @($d)) { [void]$dirs.Remove($x) } }
        $dirs.Add($d.TrimEnd('\')); $dirProof[$d.TrimEnd('\').ToLower()] = $why
    }
    $loc = [string]$P.InstallLocation
    if ($loc) { & $addDir $loc $(if ($P.LocationGuessed) { 'Ordner der Programmdatei laut Windows-Eintrag des Programms' } else { 'Installationsordner laut Windows-Eintrag des Programms' }) }
    $exe = [string]$P.MainExe
    if ($exe -and (Test-Path -LiteralPath $exe)) { & $addDir (Split-Path $exe -Parent) 'Ordner der Programmdatei laut Windows-Eintrag des Programms' }
    $unExe = Get-ExeFromCommand ([string]$P.UninstallString)
    if ($unExe -and $unExe -notmatch '(?i)\\(msiexec|rundll32)\.exe$' -and (Test-Path -LiteralPath $unExe)) {
        $ud = Split-Path $unExe -Parent
        if ((ConvertTo-Token (Split-Path $ud -Leaf)) -in 'uninstall', 'uninst') { $ud = Split-Path $ud -Parent }
        if ($ud -notmatch '(?i)\\(Package Cache|Installer|Temp)(\\|$)') { & $addDir $ud 'Ordner des Deinstallationsprogramms laut Windows-Eintrag' }
    }
    $msi = $null
    if ($P.IsMsi -and $P.ProductCode) {
        Report "Lese die Dateiliste von Windows Installer für $($P.Name) ... (kann bis zu einer Minute dauern)"
        $msi = Get-MsiOwnedPaths $P.ProductCode
        foreach ($f in $msi.Files) {
            $d = Split-Path $f -Parent
            if ($d -notmatch '(?i)\\(Common Files|Windows|System32|SysWOW64)(\\|$)') { & $addDir $d 'Von Windows Installer für dieses Programm installiert' }
        }
    }
    foreach ($d in $dirs) { if (Test-Path -LiteralPath $d) { Add-Fp (New-Leftover 'Ordner' $d 'Programmordner') $dirProof[$d.ToLower()] } }
    $needles = @(@($dirs) + @($exe) | Where-Object { $_ -and $_.Length -gt 8 } | Select-Object -Unique)
    $otherNeedles = @($others | Where-Object { $_.Length -gt 8 })
    # Namen genau dieses Programms (ohne Hersteller): zusätzliche Bedingung für Registry-Unterschlüssel und Datenordner
    $fpOwn = Get-OwnTokens ([string]$P.Name) ([string]$P.Publisher) @($(if ($exe) { [IO.Path]::GetFileNameWithoutExtension($exe) }))

    # Signatur und Produktname der Programmdateien (für Datenordner in AppData)
    $thumbs = @{}; $products = @{}
    foreach ($d in $dirs) {
        foreach ($b in @(Get-ChildItem -LiteralPath $d -Filter *.exe -File -Recurse -Depth 2 -ErrorAction SilentlyContinue | Select-Object -First 8)) {
            $t = Get-SignerThumb $b.FullName; if ($t) { $thumbs[$t] = $true }
            $v = Get-FileVendor $b.FullName
            if ($v -and $v.Product -and $v.Company -and $v.Company -notmatch '^Microsoft') { $products["$($v.Company)|$($v.Product)".ToLower()] = $true }
        }
    }

    # --- 2) Registry: Deinstallationseintrag, Windows Installer
    if ($P.SubKey) { Add-FpKey $P.Hive $P.View $P.SubKey 'Deinstallationseintrag' 'Deinstallationseintrag genau dieses Programms' }
    if ($msi) {
        foreach ($k in $msi.Keys) {
            if ($k.IsKey) {
                if (Test-OwnableKey $k.Path) { Add-FpKey $k.Hive $k.View $k.Path 'Registry-Eintrag des Programms' 'Von Windows Installer für dieses Programm angelegt' }
            } else {
                $i = $k.Path.LastIndexOf('\'); if ($i -lt 1) { continue }
                $sub = $k.Path.Substring(0, $i); $vn = $k.Path.Substring($i + 1)
                Add-Fp (New-Leftover 'Registry-Wert' ("{0} -> {1}" -f (Get-RegDisplayPath $k.Hive $k.View $sub), $vn) 'Registry-Wert des Programms' @{ Hive = $k.Hive; View = $k.View; SubKey = $sub; ValueName = $vn }) 'Von Windows Installer für dieses Programm angelegt'
            }
        }
        foreach ($k in @("SOFTWARE\Classes\Installer\Products\$($msi.Packed)", "SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\$($msi.Packed)")) {
            try { $bk = Open-BaseKey 'HKLM' '64'; $kk = $bk.OpenSubKey($k); if ($kk) { $kk.Close(); Add-FpKey 'HKLM' '64' $k 'Windows-Installer-Registrierung' 'Produktcode genau dieses Programms' }; $bk.Close() } catch {}
        }
    }

    if ($needles.Count -gt 0) {
        # --- 3) Autostart, App Paths
        Report 'Prüfe Autostart und Programmpfade ...'
        foreach ($src in @(@('HKCU', 'Default'), @('HKLM', '64'), @('HKLM', '32'))) {
            try {
                $bk = Open-BaseKey $src[0] $src[1]
                foreach ($run in 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce') {
                    $rk = $bk.OpenSubKey($run); if (-not $rk) { continue }
                    foreach ($v in $rk.GetValueNames()) {
                        $hit = Find-Needle (Get-RegString $rk $v) $needles
                        if ($hit) { Add-Fp (New-Leftover 'Registry-Wert' ("{0} -> {1}" -f (Get-RegDisplayPath $src[0] $src[1] $run), $v) 'Autostart-Eintrag' @{ Hive = $src[0]; View = $src[1]; SubKey = $run; ValueName = $v }) "Startet eine Datei aus $hit" }
                    }
                    $rk.Close()
                }
                $ap = 'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths'
                $apk = $bk.OpenSubKey($ap)
                if ($apk) {
                    foreach ($e in $apk.GetSubKeyNames()) {
                        $ek = $apk.OpenSubKey($e); if (-not $ek) { continue }
                        $hit = Find-Needle ((Get-RegString $ek '') + ' ' + (Get-RegString $ek 'Path')) $needles; $ek.Close()
                        if ($hit) { Add-FpKey $src[0] $src[1] "$ap\$e" 'Programmpfad-Registrierung' "Verweist auf $hit" }
                    }
                    $apk.Close()
                }
                $bk.Close()
            } catch {}
        }

        # --- 4) Dateitypen, »Öffnen mit« und COM-Registrierungen
        Report 'Prüfe Dateitypen und Programm-Registrierungen ... (kann etwas dauern)'
        foreach ($src in @(@('HKCU', 'Default', 'Software\Classes'), @('HKLM', '64', 'SOFTWARE\Classes'), @('HKLM', '32', 'SOFTWARE\Classes'))) {
            try {
                $bk = Open-BaseKey $src[0] $src[1]; $cl = $bk.OpenSubKey($src[2]); if (-not $cl) { $bk.Close(); continue }
                foreach ($n in $cl.GetSubKeyNames()) {
                    if ($n.StartsWith('.') -or $n -in 'CLSID', 'Interface', 'TypeLib', 'Installer', 'AppID', 'Wow6432Node', '*', 'Directory', 'Drive', 'Folder', 'AllFilesystemObjects') { continue }
                    if ($n -eq 'Applications') {
                        $apps = $cl.OpenSubKey('Applications')
                        foreach ($a in @($apps.GetSubKeyNames())) {
                            $ak = $apps.OpenSubKey("$a\shell\open\command"); if (-not $ak) { continue }
                            $hit = Find-Needle (Get-RegString $ak '') $needles; $ak.Close()
                            if ($hit) { Add-FpKey $src[0] $src[1] "$($src[2])\Applications\$a" '»Öffnen mit«-Eintrag' "Befehl startet eine Datei aus $hit" }
                        }
                        $apps.Close(); continue
                    }
                    # Dateityp gehört dem Programm nur, wenn ALLE Befehle darin auf das Programm zeigen (kein von Windows bzw. anderen Programmen genutzter Typ)
                    if ($n -match '^(?i)(txtfile|htmlfile|exefile|batfile|cmdfile|comfile|lnkfile|inifile|regfile|jpegfile|pngfile|giffile|mp3file|wmafile|wmvfile|aufile|http|https|ftp|mailto|ms-.+|microsoft\..+|windows\..+|app[xX].+|shell.+|file|unknown|opennewwindow)$') { continue }
                    $sh = $cl.OpenSubKey("$n\shell"); if (-not $sh) { continue }
                    $cmds = @(); foreach ($verb in $sh.GetSubKeyNames()) { $ck2 = $sh.OpenSubKey("$verb\command"); if ($ck2) { $cmds += (Get-RegString $ck2 ''); $ck2.Close() } }
                    $sh.Close()
                    $cmds = @($cmds | Where-Object { $_ })
                    if (-not $cmds.Count) { continue }
                    $hits = @($cmds | ForEach-Object { Find-Needle $_ $needles })
                    if (@($hits | Where-Object { $_ }).Count -eq $cmds.Count) { Add-FpKey $src[0] $src[1] "$($src[2])\$n" 'Dateityp-Registrierung' "Alle Befehle starten eine Datei aus $($hits[0])" }
                }
                $clsid = $cl.OpenSubKey('CLSID')
                if ($clsid) {
                    foreach ($c in $clsid.GetSubKeyNames()) {
                        $txt = ''
                        foreach ($sub in 'InprocServer32', 'LocalServer32', 'DefaultIcon') { $sk = $clsid.OpenSubKey("$c\$sub"); if ($sk) { $txt += ' ' + (Get-RegString $sk ''); $sk.Close() } }
                        $hit = Find-Needle $txt $needles
                        if ($hit) { Add-FpKey $src[0] $src[1] "$($src[2])\CLSID\$c" 'COM-Registrierung' "Programmbibliothek liegt in $hit" }
                    }
                    $clsid.Close()
                }
                $cl.Close(); $bk.Close()
            } catch {}
        }

        # --- 5) Registry-Schlüssel des Herstellers mit Verweis auf das Programm
        Report 'Prüfe Registry-Schlüssel des Herstellers ...'
        $pubTok = ConvertTo-Token (([string]$P.Publisher) -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', '')
        foreach ($src in @(@('HKCU', 'Default', 'Software'), @('HKLM', '64', 'SOFTWARE'), @('HKLM', '32', 'SOFTWARE'))) {
            try {
                $bk = Open-BaseKey $src[0] $src[1]; $sw = $bk.OpenSubKey($src[2]); if (-not $sw) { $bk.Close(); continue }
                foreach ($vendor in $sw.GetSubKeyNames()) {
                    $vt = ConvertTo-Token $vendor
                    if ($vt -in 'microsoft', 'classes', 'policies', 'wow6432node', 'clients', 'registeredapplications') { continue }
                    # nur der Schlüssel des Herstellers des Programms - in fremden Schlüsseln (z. B. Grafiktreiber-Profilen) wird nichts gelöscht
                    if (-not $pubTok -or -not ($vt -eq $pubTok -or ($vt.Length -ge 4 -and $pubTok.StartsWith($vt)) -or ($pubTok.Length -ge 4 -and $vt.StartsWith($pubTok)))) { continue }
                    $vk = $sw.OpenSubKey($vendor); if (-not $vk) { continue }
                    $subs = @($vk.GetSubKeyNames()); $provenSubs = 0
                    foreach ($s in $subs) {
                        # ein Hersteller hat oft mehrere Produkte: der Unterschlüssel muss zusätzlich wie dieses Programm heißen
                        if (-not (Test-NameRelated $s $fpOwn)) { continue }
                        $sk = $vk.OpenSubKey($s); if (-not $sk) { continue }
                        $hit = Find-RegNeedle $sk $needles
                        if ($hit -and $others.Count -and (Find-RegNeedle $sk @($others | Where-Object { $_.Length -gt 8 }))) { $hit = $null }   # auch von einem anderen Programm genutzt
                        $sk.Close()
                        if ($hit) { $provenSubs++; Add-FpKey $src[0] $src[1] "$($src[2])\$vendor\$s" 'Programmeinstellungen' ("Eintrag »{0}« verweist auf {1}" -f $(if ($hit.Rel) { "$($hit.Rel)\$($hit.Value)" } else { $hit.Value }), $hit.Needle) }
                    }
                    if ($provenSubs -gt 0 -and $provenSubs -eq $subs.Count -and $vk.ValueCount -eq 0) {
                        Add-FpKey $src[0] $src[1] "$($src[2])\$vendor" 'Herstellerschlüssel' 'Enthält ausschließlich Einträge dieses Programms'
                    }
                    $vk.Close()
                }
                $sw.Close(); $bk.Close()
            } catch {}
        }

        # --- 6) Verknüpfungen, deren Ziel im Programmordner liegt
        Report 'Prüfe Verknüpfungen ...'
        $shell = $null; try { $shell = New-Object -ComObject WScript.Shell } catch {}
        $menus = @(([Environment]::GetFolderPath('CommonStartMenu') + '\Programs'), ([Environment]::GetFolderPath('StartMenu') + '\Programs'))
        $flat = @([Environment]::GetFolderPath('DesktopDirectory'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
                  "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch", "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar")
        $linkOk = @{}
        foreach ($lr in @($menus + $flat) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) {
            $deep = $menus -contains $lr
            $links = if ($deep) { @(Get-ChildItem -LiteralPath $lr -Filter *.lnk -File -Recurse -Depth 3 -ErrorAction SilentlyContinue) } else { @(Get-ChildItem -LiteralPath $lr -Filter *.lnk -File -ErrorAction SilentlyContinue) }
            foreach ($l in $links) {
                $target = ''; if ($shell) { try { $target = [Environment]::ExpandEnvironmentVariables([string]$shell.CreateShortcut($l.FullName).TargetPath) } catch {} }
                $hit = Test-PathUnder $target $dirs
                if (-not $hit -and $exe -and $target -ieq $exe) { $hit = $exe }
                if ($hit) {
                    $linkOk[$l.FullName.ToLower()] = $true
                    $what = if ($deep) { 'Startmenü-Verknüpfung' } elseif ($lr -like '*TaskBar') { 'Taskleisten-Verknüpfung' } else { 'Verknüpfung' }
                    Add-Fp (New-Leftover 'Datei' $l.FullName $what) "Zeigt auf $target"
                }
            }
            # Startmenü-Ordner, in dem nur Verknüpfungen dieses Programms liegen
            if ($deep) {
                foreach ($sd in @(Get-ChildItem -LiteralPath $lr -Directory -ErrorAction SilentlyContinue)) {
                    $all = @(Get-ChildItem -LiteralPath $sd.FullName -File -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' })
                    if ($all.Count -gt 0 -and @($all | Where-Object { -not $linkOk[$_.FullName.ToLower()] }).Count -eq 0) {
                        Add-Fp (New-Leftover 'Ordner' $sd.FullName 'Startmenü-Ordner') 'Enthält ausschließlich Verknüpfungen dieses Programms'
                    }
                }
            }
        }

        # --- 7) Dienste, geplante Aufgaben, Firewall-Regeln
        Report 'Prüfe Dienste, geplante Aufgaben und Firewall-Regeln ...'
        foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
            $hit = Find-Needle ([Environment]::ExpandEnvironmentVariables([string]$s.PathName)) $needles
            if ($hit) { Add-Fp (New-Leftover 'Dienst' ("{0} ({1})" -f $s.DisplayName, $s.Name) 'Dienst' @{ Service = $s.Name }) "Dienst startet eine Datei aus $hit" }
        }
        foreach ($t in @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' })) {
            $txt = (@($t.Actions) | ForEach-Object { [Environment]::ExpandEnvironmentVariables(([string]$_.Execute) + ' ' + ([string]$_.Arguments)) }) -join ' '
            $hit = Find-Needle $txt $needles
            if ($hit) { Add-Fp (New-Leftover 'Aufgabe' ("{0}{1}" -f $t.TaskPath, $t.TaskName) 'Geplante Aufgabe' @{ Task = $t.TaskName; TaskPath = $t.TaskPath }) "Aufgabe startet eine Datei aus $hit" }
        }
        try {
            foreach ($af in @(Get-NetFirewallApplicationFilter -ErrorAction Stop)) {
                $prog = [Environment]::ExpandEnvironmentVariables([string]$af.Program)
                $hit = Test-PathUnder $prog $dirs
                if (-not $hit -and $exe -and $prog -ieq $exe) { $hit = $exe }
                if ($hit) {
                    foreach ($rule in @($af | Get-NetFirewallRule -ErrorAction SilentlyContinue)) {
                        Add-Fp (New-Leftover 'Firewall-Regel' ("{0} ({1})" -f $rule.DisplayName, $rule.Direction) 'Firewall-Regel' @{ Rule = $rule.Name }) "Regel gilt für $prog"
                    }
                }
            }
        } catch {}
    }

    # --- 8) Datenordner in AppData und ProgramData: gleiche Signatur bzw. gleiches Produkt, oder Konfiguration mit Programmpfad
    Report 'Prüfe Datenordner in AppData und ProgramData ... (kann bis zu zwei Minuten dauern)'
    $otherTokens = @{}
    foreach ($o in @($AllPrograms | Where-Object { $_ -and $_.Name -ne $P.Name })) {
        foreach ($t in @((Get-CleanName ([string]$o.Name)), ([string]$o.Publisher -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', ''))) { $tk = ConvertTo-Token $t; if ($tk.Length -ge 3) { $otherTokens[$tk] = $true } }
    }
    # Eigene Namen (Programm ohne Hersteller, Programmdatei, Hersteller) - nur als ZUSÄTZLICHE Bedingung in Sammelordnern, nie als Beleg
    $ownTokens = @{}
    $pubWords = @(([string]$P.Publisher) -split '[^\p{L}\p{N}]+' | ForEach-Object { ConvertTo-Token $_ } | Where-Object { $_ })
    $clean = Get-CleanName ([string]$P.Name)
    $noPub = (@($clean -split '\s+' | Where-Object { $pubWords -notcontains (ConvertTo-Token $_) }) -join ' ')
    foreach ($t in @($clean, $noPub, $(if ($exe) { [IO.Path]::GetFileNameWithoutExtension($exe) }), ([string]$P.Publisher -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', ''))) {
        $tk = ConvertTo-Token $t; if ($tk.Length -ge 3) { $ownTokens[$tk] = $true; [void]$otherTokens.Remove($tk) }
    }
    $textExt = @('.ini', '.cfg', '.conf', '.config', '.json', '.xml', '.txt', '.settings', '.properties', '.yaml', '.yml', '.vdf', '.reg')
    $dataRoots = @($env:APPDATA, $env:LOCALAPPDATA, "$env:USERPROFILE\AppData\LocalLow", $env:ProgramData) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach ($root in $dataRoots) {
        foreach ($d1 in @(Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction SilentlyContinue)) {
            $t1 = ConvertTo-Token $d1.Name
            if ($script:SharedDataFolders -contains $t1 -and -not $ownTokens.ContainsKey($t1)) { $hub = $true } else { $hub = $false }
            if ($d1.Name -in 'Microsoft', 'Packages', 'Temp', 'Programs', 'Package Cache') { continue }
            if (Test-PathUnder $d1.FullName $dirs) { continue }     # schon als Programmordner erfasst
            if (& $isShared $d1.FullName) { continue }
            # Belege einsammeln, zugeordnet zum Unterordner der 2. Ebene
            $evidence = @{}; $strong = @{}
            $files = @(Get-ChildItem -LiteralPath $d1.FullName -File -Recurse -Depth 3 -Force -ErrorAction SilentlyContinue | Select-Object -First 400)
            $bins = @($files | Where-Object { $_.Extension -in '.exe', '.dll' } | Select-Object -First 25)
            $texts = @($files | Where-Object { $textExt -contains $_.Extension.ToLower() -and $_.Length -lt 512KB } | Select-Object -First 40)
            foreach ($b in $bins) {
                $why = ''
                $t = if ($thumbs.Count) { Get-SignerThumb $b.FullName } else { '' }
                $isStrong = $false
                if ($products.Count) { $v = Get-FileVendor $b.FullName; if ($v -and $products.ContainsKey("$($v.Company)|$($v.Product)".ToLower())) { $why = "Datei $($b.Name) gehört laut Versionsangabe zu »$($v.Product)« von $($v.Company)"; $isStrong = $true } }
                # gleiche Signatur heißt nur »gleicher Hersteller« (z. B. Google Chrome und Google Drive) - zählt nur zusammen mit dem Namen
                if (-not $why -and $t -and $thumbs.ContainsKey($t)) { $why = "Datei $($b.Name) trägt dieselbe digitale Signatur wie das Programm" }
                if ($why) { $k = Get-EvidenceFolder $d1.FullName $b.FullName; $evidence[$k] = $why; if ($isStrong) { $strong[$k] = $true } }
            }
            if ($needles.Count) {
                foreach ($f in $texts) {
                    $txt = try { [IO.File]::ReadAllText($f.FullName) } catch { '' }
                    $hit = Find-Needle $txt $needles
                    # verweist dieselbe Datei auch auf ein anderes installiertes Programm, ist sie kein Beleg
                    if ($hit -and $otherNeedles.Count -and (Find-Needle $txt $otherNeedles)) { $hit = $null }
                    if ($hit) { $k = Get-EvidenceFolder $d1.FullName $f.FullName; $evidence[$k] = "Datei $($f.Name) enthält den Programmpfad $hit"; $strong[$k] = $true }
                }
            }
            if ($evidence.Count -eq 0) { continue }
            # Ordner der 1. Ebene nur, wenn er kein Sammelordner ist und alle Inhalte belegt sind; sonst die belegten Unterordner
            $children = @(Get-ChildItem -LiteralPath $d1.FullName -Force -ErrorAction SilentlyContinue)
            $allProven = -not $hub -and -not $otherTokens.ContainsKey($t1) -and ($evidence.ContainsKey($d1.FullName) -or @($children | Where-Object { -not $evidence.ContainsKey($_.FullName) }).Count -eq 0)
            # Zusätzlich zum Beleg muss der Ordnername zum Programm passen
            $d1Rel = Test-NameRelated $d1.Name $fpOwn
            if ($allProven -and -not $d1Rel) {
                # Herstellerordner (z. B. ...\VideoLAN): nur, wenn jeder Inhalt stark belegt ist UND wie das Programm heißt
                $allProven = ($t1 -eq (ConvertTo-Token ([string]$P.Publisher -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', ''))) -and $children.Count -gt 0 -and
                    @($children | Where-Object { -not ($strong.ContainsKey($_.FullName) -and (Test-NameRelated $_.Name $fpOwn)) }).Count -eq 0
            }
            if ($allProven) {
                Add-Fp (New-Leftover 'Ordner' $d1.FullName 'Programmdaten') (@($evidence.Values)[0])
            } else {
                $foreignTop = $hub -or $otherTokens.ContainsKey($t1)
                foreach ($k in $evidence.Keys) {
                    if ($k -eq $d1.FullName) { continue }      # Beleg direkt im Sammelordner: nicht genug, um den ganzen Ordner zu löschen
                    $t2 = ConvertTo-Token (Split-Path $k -Leaf)
                    if ($otherTokens.ContainsKey($t2)) { continue }
                    # In Sammelordnern (z. B. NVIDIA, Steam, Mozilla) reicht ein Pfadverweis nicht: der Unterordner muss zusätzlich genau wie das Programm heißen
                    if ($foreignTop -and -not $ownTokens.ContainsKey($t2)) { continue }
                    if (-not (Test-NameRelated (Split-Path $k -Leaf) $fpOwn)) { continue }
                    if (-not $strong.ContainsKey($k) -and -not $d1Rel) { continue }     # nur Signatur: reicht nur im Ordner des Programms selbst
                    Add-Fp (New-Leftover 'Ordner' $k 'Programmdaten') $evidence[$k]
                }
            }
        }
    }

    [pscustomobject]@{ Name = $P.Name; Items = @($items); Dirs = @($dirs); Needles = $needles; Time = (Get-Date) }
}

# Unterordner der 2. Ebene, in dem eine Beleg-Datei liegt (bzw. der Ordner der 1. Ebene, wenn sie direkt darin liegt)
function Get-EvidenceFolder([string]$Top, [string]$File) {
    $rel = $File.Substring($Top.Length).TrimStart('\')
    $i = $rel.IndexOf('\')
    if ($i -lt 0) { return $Top }
    return ($Top.TrimEnd('\') + '\' + $rel.Substring(0, $i))
}

# Existiert ein Eintrag aus dem Fußabdruck noch?
function Test-LeftoverExists($It) {
    switch ($It.Type) {
        { $_ -in 'Ordner', 'Datei' } { return (Test-PathAny $It.Path) }
        'Registry-Schlüssel' { return (Test-RegKeyExists $It) }
        'Registry-Wert' { try { $bk = Open-BaseKey $It.Hive $It.View; $k = $bk.OpenSubKey($It.SubKey); $e = $k -and ($k.GetValueNames() -contains $It.ValueName); if ($k) { $k.Close() }; $bk.Close(); return [bool]$e } catch { return $false } }
        'Dienst' { return [bool](Get-CimInstance Win32_Service -Filter "Name='$($It.Service -replace "'", "''")'" -ErrorAction SilentlyContinue) }
        'Aufgabe' { return [bool](Get-ScheduledTask -TaskName $It.Task -TaskPath $It.TaskPath -ErrorAction SilentlyContinue) }
        'Firewall-Regel' { return [bool](Get-NetFirewallRule -Name $It.Rule -ErrorAction SilentlyContinue) }
    }
    return $false
}

# Reste = Einträge des Fußabdrucks, die nach der Deinstallation noch da sind. Ohne Fußabdruck wird er jetzt erstellt.
function Find-Leftovers($P, $AllPrograms, $FP = $null) {
    if (-not $FP) { $FP = Get-ProgramFootprint $P $AllPrograms }
    Report 'Prüfe, was davon noch vorhanden ist ...'
    $left = @($FP.Items | Where-Object { Test-LeftoverExists $_ })
    $left = @(Remove-StillReferenced $left)
    foreach ($it in $left) {
        if ($it.Type -eq 'Ordner') { $it.Size = Get-DirSize $it.Path }
        $it.Selected = -not (($it.Type -in 'Ordner', 'Datei') -and (Test-ProtectedPath $it.Path))
    }
    # Einträge in einem ebenfalls gefundenen Ordner bzw. Schlüssel nicht doppelt aufführen
    $folders = @($left | Where-Object { $_.Type -eq 'Ordner' } | ForEach-Object { $_.Path.TrimEnd('\') + '\' })
    $keys = @($left | Where-Object { $_.Type -eq 'Registry-Schlüssel' } | ForEach-Object { $_.Path.TrimEnd('\') + '\' })
    $left | Where-Object {
        $x = $_
        switch ($x.Type) {
            { $_ -in 'Ordner', 'Datei' } { -not ($folders | Where-Object { ($x.Path.TrimEnd('\') + '\').StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -and ($x.Path.TrimEnd('\') + '\') -ne $_ }); break }
            'Registry-Schlüssel' { -not ($keys | Where-Object { ($x.Path + '\').StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -and ($x.Path + '\') -ne $_ }); break }
            default { $true }
        }
    } | Sort-Object Type, Path
}

# ===========================================================================
#  RESTE NICHT MEHR INSTALLIERTER PROGRAMME UND SPIELE
#  Grundsatz wie bei der Deinstallation: nur mit Beleg, nie nach ähnlichen Namen.
#  Belege:
#    - Eintrag verweist auf ein Programm, das auf einem lokalen Laufwerk nicht mehr existiert
#    - Spieleordner, den der Launcher (Steam, Epic, GOG) nicht mehr als installiert führt
#    - Fußabdruck einer früheren Deinstallation mit TuneRig
#    - Datenordner, deren Einstellungen ausschließlich auf ein solches Programm verweisen
#    - leere Ordner in Programmbereichen
# ===========================================================================
$script:FootprintDir = Join-Path $env:LOCALAPPDATA 'TuneRig\Footprints'

# Fußabdruck einer Deinstallation dauerhaft speichern (für spätere Restesuchen)
function Save-Footprint($P, $FP) {
    try {
        New-Item -ItemType Directory -Force -Path $script:FootprintDir | Out-Null
        $safe = ($P.Name -replace '[^\w\-]+', '_')
        $o = [pscustomobject]@{ Program = [pscustomobject]@{ Name = $P.Name; Publisher = $P.Publisher; Hive = $P.Hive; View = $P.View; SubKey = $P.SubKey; InstallLocation = $P.InstallLocation }
                                Time = (Get-Date).ToString('o'); Items = @($FP.Items); Dirs = @($FP.Dirs) }
        $o | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $script:FootprintDir ("{0:yyyyMMdd-HHmmss}_{1}.json" -f (Get-Date), $safe)) -Encoding UTF8
    } catch {}
}

# Fehlt ein Ziel nachweislich? Nur für absolute Pfade auf vorhandenen, fest eingebauten Laufwerken, außerhalb von Windows.
function Test-TargetMissing([string]$Path) {
    $raw = ([string]$Path).Trim().Trim('"')
    $p = [Environment]::ExpandEnvironmentVariables($raw)
    if ($p -notmatch '^[A-Za-z]:\\.+') { return $false }
    if ($raw -match '%[^%]+%' -and $p -match '%[^%]+%') { return $false }             # Variable eines anderen Kontos o. Ä. - nicht auflösbar
    try { $drv = New-Object IO.DriveInfo($p.Substring(0, 1)); if (-not $drv.IsReady -or [string]$drv.DriveType -ne 'Fixed') { return $false } } catch { return $false }
    if ($p.StartsWith($env:windir + '\', [StringComparison]::OrdinalIgnoreCase)) { return $false }
    # Windows-eigene Programme, Store-Apps und virtualisierte Programme (Office Klick-und-Los, App-V): Pfade sind oft nur Aliase
    if ($p -match '(?i)\\(WindowsApps|Microsoft\\WindowsApps|Microsoft Office\\root|Microsoft Office 15\\root|App-V|AppV|Package Cache)\\') { return $false }
    if ($p -match '(?i)^[A-Za-z]:\\Program Files( \(x86\))?\\(Windows [^\\]+|Internet Explorer|Microsoft[^\\]*|Common Files\\(Microsoft Shared|System))(\\|$)') { return $false }
    # Alle Schreibweisen prüfen: 64-/32-Bit-Programmordner (z. B. %ProgramFiles% im 32-Bit-Teil der Registry) und Kurznamen
    $variants = New-Object System.Collections.Generic.List[string]
    $variants.Add($p)
    $pf = $env:ProgramW6432; if (-not $pf) { $pf = $env:ProgramFiles }; $pf86 = ${env:ProgramFiles(x86)}
    if ($pf -and $pf86) {
        if ($p.StartsWith($pf + '\', [StringComparison]::OrdinalIgnoreCase)) { $variants.Add($pf86 + $p.Substring($pf.Length)) }
        if ($p.StartsWith($pf86 + '\', [StringComparison]::OrdinalIgnoreCase)) { $variants.Add($pf + $p.Substring($pf86.Length)) }
    }
    foreach ($v in $variants) { if (Test-PathAny $v) { return $false } }
    return $true
}

# Pfade, aus denen gerade etwas läuft oder die zu installierter Software gehören (für Test-ProgramGone)
function Get-LiveRoots($AllPrograms) {
    $roots = New-Object System.Collections.Generic.List[string]
    foreach ($x in @(Get-CimInstance Win32_Process -Property ExecutablePath -ErrorAction SilentlyContinue)) { if ($x.ExecutablePath) { $roots.Add((Split-Path ([string]$x.ExecutablePath) -Parent)) } }
    foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) { $t = Get-ExeFromCommand ([string]$s.PathName); if ($t -and (Test-PathAny $t)) { $roots.Add((Split-Path $t -Parent)) } }
    foreach ($p in @($AllPrograms)) {
        if ($p.InstallLocation -and (Test-PathAny $p.InstallLocation)) { $roots.Add([string]$p.InstallLocation) }
        if ($p.MainExe -and (Test-PathAny $p.MainExe)) { $roots.Add((Split-Path ([string]$p.MainExe) -Parent)) }
    }
    return @($roots | Where-Object { $_ -and $_.Length -gt 3 } | ForEach-Object { $_.TrimEnd('\') } | Sort-Object -Unique)
}

# Ist das GANZE Programm weg - nicht nur eine Datei? Viele Programme liegen in Versionsordnern
# (z. B. ...\Google\Drive File Stream\85.0.13.0\), die bei jedem Update wechseln. Alte Einträge zeigen dann auf den
# alten Versionsordner, obwohl das Programm installiert ist. Verwaist ist ein Ziel deshalb nur, wenn
#   - vom Programmordner nichts mehr existiert (höchstens noch der Herstellerordner, z. B. ...\Google),
#   - im noch vorhandenen Ordner keine gleichnamige Programmdatei an anderer Stelle liegt und
#   - darunter kein Prozess läuft, kein Dienst installiert ist und kein installiertes Programm liegt.
function Test-ProgramGone([string]$Target, $LiveRoots = $script:OrphanLiveRoots, [switch]$NoTwin) {
    $p = [Environment]::ExpandEnvironmentVariables(([string]$Target).Trim().Trim('"')).TrimEnd('\')
    if ($p -notmatch '^[A-Za-z]:\\.+') { return $false }
    $pf = $env:ProgramW6432; if (-not $pf) { $pf = $env:ProgramFiles }
    $areas = @($pf, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA, "$env:LOCALAPPDATA\Programs", "$env:USERPROFILE\AppData\LocalLow", $env:USERPROFILE) |
             Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') } | Sort-Object Length -Descending
    $area = @($areas | Where-Object { $p.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) })[0]
    if (-not $area) { $area = $p.Substring(0, 2) }                              # sonst: Laufwerk (z. B. D:\Games\...)
    $rel = @($p.Substring($area.Length).Trim('\').Split('\') | Where-Object { $_ })
    # nächster noch existierender Ordner auf dem Weg zum Ziel
    $exist = $area; $depth = 0
    for ($i = 0; $i -lt $rel.Count - 1; $i++) {
        $next = $exist + '\' + $rel[$i]
        if (Test-PathAny $next) { $exist = $next; $depth = $i + 1 } else { break }
    }
    if ($depth -ge 2) { return $false }                                         # Programmordner existiert noch -> Programm vermutlich installiert
    if ($depth -ge 1 -and $depth -eq $rel.Count - 1) { return $false }        # der Ordner, in dem die Datei direkt liegt, existiert noch
    $variants = @($p)
    if (-not $NoTwin -and $p.StartsWith($pf + '\', [StringComparison]::OrdinalIgnoreCase) -and ${env:ProgramFiles(x86)}) { $variants += ${env:ProgramFiles(x86)} + $p.Substring($pf.Length) }
    if (-not $NoTwin -and ${env:ProgramFiles(x86)} -and $p.StartsWith(${env:ProgramFiles(x86)} + '\', [StringComparison]::OrdinalIgnoreCase)) { $variants += $pf + $p.Substring(${env:ProgramFiles(x86)}.Length) }
    if ($depth -eq 1) {
        # Herstellerordner existiert noch: liegt dort dieselbe Programmdatei an anderer Stelle (neuere Version)?
        $leaf = Split-Path $p -Leaf
        if ($leaf -match '\.(exe|dll)$' -and (Get-ChildItem -LiteralPath $exist -Filter $leaf -File -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1)) { return $false }
        # Herstellerordner in Programmbereichen (z. B. ...\Program Files\Google): läuft dort etwas, oder liegt dort installierte Software / ein Dienst?
        # (nicht bei Sammelordnern auf anderen Laufwerken wie D:\Games, sonst würde jedes installierte Spiel alle anderen blockieren)
        if ($area.Length -gt 2) { foreach ($r in @($LiveRoots)) { if ($r -and ($r + '\').StartsWith($exist + '\', [StringComparison]::OrdinalIgnoreCase)) { return $false } } }
    }
    # Gleiche Prüfung für den 32-/64-Bit-Zwilling des Pfads
    foreach ($v in @($variants | Select-Object -Skip 1)) { if (-not (Test-ProgramGone $v $LiveRoots -NoTwin)) { return $false } }
    return $true
}

# Verwaistes Ziel = Datei fehlt UND das ganze Programm ist weg
function Test-OrphanTarget([string]$Path) { (Test-TargetMissing $Path) -and (Test-ProgramGone $Path) }

# Gehört ein Eintrag zu Windows selbst? Windows schützt seine Dateien und Schlüssel mit dem Besitzer »TrustedInstaller«.
function Test-WindowsOwned($It) {
    try {
        switch ($It.Type) {
            { $_ -in 'Ordner', 'Datei' } {
                if (-not (Test-PathAny $It.Path)) { return $false }
                return ([string](Get-Acl -LiteralPath $It.Path -ErrorAction Stop).Owner -match '(?i)TrustedInstaller')
            }
            { $_ -in 'Registry-Schlüssel', 'Registry-Wert' } {
                $bk = Open-BaseKey $It.Hive $It.View; $k = $bk.OpenSubKey($It.SubKey)
                if (-not $k) { $bk.Close(); return $false }
                $owner = [string]$k.GetAccessControl([System.Security.AccessControl.AccessControlSections]::Owner).GetOwner([System.Security.Principal.NTAccount])
                $k.Close(); $bk.Close()
                return ($owner -match '(?i)TrustedInstaller')
            }
        }
    } catch {}
    return $false
}

# ---------------------------------------------------------------------------
#  Gegenprüfung über die gesamte Registry: Wird ein Ordner bzw. eine Datei noch
#  irgendwo erwähnt (Dienste, COM, Umgebungsvariablen, Windows Installer,
#  gemeinsam genutzte DLLs, Firewall, Einstellungen anderer Programme ...)?
#  Erwähnungen in Einträgen, die selbst als Rest gelöscht werden, zählen nicht.
#  Reine Verlaufslisten (zuletzt geöffnet, Kompatibilitäts-Protokoll ...) auch nicht.
# ---------------------------------------------------------------------------
function Initialize-RegRefs {
    if ('TuneRig.RegRefs' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace TuneRig
{
    public static class RegRefs
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        static extern uint GetShortPathName(string longPath, StringBuilder shortPath, uint size);

        public static string ShortPath(string p)
        {
            try { var sb = new StringBuilder(1024); uint n = GetShortPathName(p, sb, 1024); if (n > 0 && n < 1024) return sb.ToString(); } catch { }
            return null;
        }

        static readonly Regex Noise = new Regex(@"\\(recentdocs|comdlg32|typedpaths|runmru|featureusage|userassist|wordwheelquery|muicache|bagmru|bags|shellnoroam|appcompatflags|bam|dam|tracing|directinput|gameconfigstore|capabilityaccessmanager|search|notifications|pushnotifications|jumplist[^\\]*|recent[^\\]*|[^\\]*mru[^\\]*)(\\|$)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        static string[] needles; static string[] owners; static Dictionary<string, string> found;
        static HashSet<string> exKeys; static HashSet<string> exValues; static string[] exPrefixes;
        static DateTime deadline;

        // needles: Pfade (klein), owners: zugehöriger Original-Pfad; excludeKeys: Schlüssel (inkl. Unterschlüssel), excludeValues: "schlüssel|wert"
        public static Dictionary<string, string> Find(string[] needleList, string[] ownerList, string[] excludeKeys, string[] excludeValues, int seconds)
        {
            needles = needleList; owners = ownerList; found = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            exPrefixes = excludeKeys; exKeys = new HashSet<string>(excludeKeys, StringComparer.OrdinalIgnoreCase);
            exValues = new HashSet<string>(excludeValues, StringComparer.OrdinalIgnoreCase);
            deadline = DateTime.Now.AddSeconds(seconds);
            string sid = System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;
            using (var lm = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            {
                Walk(lm, "SOFTWARE", "HKLM\\SOFTWARE", 0);
                Walk(lm, "SYSTEM\\CurrentControlSet", "HKLM\\SYSTEM\\CurrentControlSet", 0);
            }
            using (var hu = RegistryKey.OpenBaseKey(RegistryHive.Users, RegistryView.Registry64))
            {
                foreach (var u in hu.GetSubKeyNames())
                {
                    string disp = u.Equals(sid, StringComparison.OrdinalIgnoreCase) ? "HKCU"
                                : u.Equals(sid + "_Classes", StringComparison.OrdinalIgnoreCase) ? "HKCU\\Software\\Classes" : "HKU\\" + u;
                    Walk(hu, u, disp, 0);
                }
            }
            if (DateTime.Now > deadline) found["*timeout*"] = "";
            return found;
        }

        static bool Excluded(string disp)
        {
            if (exKeys.Contains(disp)) return true;
            foreach (var p in exPrefixes) if (disp.StartsWith(p + "\\", StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        static void Walk(RegistryKey parent, string sub, string disp, int depth)
        {
            if (depth > 40 || found.Count >= owners.Length || DateTime.Now > deadline) return;
            if (Noise.IsMatch(disp) || Excluded(disp)) return;
            RegistryKey k = null;
            try { k = parent.OpenSubKey(sub, false); } catch { return; }
            if (k == null) return;
            using (k)
            {
                string[] names = null;
                try { names = k.GetValueNames(); } catch { }
                if (names != null)
                {
                    foreach (var n in names)
                    {
                        if (exValues.Contains(disp + "|" + n)) continue;
                        Check(n, disp, n);
                        object v = null;
                        try { v = k.GetValue(n); } catch { }
                        var s = v as string;
                        if (s != null) Check(s, disp, n);
                        else { var m = v as string[]; if (m != null) foreach (var x in m) Check(x, disp, n); }
                    }
                }
                string[] subs = null;
                try { subs = k.GetSubKeyNames(); } catch { }
                if (subs != null) foreach (var s in subs) Walk(k, s, disp + "\\" + s, depth + 1);
            }
        }

        static void Check(string text, string disp, string valueName)
        {
            if (string.IsNullOrEmpty(text) || text.Length < 4) return;
            if (text.IndexOf(":\\", StringComparison.Ordinal) < 0 && text.IndexOf(":/", StringComparison.Ordinal) < 0 && text.IndexOf('~') < 0) return;
            string t = text.Replace('/', '\\').Replace("\\\\", "\\").ToLowerInvariant();
            for (int i = 0; i < needles.Length; i++)
            {
                if (found.ContainsKey(owners[i])) continue;
                string nd = needles[i]; int pos = 0;
                while ((pos = t.IndexOf(nd, pos, StringComparison.Ordinal)) >= 0)
                {
                    int e = pos + nd.Length;
                    bool startOk = pos == 0 || !char.IsLetterOrDigit(t[pos - 1]);
                    bool endOk = e >= t.Length || !(char.IsLetterOrDigit(t[e]) || t[e] == '_' || t[e] == '-');
                    if (startOk && endOk) { found[owners[i]] = disp + (string.IsNullOrEmpty(valueName) ? " (Standardwert)" : " -> " + valueName); break; }
                    pos = e;
                }
            }
        }
    }
}
'@
}

# Entfernt Ordner/Dateien aus der Liste, die woanders in der Registry noch erwähnt werden
function Remove-StillReferenced($Items) {
    $list = @($Items)
    $paths = @($list | Where-Object { $_.Type -in 'Ordner', 'Datei' -and $_.Path })
    if (-not $paths.Count) { return $list }
    try { Initialize-RegRefs } catch { return $list }
    Report 'Gegenprüfung: Wird davon noch irgendwo in Windows etwas erwähnt? ... (kann bis zu einer Minute dauern)'
    $needles = New-Object System.Collections.Generic.List[string]; $owners = New-Object System.Collections.Generic.List[string]
    foreach ($it in $paths) {
        $p = $it.Path.TrimEnd('\')
        foreach ($form in @($p, [TuneRig.RegRefs]::ShortPath($p)) | Where-Object { $_ } | Select-Object -Unique) { $needles.Add($form.ToLowerInvariant()); $owners.Add($p) }
    }
    $exKeys = New-Object System.Collections.Generic.List[string]; $exVals = New-Object System.Collections.Generic.List[string]
    foreach ($it in $list) {
        switch ($it.Type) {
            'Registry-Schlüssel' { $exKeys.Add((Get-RegDisplayPath $it.Hive $it.View $it.SubKey)) }
            'Registry-Wert' { $exVals.Add(((Get-RegDisplayPath $it.Hive $it.View $it.SubKey) + '|' + $it.ValueName)) }
            'Dienst' { if ($it.Service) { $exKeys.Add("HKLM\SYSTEM\CurrentControlSet\Services\$($it.Service)") } }
            'Firewall-Regel' { if ($it.Rule) { $exVals.Add("HKLM\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules|$($it.Rule)") } }
        }
    }
    # Deinstallationseinträge und Windows-Installer-Daten der gefundenen Reste gehören ebenfalls dazu
    $found = $null
    try { $found = [TuneRig.RegRefs]::Find($needles.ToArray(), $owners.ToArray(), $exKeys.ToArray(), $exVals.ToArray(), 90) } catch { return $list }
    if ($found.ContainsKey('*timeout*')) {
        # nicht vollständig geprüft: dann nichts vorauswählen
        foreach ($it in $paths) { if (-not $found.ContainsKey($it.Path.TrimEnd('\'))) { $it.Selected = $false; $it.Reason = "$($it.Reason) – Gegenprüfung unvollständig, bitte prüfen" } }
    }
    $script:LastReferenced = @()
    $keep = foreach ($it in $list) {
        if ($it.Type -in 'Ordner', 'Datei' -and $found.ContainsKey($it.Path.TrimEnd('\'))) {
            $script:LastReferenced += [pscustomobject]@{ Path = $it.Path; By = $found[$it.Path.TrimEnd('\')] }
            continue
        }
        $it
    }
    return @($keep)
}

# Ordner, der vermutlich Windows bzw. einem Systemdienst gehört:
# Besitzer TrustedInstaller/SYSTEM/LOCAL SERVICE/NETWORK SERVICE, eigens gesetzte Berechtigungen oder Systemattribut
function Test-SystemFolder([string]$Path) {
    try {
        $di = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
        if ($di.Attributes -band [IO.FileAttributes]::System) { return 'hat das Systemattribut' }
        $acl = Get-Acl -LiteralPath $Path -ErrorAction Stop
        $sid = try { ([Security.Principal.NTAccount]$acl.Owner).Translate([Security.Principal.SecurityIdentifier]).Value } catch { '' }
        if ($acl.Owner -match '(?i)TrustedInstaller' -or $sid -in 'S-1-5-18', 'S-1-5-19', 'S-1-5-20' -or $sid -like 'S-1-5-80-*') { return "gehört $($acl.Owner)" }
        if ($acl.AreAccessRulesProtected) { return 'hat eigens gesetzte Berechtigungen' }
        if (@($acl.Access | Where-Object { -not $_.IsInherited }).Count) { return 'hat eigens gesetzte Berechtigungen' }
    } catch { return 'Berechtigungen nicht lesbar' }
    return $null
}

# Gegenprüfung unmittelbar vor dem Löschen: gilt der Beleg noch?
function Test-LeftoverStillValid($It) {
    if (Test-WindowsOwned $It) { return 'Gehört zu Windows (Besitzer TrustedInstaller) – wird nie gelöscht.' }
    if ($It.Target) {
        if (-not $script:OrphanLiveRoots) { $script:OrphanLiveRoots = @(Get-LiveRoots @(Get-InstalledPrograms $false)) }
        if (-not (Test-OrphanTarget $It.Target)) { return "Das Programm ist (wieder) vorhanden oder wird noch genutzt ($($It.Target)) – nicht gelöscht." }
    }
    if (($It.Type -in 'Ordner', 'Datei') -and (Test-ProtectedPath $It.Path)) { return 'Geschützter Ordner – wird nie gelöscht.' }
    return ''
}

# Programmdatei aus einer Befehlszeile; Hilfsprogramme von Windows (rundll32, msiexec ...) zählen nicht
function Get-CommandTarget([string]$Cmd) {
    $exe = Get-ExeFromCommand $Cmd
    if (-not $exe -or $exe -notmatch '^[A-Za-z]:\\') { return '' }
    if ($exe -match '(?i)\\(rundll32|regsvr32|msiexec|cmd|powershell|pwsh|wscript|cscript|mshta|explorer|conhost|svchost|dllhost)\.exe$') { return '' }
    return $exe
}

# ---------------------------------------------------------------------------
#  Zusätzliche Schutzprüfungen für Reste
# ---------------------------------------------------------------------------
# Ordner, auf die vorhandene Verknüpfungen zeigen (Programme, die man direkt startet)
function Get-LiveLinkDirs {
    $dirs = New-Object System.Collections.Generic.List[string]
    $shell = $null; try { $shell = New-Object -ComObject WScript.Shell } catch { return @() }
    $roots = @(([Environment]::GetFolderPath('CommonStartMenu') + '\Programs'), ([Environment]::GetFolderPath('StartMenu') + '\Programs'),
               [Environment]::GetFolderPath('DesktopDirectory'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
               "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar") | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
    foreach ($r in $roots) {
        foreach ($l in @(Get-ChildItem -LiteralPath $r -Filter *.lnk -File -Recurse -Depth 3 -ErrorAction SilentlyContinue)) {
            try { $t = [string]$shell.CreateShortcut($l.FullName).TargetPath; if ($t -and (Test-PathAny $t)) { $dirs.Add((Split-Path $t -Parent)) } } catch {}
        }
    }
    return @($dirs | Sort-Object -Unique)
}

# Wird ein Ordner noch benutzt? (Prozess läuft daraus, Dienst/Programm liegt darin, eine Verknüpfung zeigt hinein)
function Test-InUse([string]$Folder) {
    $f = $Folder.TrimEnd('\') + '\'
    foreach ($r in @($script:OrphanLiveRoots) + @($script:OrphanLinkDirs)) { if ($r -and ($r.TrimEnd('\') + '\').StartsWith($f, [StringComparison]::OrdinalIgnoreCase)) { return $true } }
    return $false
}

# Wurde im Ordner in den letzten Tagen noch etwas geändert?
function Test-RecentlyUsed([string]$Folder, [int]$Days = 30, $Since = $null) {
    $limit = if ($Since) { [datetime]$Since } else { (Get-Date).AddDays(-$Days) }
    try { if ((Get-Item -LiteralPath $Folder -Force -ErrorAction Stop).LastWriteTime -gt $limit) { return $true } } catch {}
    return [bool](Get-ChildItem -LiteralPath $Folder -Recurse -Force -ErrorAction SilentlyContinue | Select-Object -First 3000 | Where-Object { $_.LastWriteTime -gt $limit } | Select-Object -First 1)
}

# Enthält der Ordner vermutlich eigene Dateien (Spielstände, Dokumente, Fotos, Videos)?
function Test-LikelyUserData([string]$Folder) {
    $hit = Get-ChildItem -LiteralPath $Folder -Recurse -Depth 4 -Force -ErrorAction SilentlyContinue | Select-Object -First 3000 | Where-Object {
        $_.Name -match '(?i)^(saves?|savegames?|saved ?games?|savedata|save_data|screenshots|recordings|profiles?|userdata|my .+)$' -or
        $_.Extension -match '(?i)^\.(sav|save|sl2|ess|fos|docx?|xlsx?|pptx?|odt|ods|pdf|psd|kra|blend|jpe?g|png|heic|raw|cr2|nef|mp4|mkv|mov|avi|mp3|flac|wav|zip|rar|7z)$'
    } | Select-Object -First 1
    return [bool]$hit
}

# Namen eines Programms (nur als ZUSÄTZLICHE Bedingung zum Beleg, nie allein)
function Get-OwnTokens([string]$Name, [string]$Publisher, $ExeNames = @()) {
    $t = @{}
    $pubWords = @(([string]$Publisher) -split '[^\p{L}\p{N}]+' | ForEach-Object { ConvertTo-Token $_ } | Where-Object { $_ })
    $clean = Get-CleanName ([string]$Name)
    $noPub = (@($clean -split '\s+' | Where-Object { $pubWords -notcontains (ConvertTo-Token $_) }) -join ' ')
    foreach ($s in @($Name, $clean, $noPub) + @($ExeNames)) { $k = ConvertTo-Token $s; if ($k.Length -ge 3 -and $script:GenericNames -notcontains $k) { $t[$k] = $true } }
    # Herstellername merken: ein Ordner, der nur so heißt wie der Hersteller, gehört nicht automatisch zu diesem Programm
    $t['|pub'] = ConvertTo-Token (([string]$Publisher) -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', '')
    return $t
}
function Test-NameRelated([string]$FolderName, $Tokens) {
    $k = ConvertTo-Token $FolderName
    if (-not $k) { return $false }
    if ($Tokens.ContainsKey($k)) { return $true }
    # allgemeine Namen (Google, Steam, Data ...) und reine Herstellernamen nie über den Wortanfang zuordnen
    if ($script:GenericNames -contains $k -or ($Tokens['|pub'] -and $k -eq $Tokens['|pub'])) { return $false }
    foreach ($o in $Tokens.Keys) { if ($o -eq '|pub') { continue }; if ($o.Length -ge 5 -and $k.Length -ge 5 -and ($k.StartsWith($o) -or $o.StartsWith($k))) { return $true } }
    return $false
}

# Benutzerbezogene Umgebungsvariablen: ein solcher Pfad kann für ein anderes Benutzerkonto existieren
$script:UserVarPattern = '(?i)%(LOCALAPPDATA|APPDATA|USERPROFILE|HOMEPATH|HOMEDRIVE|TEMP|TMP|USERNAME|ONEDRIVE[^%]*)%'

# Windows-eigene Startmenü-Ordner (auch wenn sie leer sind)
$script:WindowsMenuFolders = '^(?i)(Startup|Autostart|Accessibility|Accessories|Administrative Tools|Maintenance|System Tools|Windows PowerShell|Windows Accessories|Windows Administrative Tools|Windows Ease of Access|Windows System|Windows Tools|Zubehör|Erleichterte Bedienung|Windows-Verwaltungsprogramme|Windows-System|Windows-Zubehör|Windows-Tools|Systemprogramme|Wartung|Verwaltung|Windows Kits|Microsoft .+)$'

function Find-OrphanLeftovers {
    $items = New-Object System.Collections.ArrayList
    $seen = @{}
    function Add-O($It, [string]$Proof, [string]$Owner, [bool]$Select = $true) {
        $id = ($It.Type + '|' + $It.Path).ToLower(); if ($seen.ContainsKey($id)) { return }; $seen[$id] = $true
        if (($It.Type -in 'Ordner', 'Datei') -and ((Test-ProtectedPath $It.Path) -or (& $isInstalled $It.Path))) { return }
        if (Test-WindowsOwned $It) { return }                                   # Windows-Bestandteil: nie
        if ($It.Type -eq 'Ordner' -and (Test-InUse $It.Path)) { return }        # Prozess läuft daraus, Dienst/Programm/Verknüpfung zeigt hinein: nie
        # fehlendes Ziel merken - es wird direkt vor dem Löschen noch einmal geprüft
        if ($Proof -match '(?:existiert nicht mehr|ins Leere, z\. B\.): (.+)$') { $It.Target = $Matches[1].Trim() }
        $It.Proof = $Proof; $It.Confidence = 'sicher'; $It.Owner = $Owner; $It.Selected = $Select
        [void]$items.Add($It)
    }

    Report 'Lese die installierten Programme ...'
    $all = @(Get-InstalledPrograms $true)
    $script:OrphanLiveRoots = @(Get-LiveRoots $all)
    Report 'Prüfe, welche Programme über Verknüpfungen gestartet werden ...'
    $script:OrphanLinkDirs = @(Get-LiveLinkDirs)
    $orphanEntries = New-Object System.Collections.ArrayList
    $owners = New-Object System.Collections.ArrayList          # verwaiste Programme: Name, Herkunft, Pfade (Nadeln)

    # --- 1) Verwaiste Deinstallationseinträge
    Report 'Prüfe Deinstallationseinträge ...'
    foreach ($p in @($all | Where-Object { $_.Source -eq 'Win32' })) {
        $why = ''
        if ($p.IsMsi -and $p.ProductCode) {
            $packed = ConvertTo-PackedGuid $p.ProductCode
            $known = $false
            foreach ($k in @(@('HKLM', '64', "SOFTWARE\Classes\Installer\Products\$packed"), @('HKCU', 'Default', "Software\Microsoft\Installer\Products\$packed"))) {
                try { $bk = Open-BaseKey $k[0] $k[1]; $kk = $bk.OpenSubKey($k[2]); if ($kk) { $known = $true; $kk.Close() }; $bk.Close() } catch { $known = $true }
            }
            # auch Installationen anderer Benutzerkonten (Windows Installer führt sie unter UserData\<Konto>\Products)
            try {
                $bk = Open-BaseKey 'HKLM' '64'; $ud = $bk.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData')
                if ($ud) { foreach ($sid in $ud.GetSubKeyNames()) { $kk = $ud.OpenSubKey("$sid\Products\$packed"); if ($kk) { $known = $true; $kk.Close() } }; $ud.Close() }
                $bk.Close()
            } catch { $known = $true }
            $locGone = (-not $p.InstallLocation) -or (Test-OrphanTarget $p.InstallLocation)
            if (-not $known -and $locGone) { $why = 'Windows Installer kennt dieses Programm nicht mehr' }
        } else {
            $un = Get-CommandTarget ([string]$p.UninstallString)
            $loc = [string]$p.InstallLocation
            $exe = [string]$p.MainExe
            if ($un -and (Test-OrphanTarget $un) -and ((-not $loc) -or (Test-OrphanTarget $loc) -or -not (Get-ChildItem -LiteralPath $loc -Include *.exe, *.dll -File -Recurse -Depth 3 -ErrorAction SilentlyContinue | Select-Object -First 1)) -and ((-not $exe) -or (Test-OrphanTarget $exe))) {
                $why = "Deinstallationsprogramm existiert nicht mehr: $un"
            }
        }
        if (-not $why) { continue }
        $p | Add-Member -NotePropertyName OrphanWhy -NotePropertyValue $why -Force
        [void]$orphanEntries.Add($p)
    }
    $installed = @($all | Where-Object { $_.Source -eq 'Win32' -and $orphanEntries -notcontains $_ -and ([string]$_.InstallLocation).Length -gt 3 -and (Test-PathAny $_.InstallLocation) } | ForEach-Object { $_.InstallLocation.TrimEnd('\') })
    $isInstalled = { param($path) $d = $path.TrimEnd('\') + '\'; [bool]($installed | Where-Object { ($_ + '\').StartsWith($d, [StringComparison]::OrdinalIgnoreCase) -or $d.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase) }) }

    foreach ($p in $orphanEntries) {
        Add-O (New-RegLeftover $p.Hive $p.View $p.SubKey 'Verwaister Deinstallationseintrag') $p.OrphanWhy $p.Name
        $dirs = @(@([string]$p.InstallLocation, $(if ($p.MainExe) { Split-Path $p.MainExe -Parent }), $(if (Get-CommandTarget ([string]$p.UninstallString)) { Split-Path (Get-CommandTarget ([string]$p.UninstallString)) -Parent })) |
                  Where-Object { $_ -and $_.Length -gt 8 -and -not (Test-ProtectedPath $_) -and $_ -notmatch '(?i)\\(Package Cache|Installer|Temp|Common Files)(\\|$)' } | Select-Object -Unique)
        # Installationsordner ohne Programmdateien = Rest
        foreach ($d in $dirs) {
            if ((Test-PathAny $d) -and -not (Get-ChildItem -LiteralPath $d -Include *.exe, *.dll -File -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1)) {
                $keep = (Test-LikelyUserData $d) -or (Test-RecentlyUsed $d 30)
                Add-O (New-Leftover 'Ordner' $d $(if ($keep) { 'Installationsordner – enthält eigene oder kürzlich geänderte Dateien, bitte prüfen' } else { 'Installationsordner ohne Programmdateien' })) 'Programm ist nicht mehr installiert, im Ordner liegen keine Programmdateien mehr' $p.Name (-not $keep)
            }
        }
        [void]$owners.Add([pscustomobject]@{ Name = $p.Name; Publisher = [string]$p.Publisher; Dirs = $dirs })
    }

    # --- 2) Spiele-Launcher: Steam
    Report 'Prüfe Steam-Bibliotheken ...'
    $libs = New-Object System.Collections.Generic.List[string]
    $steamPath = [string](Get-RegValue 'HKCU' 'Software\Valve\Steam' 'SteamPath' '')
    if ($steamPath) {
        $sp = $steamPath.Replace('/', '\')
        $libs.Add((Join-Path $sp 'steamapps'))
        $vdf = Join-Path $sp 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) { foreach ($m in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s+"([^"]+)"')) { $libs.Add((Join-Path ($m.Groups[1].Value.Replace('\\', '\')) 'steamapps')) } }
    }
    foreach ($drv in @([IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady -and [string]$_.DriveType -eq 'Fixed' })) {
        foreach ($c in 'SteamLibrary\steamapps', 'Steam\steamapps', 'Program Files (x86)\Steam\steamapps', 'Games\Steam\steamapps', 'Games\SteamLibrary\steamapps') { $libs.Add((Join-Path $drv.RootDirectory.FullName $c)) }
    }
    foreach ($lib in @($libs | Where-Object { Test-Path -LiteralPath $_ } | ForEach-Object { (Get-Item -LiteralPath $_).FullName.TrimEnd('\') } | Sort-Object -Unique)) {
        $ids = @{}; $dirsOk = @{}
        foreach ($f in @(Get-ChildItem -LiteralPath $lib -Filter 'appmanifest_*.acf' -File -ErrorAction SilentlyContinue)) {
            $t = try { [IO.File]::ReadAllText($f.FullName) } catch { '' }
            if ($t -match '"appid"\s+"(\d+)"') { $ids[$Matches[1]] = $true }
            if ($t -match '"installdir"\s+"([^"]+)"') { $dirsOk[$Matches[1].ToLower()] = $true }
        }
        $common = Join-Path $lib 'common'
        foreach ($g in @(Get-ChildItem -LiteralPath $common -Directory -ErrorAction SilentlyContinue)) {
            if ($dirsOk.ContainsKey($g.Name.ToLower()) -or $g.Name -eq 'Steamworks Shared') { continue }
            Add-O (New-Leftover 'Ordner' $g.FullName 'Spieleordner – nicht vorausgewählt: Steam kann vorhandene Spieldateien bei einer Neuinstallation weiterverwenden') 'Steam führt kein installiertes Spiel mit diesem Ordner (kein App-Manifest in der Bibliothek)' $g.Name $false
            [void]$owners.Add([pscustomobject]@{ Name = $g.Name; Publisher = ''; Dirs = @($g.FullName) })
        }
        foreach ($sub in @(@('workshop\content', 'Workshop-Inhalte (Mods, Karten)'), @('shadercache', 'Shader-Cache'), @('downloading', 'Abgebrochener Download'), @('temp', 'Temporäre Steam-Dateien'))) {
            foreach ($d in @(Get-ChildItem -LiteralPath (Join-Path $lib $sub[0]) -Directory -ErrorAction SilentlyContinue)) {
                if ($d.Name -match '^\d+$' -and -not $ids.ContainsKey($d.Name)) {
                    Add-O (New-Leftover 'Ordner' $d.FullName $sub[1]) "Gehört zur Steam-App $($d.Name), die in dieser Bibliothek nicht mehr installiert ist" "Steam-App $($d.Name)"
                }
            }
        }
        foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $lib 'workshop') -Filter 'appworkshop_*.acf' -File -ErrorAction SilentlyContinue)) {
            if ($f.BaseName -match '_(\d+)$' -and -not $ids.ContainsKey($Matches[1])) { Add-O (New-Leftover 'Datei' $f.FullName 'Workshop-Verzeichnis') "Gehört zur Steam-App $($Matches[1]), die nicht mehr installiert ist" "Steam-App $($Matches[1])" }
        }
    }

    # --- 3) Epic Games
    Report 'Prüfe Epic-Games-Bibliotheken ...'
    $epicData = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    $epicLauncher = @($all | Where-Object { $_.Name -match '^Epic Games Launcher' -and $orphanEntries -notcontains $_ }).Count -gt 0
    $epicOk = @{}
    $epicBroken = $false
    foreach ($f in @(Get-ChildItem -LiteralPath $epicData -Filter *.item -File -ErrorAction SilentlyContinue)) { try { $j = Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json; if ($j.InstallLocation) { $epicOk[([string]$j.InstallLocation).TrimEnd('\').ToLower()] = $true } } catch { $epicBroken = $true } }
    $ueDat = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
    if (Test-Path -LiteralPath $ueDat) { try { foreach ($x in @((Get-Content -LiteralPath $ueDat -Raw | ConvertFrom-Json).InstallationList)) { if ($x.InstallLocation) { $epicOk[([string]$x.InstallLocation).TrimEnd('\').ToLower()] = $true } } } catch {} }
    # Ist ein Manifest unlesbar, wäre die Liste unvollständig: dann gar nichts als verwaist melden
    if (-not $epicBroken -and ((Test-Path -LiteralPath $epicData) -or -not $epicLauncher)) {
        $epicRoots = @($epicOk.Keys | ForEach-Object { Split-Path $_ -Parent }) + @([IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady -and [string]$_.DriveType -eq 'Fixed' } | ForEach-Object { Join-Path $_.RootDirectory.FullName 'Program Files\Epic Games'; Join-Path $_.RootDirectory.FullName 'Epic Games' })
        foreach ($root in @($epicRoots | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | ForEach-Object { (Get-Item -LiteralPath $_).FullName.TrimEnd('\') } | Sort-Object -Unique)) {
            if ((Split-Path $root -Leaf) -ne 'Epic Games') { continue }
            foreach ($g in @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
                if ($epicOk.ContainsKey($g.FullName.ToLower())) { continue }
                if ($epicLauncher -and $g.Name -in 'Launcher', 'DirectXRedist', 'EpicOnlineServices') { continue }
                Add-O (New-Leftover 'Ordner' $g.FullName 'Spieleordner – nicht vorausgewählt: kann eine bewusst behaltene Kopie sein') 'Der Epic Games Launcher führt kein installiertes Spiel in diesem Ordner' $g.Name $false
                [void]$owners.Add([pscustomobject]@{ Name = $g.Name; Publisher = ''; Dirs = @($g.FullName) })
            }
        }
    }

    # --- 4) GOG
    Report 'Prüfe GOG-Bibliotheken ...'
    $gogOk = @{}
    foreach ($v in '32', '64') {
        try { $bk = Open-BaseKey 'HKLM' $v; $gk = $bk.OpenSubKey('SOFTWARE\GOG.com\Games'); if ($gk) { foreach ($id in $gk.GetSubKeyNames()) { $k = $gk.OpenSubKey($id); $pth = [string]$k.GetValue('path'); $k.Close(); if ($pth) { $gogOk[$pth.TrimEnd('\').ToLower()] = $true } }; $gk.Close() }; $bk.Close() } catch {}
    }
    foreach ($drv in @([IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady -and [string]$_.DriveType -eq 'Fixed' })) {
        foreach ($c in 'GOG Games', 'Program Files (x86)\GOG Galaxy\Games', 'Games\GOG Games') {
            $root = Join-Path $drv.RootDirectory.FullName $c
            foreach ($g in @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
                if ($gogOk.ContainsKey($g.FullName.ToLower()) -or (& $isInstalled $g.FullName)) { continue }
                Add-O (New-Leftover 'Ordner' $g.FullName 'Spieleordner – nicht vorausgewählt: kann eine bewusst behaltene Kopie sein') 'GOG führt kein installiertes Spiel in diesem Ordner, und kein Deinstallationseintrag verweist darauf' $g.Name $false
                [void]$owners.Add([pscustomobject]@{ Name = $g.Name; Publisher = ''; Dirs = @($g.FullName) })
            }
        }
    }

    # --- 5) Frühere Deinstallationen mit TuneRig
    Report 'Prüfe Reste früherer Deinstallationen ...'
    foreach ($f in @(Get-ChildItem -LiteralPath $script:FootprintDir -Filter *.json -File -ErrorAction SilentlyContinue)) {
        try { $h = Get-Content -LiteralPath $f.FullName -Raw | ConvertFrom-Json } catch { continue }
        $prog = $h.Program
        $histTime = try { [datetime]$h.Time } catch { $null }
        $histDirs = @($h.Dirs | Where-Object { $_ })
        # Wieder installiert? - gleicher Name (auch mit anderer Versionsnummer), gleicher Ordner mit Programmdateien,
        # oder ein installiertes Programm liegt in einem der damaligen Ordner
        $cleanOld = ConvertTo-Token (Get-CleanName ([string]$prog.Name))
        $reinstalled = @($all | Where-Object { $orphanEntries -notcontains $_ -and ($_.Name -eq $prog.Name -or ((ConvertTo-Token (Get-CleanName ([string]$_.Name))) -eq $cleanOld -and $cleanOld)) }).Count -gt 0
        if (-not $reinstalled) { foreach ($d in $histDirs) { if ((Test-PathAny $d) -and (Get-ChildItem -LiteralPath $d -Include *.exe, *.dll -File -Recurse -Depth 4 -ErrorAction SilentlyContinue | Select-Object -First 1)) { $reinstalled = $true; break } } }
        if (-not $reinstalled) { foreach ($d in $histDirs) { if (& $isInstalled $d) { $reinstalled = $true; break } } }
        if ($reinstalled) { continue }
        $when = if ($histTime) { $histTime.ToString('dd.MM.yyyy') } else { '' }
        foreach ($it in @($h.Items)) {
            if (-not (Test-LeftoverExists $it)) { continue }
            # Registry-Schlüssel, die inzwischen auf ein installiertes Programm verweisen, gehören nicht mehr (nur) dazu
            if ($it.Type -eq 'Registry-Schlüssel') {
                try {
                    $bk = Open-BaseKey ([string]$it.Hive) ([string]$it.View); $k = $bk.OpenSubKey([string]$it.SubKey)
                    $liveRef = if ($k) { Find-RegNeedle $k @($installed | Where-Object { $_.Length -gt 8 }) } else { $null }
                    if ($k) { $k.Close() }; $bk.Close()
                    if ($liveRef) { continue }
                } catch { continue }
            }
            $n = New-Leftover ([string]$it.Type) ([string]$it.Path) ([string]$it.Reason) @{ Hive = [string]$it.Hive; View = [string]$it.View; SubKey = [string]$it.SubKey; ValueName = [string]$it.ValueName; Service = [string]$it.Service; Task = [string]$it.Task; TaskPath = [string]$it.TaskPath; Rule = [string]$it.Rule }
            # Seit der Deinstallation verändert? Dann nicht vorauswählen - etwas nutzt den Ordner offenbar noch
            $changed = ($it.Type -eq 'Ordner') -and $histTime -and (Test-RecentlyUsed ([string]$it.Path) 0 $histTime.AddMinutes(10))
            if ($changed) { $n.Reason += ' – seit der Deinstallation verändert, bitte prüfen' }
            Add-O $n ("$($it.Proof) (erfasst bei der Deinstallation am $when)") $prog.Name (-not $changed)
        }
        [void]$owners.Add([pscustomobject]@{ Name = $prog.Name; Publisher = [string]$prog.Publisher; Dirs = @($h.Dirs | Where-Object { $_ }) })
    }

    # --- 6) Verwaiste Verweise: Ziel existiert nicht mehr
    $ownerOf = { param($path) foreach ($o in $owners) { if (Test-PathUnder $path $o.Dirs) { return $o.Name } }; return '' }
    Report 'Prüfe Verknüpfungen ...'
    $shell = $null; try { $shell = New-Object -ComObject WScript.Shell } catch {}
    $menus = @(([Environment]::GetFolderPath('CommonStartMenu') + '\Programs'), ([Environment]::GetFolderPath('StartMenu') + '\Programs'))
    $flat = @([Environment]::GetFolderPath('DesktopDirectory'), [Environment]::GetFolderPath('CommonDesktopDirectory'), [Environment]::GetFolderPath('Startup'), [Environment]::GetFolderPath('CommonStartup'),
              "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch", "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar")
    $deadLinks = @{}
    foreach ($lr in @($menus + $flat) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) {
        $deep = $menus -contains $lr
        $links = if ($deep) { @(Get-ChildItem -LiteralPath $lr -Filter *.lnk -File -Recurse -Depth 3 -ErrorAction SilentlyContinue) } else { @(Get-ChildItem -LiteralPath $lr -Filter *.lnk -File -ErrorAction SilentlyContinue) }
        foreach ($l in $links) {
            $target = ''; if ($shell) { try { $target = [string]$shell.CreateShortcut($l.FullName).TargetPath } catch {} }
            if ($target -and (Test-OrphanTarget $target)) {
                $deadLinks[$l.FullName.ToLower()] = $true
                Add-O (New-Leftover 'Datei' $l.FullName 'Verknüpfung ins Leere') "Ziel existiert nicht mehr: $target" (& $ownerOf $target)
            }
        }
    }
    # Startmenü-Ordner, die nur noch tote Verknüpfungen enthalten (leere Ordner beweisen nichts und bleiben stehen)
    foreach ($m in @($menus | Where-Object { Test-Path -LiteralPath $_ })) {
        foreach ($sd in @(Get-ChildItem -LiteralPath $m -Directory -ErrorAction SilentlyContinue)) {
            if ($sd.Name -match $script:WindowsMenuFolders -or (Test-Path -LiteralPath (Join-Path $sd.FullName 'desktop.ini'))) { continue }   # Windows-eigene (übersetzte) Ordner
            $files = @(Get-ChildItem -LiteralPath $sd.FullName -File -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' })
            if ($files.Count -eq 0) { continue }
            if (@($files | Where-Object { -not $deadLinks[$_.FullName.ToLower()] }).Count -eq 0) { Add-O (New-Leftover 'Ordner' $sd.FullName 'Startmenü-Ordner') 'Enthält nur noch Verknüpfungen ins Leere' '' }
        }
    }

    Report 'Prüfe Dienste, geplante Aufgaben und Autostart ...'
    # Dienste, von denen andere Dienste abhängen, werden nie angefasst
    $needed = @{}
    try {
        $svcRoot = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services')
        foreach ($sn in $svcRoot.GetSubKeyNames()) { $sk = $svcRoot.OpenSubKey($sn); if ($sk) { foreach ($d in @($sk.GetValue('DependOnService'))) { if ($d) { $needed[([string]$d).ToLower()] = $true } }; $sk.Close() } }
        $svcRoot.Close()
    } catch {}
    foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
        if ($needed.ContainsKey(([string]$s.Name).ToLower())) { continue }
        if ([string]$s.State -ne 'Stopped') { continue }                         # läuft (oder startet) - wird also benutzt
        $t = Get-CommandTarget ([string]$s.PathName)
        if ($t -and (Test-OrphanTarget $t)) { Add-O (New-Leftover 'Dienst' ("{0} ({1})" -f $s.DisplayName, $s.Name) 'Dienst ohne Programmdatei' @{ Service = $s.Name }) "Programmdatei existiert nicht mehr: $t" (& $ownerOf $t) }
    }
    foreach ($task in @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft\*' })) {
        if (@($task.Actions | Where-Object { [string]$_.Execute -match $script:UserVarPattern }).Count) { continue }   # %LOCALAPPDATA% u. Ä. - kann einem anderen Konto gehören
        $execs = @($task.Actions | Where-Object { $_.Execute } | ForEach-Object { Get-CommandTarget ('"' + [Environment]::ExpandEnvironmentVariables([string]$_.Execute).Trim('"') + '"') })
        $execs = @($execs | Where-Object { $_ })
        if ($execs.Count -and @($execs | Where-Object { -not (Test-OrphanTarget $_) }).Count -eq 0) {
            Add-O (New-Leftover 'Aufgabe' ("{0}{1}" -f $task.TaskPath, $task.TaskName) 'Geplante Aufgabe ohne Programmdatei' @{ Task = $task.TaskName; TaskPath = $task.TaskPath }) "Programmdatei existiert nicht mehr: $($execs[0])" (& $ownerOf $execs[0])
        }
    }
    foreach ($src in @(@('HKCU', 'Default'), @('HKLM', '64'), @('HKLM', '32'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]
            foreach ($run in 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce') {
                $rk = $bk.OpenSubKey($run); if (-not $rk) { continue }
                foreach ($v in $rk.GetValueNames()) {
                    if ($src[0] -eq 'HKLM' -and ([string]$rk.GetValue($v, '', 'DoNotExpandEnvironmentNames')) -match $script:UserVarPattern) { continue }
                    $t = Get-CommandTarget (Get-RegString $rk $v)
                    if ($t -and (Test-OrphanTarget $t)) { Add-O (New-Leftover 'Registry-Wert' ("{0} -> {1}" -f (Get-RegDisplayPath $src[0] $src[1] $run), $v) 'Autostart ohne Programmdatei' @{ Hive = $src[0]; View = $src[1]; SubKey = $run; ValueName = $v }) "Programmdatei existiert nicht mehr: $t" (& $ownerOf $t) }
                }
                $rk.Close()
            }
            $ap = 'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths'
            $apk = $bk.OpenSubKey($ap)
            if ($apk) {
                foreach ($e in $apk.GetSubKeyNames()) {
                    $ek = $apk.OpenSubKey($e); if (-not $ek) { continue }
                    $rawAp = [string]$ek.GetValue('', '', 'DoNotExpandEnvironmentNames')
                    $t = Get-CommandTarget ('"' + (Get-RegString $ek '').Trim('"') + '"'); $ek.Close()
                    if ($src[0] -eq 'HKLM' -and $rawAp -match $script:UserVarPattern) { continue }
                    if ($t -and (Test-OrphanTarget $t)) { Add-O (New-RegLeftover $src[0] $src[1] "$ap\$e" 'Programmpfad ohne Programmdatei') "Programmdatei existiert nicht mehr: $t" (& $ownerOf $t) }
                }
                $apk.Close()
            }
            $bk.Close()
        } catch {}
    }

    Report 'Prüfe Dateitypen und COM-Registrierungen ... (kann etwas dauern)'
    foreach ($src in @(@('HKCU', 'Default', 'Software\Classes'), @('HKLM', '64', 'SOFTWARE\Classes'), @('HKLM', '32', 'SOFTWARE\Classes'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]; $cl = $bk.OpenSubKey($src[2]); if (-not $cl) { $bk.Close(); continue }
            # »Öffnen mit«-Einträge einzelner Programmdateien
            $apps = $cl.OpenSubKey('Applications')
            if ($apps) {
                foreach ($a in $apps.GetSubKeyNames()) {
                    $ak = $apps.OpenSubKey("$a\shell\open\command"); if (-not $ak) { continue }
                    $t = Get-CommandTarget (Get-RegString $ak ''); $ak.Close()
                    if ($t -and (Test-OrphanTarget $t)) { Add-O (New-RegLeftover $src[0] $src[1] "$($src[2])\Applications\$a" '»Öffnen mit« ohne Programmdatei') "Programmdatei existiert nicht mehr: $t" (& $ownerOf $t) }
                }
                $apps.Close()
            }
            # Dateitypen, deren sämtliche Befehle ins Leere zeigen (Windows-eigene Typen ausgenommen)
            foreach ($n in $cl.GetSubKeyNames()) {
                if ($n -match '^(?i)(txtfile|htmlfile|exefile|batfile|cmdfile|comfile|lnkfile|inifile|regfile|jpegfile|pngfile|giffile|mp3file|wmafile|wmvfile|aufile|http|https|ftp|mailto|ms-.+|microsoft.+|windows.+|wmp.+|wmp11.+|app[xX].+|shell.+|file|unknown|opennewwindow|cabfolder|compressedfolder|ie\..+|msedge.+|photoviewer.+)$') { continue }
                if ($n.StartsWith('.') -or $n -in 'CLSID', 'Interface', 'TypeLib', 'Installer', 'AppID', 'Wow6432Node', 'Applications', '*', 'Directory', 'Drive', 'Folder', 'AllFilesystemObjects', 'SystemFileAssociations') { continue }
                $sh = $cl.OpenSubKey("$n\shell"); if (-not $sh) { continue }
                $targets = @(); $comVerb = $false
                foreach ($verb in $sh.GetSubKeyNames()) {
                    $vk = $sh.OpenSubKey($verb)
                    if ($vk) { if ($vk.GetValue('ExplorerCommandHandler') -or $vk.GetValue('DelegateExecute')) { $comVerb = $true }; $vk.Close() }
                    $ck = $sh.OpenSubKey("$verb\command")
                    if ($ck) { if ($ck.GetValue('DelegateExecute')) { $comVerb = $true }; $targets += (Get-CommandTarget (Get-RegString $ck '')); $ck.Close() }
                }
                $sh.Close()
                if ($comVerb) { continue }                                             # Befehl läuft über COM - funktioniert evtl. weiter
                $clk = $cl.OpenSubKey("$n\CLSID"); if ($clk) { $clk.Close(); continue }  # Dateityp ist zugleich COM-Objekt - kann von anderen Programmen genutzt werden
                $targets = @($targets | Where-Object { $_ })
                if ($targets.Count -and @($targets | Where-Object { -not (Test-OrphanTarget $_) }).Count -eq 0) { Add-O (New-RegLeftover $src[0] $src[1] "$($src[2])\$n" 'Dateityp ohne Programm') "Alle Befehle zeigen ins Leere, z. B. $($targets[0])" (& $ownerOf $targets[0]) }
            }
            # COM-Klassen, deren Programmbibliothek fehlt
            $clsid = $cl.OpenSubKey('CLSID')
            if ($clsid) {
                foreach ($c in $clsid.GetSubKeyNames()) {
                    $ck0 = $clsid.OpenSubKey($c); if (-not $ck0) { continue }
                    $appId = [string]$ck0.GetValue('AppID'); $treat = $ck0.OpenSubKey('TreatAs'); $ck0.Close()
                    if ($treat) { $treat.Close(); continue }                              # umgeleitet auf eine andere Klasse
                    if ($appId) {
                        $ak2 = $cl.OpenSubKey("AppID\$appId")
                        if ($ak2) { $svcHosted = $ak2.GetValue('LocalService') -or ($null -ne $ak2.GetValue('DllSurrogate')); $ak2.Close(); if ($svcHosted) { continue } }   # läuft über Dienst/Ersatzprozess
                    }
                    $ip = $clsid.OpenSubKey("$c\InprocServer32"); if ($ip) { $net = $ip.GetValue('Assembly') -or $ip.GetValue('CodeBase'); $ip.Close(); if ($net) { continue } }   # .NET-Klasse
                    $files = @()
                    foreach ($sub in 'InprocServer32', 'LocalServer32') { $sk = $clsid.OpenSubKey("$c\$sub"); if ($sk) { $v = (Get-RegString $sk '').Trim().Trim('"'); if ($sub -eq 'LocalServer32') { $v = Get-CommandTarget $v }; if ($v -match '^[A-Za-z]:\\') { $files += $v }; $sk.Close() } }
                    if ($files.Count -and @($files | Where-Object { -not (Test-OrphanTarget $_) }).Count -eq 0) { Add-O (New-RegLeftover $src[0] $src[1] "$($src[2])\CLSID\$c" 'COM-Registrierung ohne Datei') "Programmbibliothek existiert nicht mehr: $($files[0])" (& $ownerOf $files[0]) }
                }
                $clsid.Close()
            }
            $cl.Close(); $bk.Close()
        } catch {}
    }

    Report 'Prüfe Firewall-Regeln ...'
    try {
        foreach ($af in @(Get-NetFirewallApplicationFilter -ErrorAction Stop)) {
            $prog = [Environment]::ExpandEnvironmentVariables([string]$af.Program)
            if ($prog -match '^[A-Za-z]:\\' -and (Test-OrphanTarget $prog)) {
                foreach ($rule in @($af | Get-NetFirewallRule -ErrorAction SilentlyContinue | Where-Object { [string]$_.Group -notmatch '^@' -and -not $_.Owner -and [string]$_.DisplayName -notmatch '^@' })) { Add-O (New-Leftover 'Firewall-Regel' ("{0} ({1})" -f $rule.DisplayName, $rule.Direction) 'Firewall-Regel ohne Programm' @{ Rule = $rule.Name }) "Programm existiert nicht mehr: $prog" (& $ownerOf $prog) }
            }
        }
    } catch {}

    # --- 7) Datenordner, deren Einstellungen ausschließlich auf ein verwaistes Programm verweisen
    $deadNeedles = @{}; $deadTokens = @{}
    foreach ($o in $owners) {
        $exeNames = @($o.Dirs | Where-Object { $_ } | ForEach-Object { Split-Path $_ -Leaf })
        $tok = Get-OwnTokens $o.Name '' $exeNames
        foreach ($d in @($o.Dirs)) { if ($d -and $d.Length -gt 8 -and -not (Test-PathAny $d)) { $deadNeedles[$d] = $o.Name; $deadTokens[$d] = $tok } }
    }
    foreach ($it in @($items | Where-Object { $_.Type -eq 'Ordner' -and $_.Reason -like 'Spieleordner*' })) { $deadNeedles[$it.Path] = $it.Owner; $deadTokens[$it.Path] = Get-OwnTokens $it.Owner '' @() }
    # »lebendig« = installierte Programme, laufende Prozesse, Dienste und Verknüpfungsziele
    $liveNeedles = @(@($installed) + @($script:OrphanLiveRoots) + @($script:OrphanLinkDirs) | Where-Object { $_ -and $_.Length -gt 8 } | Sort-Object -Unique)
    if ($deadNeedles.Count -gt 0) {
        Report 'Prüfe Datenordner in AppData und ProgramData ... (kann einige Minuten dauern)'
        $instTokens = @{}
        foreach ($p in @($all | Where-Object { $orphanEntries -notcontains $_ })) { foreach ($t in @((Get-CleanName ([string]$p.Name)), ([string]$p.Publisher -replace '[,.]?\s*\b(inc|gmbh|ltd|llc|corp|corporation|co|ag|limited)\b\.?', ''))) { $tk = ConvertTo-Token $t; if ($tk.Length -ge 3) { $instTokens[$tk] = $true } } }
        $textExt = @('.ini', '.cfg', '.conf', '.config', '.json', '.xml', '.txt', '.settings', '.properties', '.yaml', '.yml', '.vdf')
        foreach ($root in @($env:APPDATA, $env:LOCALAPPDATA, "$env:USERPROFILE\AppData\LocalLow", $env:ProgramData) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) {
            foreach ($d1 in @(Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction SilentlyContinue)) {
                $t1 = ConvertTo-Token $d1.Name
                if ($script:SharedDataFolders -contains $t1 -or $instTokens.ContainsKey($t1) -or (& $isInstalled $d1.FullName)) { continue }
                if (($d1.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                $texts = @(Get-ChildItem -LiteralPath $d1.FullName -File -Recurse -Depth 3 -Force -ErrorAction SilentlyContinue | Where-Object { $textExt -contains $_.Extension.ToLower() -and $_.Length -lt 512KB } | Select-Object -First 40)
                $dead = $null; $live = $false; $deadFile = $null
                foreach ($f in $texts) {
                    $txt = try { [IO.File]::ReadAllText($f.FullName) } catch { '' }
                    if (-not $txt) { continue }
                    if (Find-Needle $txt $liveNeedles) { $live = $true; break }          # verweist auch auf ein installiertes/laufendes Programm: nicht anfassen
                    if (-not $dead) { $hit = Find-Needle $txt @($deadNeedles.Keys); if ($hit) { $dead = $hit; $deadFile = $f } }
                }
                if (-not $dead -or $live) { continue }
                # Zusätzlich muss der Ordner zum entfernten Programm passen - sonst könnte es der Verlauf eines
                # ganz anderen (z. B. portablen) Programms sein, der zufällig einen alten Pfad enthält
                $tok = $deadTokens[$dead]
                $target = $null
                if (Test-NameRelated $d1.Name $tok) { $target = $d1.FullName }
                else {
                    $rel = $deadFile.FullName.Substring($d1.FullName.Length).TrimStart('\')
                    $first = if ($rel.Contains('\')) { $rel.Substring(0, $rel.IndexOf('\')) } else { '' }
                    if ($first -and (Test-NameRelated $first $tok)) { $target = $d1.FullName + '\' + $first }
                }
                if (-not $target) { continue }
                # eigene Dateien (Spielstände, Dokumente ...) oder kürzlich benutzt: anzeigen, aber nie vorauswählen
                $userData = Test-LikelyUserData $target
                $recent = Test-RecentlyUsed $target 30
                $why = if ($userData) { 'Programmdaten – enthält vermutlich Spielstände oder eigene Dateien, bitte prüfen' } elseif ($recent) { 'Programmdaten – in den letzten 30 Tagen verändert, bitte prüfen' } else { 'Programmdaten' }
                Add-O (New-Leftover 'Ordner' $target $why) "Einstellungen ($($deadFile.Name)) verweisen ausschließlich auf $dead, das nicht mehr existiert" $deadNeedles[$dead] (-not ($userData -or $recent))
            }
        }
    }

    # Leere Ordner werden bewusst NICHT angeboten: »leer« beweist nicht, dass ein Ordner nicht mehr
    # gebraucht wird (Programme legen Ordner für Plugins, Updates oder Daten oft leer an).
    # Leere Ordner von entfernten Programmen findet die Suche nur über einen Beleg (Abschnitte 1-7).

    $items = @(Remove-StillReferenced $items)
    # Größen berechnen, Verschachteltes zusammenfassen
    foreach ($it in $items) { if ($it.Type -eq 'Ordner') { $it.Size = Get-DirSize $it.Path } }
    $folders = @($items | Where-Object { $_.Type -eq 'Ordner' } | ForEach-Object { $_.Path.TrimEnd('\') + '\' })
    $keys = @($items | Where-Object { $_.Type -eq 'Registry-Schlüssel' } | ForEach-Object { $_.Path.TrimEnd('\') + '\' })
    $items | Where-Object {
        $x = $_
        switch ($x.Type) {
            { $_ -in 'Ordner', 'Datei' } { -not ($folders | Where-Object { ($x.Path.TrimEnd('\') + '\').StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -and ($x.Path.TrimEnd('\') + '\') -ne $_ }); break }
            'Registry-Schlüssel' { -not ($keys | Where-Object { ($x.Path + '\').StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -and ($x.Path + '\') -ne $_ }); break }
            default { $true }
        }
    } | Sort-Object @{ e = { $_.Owner -eq '' } }, Owner, Type, Path
}

# Sichert einen Registry-Schlüssel als .reg-Datei (per Doppelklick wiederherstellbar)
function Export-RegKey([string]$Hive, [string]$View, [string]$Sub, [string]$File) {
    $a = @('export', "$Hive\$Sub", $File, '/y')
    if ($View -eq '32') { $a += '/reg:32' } elseif ($View -eq '64') { $a += '/reg:64' }
    & reg.exe @a 2>&1 | Out-Null
}

# Gibt es Datei oder Ordner noch? (auch bei Pfaden über 260 Zeichen)
function Test-PathAny([string]$Path) {
    if (-not $Path) { return $false }
    $long = if ($Path.StartsWith('\\?\')) { $Path } else { '\\?\' + $Path }
    try { return [IO.File]::Exists($long) -or [IO.Directory]::Exists($long) -or [IO.File]::Exists($Path) -or [IO.Directory]::Exists($Path) } catch { return (Test-Path -LiteralPath $Path) }
}

# Beendet Programme, die aus diesem Ordner (bzw. dieser Datei) laufen - sonst sind ihre Dateien gesperrt
function Stop-ProcessesInPath([string]$Path) {
    $dir = $Path.TrimEnd('\') + '\'
    $n = 0
    foreach ($x in @(Get-CimInstance Win32_Process -Property ProcessId, ExecutablePath -ErrorAction SilentlyContinue)) {
        $e = [string]$x.ExecutablePath
        if (-not $e -or $x.ProcessId -eq $PID) { continue }
        if ($e.StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) -or $e -ieq $Path) {
            try { Stop-Process -Id $x.ProcessId -Force -ErrorAction Stop; $n++ } catch {}
        }
    }
    if ($n -gt 0) { Start-Sleep -Milliseconds 800 }
    return $n
}

# ---------------------------------------------------------------------------
#  Löschen mit Administrator-Sonderrechten (Sichern/Wiederherstellen/Besitz übernehmen):
#  Damit darf Windows eine Datei auch dann löschen, wenn ihre Berechtigungen
#  Administratoren eigentlich aussperren. Gesperrte Dateien (von einem Programm geöffnet)
#  werden erkannt; das sperrende Programm wird über den Neustart-Manager benannt.
# ---------------------------------------------------------------------------
function Initialize-ForceOps {
    if ('TuneRig.ForceOps' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace TuneRig
{
    public static class ForceOps
    {
        // ---------- Sonderrechte ----------
        [StructLayout(LayoutKind.Sequential)] struct LUID { public uint Low; public int High; }
        [StructLayout(LayoutKind.Sequential)] struct TOKEN_PRIVILEGES { public int Count; public LUID Luid; public int Attr; }
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr h, int access, out IntPtr token);
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool LookupPrivilegeValue(string sys, string name, out LUID luid);
        [DllImport("advapi32.dll", SetLastError = true)] static extern bool AdjustTokenPrivileges(IntPtr token, bool disableAll, ref TOKEN_PRIVILEGES p, int len, IntPtr prev, IntPtr retLen);
        [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
        [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);

        static bool privOk;
        public static bool EnablePrivileges()
        {
            if (privOk) return true;
            IntPtr tok;
            if (!OpenProcessToken(GetCurrentProcess(), 0x0020 | 0x0008, out tok)) return false;
            int ok = 0;
            foreach (var n in new[] { "SeBackupPrivilege", "SeRestorePrivilege", "SeTakeOwnershipPrivilege", "SeSecurityPrivilege" })
            {
                LUID l;
                if (!LookupPrivilegeValue(null, n, out l)) continue;
                var tp = new TOKEN_PRIVILEGES { Count = 1, Luid = l, Attr = 2 };
                if (AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero) && Marshal.GetLastWin32Error() == 0) ok++;
            }
            CloseHandle(tok);
            privOk = ok >= 2;
            return privOk;
        }

        // ---------- Dateien ----------
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern SafeFileHandle CreateFile(string name, uint access, uint share, IntPtr sa, uint disp, uint flags, IntPtr tmpl);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool SetFileInformationByHandle(SafeFileHandle h, int cls, ref FILE_DISPOSITION_INFO_EX info, int size);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool SetFileInformationByHandle(SafeFileHandle h, int cls, ref FILE_DISPOSITION_INFO info, int size);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool SetFileInformationByHandle(SafeFileHandle h, int cls, ref FILE_BASIC_INFO info, int size);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool MoveFileEx(string from, string to, int flags);
        [StructLayout(LayoutKind.Sequential)] struct FILE_DISPOSITION_INFO_EX { public uint Flags; }
        [StructLayout(LayoutKind.Sequential)] struct FILE_DISPOSITION_INFO { [MarshalAs(UnmanagedType.U1)] public bool Delete; }
        [StructLayout(LayoutKind.Sequential)] struct FILE_BASIC_INFO { public long Creation, LastAccess, LastWrite, Change; public uint Attributes; }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct WIN32_FIND_DATA
        {
            public uint Attr; public System.Runtime.InteropServices.ComTypes.FILETIME C, A, W; public uint SizeHigh, SizeLow, Res0, Res1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string Name;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)] public string Alt;
        }
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern IntPtr FindFirstFileW(string p, out WIN32_FIND_DATA d);
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)] static extern bool FindNextFileW(IntPtr h, out WIN32_FIND_DATA d);
        [DllImport("kernel32.dll")] static extern bool FindClose(IntPtr h);

        static string Long(string p) { return p.StartsWith(@"\\?\") ? p : (p.StartsWith(@"\\") ? @"\\?\UNC\" + p.Substring(2) : @"\\?\" + p); }

        public class Result { public int Deleted; public int Failed; public int InUse; public int Denied; public List<string> Locked = new List<string>(); public string FirstError = ""; }

        // Löscht eine Datei bzw. einen leeren Ordner; Rückgabe 0 = gelöscht, sonst Win32-Fehlercode
        static int DeleteOne(string longPath, bool dir)
        {
            uint flags = 0x02000000 | 0x00200000; // BACKUP_SEMANTICS | OPEN_REPARSE_POINT (Verknüpfungen nicht verfolgen)
            using (var h = CreateFile(longPath, 0x00010000 | 0x0100, 7, IntPtr.Zero, 3, flags, IntPtr.Zero)) // DELETE | FILE_WRITE_ATTRIBUTES
            {
                if (h.IsInvalid) return Marshal.GetLastWin32Error();
                // Windows 10+: auch schreibgeschützte und noch offene Dateien sofort entfernen
                var ex = new FILE_DISPOSITION_INFO_EX { Flags = 0x1 | 0x2 | 0x10 }; // DELETE | POSIX_SEMANTICS | IGNORE_READONLY_ATTRIBUTE
                if (SetFileInformationByHandle(h, 21, ref ex, 4)) return 0;
                var bi = new FILE_BASIC_INFO { Attributes = dir ? 0x10u : 0x80u };
                SetFileInformationByHandle(h, 0, ref bi, Marshal.SizeOf(typeof(FILE_BASIC_INFO)));
                var di = new FILE_DISPOSITION_INFO { Delete = true };
                if (SetFileInformationByHandle(h, 4, ref di, Marshal.SizeOf(typeof(FILE_DISPOSITION_INFO)))) return 0;
                return Marshal.GetLastWin32Error();
            }
        }

        static void Note(Result r, string path, int err, bool reboot)
        {
            r.Failed++;
            if (err == 32 || err == 33) { r.InUse++; if (r.Locked.Count < 50) r.Locked.Add(path); }
            else if (err == 5) r.Denied++;
            if (r.FirstError == "") r.FirstError = new Win32Exception(err).Message;
            if (reboot) MoveFileEx(Long(path), null, 4);
        }

        static void Walk(string path, Result r, bool reboot)
        {
            WIN32_FIND_DATA d;
            IntPtr h = FindFirstFileW(Long(path) + @"\*", out d);
            if (h != new IntPtr(-1))
            {
                do
                {
                    if (d.Name == "." || d.Name == "..") continue;
                    string full = path.TrimEnd('\\') + "\\" + d.Name;
                    bool isDir = (d.Attr & 0x10) != 0, isLink = (d.Attr & 0x400) != 0;
                    if (isDir && !isLink) Walk(full, r, reboot);
                    int e = DeleteOne(Long(full), isDir);
                    if (e == 0) r.Deleted++; else if (!(isDir && e == 145)) Note(r, full, e, reboot); // 145 = Ordner nicht leer (Inhalt schon gezählt)
                    else if (reboot) MoveFileEx(Long(full), null, 4);
                } while (FindNextFileW(h, out d));
                FindClose(h);
            }
        }

        // Löscht Datei oder Ordner endgültig. reboot = Gesperrtes zum Löschen beim Neustart vormerken
        public static Result Delete(string path, bool reboot)
        {
            EnablePrivileges();
            var r = new Result();
            path = path.TrimEnd('\\');
            bool dir = System.IO.Directory.Exists(Long(path));
            if (dir && (System.IO.File.GetAttributes(Long(path)) & System.IO.FileAttributes.ReparsePoint) == 0) Walk(path, r, reboot);
            int e = DeleteOne(Long(path), dir);
            if (e == 0) r.Deleted++; else if (!(dir && e == 145 && r.Failed > 0)) Note(r, path, e, reboot); else if (reboot) MoveFileEx(Long(path), null, 4);
            return r;
        }

        // ---------- Wer sperrt die Datei? (Neustart-Manager) ----------
        [StructLayout(LayoutKind.Sequential)] struct RM_UNIQUE_PROCESS { public int Pid; public System.Runtime.InteropServices.ComTypes.FILETIME Start; }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct RM_PROCESS_INFO
        {
            public RM_UNIQUE_PROCESS Process;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string AppName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)] public string ServiceName;
            public int AppType; public uint AppStatus; public uint TSSessionId; [MarshalAs(UnmanagedType.Bool)] public bool Restartable;
        }
        [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)] static extern int RmStartSession(out uint h, int flags, string key);
        [DllImport("rstrtmgr.dll")] static extern int RmEndSession(uint h);
        [DllImport("rstrtmgr.dll", CharSet = CharSet.Unicode)] static extern int RmRegisterResources(uint h, uint nFiles, string[] files, uint nApps, RM_UNIQUE_PROCESS[] apps, uint nSvc, string[] svcs);
        [DllImport("rstrtmgr.dll")] static extern int RmGetList(uint h, out uint needed, ref uint count, [In, Out] RM_PROCESS_INFO[] info, ref uint reasons);

        public static string[] WhoLocks(string[] files)
        {
            var names = new List<string>();
            if (files == null || files.Length == 0) return names.ToArray();
            uint h; if (RmStartSession(out h, 0, Guid.NewGuid().ToString()) != 0) return names.ToArray();
            try
            {
                if (RmRegisterResources(h, (uint)files.Length, files, 0, null, 0, null) != 0) return names.ToArray();
                uint need = 0, count = 0, reasons = 0;
                int rc = RmGetList(h, out need, ref count, null, ref reasons);
                if (rc == 234 && need > 0)
                {
                    var info = new RM_PROCESS_INFO[need]; count = need;
                    if (RmGetList(h, out need, ref count, info, ref reasons) == 0)
                        for (int i = 0; i < count; i++)
                        {
                            string n = info[i].AppName;
                            try { n = System.Diagnostics.Process.GetProcessById(info[i].Process.Pid).ProcessName + ".exe (" + info[i].AppName + ")"; } catch { }
                            if (!names.Contains(n)) names.Add(n);
                        }
                }
            }
            finally { RmEndSession(h); }
            return names.ToArray();
        }

        // ---------- Registry: gesperrten Schlüssel für Administratoren freigeben ----------
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
        static extern int RegCreateKeyEx(UIntPtr hKey, string sub, int res, string cls, int options, int sam, IntPtr sa, out UIntPtr result, out int disp);
        [DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
        static extern int RegOpenKeyEx(UIntPtr hKey, string sub, int options, int sam, out UIntPtr result);
        [DllImport("advapi32.dll")] static extern int RegSetKeySecurity(UIntPtr hKey, int info, byte[] sd);
        [DllImport("advapi32.dll")] static extern int RegCloseKey(UIntPtr hKey);

        // Setzt Besitzer = Administratoren und Vollzugriff für Administratoren und SYSTEM, rekursiv
        public static int Unlock(bool machine, bool wow32, string sub)
        {
            EnablePrivileges();
            var root = machine ? new UIntPtr(0x80000002u) : new UIntPtr(0x80000001u);
            int view = wow32 ? 0x0200 : 0x0100;
            var raw = new System.Security.AccessControl.RawSecurityDescriptor("O:BAD:(A;OICI;KA;;;BA)(A;OICI;KA;;;SY)");
            var sd = new byte[raw.BinaryLength]; raw.GetBinaryForm(sd, 0);
            return UnlockRec(root, sub, view, sd, 0);
        }
        static int UnlockRec(UIntPtr root, string sub, int view, byte[] sd, int depth)
        {
            if (depth > 64) return 0;
            UIntPtr k; int disp;
            // REG_OPTION_BACKUP_RESTORE: öffnet unabhängig von den Berechtigungen (nur mit Sonderrechten)
            // nur vorhandene Schlüssel anfassen (sonst würde RegCreateKeyEx einen neuen anlegen)
            UIntPtr probe;
            int ex = RegOpenKeyEx(root, sub, 0, view, out probe);
            if (ex == 0) RegCloseKey(probe); else if (ex == 2) return 2;
            int rc = RegCreateKeyEx(root, sub, 0, null, 0x4, 0x000F003F | 0x00080000 | view, IntPtr.Zero, out k, out disp);
            if (rc != 0) return rc;
            RegSetKeySecurity(k, 0x1 | 0x4, sd); // OWNER | DACL
            RegCloseKey(k);
            // Unterschlüssel
            try
            {
                using (var b = RegistryKey.OpenBaseKey(root.ToUInt64() == 0x80000002u ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, view == 0x0200 ? RegistryView.Registry32 : RegistryView.Registry64))
                using (var key = b.OpenSubKey(sub, false))
                    if (key != null) foreach (var s in key.GetSubKeyNames()) UnlockRec(root, sub + "\\" + s, view, sd, depth + 1);
            }
            catch { }
            return 0;
        }
    }
}
'@
}

# Löscht Datei oder Ordner so gründlich wie möglich:
#   1. Papierkorb  2. Schreibschutz entfernen  3. Besitz und Rechte übernehmen  4. direkt löschen (auch lange Pfade)
#   5. was gesperrt bleibt, beim nächsten Neustart. Rückgabe: Status ok | deleted | reboot | failed und Text
function Remove-PathHard([string]$Path, [switch]$RecycleOnly) {
    if (-not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'ok'; Note = 'War schon entfernt.' } }
    if (Test-ProtectedPath $Path) { return [pscustomobject]@{ Status = 'failed'; Note = 'Geschützter Windows- oder Benutzerordner – wird nie gelöscht.' } }
    $killed = if ($RecycleOnly) { 0 } else { Stop-ProcessesInPath $Path }
    $pre = if ($killed) { "$killed laufende Programmteile beendet. " } else { '' }
    if ([PCO.Native]::Recycle($Path) -and -not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'ok'; Note = $pre + 'Im Papierkorb.' } }
    # Nur Papierkorb gewünscht (z. B. eigene Dateien): hier aufhören, nichts an Attributen oder Rechten ändern
    if ($RecycleOnly) { return [pscustomobject]@{ Status = 'norecycle'; Note = 'Passt nicht in den Papierkorb, ist gesperrt oder kein Zugriff.' } }

    $isDir = [IO.Directory]::Exists('\\?\' + $Path) -or [IO.Directory]::Exists($Path)
    $q = '"' + $Path + '"'
    # Schreibschutz, System- und Versteckt-Attribut entfernen
    if ($isDir) { & cmd.exe /c "attrib -r -s -h $q /d >nul 2>&1 & attrib -r -s -h `"$Path\*`" /s /d >nul 2>&1" } else { & cmd.exe /c "attrib -r -s -h $q >nul 2>&1" }
    if ([PCO.Native]::Recycle($Path) -and -not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'ok'; Note = $pre + 'Im Papierkorb (Schreibschutz entfernt).' } }

    # Besitz an Administratoren übertragen und Vollzugriff geben (sprachunabhängig über die SID)
    & takeown.exe /f $Path /a 2>&1 | Out-Null
    if ($isDir) {
        & icacls.exe $Path /setowner '*S-1-5-32-544' /t /c /q 2>&1 | Out-Null
        & icacls.exe $Path /grant '*S-1-5-32-544:(OI)(CI)F' /t /c /q 2>&1 | Out-Null
    } else {
        & icacls.exe $Path /setowner '*S-1-5-32-544' /c /q 2>&1 | Out-Null
        & icacls.exe $Path /grant '*S-1-5-32-544:F' /c /q 2>&1 | Out-Null
    }
    if ([PCO.Native]::Recycle($Path) -and -not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'ok'; Note = $pre + 'Im Papierkorb (Zugriffsrechte übernommen).' } }

    # Endgültig löschen - mit den Sonderrechten für Administratoren (Sichern/Wiederherstellen), die
    # Berechtigungen umgehen; auch Pfade über 260 Zeichen, schreibgeschützte und noch geöffnete Dateien
    $fo = $null
    try { Initialize-ForceOps; $fo = [TuneRig.ForceOps]::Delete($Path, $false) } catch {}
    if (-not $fo) {
        $long = '"\\?\' + $Path + '"'
        if ($isDir) { & cmd.exe /c "rd /s /q $long >nul 2>&1" } else { & cmd.exe /c "del /f /q /a $long >nul 2>&1" }
    }
    if (-not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'deleted'; Note = $pre + 'Endgültig gelöscht (Papierkorb war nicht möglich).' } }

    # Was bleibt: Wer sperrt es? Dann beim nächsten Neustart löschen
    $who = @()
    if ($fo -and $fo.Locked.Count) { try { $who = @([TuneRig.ForceOps]::WhoLocks($fo.Locked.ToArray())) } catch {} }
    $whoText = if ($who.Count) { ' Geöffnet von: ' + (($who | Select-Object -First 3) -join ', ') + '.' } else { '' }
    $sched = $null
    try { $sched = [TuneRig.ForceOps]::Delete($Path, $true) } catch {}
    if (-not $sched) {
        # Rückfall ohne Sonderrechte
        $sched = [pscustomobject]@{ Failed = 0; InUse = 0; Denied = 0; FirstError = '' }
        if ($isDir) {
            foreach ($f in @(Get-ChildItem -LiteralPath $Path -File -Recurse -Force -ErrorAction SilentlyContinue)) { [void][PCO.Native]::DeleteOnReboot($f.FullName); $sched.Failed++ }
            foreach ($d in @(@(Get-ChildItem -LiteralPath $Path -Directory -Recurse -Force -ErrorAction SilentlyContinue | Sort-Object { $_.FullName.Length } -Descending) + @(Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue))) { if ($d) { [void][PCO.Native]::DeleteOnReboot($d.FullName) } }
        } else { [void][PCO.Native]::DeleteOnReboot($Path); $sched.Failed = 1 }
        $sched.InUse = $sched.Failed
    }
    if (-not (Test-PathAny $Path)) { return [pscustomobject]@{ Status = 'deleted'; Note = $pre + 'Endgültig gelöscht.' } }
    $pending = [bool](Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)
    if ($sched.InUse -gt 0 -and $pending) {
        return [pscustomobject]@{ Status = 'reboot'; Note = $pre + "$($sched.InUse) Datei(en) sind gerade geöffnet und werden beim nächsten Neustart gelöscht.$whoText" }
    }
    if ($sched.Denied -gt 0) {
        return [pscustomobject]@{ Status = $(if ($pending) { 'reboot' } else { 'failed' }); Note = $pre + "Windows verweigert den Zugriff auf $($sched.Denied) Element(e), obwohl TuneRig mit Administratorrechten löscht. Meist schützt ein Virenscanner oder ein Treiber seine eigenen Dateien. " + $(if ($pending) { 'Beim nächsten Neustart wird es erneut versucht.' } else { 'Deinstalliere bzw. deaktiviere das Schutzprogramm zuerst.' }) }
    }
    return [pscustomobject]@{ Status = $(if ($pending) { 'reboot' } else { 'failed' }); Note = $pre + "Nicht gelöscht: $($sched.FirstError)$whoText" + $(if ($pending) { ' Beim nächsten Neustart wird es erneut versucht.' } else { '' }) }
}

function Get-RegExePath($It) { if ($It.Hive -eq 'HKLM') { "HKLM\$($It.SubKey)" } else { "HKCU\$($It.SubKey)" } }
function Get-RegViewArg($It) { if ($It.View -eq '32') { '/reg:32' } elseif ($It.View -eq '64') { '/reg:64' } else { '' } }

function Test-RegKeyExists($It) {
    try { $bk = Open-BaseKey $It.Hive $It.View; $k = $bk.OpenSubKey($It.SubKey); $e = [bool]$k; if ($k) { $k.Close() }; $bk.Close(); return $e } catch { return $true }
}

function Remove-Leftovers($P, $Items, [bool]$Backup = $true) {
    $safe = $P.Name -replace '[^\w\-]+', '_'
    $backup = Join-Path $script:BackupRoot ("{0:yyyy-MM-dd_HH-mm-ss}_{1}" -f (Get-Date), $safe)
    if ($Backup) { New-Item -ItemType Directory -Path $backup -Force | Out-Null }
    $results = New-Object System.Collections.ArrayList
    $n = 0
    # Dienste und Aufgaben zuerst (sie halten oft Dateien offen), dann Dateien, zuletzt Registry
    $order = @{ 'Dienst' = 0; 'Aufgabe' = 1; 'Firewall-Regel' = 1; 'Registry-Wert' = 2; 'Ordner' = 3; 'Datei' = 3; 'Registry-Schlüssel' = 4 }
    foreach ($it in @($Items | Sort-Object { $order[$_.Type] })) {
        $n++; Report "Entferne $n/$(@($Items).Count): $($it.Path)"
        $status = 'failed'; $note = ''
        # Gegenprüfung direkt vor dem Löschen: Windows-Bestandteil? Programm wieder da? Geschützter Ordner?
        $veto = Test-LeftoverStillValid $it
        if ($veto) { [void]$results.Add([pscustomobject]@{ Item = $it; Status = 'skipped'; Note = $veto }); continue }
        try {
            switch ($it.Type) {
                'Registry-Schlüssel' {
                    if (-not (Test-RegKeyExists $it)) { $status = 'ok'; $note = 'War schon entfernt.'; break }
                    $file = Join-Path $backup ("reg_{0:000}.reg" -f $n)
                    if ($Backup) { Export-RegKey $it.Hive $it.View $it.SubKey $file }
                    $del = { try { $bk = Open-BaseKey $it.Hive $it.View; $bk.DeleteSubKeyTree($it.SubKey, $false); $bk.Close() } catch {}
                             if (Test-RegKeyExists $it) { $va = Get-RegViewArg $it; & reg.exe delete (Get-RegExePath $it) /f $(if ($va) { $va }) 2>&1 | Out-Null } }
                    & $del
                    $unlocked = $false
                    if (Test-RegKeyExists $it) {
                        # gesperrter Schlüssel: Besitz und Vollzugriff für Administratoren übernehmen, dann erneut
                        try { Initialize-ForceOps; [void][TuneRig.ForceOps]::Unlock($it.Hive -eq 'HKLM', $it.View -eq '32', $it.SubKey); $unlocked = $true } catch {}
                        if ($Backup -and -not ((Test-Path -LiteralPath $file) -and (Get-Item -LiteralPath $file).Length -gt 0)) { Export-RegKey $it.Hive $it.View $it.SubKey $file }
                        & $del
                    }
                    if (Test-RegKeyExists $it) { $note = 'Windows verweigert den Zugriff auf den Registry-Schlüssel, auch nach Übernahme der Rechte. Meist schützt ein Virenscanner oder Treiber ihn.' }
                    else { $status = 'ok'; $note = $(if ($Backup) { 'Gelöscht (gesichert).' } else { 'Gelöscht.' }) + $(if ($unlocked) { ' Dafür wurden die Zugriffsrechte übernommen.' } else { '' }) }
                }
                'Registry-Wert' {
                    if ($Backup) { Export-RegKey $it.Hive $it.View $it.SubKey (Join-Path $backup ("reg_{0:000}.reg" -f $n)) }
                    $delV = {
                        $bk = Open-BaseKey $it.Hive $it.View; $k = $null
                        try { $k = $bk.OpenSubKey($it.SubKey, $true) } catch {}
                        if ($k) { $k.DeleteValue($it.ValueName, $false); $k.Close() }
                        $bk.Close()
                        $k2 = (Open-BaseKey $it.Hive $it.View).OpenSubKey($it.SubKey)
                        $r = $k2 -and ($k2.GetValueNames() -contains $it.ValueName); if ($k2) { $k2.Close() }; $r
                    }
                    $still = & $delV
                    if ($still) { try { Initialize-ForceOps; [void][TuneRig.ForceOps]::Unlock($it.Hive -eq 'HKLM', $it.View -eq '32', $it.SubKey) } catch {}; $still = & $delV }
                    if ($still) { $note = 'Windows verweigert den Zugriff auf den Registry-Wert, auch nach Übernahme der Rechte.' } else { $status = 'ok'; $note = $(if ($Backup) { 'Gelöscht (gesichert).' } else { 'Gelöscht.' }) }
                }
                { $_ -in 'Ordner', 'Datei' } {
                    $r = Remove-PathHard $it.Path
                    $status = $r.Status; $note = $r.Note
                }
                'Aufgabe' {
                    if ($Backup) { try { Export-ScheduledTask -TaskName $it.Task -TaskPath $it.TaskPath -ErrorAction Stop | Set-Content -LiteralPath (Join-Path $backup ("task_{0:000}.xml" -f $n)) -Encoding Unicode } catch {} }
                    try { Stop-ScheduledTask -TaskName $it.Task -TaskPath $it.TaskPath -ErrorAction SilentlyContinue } catch {}
                    try { Unregister-ScheduledTask -TaskName $it.Task -TaskPath $it.TaskPath -Confirm:$false -ErrorAction Stop }
                    catch { & schtasks.exe /delete /tn ($it.TaskPath + $it.Task) /f 2>&1 | Out-Null }
                    if (Get-ScheduledTask -TaskName $it.Task -TaskPath $it.TaskPath -ErrorAction SilentlyContinue) { throw 'Windows verweigert das Löschen der Aufgabe.' }
                    $status = 'ok'; $note = $(if ($Backup) { 'Gelöscht (als XML gesichert).' } else { 'Gelöscht.' })
                }
                'Firewall-Regel' {
                    Remove-NetFirewallRule -Name $it.Rule -ErrorAction Stop
                    $status = 'ok'; $note = 'Regel entfernt.'
                }
                'Dienst' {
                    $svc = Get-CimInstance Win32_Service -Filter "Name='$($it.Service -replace "'", "''")'" -ErrorAction SilentlyContinue
                    if (-not $svc) { $status = 'ok'; $note = 'War schon entfernt.'; break }
                    & sc.exe config $it.Service start= disabled 2>&1 | Out-Null
                    & sc.exe stop $it.Service 2>&1 | Out-Null
                    for ($w = 0; $w -lt 20; $w++) {
                        $s = Get-CimInstance Win32_Service -Filter "Name='$($it.Service -replace "'", "''")'" -ErrorAction SilentlyContinue
                        if (-not $s -or $s.State -eq 'Stopped') { break }
                        Start-Sleep -Milliseconds 500
                    }
                    if ($s -and $s.State -ne 'Stopped' -and $s.ProcessId) { Stop-Process -Id $s.ProcessId -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 500 }
                    $out = & sc.exe delete $it.Service 2>&1
                    if ($LASTEXITCODE -eq 0) { $status = 'ok'; $note = 'Gestoppt und entfernt.' }
                    elseif ($LASTEXITCODE -eq 1072) { $status = 'reboot'; $note = 'Zum Löschen markiert – verschwindet nach dem Neustart.' }
                    else { $note = "Konnte nicht entfernt werden: $(($out | Out-String).Trim())" }
                }
            }
        } catch { $status = 'failed'; $note = $_.Exception.Message }
        [void]$results.Add([pscustomobject]@{ Item = $it; Status = $status; Note = $note })
    }
    $ok = @($results | Where-Object { $_.Status -in 'ok', 'deleted' }).Count
    $rb = @($results | Where-Object { $_.Status -eq 'reboot' }).Count
    $fl = @($results | Where-Object { $_.Status -eq 'failed' })
    $sk = @($results | Where-Object { $_.Status -eq 'skipped' })
    $direct = @($results | Where-Object { $_.Status -eq 'deleted' }).Count
    $msg = "$ok von $(@($Items).Count) Einträgen entfernt."
    if ($direct -gt 0) { $msg += " $direct davon direkt gelöscht, weil sie nicht in den Papierkorb passten." }
    if ($rb -gt 0) { $msg += "`n$rb Einträge sind gesperrt und werden beim nächsten Neustart gelöscht." }
    if ($sk.Count -gt 0) { $msg += "`n$($sk.Count) Einträge hat die Gegenprüfung vor dem Löschen zurückgehalten:`n" + (($sk | Select-Object -First 8 | ForEach-Object { "–  $($_.Item.Path): $($_.Note)" }) -join "`n") }
    if ($fl.Count -gt 0) { $msg += "`n$($fl.Count) Einträge ließen sich nicht entfernen:`n" + (($fl | Select-Object -First 8 | ForEach-Object { "–  $($_.Item.Path): $($_.Note)" }) -join "`n") }
    $msg += $(if ($Backup) { "`n`nRegistry-Sicherung: $backup" } else { "`n`nOhne Registry-Sicherung gelöscht." }) + "`nGelöschte Dateien liegen im Papierkorb, soweit er sie aufnehmen konnte."
    [pscustomobject]@{ Message = $msg; Results = @($results); Reboot = ($rb -gt 0) }
}

# ===========================================================================
#  GAMING-MODUS
#  Jede Optimierung hat: Wirkung (Impact 0-3), Modus (recommended / optional /
#  experimental), ggf. Nebenwirkung (Risk) und - wo möglich - Rückgängig (Revert).
#  Bewusst NICHT enthalten sind Tweaks ohne belegte Wirkung oder mit Schaden
#  (siehe $script:GamingMyths).
# ===========================================================================
$script:MmKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
$script:MmGames = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
$script:DoKey = 'S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings'
$script:ProcSub = '54533251-82be-4824-96c1-47b60b740d00'
$script:CoreParking = '0cc5b647-c1df-4637-891a-dec35c318583'
$script:WlanSub = '19cbb8fa-5279-450e-9fac-8a3d5fedd0c1'
$script:WlanPower = '12bbebe6-58d6-4636-95bb-3217ef867c1a'
$script:EeeKeywords = '*EEE', 'EEE', 'AdvancedEEE', 'EnableGreenEthernet'

$script:GamingMyths = @(
    @{ T = 'Windows Defender abschalten'; W = 'Kaum Leistungsgewinn, aber der PC ist ungeschützt. Besser: Spieleordner bei Bedarf als Ausnahme eintragen.' }
    @{ T = '20 % reservierte Bandbreite (QoS) freigeben'; W = 'Ein Mythos: Windows reserviert keine Bandbreite, solange kein Programm sie anfordert.' }
    @{ T = 'TCP-Autotuning abschalten'; W = 'Macht Downloads langsamer und senkt den Ping nicht. Das Programm stellt es im Gegenteil auf »Normal« zurück.' }
    @{ T = 'NetworkThrottlingIndex ändern'; W = 'Betrifft die Multimedia-Wiedergabe, nicht den Ping in Spielen.' }
    @{ T = 'Arbeitsspeicher-»Booster« / RAM-Cleaner'; W = 'Leeren den Speicher nur scheinbar - Windows muss die Daten danach neu laden, das verursacht eher Ruckler.' }
    @{ T = 'Auslagerungsdatei abschalten'; W = 'Kann Spiele zum Absturz bringen, wenn der Arbeitsspeicher knapp wird.' }
    @{ T = 'HPET / Zeitgeber per bcdedit verändern'; W = 'Wirkung je nach PC unterschiedlich, kann Ruckler sogar verstärken.' }
    @{ T = 'Windows Update dauerhaft abschalten'; W = 'Sicherheitsrisiko und keine Leistung im Spiel - der Spielmodus verhindert Updates beim Spielen ohnehin.' }
)

# ---------------------------------------------------------------------------
#  Bildschirme
# ---------------------------------------------------------------------------
function Get-DisplayInfo {
    $i = 0
    foreach ($l in @([PCO.Native]::GetDisplays())) {
        $i++
        $p = $l -split '\|'
        [pscustomobject]@{ No = $i; Device = $p[0]; Monitor = $p[1]; Width = [int]$p[2]; Height = [int]$p[3]; Hz = [int]$p[4]; MaxHz = [int]$p[5]; Gpu = $p[6] }
    }
}

# ---------------------------------------------------------------------------
#  Netzwerk
# ---------------------------------------------------------------------------
function Get-ActiveAdapters {
    @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
}

# Energiespar-Einträge der aktiven Netzwerkadapter (»Computer kann das Gerät ausschalten, um Energie zu sparen«)
function Get-NicPowerEntries {
    $ids = @(Get-ActiveAdapters | ForEach-Object { [string]$_.PnPDeviceID } | Where-Object { $_ })
    if ($ids.Count -eq 0) { return }
    @(Get-CimInstance -Namespace 'root\wmi' -ClassName MSPower_DeviceEnable -ErrorAction SilentlyContinue | Where-Object {
        $inst = [string]$_.InstanceName
        @($ids | Where-Object { $inst.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }).Count -gt 0 })
}

function Test-WifiAdapter($a) {
    ([string]$a.PhysicalMediaType -match '802\.11|Wireless') -or ([string]$a.InterfaceDescription -match 'Wi-?Fi|Wireless|WLAN|802\.11')
}

function Get-EeeProperties {
    $list = @()
    foreach ($a in @(Get-ActiveAdapters | Where-Object { -not (Test-WifiAdapter $_) })) {
        foreach ($k in $script:EeeKeywords) {
            $p = Get-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $k -ErrorAction SilentlyContinue
            if ($p) { $list += $p }
        }
    }
    return $list
}

function Get-TcpInterfaceKeys {
    $root = 'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
    $k = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($root)
    if (-not $k) { return @() }
    $res = @()
    foreach ($n in $k.GetSubKeyNames()) {
        $s = $k.OpenSubKey($n)
        if (-not $s) { continue }
        $ip = [string](@($s.GetValue('DhcpIPAddress')) + @($s.GetValue('IPAddress')) | Where-Object { $_ -and $_ -ne '0.0.0.0' } | Select-Object -First 1)
        if ($ip) { $res += "$root\$n" }
        $s.Close()
    }
    $k.Close()
    return $res
}

function Measure-Ping([string]$Target, [int]$Count = 10) {
    $p = New-Object System.Net.NetworkInformation.Ping
    $times = @(); $lost = 0
    for ($i = 0; $i -lt $Count; $i++) {
        try { $r = $p.Send($Target, 1000); if ($r.Status -eq 'Success') { $times += [int]$r.RoundtripTime } else { $lost++ } } catch { $lost++ }
        Start-Sleep -Milliseconds 120
    }
    if ($times.Count -eq 0) { return [pscustomobject]@{ Target = $Target; Avg = -1; Jitter = -1; Max = -1; Loss = 100 } }
    $avg = ($times | Measure-Object -Average).Average
    $jit = 0.0
    for ($i = 1; $i -lt $times.Count; $i++) { $jit += [math]::Abs($times[$i] - $times[$i - 1]) }
    if ($times.Count -gt 1) { $jit = $jit / ($times.Count - 1) }
    [pscustomobject]@{ Target = $Target; Avg = [math]::Round($avg, 1); Jitter = [math]::Round($jit, 1)
        Max = ($times | Measure-Object -Maximum).Maximum; Loss = [math]::Round($lost * 100 / $Count) }
}

function Measure-Dns([string]$Server) {
    $names = 'www.google.com', 'www.wikipedia.org', 'www.microsoft.com', 'www.amazon.de', 'store.steampowered.com'
    $t = @()
    foreach ($n in $names) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        try { $null = Resolve-DnsName -Name $n -Server $Server -DnsOnly -NoHostsFile -QuickTimeout -ErrorAction Stop; $t += $sw.Elapsed.TotalMilliseconds }
        catch { $t += 2000 }
    }
    $s = @($t | Sort-Object)
    return [math]::Round($s[[int][math]::Floor($s.Count / 2)], 0)
}

$script:PublicDns = @(
    @{ Name = 'Cloudflare'; P = '1.1.1.1'; S = '1.0.0.1' }
    @{ Name = 'Google'; P = '8.8.8.8'; S = '8.8.4.4' }
    @{ Name = 'Quad9'; P = '9.9.9.9'; S = '149.112.112.112' }
)

function Get-NetworkStatus {
    $cfg = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } | Select-Object -First 1
    if (-not $cfg) { return [pscustomobject]@{ Connected = $false; Time = (Get-Date) } }
    $ad = $cfg.NetAdapter
    $gw = [string](@($cfg.IPv4DefaultGateway)[0].NextHop)
    Report 'Messe den Ping zum Router und ins Internet ...'
    $pGw = Measure-Ping $gw 10
    $pNet = Measure-Ping '1.1.1.1' 15
    Report 'Teste die Geschwindigkeit der DNS-Server ...'
    $cur = @((Get-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses)
    $curDns = [string]($cur | Select-Object -First 1)
    $dns = @()
    if ($curDns) { $dns += [pscustomobject]@{ Name = 'Aktuell'; P = $curDns; S = ''; Ms = (Measure-Dns $curDns) } }
    foreach ($d in $script:PublicDns) { if ($d.P -ne $curDns) { $dns += [pscustomobject]@{ Name = $d.Name; P = $d.P; S = $d.S; Ms = (Measure-Dns $d.P) } } }
    $public = $script:PublicDns | Where-Object { $_.P -eq $curDns } | Select-Object -First 1
    [pscustomobject]@{
        Connected = $true; Adapter = $ad.Name; Desc = $ad.InterfaceDescription; IfIndex = $ad.ifIndex; Wifi = (Test-WifiAdapter $ad)
        Speed = [string]$ad.LinkSpeed; Gateway = $gw; PingGw = $pGw; PingNet = $pNet; CurrentDns = $curDns
        CurrentDnsName = $(if ($public) { $public.Name } elseif ($curDns -eq $gw) { 'Router' } else { $curDns }); Dns = $dns; Time = (Get-Date)
    }
}

function Set-GamingDns([int]$IfIndex, [string]$Primary, [string]$Secondary) {
    Set-DnsClientServerAddress -InterfaceIndex $IfIndex -ServerAddresses @($Primary, $Secondary) -ErrorAction Stop
    Clear-DnsClientCache -ErrorAction SilentlyContinue
}

function Reset-GamingDns([int]$IfIndex) {
    Set-DnsClientServerAddress -InterfaceIndex $IfIndex -ResetServerAddresses -ErrorAction Stop
    Clear-DnsClientCache -ErrorAction SilentlyContinue
}

# ---------------------------------------------------------------------------
#  Autostart
# ---------------------------------------------------------------------------
$script:StartupKeepRx = 'SecurityHealth|Windows Security|Defender|RtkAud|Realtek|Waves|Dolby|Nahimic|NVIDIA|nvcpl|NvBackend|Radeon|AMD|igfx|Intel|Synaptics|ELAN|Logitech|LGHUB|Razer|Corsair|iCUE|SteelSeries|OneDrive|Dropbox|Bitdefender|Kaspersky|Avast|AVG|ESET|Norton|McAfee|Avira|Malwarebytes|Sophos|G DATA|Wacom|Bluetooth|Touchpad|Audio|Keyboard|Tastatur|VPN'
$script:StartupOffRx = 'Steam|Epic|Discord|Spotify|Teams|Skype|EADesktop|EA Desktop|Origin|Ubisoft|uplay|Battle\.net|GOG|Galaxy|Adobe|CCXProcess|Creative Cloud|EdgeAutoLaunch|iTunes|Opera|Zoom|WhatsApp|Telegram|Slack|CCleaner|jusched|Java Update|Overwolf|Medal|Cortana|Wallpaper Engine|uTorrent|qBittorrent|BitTorrent|Messenger|Amazon Music|Deezer'

function Get-StartupApproved([string]$Hive, [string]$Sub, [string]$Name) {
    try {
        $bk = Open-BaseKey $Hive $(if ($Hive -eq 'HKLM') { '64' } else { 'Default' })
        $k = $bk.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\$Sub")
        if (-not $k) { return $true }
        $v = $k.GetValue($Name)
        $k.Close(); $bk.Close()
        if ($v -is [byte[]] -and $v.Length -gt 0) { return (($v[0] % 2) -eq 0) }
    } catch {}
    return $true
}

function Set-StartupItemState([string]$Id, [bool]$Enable) {
    $hive, $sub, $name = $Id -split '\|', 3
    $bk = Open-BaseKey $hive $(if ($hive -eq 'HKLM') { '64' } else { 'Default' })
    $k = $bk.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\$sub")
    $bytes = New-Object byte[] 12
    $bytes[0] = if ($Enable) { 2 } else { 3 }
    $k.SetValue($name, $bytes, [Microsoft.Win32.RegistryValueKind]::Binary)
    $k.Close(); $bk.Close()
}

function Get-StartupItems {
    $items = @()
    $sources = @(
        @{ Hive = 'HKCU'; View = 'Default'; Sub = 'Run'; Who = 'Nur dieser Benutzer' }
        @{ Hive = 'HKLM'; View = '64'; Sub = 'Run'; Who = 'Alle Benutzer' }
        @{ Hive = 'HKLM'; View = '32'; Sub = 'Run32'; Who = 'Alle Benutzer' }
    )
    foreach ($src in $sources) {
        try {
            $bk = Open-BaseKey $src.Hive $src.View
            $k = $bk.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
            if ($k) {
                foreach ($n in $k.GetValueNames()) {
                    if (-not $n) { continue }
                    $items += [pscustomobject]@{ Id = "$($src.Hive)|$($src.Sub)|$n"; Name = $n; Command = [string]$k.GetValue($n); Who = $src.Who
                        Enabled = (Get-StartupApproved $src.Hive $src.Sub $n) }
                }
                $k.Close()
            }
            $bk.Close()
        } catch {}
    }
    foreach ($f in @(@{ Dir = [Environment]::GetFolderPath('Startup'); Hive = 'HKCU'; Who = 'Nur dieser Benutzer' }, @{ Dir = [Environment]::GetFolderPath('CommonStartup'); Hive = 'HKLM'; Who = 'Alle Benutzer' })) {
        foreach ($file in @(Get-ChildItem -LiteralPath $f.Dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' })) {
            $items += [pscustomobject]@{ Id = "$($f.Hive)|StartupFolder|$($file.Name)"; Name = $file.BaseName; Command = $file.FullName; Who = $f.Who
                Enabled = (Get-StartupApproved $f.Hive 'StartupFolder' $file.Name) }
        }
    }
    foreach ($i in $items) {
        $text = "$($i.Name) $($i.Command)"
        $class = if ($text -match $script:StartupKeepRx) { 'keep' } elseif ($text -match $script:StartupOffRx) { 'off' } else { 'neutral' }
        $i | Add-Member -NotePropertyName Class -NotePropertyValue $class
    }
    $items | Sort-Object @{ e = { @{ off = 0; neutral = 1; keep = 2 }[$_.Class] } }, Name
}

# ---------------------------------------------------------------------------
#  Gaming-Optimierungen
# ---------------------------------------------------------------------------
function Get-GamingTweakDefs([bool]$IsLaptop) {
    $akku = if ($IsLaptop) { 'Laptop: Der Akku hält etwas kürzer.' } else { '' }
    @(
        # ======================= Bild & Steuerung =======================
        @{ Id = 'refresh'; Group = 'display'; Mode = 'recommended'; Impact = 3; Restart = $false
           Title = 'Bildwiederholrate des Monitors'; Target = 'Höchste mögliche Bildwiederholrate'; Fix = 'Auf Maximum stellen'; Risk = ''
           Benefit = 'Deutlich flüssigeres Bild und weniger Verzögerung - der Monitor zeigt alle Bilder, die die Grafikkarte liefert.'
           Desc = 'Windows stellt Monitore oft auf 60 Hz, obwohl sie 144 Hz oder mehr können. Beim Umstellen wird der Bildschirm kurz schwarz. Erscheint die höhere Rate gar nicht, liegt es meist am Kabel (DisplayPort verwenden) oder am Anschluss (Grafikkarte statt Mainboard).'
           Applicable = { @(Get-DisplayInfo).Count -gt 0 }
           Read = { (@(Get-DisplayInfo) | ForEach-Object { "Bildschirm $($_.No): $($_.Hz) Hz" + $(if ($_.MaxHz -gt $_.Hz) { " (möglich: $($_.MaxHz) Hz)" } else { ' (Maximum)' }) }) -join '  ·  ' }
           Check = { -not (@(Get-DisplayInfo) | Where-Object { $_.MaxHz -gt $_.Hz }) }
           Apply = {
               foreach ($d in @(Get-DisplayInfo | Where-Object { $_.MaxHz -gt $_.Hz })) {
                   $r = [PCO.Native]::SetRefreshRate($d.Device, $d.MaxHz)
                   if ($r -ne 0) { throw "Bildschirm $($d.No) ließ sich nicht auf $($d.MaxHz) Hz stellen (Code $r). Prüf Kabel und Anschluss." }
               }
           } }
        @{ Id = 'vrr'; Group = 'display'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Variable Bildwiederholrate für Fensterspiele'; Target = 'Einschalten'; Fix = 'Einschalten'; Risk = ''
           Benefit = 'G-Sync/FreeSync funktioniert auch bei Spielen im Fenster- oder randlosen Modus - weniger Zerreißen und Ruckeln.'
           Desc = 'Wirkt nur mit einem Monitor, der G-Sync, FreeSync oder »Adaptive Sync« unterstützt. Sonst schadet die Einstellung nicht.'
           Read = { if ((Get-DxGlobal) -match 'VRROptimizeEnable=1;') { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { (Get-DxGlobal) -match 'VRROptimizeEnable=1;' }
           Apply = { Save-OrigDx 'vrr' 'VRROptimizeEnable'; Set-DxGlobalValue 'VRROptimizeEnable' '1' }
           Revert = { Restore-OrigDx 'vrr' 'VRROptimizeEnable' } }
        @{ Id = 'mouse'; Group = 'display'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Mausbeschleunigung'; Target = 'Ausschalten'; Fix = 'Ausschalten'; Risk = ''
           Benefit = 'Präziseres Zielen: Die gleiche Handbewegung bewegt den Mauszeiger immer gleich weit.'
           Desc = 'Windows beschleunigt den Mauszeiger bei schnellen Bewegungen (»Zeigerbeschleunigung verbessern«). Für Spiele ist das hinderlich. Die Mausempfindlichkeit selbst bleibt unverändert.'
           Read = { if ((Get-RegValue 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1') -eq '0') { 'Mausbeschleunigung ist ausgeschaltet' } else { 'Mausbeschleunigung ist eingeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1') -eq '0' }
           Apply = {
               foreach ($n in 'MouseSpeed', 'MouseThreshold1', 'MouseThreshold2') { Save-OrigReg "mouse|$n" 'HKCU' 'Control Panel\Mouse' $n }
               Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '0'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold1' '0'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold2' '0'
               [void][PCO.Native]::SetMouseAcceleration($false)
           }
           Revert = {
               Restore-OrigReg 'mouse|MouseSpeed' 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1'
               Restore-OrigReg 'mouse|MouseThreshold1' 'HKCU' 'Control Panel\Mouse' 'MouseThreshold1' '6'
               Restore-OrigReg 'mouse|MouseThreshold2' 'HKCU' 'Control Panel\Mouse' 'MouseThreshold2' '10'
               [void][PCO.Native]::SetMouseAcceleration([string](Get-RegValue 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1') -ne '0')
           } }

        # ======================= Prozessor & System =======================
        @{ Id = 'coreparking'; Group = 'system'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Prozessorkerne schlafen legen (Core Parking)'; Target = 'Alle Kerne bleiben aktiv'; Fix = 'Alle Kerne aktiv halten'; Risk = $akku
           Benefit = 'Weniger Mikroruckler, weil keine Prozessorkerne erst »aufwachen« müssen.'
           Desc = 'Windows legt ungenutzte Kerne schlafen, um Strom zu sparen. Wird plötzlich Leistung gebraucht, dauert das Aufwecken einen Moment.'
           Read = { $v = Get-PowerValue $script:ProcSub $script:CoreParking; if ($v -lt 0) { 'unbekannt' } else { "Mindestens $v % der Kerne bleiben aktiv" } }
           Check = { $v = Get-PowerValue $script:ProcSub $script:CoreParking; ($v -eq 100) -or ($v -lt 0) }
           Apply = { Save-OrigPower 'coreparking' $script:ProcSub $script:CoreParking; Set-PowerValue $script:ProcSub $script:CoreParking 100 }
           Revert = { Restore-OrigPower 'coreparking' $script:ProcSub $script:CoreParking $null } }
        @{ Id = 'powerthrottling'; Group = 'system'; Mode = 'optional'; Impact = 0; Restart = $true
           Title = 'Drosselung von Hintergrundprogrammen'; Target = 'Ausschalten - nur beim Streamen oder Aufnehmen'; Fix = 'Drosselung ausschalten'
           Risk = 'Hintergrundprogramme verbrauchen mehr Strom' + $(if ($IsLaptop) { ' - kürzere Akkulaufzeit' } else { '' }) + '. Dem Spiel selbst bringt das nichts.'
           Benefit = 'Nur sinnvoll, wenn du nebenbei streamst oder aufnimmst (z. B. OBS) und die Aufnahme ruckelt. Das Spiel selbst wird nie gedrosselt.'
           Desc = 'Windows bremst nur Programme, die im Hintergrund laufen (»Power Throttling«). Das Spiel im Vordergrund ist davon nie betroffen und bekommt immer volle Leistung. Mit dem Energiesparplan Höchstleistung (Schritt Leistung) drosselt Windows ohnehin kaum noch. Deshalb hier: eingeschaltet lassen.'
           Read = { if ((Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0) -eq 1) { 'Drosselung ist ausgeschaltet' } else { 'Drosselung ist eingeschaltet (Windows-Standard)' } }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0) -eq 1 }
           Apply = { Save-OrigReg 'powerthrottling' 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff'; Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1 }
           Revert = { Restore-OrigReg 'powerthrottling' 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' '__delete__' } }
        @{ Id = 'trim'; Group = 'system'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'SSD-Pflege (TRIM)'; Target = 'Einschalten'; Fix = 'TRIM einschalten'; Risk = ''
           Benefit = 'Die SSD bleibt dauerhaft schnell - Spiele laden nicht mit der Zeit langsamer.'
           Desc = 'TRIM teilt der SSD mit, welche Bereiche frei sind. Ist es ausgeschaltet (oft durch alte Tuning-Programme), wird die SSD mit der Zeit langsamer.'
           Applicable = { @(Get-CimInstance -Namespace 'root\Microsoft\Windows\Storage' -ClassName MSFT_PhysicalDisk -ErrorAction SilentlyContinue | Where-Object { [int]$_.MediaType -eq 4 }).Count -gt 0 }
           Read = { if ((fsutil.exe behavior query DisableDeleteNotify | Out-String) -match 'NTFS[^\r\n]*=\s*1') { 'TRIM ist ausgeschaltet' } else { 'TRIM ist eingeschaltet' } }
           Check = { -not ((fsutil.exe behavior query DisableDeleteNotify | Out-String) -match 'NTFS[^\r\n]*=\s*1') }
           Apply = { fsutil.exe behavior set DisableDeleteNotify 0 | Out-Null } }
        @{ Id = 'hvci'; Group = 'system'; Mode = 'optional'; Impact = 2; Restart = $true
           Title = 'Speicher-Integrität (Kernisolierung)'; Target = 'Beim Spielen ausschalten'; Fix = 'Ausschalten'
           Risk = 'Weniger Schutz vor Schadsoftware, die Treiber angreift. Microsoft empfiehlt, sie nach dem Spielen wieder einzuschalten.'
           Benefit = 'Laut Microsoft in manchen Spielen spürbar mehr FPS, weil Windows Treiber nicht mehr zusätzlich überwacht.'
           Desc = 'Eine Sicherheitsfunktion von Windows 11. Microsoft nennt das Abschalten selbst als Möglichkeit für mehr Spieleleistung - mit dem Hinweis, dass der PC dann angreifbarer ist. Hier jederzeit wieder einschaltbar (Button »Zurücksetzen«).'
           Read = {
               # VBS aus (Overdrive) schaltet die Speicher-Integrität mit ab
               if ((Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null) -eq 0) { return 'Ausgeschaltet über Overdrive (VBS aus) - Zurücksetzen dort' }
               $cfg = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' $null
               $run = @((Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning) -contains 2
               if ($cfg -eq 0 -and $run) { 'Ausgeschaltet - wirkt nach dem Neustart' } elseif ($cfg -eq 1 -and -not $run) { 'Eingeschaltet - wirkt nach dem Neustart' } elseif ($run -or $cfg -eq 1) { 'Eingeschaltet' } else { 'Ausgeschaltet' }
           }
           Check = {
               if ((Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null) -eq 0) { return $true }
               $cfg = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' $null
               if ($cfg -eq 0) { return $true }
               if ($cfg -eq 1) { return $false }
               -not (@((Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning) -contains 2)
           }
           Apply = { Save-OrigReg 'hvci' 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled'; Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' 0 }
           # Unbekannter Ursprungszustand: nicht blind einschalten (inkompatible Treiber würden blockiert)
           Revert = { Restore-OrigReg 'hvci' 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' $null } }
        @{ Id = 'vmp'; Group = 'system'; Mode = 'optional'; Impact = 1; Restart = $true
           Title = 'Plattform für virtuelle Computer'; Target = 'Ausschalten (wenn nicht benötigt)'; Fix = 'Ausschalten'
           Risk = 'WSL 2, Android-Apps, Hyper-V und manche Emulatoren funktionieren danach nicht mehr.'
           Benefit = 'Laut Microsoft in manchen Spielen etwas mehr Leistung, weil die Virtualisierungsschicht wegfällt.'
           Desc = 'Wird für virtuelle Maschinen und Linux unter Windows benötigt. Wer das nicht nutzt, kann sie abschalten. Hier jederzeit wieder einschaltbar.'
           Applicable = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; [bool]$f }
           Read = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; if ([string]$f.State -match '^Enabled') { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; [string]$f.State -notmatch '^Enabled' }
           Apply = { Save-OdValue 'vmp' 'enabled'; Disable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart -ErrorAction Stop | Out-Null }
           Revert = { [void](Pop-OdValue 'vmp'); Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart -ErrorAction Stop | Out-Null } }
        @{ Id = 'bgapps'; Group = 'system'; Mode = 'optional'; Impact = 1; Restart = $false
           Title = 'Store-Apps im Hintergrund'; Target = 'Nicht im Hintergrund ausführen'; Fix = 'Ausschalten'
           Risk = 'Store-Apps wie Mail, Kalender oder Wetter aktualisieren sich erst beim Öffnen und zeigen evtl. keine Benachrichtigungen.'
           Benefit = 'Weniger Programme im Hintergrund - etwas mehr Leistung und Arbeitsspeicher für Spiele.'
           Desc = 'Gilt nur für Apps aus dem Microsoft Store, nicht für normale Programme wie Discord oder Steam.'
           Read = { if ((Get-RegValue 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 0) -eq 2) { 'Store-Apps laufen nicht im Hintergrund' } else { 'Store-Apps dürfen im Hintergrund laufen' } }
           Check = { (Get-RegValue 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 0) -eq 2 }
           Apply = { Save-OrigReg 'bgapps' 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground'; Set-RegDword 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 2 }
           Revert = { Restore-OrigReg 'bgapps' 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' '__delete__' } }
        @{ Id = 'mmcss'; Group = 'system'; Mode = 'experimental'; Impact = 1; Restart = $true
           Title = 'Vorrang für Spiele im Multimedia-Planer'; Target = 'Spiele bevorzugen'; Fix = 'Anwenden'
           Risk = 'Die Wirkung ist umstritten und je nach PC kaum messbar.'
           Benefit = 'Windows reserviert weniger Rechenzeit für Hintergrundaufgaben und gibt Spielen höhere Priorität.'
           Desc = 'Setzt SystemResponsiveness auf 10 % und für die Aufgabe »Games« höhere Prozessor- und Grafikpriorität. Beliebter Gaming-Tweak, unabhängige Messungen zeigen aber meist nur kleine Unterschiede.'
           Read = { "Für Hintergrund reserviert: $(Get-RegValue 'HKLM' $script:MmKey 'SystemResponsiveness' 20) %  ·  Spiele-Priorität: $(Get-RegValue 'HKLM' $script:MmGames 'Priority' 2)" }
           Check = { (Get-RegValue 'HKLM' $script:MmKey 'SystemResponsiveness' 20) -le 10 -and (Get-RegValue 'HKLM' $script:MmGames 'Priority' 2) -ge 6 }
           Apply = {
               Save-OrigReg 'mmcss|sr' 'HKLM' $script:MmKey 'SystemResponsiveness'
               foreach ($n in 'GPU Priority', 'Priority', 'Scheduling Category', 'SFIO Priority') { Save-OrigReg "mmcss|$n" 'HKLM' $script:MmGames $n }
               Set-RegDword 'HKLM' $script:MmKey 'SystemResponsiveness' 10
               Set-RegDword 'HKLM' $script:MmGames 'GPU Priority' 8; Set-RegDword 'HKLM' $script:MmGames 'Priority' 6
               Set-RegString 'HKLM' $script:MmGames 'Scheduling Category' 'High'; Set-RegString 'HKLM' $script:MmGames 'SFIO Priority' 'High'
           }
           Revert = {
               Restore-OrigReg 'mmcss|sr' 'HKLM' $script:MmKey 'SystemResponsiveness' 20
               Restore-OrigReg 'mmcss|GPU Priority' 'HKLM' $script:MmGames 'GPU Priority' 8
               Restore-OrigReg 'mmcss|Priority' 'HKLM' $script:MmGames 'Priority' 2
               Restore-OrigReg 'mmcss|Scheduling Category' 'HKLM' $script:MmGames 'Scheduling Category' 'Medium'
               Restore-OrigReg 'mmcss|SFIO Priority' 'HKLM' $script:MmGames 'SFIO Priority' 'Normal'
           } }
        @{ Id = 'priosep'; Group = 'system'; Mode = 'experimental'; Impact = 1; Restart = $false
           Title = 'Prozessor-Zeitverteilung (Vordergrund-Vorrang)'; Target = 'Vordergrund stärker bevorzugen'; Fix = 'Anwenden'
           Risk = 'Wirkung umstritten. Hintergrundaufgaben (Downloads, Aufnahmen) können langsamer laufen.'
           Benefit = 'Das Programm im Vordergrund - also das Spiel - bekommt kürzere Reaktionszeiten.'
           Desc = 'Setzt Win32PrioritySeparation auf 0x26 (kurze, variable Zeitscheiben mit hohem Vordergrund-Vorrang). In Gaming-Foren beliebt, messbare Vorteile sind nicht belegt.'
           Read = { $v = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2; 'Wert: 0x{0:X2}{1}' -f [int]$v, $(if ([int]$v -eq 2) { ' (Windows-Standard)' } else { '' }) }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2) -eq 0x26 }
           Apply = { Save-OrigReg 'priosep' 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation'; Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 0x26 }
           Revert = { Restore-OrigReg 'priosep' 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2 } }

        # ======================= Internet & Ping =======================
        @{ Id = 'autotuning'; Group = 'network'; Mode = 'recommended'; Impact = 2; Restart = $false
           Title = 'TCP-Autotuning (Empfangsfenster)'; Target = 'Normal (Windows-Standard)'; Fix = 'Reparieren'; Risk = ''
           Benefit = 'Downloads (z. B. Spiele-Updates) nutzen wieder die volle Geschwindigkeit deiner Leitung.'
           Desc = 'Viele »Internet-Tuning«-Programme schalten diese Funktion ab. Das senkt den Ping nicht, macht aber Downloads langsamer.'
           Read = { $s = Get-NetTCPSetting -SettingName Internet -ErrorAction SilentlyContinue; if ($s) { "Stufe: $($s.AutoTuningLevelLocal)" } else { 'unbekannt' } }
           Check = { $s = Get-NetTCPSetting -SettingName Internet -ErrorAction SilentlyContinue; (-not $s) -or ([string]$s.AutoTuningLevelLocal -eq 'Normal') }
           Apply = { netsh.exe int tcp set global autotuninglevel=normal | Out-Null } }
        @{ Id = 'deliveryopt'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Windows-Updates mit anderen PCs teilen'; Target = 'Ausgeschaltet'; Fix = 'Teilen ausschalten'; Risk = ''
           Benefit = 'Deine Upload-Bandbreite bleibt für Spiele, Voice-Chat und Streaming frei.'
           Desc = 'Die Übermittlungsoptimierung verteilt heruntergeladene Updates an andere PCs – im Heimnetz oder im Internet. Danach lädt Windows Updates nur noch direkt von Microsoft und teilt sie mit niemandem. Entspricht in den Windows-Einstellungen »Downloads von anderen PCs zulassen: Aus«.'
           Read = { $v = try { [Microsoft.Win32.Registry]::Users.OpenSubKey($script:DoKey).GetValue('DownloadMode') } catch { $null }
                    switch ($v) { 0 { 'Ausgeschaltet' } 99 { 'Ausgeschaltet' } 100 { 'Ausgeschaltet' } 1 { 'Eingeschaltet – teilt mit PCs im Heimnetz' } 3 { 'Eingeschaltet – teilt mit PCs im Internet' } default { 'Eingeschaltet (Windows-Standard)' } } }
           Check = { $v = try { [Microsoft.Win32.Registry]::Users.OpenSubKey($script:DoKey).GetValue('DownloadMode') } catch { $null }; $null -ne $v -and [int]$v -in 0, 99, 100 }
           Apply = { Save-OrigReg 'deliveryopt' 'HKU' $script:DoKey 'DownloadMode'; Set-RegValueAny 'HKU' $script:DoKey 'DownloadMode' 0 }
           Revert = { Restore-OrigReg 'deliveryopt' 'HKU' $script:DoKey 'DownloadMode' '__delete__' } }
        @{ Id = 'wlanpower'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Energiesparen des WLAN-Adapters'; Target = 'Höchstleistung'; Fix = 'Energiesparen ausschalten'; Risk = $akku
           Benefit = 'Weniger Ping-Spitzen und Aussetzer, weil der WLAN-Adapter nicht zwischendurch in den Sparmodus wechselt.'
           Desc = 'Gilt für den aktiven Energiesparplan, im Netz- und im Akkubetrieb.'
           Applicable = { @(Get-ActiveAdapters | Where-Object { Test-WifiAdapter $_ }).Count -gt 0 }
           Read = { switch (Get-PowerValue $script:WlanSub $script:WlanPower) { 0 { 'Höchstleistung' } 1 { 'Niedriger Energiesparmodus' } 2 { 'Mittlerer Energiesparmodus' } 3 { 'Maximaler Energiesparmodus' } default { 'unbekannt' } } }
           Check = { (Get-PowerValue $script:WlanSub $script:WlanPower) -le 0 }
           Apply = { Save-OrigPower 'wlanpower' $script:WlanSub $script:WlanPower; Set-PowerValue $script:WlanSub $script:WlanPower 0 }
           Revert = { Restore-OrigPower 'wlanpower' $script:WlanSub $script:WlanPower $null } }
        @{ Id = 'nicpower'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Netzwerkadapter zum Stromsparen abschalten'; Target = 'Nicht abschalten'; Fix = 'Ausschalten'; Risk = 'Die Verbindung ist beim Umstellen wenige Sekunden unterbrochen.'
           Benefit = 'Keine Verbindungsabbrüche, weil Windows den Netzwerkadapter nicht mehr zum Stromsparen abschaltet.'
           Desc = 'Entspricht im Geräte-Manager dem Häkchen »Computer kann das Gerät ausschalten, um Energie zu sparen«.'
           Applicable = { @(Get-NicPowerEntries).Count -gt 0 }
           Read = { $on = @(Get-NicPowerEntries | Where-Object { $_.Enable }); if ($on.Count) { "Windows darf $($on.Count) Adapter abschalten" } else { 'Windows schaltet die Adapter nicht ab' } }
           Check = { @(Get-NicPowerEntries | Where-Object { $_.Enable }).Count -eq 0 }
           Apply = { $on = @(Get-NicPowerEntries | Where-Object { $_.Enable })
                     Save-OdValue 'nicpower' ((@($on | ForEach-Object { [string]$_.InstanceName })) -join '|')
                     foreach ($e in $on) { Set-CimInstance -InputObject $e -Property @{ Enable = $false } -ErrorAction Stop } }
           # nur die Adapter wieder einschalten, die vorher eingeschaltet waren
           Revert = { $known = (Get-OdBackup).ContainsKey('nicpower'); $names = @(([string](Pop-OdValue 'nicpower')) -split '\|' | Where-Object { $_ })
                      foreach ($e in @(Get-NicPowerEntries | Where-Object { -not $_.Enable })) { if (-not $known -or $names -contains [string]$e.InstanceName) { Set-CimInstance -InputObject $e -Property @{ Enable = $true } -ErrorAction SilentlyContinue } } } }
        @{ Id = 'eee'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Energiesparendes Ethernet (Green Ethernet)'; Target = 'Ausschalten'; Fix = 'Ausschalten'; Risk = 'Die Verbindung ist beim Umstellen wenige Sekunden unterbrochen.'
           Benefit = 'Gleichmäßigerer Ping über das Netzwerkkabel, weil die Verbindung nicht in Pausen heruntergefahren wird.'
           Desc = 'Der Netzwerkanschluss spart in Datenpausen Strom. Beim Spielen kann das kleine Verzögerungen verursachen.'
           Applicable = { @(Get-EeeProperties).Count -gt 0 }
           Read = { $on = @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' }); if ($on.Count) { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' }).Count -eq 0 }
           Apply = { $on = @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' })
                     Save-OdValue 'eee' ((@($on | ForEach-Object { "$($_.Name)`t$($_.RegistryKeyword)`t$(@($_.RegistryValue)[0])" })) -join "`n")
                     foreach ($p in $on) { Set-NetAdapterAdvancedProperty -Name $p.Name -RegistryKeyword $p.RegistryKeyword -RegistryValue 0 -ErrorAction Stop } }
           Revert = { if ((Get-OdBackup).ContainsKey('eee')) {
                          foreach ($l in @(([string](Pop-OdValue 'eee')) -split "`n" | Where-Object { $_ })) { $x = $l -split "`t"; Set-NetAdapterAdvancedProperty -Name $x[0] -RegistryKeyword $x[1] -RegistryValue $x[2] -ErrorAction SilentlyContinue }
                      } else { foreach ($p in @(Get-EeeProperties)) { Set-NetAdapterAdvancedProperty -Name $p.Name -RegistryKeyword $p.RegistryKeyword -RegistryValue 1 -ErrorAction SilentlyContinue } } } }
        @{ Id = 'intmod'; Group = 'network'; Mode = 'experimental'; Impact = 1; Restart = $false
           Title = 'Interrupt-Moderation des Netzwerkadapters'; Target = 'Ausschalten'; Fix = 'Ausschalten'
           Risk = 'Etwas höhere Prozessorlast bei viel Datenverkehr. Verbindung beim Umstellen kurz unterbrochen. Nur bei schnellen Prozessoren sinnvoll.'
           Benefit = 'Netzwerkpakete werden sofort statt gesammelt verarbeitet - minimal geringere Verzögerung.'
           Desc = 'Der Adapter sammelt eingehende Pakete und meldet sie gebündelt. Das schont den Prozessor, kostet aber Bruchteile von Millisekunden.'
           Applicable = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue }).Count -gt 0 }
           Read = { $on = @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue } | Where-Object { [string]$_.RegistryValue -ne '0' }); if ($on.Count) { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue } | Where-Object { [string]$_.RegistryValue -ne '0' }).Count -eq 0 }
           Apply = { $cur = @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue } | Where-Object { $_ })
                     Save-OdValue 'intmod' ((@($cur | ForEach-Object { "$($_.Name)`t$(@($_.RegistryValue)[0])" })) -join "`n")
                     foreach ($a in @(Get-ActiveAdapters)) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*InterruptModeration' -RegistryValue 0 -ErrorAction SilentlyContinue } }
           Revert = { if ((Get-OdBackup).ContainsKey('intmod')) {
                          foreach ($l in @(([string](Pop-OdValue 'intmod')) -split "`n" | Where-Object { $_ })) { $x = $l -split "`t"; Set-NetAdapterAdvancedProperty -Name $x[0] -RegistryKeyword '*InterruptModeration' -RegistryValue $x[1] -ErrorAction SilentlyContinue }
                      } else { foreach ($a in @(Get-ActiveAdapters)) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*InterruptModeration' -RegistryValue 1 -ErrorAction SilentlyContinue } } } }
        @{ Id = 'nagle'; Group = 'network'; Mode = 'experimental'; Impact = 1; Restart = $true
           Title = 'Nagle-Algorithmus (TCP-Verzögerung)'; Target = 'Ausschalten'; Fix = 'Ausschalten'
           Risk = 'Hilft nur bei älteren Online-Spielen, die TCP nutzen (z. B. manche MMOs). Die meisten Shooter nutzen UDP - dort ändert sich nichts.'
           Benefit = 'Kleine Datenpakete werden sofort gesendet statt kurz gesammelt.'
           Desc = 'Setzt TcpAckFrequency=1 und TCPNoDelay=1 für die aktiven Netzwerkverbindungen. Wird nach einem Neustart wirksam.'
           Applicable = { @(Get-TcpInterfaceKeys).Count -gt 0 }
           Read = { $keys = @(Get-TcpInterfaceKeys); $off = @($keys | Where-Object { (Get-RegValue 'HKLM' $_ 'TcpAckFrequency' 0) -eq 1 -and (Get-RegValue 'HKLM' $_ 'TCPNoDelay' 0) -eq 1 }); if ($off.Count -eq $keys.Count) { 'Ausgeschaltet' } else { 'Eingeschaltet (Windows-Standard)' } }
           Check = { $keys = @(Get-TcpInterfaceKeys); @($keys | Where-Object { (Get-RegValue 'HKLM' $_ 'TcpAckFrequency' 0) -eq 1 -and (Get-RegValue 'HKLM' $_ 'TCPNoDelay' 0) -eq 1 }).Count -eq $keys.Count }
           Apply = { $i = 0
                     foreach ($k in @(Get-TcpInterfaceKeys)) { $i++; Save-OdValue "nagle|$i|k" $k; Save-OrigReg "nagle|$i|a" 'HKLM' $k 'TcpAckFrequency'; Save-OrigReg "nagle|$i|n" 'HKLM' $k 'TCPNoDelay'
                                                               Set-RegDword 'HKLM' $k 'TcpAckFrequency' 1; Set-RegDword 'HKLM' $k 'TCPNoDelay' 1 } }
           Revert = { $h = Get-OdBackup
                      if ($h.ContainsKey('nagle|1|k')) {
                          for ($i = 1; $h.ContainsKey("nagle|$i|k"); $i++) { $k = [string](Pop-OdValue "nagle|$i|k"); Restore-OrigReg "nagle|$i|a" 'HKLM' $k 'TcpAckFrequency' '__delete__'; Restore-OrigReg "nagle|$i|n" 'HKLM' $k 'TCPNoDelay' '__delete__' }
                      } else { foreach ($k in @(Get-TcpInterfaceKeys)) { Remove-RegValueAny 'HKLM' $k 'TcpAckFrequency'; Remove-RegValueAny 'HKLM' $k 'TCPNoDelay' } } } }
    )
}

function Get-GamingTweaks([string]$Group = '', [bool]$IsLaptop = $false) {
    $defs = if ($Group -eq 'overdrive') { Get-OverdriveTweakDefs $IsLaptop } else { Get-GamingTweakDefs $IsLaptop }
    foreach ($t in $defs) {
        if ($Group -and $t.Group -ne $Group) { continue }
        if ($t.Applicable) { $ok = try { [bool](& $t.Applicable) } catch { $false }; if (-not $ok) { continue } }
        Report "Prüfe: $($t.Title) ..."
        $state = try { [string](& $t.Read) } catch { 'Fehler: ' + $_.Exception.Message }
        $opt = try { [bool](& $t.Check) } catch { $false }
        [pscustomobject]@{
            Id = $t.Id; Group = $t.Group; Title = $t.Title; Target = $t.Target; Fix = $t.Fix; Benefit = $t.Benefit; Desc = $t.Desc
            Risk = $t.Risk; Mode = $t.Mode; Impact = $t.Impact; Restart = $t.Restart; CanRevert = [bool]$t.Revert
            State = $state; Optimal = $opt; Optional = ($t.Mode -ne 'recommended')
            Level = [int]$t.Level; ByTuneRig = $(if ($t.Group -eq 'overdrive') { Test-OdChanged $t.Id } else { $false })
        }
    }
}

function Invoke-GamingTweaks([string[]]$Ids, [switch]$Revert) { Invoke-AllSettings $Ids -Revert:$Revert }

# ============================================================================
#  ALLE EINSTELLUNGEN IN EINER LISTE (Reiter Leistung)
#  Grundeinstellungen (Energie, Spiele & Grafik) + Gaming-Optimierungen.
#  Reihenfolge: Der Energiesparplan wird zuerst umgestellt, weil die übrigen
#  Energie-Einstellungen nur für den gerade aktiven Plan gelten. Beim Zurücksetzen
#  kommt er zuletzt (die Werte gehören zum Plan, auf dem sie geändert wurden).
# ============================================================================
$script:BaseGroup = @{ power = 'power'; pcie = 'power'; usb = 'power'; gamemode = 'gaming'; hags = 'gaming'; windowed = 'gaming'; gamedvr = 'gaming'; visual = 'system' }
$script:BaseImpact = @{ power = 3; pcie = 1; usb = 1; gamemode = 1; hags = 1; windowed = 1; gamedvr = 2; visual = 1 }

function Get-AllSettings([bool]$IsLaptop) {
    $akku = if ($IsLaptop) { 'Laptop: Der Akku hält kürzer.' } else { '' }
    foreach ($t in Get-TweakDefs $IsLaptop) {
        Report "Prüfe: $($t.Title) ..."
        $state = try { [string](& $t.Read) } catch { 'Fehler: ' + $_.Exception.Message }
        $ok = try { [bool](& $t.Check) } catch { $false }
        $risk = if ($t.Id -eq 'visual') { 'Windows sieht schlichter aus.' } elseif ($t.Id -in 'power', 'pcie', 'usb') { $akku } else { '' }
        [pscustomobject]@{
            Id = $t.Id; Group = $script:BaseGroup[$t.Id]; Title = $t.Title; Target = $t.Target; Fix = $t.Fix; Benefit = $t.Benefit; Desc = $t.Desc
            Risk = $risk; Mode = $(if ($t.Optional) { 'optional' } else { 'recommended' }); Impact = [int]$script:BaseImpact[$t.Id]; Restart = $t.Restart
            CanRevert = [bool]$t.Revert; State = $state; Optimal = $ok; Optional = [bool]$t.Optional; Level = 0; ByTuneRig = (Test-TweakOrig $t.Id)
        }
    }
    foreach ($g in @(Get-GamingTweaks '' $IsLaptop)) { $g.ByTuneRig = (Test-TweakOrig $g.Id); $g }
}

# Wendet Einstellungen an bzw. setzt sie zurück (alle Arten: Grund, Gaming, Overdrive)
function Invoke-AllSettings([string[]]$Ids, [switch]$Revert) {
    $errors = @()
    $l = Test-IsLaptop
    $defs = @(@(Get-TweakDefs $l) + @(Get-GamingTweakDefs $l) + @(Get-OverdriveTweakDefs $l) | Where-Object { $Ids -contains $_.Id })
    $plan = @($defs | Where-Object { $_.Id -eq 'power' })
    $rest = @($defs | Where-Object { $_.Id -ne 'power' })
    $ordered = if ($Revert) { @($rest) + @($plan) } else { @($plan) + @($rest) }
    foreach ($t in $ordered) {
        $sb = if ($Revert) { $t.Revert } else { $t.Apply }
        if (-not $sb) { if ($Revert) { $errors += "$($t.Title): lässt sich nicht zurücksetzen (entspricht dem Windows-Standard)." }; continue }
        Report "$(if ($Revert) { 'Setze zurück' } else { 'Ändere' }): $($t.Title) ..."
        try { [void](& $sb) } catch { $errors += "$($t.Title): $($_.Exception.Message)" }
    }
    # Speicher-Integrität hängt an VBS: solange VBS (Overdrive) aus ist, bleibt sie aus
    if ($Revert -and $Ids -contains 'hvci' -and $Ids -notcontains 'od-vbs' -and (Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null) -eq 0) {
        $errors += 'Hinweis: Die Speicher-Integrität wirkt erst wieder, wenn du auch »Virtualisierungsbasierte Sicherheit« im Reiter Overdrive zurücksetzt.'
    }
    return $errors
}


# ============================================================================
#  OVERDRIVE: Feinabstimmung über die sicheren Empfehlungen hinaus (3 Stufen)
#  Ändert keine Spannungen und keine BIOS-Taktraten. Es hebt Limits auf, die
#  Windows zugunsten von Stromverbrauch, Temperatur oder Sicherheit setzt. Jeder ursprüngliche
#  Wert wird vor der Änderung gesichert (%LOCALAPPDATA%\TuneRig\overdrive.json)
#  und beim Zurücksetzen wiederhergestellt.
# ============================================================================
$script:OdPower = @{
    Boost   = 'be337238-0d82-4146-a960-4f3749d470c7'   # Prozessor-Leistungssteigerungsmodus
    Epp     = '36687f9e-e3a5-4dbf-b1dc-15eb381c6863'   # Energie-Leistungs-Präferenz
    Epp1    = '36687f9e-e3a5-4dbf-b1dc-15eb381c6864'   # dito für Effizienzkerne
    IncPol  = '465e1f50-b610-473a-ab58-00d1077dc418'   # Hochtakt-Richtlinie
    DecPol  = '40fbefc7-2e9d-4d25-a185-0cfd8574bac6'   # Runtertakt-Richtlinie
    MinState = '893dee8e-2bef-41e0-89c6-b55d0929964c'  # Minimaler Prozessorzustand
    Idle    = '5d76a2ca-e8c0-402f-a133-2158492d58ad'   # Prozessor-Leerlauf deaktivieren
}
$script:OdMemKey = 'SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
$script:OdVbsKey = 'SYSTEM\CurrentControlSet\Control\DeviceGuard'

function Get-OdBackupPath { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'TuneRig\overdrive.json' }
function Get-OdBackup {
    $h = @{}
    try { (Get-Content -LiteralPath (Get-OdBackupPath) -Raw -ErrorAction Stop | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $h[$_.Name] = $_.Value } } catch {}
    return $h
}
function Save-OdBackupFile($h) {
    $p = Get-OdBackupPath
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $p) | Out-Null
    [pscustomobject]$h | ConvertTo-Json | Set-Content -LiteralPath $p -Encoding UTF8
}
# Merkt sich den Originalwert nur beim ersten Ändern (mehrfaches Anwenden überschreibt ihn nicht)
function Save-OdValue([string]$Key, $Value) {
    $h = Get-OdBackup
    if (-not $h.ContainsKey($Key)) { $h[$Key] = $(if ($null -eq $Value) { '__none__' } else { $Value }); Save-OdBackupFile $h }
}
function Pop-OdValue([string]$Key, $Default = $null) {
    $h = Get-OdBackup
    $v = if ($h.ContainsKey($Key)) { $h[$Key] } else { $Default }
    if ($h.ContainsKey($Key)) { [void]$h.Remove($Key); Save-OdBackupFile $h }
    if ($v -eq '__none__') { return $null }
    return $v
}
function Test-OdChanged([string]$Key) { (Get-OdBackup).ContainsKey($Key) }

function Set-OdPower([string]$Key, [string]$Setting, [int]$Value) {
    Save-OdValue $Key (Get-PowerValue $script:ProcSub $Setting)
    Set-PowerValue $script:ProcSub $Setting $Value
}
function Restore-OdPower([string]$Key, [string]$Setting, [int]$Default) {
    $v = Pop-OdValue $Key $Default
    if ($null -eq $v -or [int]$v -lt 0) { $v = $Default }
    Set-PowerValue $script:ProcSub $Setting ([int]$v)
}
function Remove-RegValueSafe([string]$Path, [string]$Name) {
    try { $k = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Path, $true); if ($k) { $k.DeleteValue($Name, $false); $k.Close() } } catch {}
}
function Restore-OdReg([string]$Key, [string]$Path, [string]$Name) {
    $v = Pop-OdValue $Key $null
    if ($null -eq $v) { Remove-RegValueSafe $Path $Name } else { Set-RegDword 'HKLM' $Path $Name ([int]$v) }
}

# ---------------------------------------------------------------------------
#  Originalwerte für »Zurücksetzen« aller Einstellungen (Leistung, Gaming, Overdrive)
#  Gespeichert beim ersten Ändern in %LOCALAPPDATA%\TuneRig\overdrive.json.
#  Zurücksetzen stellt genau diesen Wert wieder her. Kennt TuneRig ihn nicht (z. B. vor
#  Version 1.6.0 geändert), gilt der angegebene Windows-Standard - oder es wird nichts
#  verändert und ein Hinweis gegeben ($null).
# ---------------------------------------------------------------------------
function Test-TweakOrig([string]$Id) { [bool](@((Get-OdBackup).Keys) | Where-Object { $_ -eq $Id -or $_ -like "$Id|*" } | Select-Object -First 1) }
function Get-HiveRoot([string]$Hive) { switch ($Hive) { 'HKLM' { [Microsoft.Win32.Registry]::LocalMachine } 'HKU' { [Microsoft.Win32.Registry]::Users } default { [Microsoft.Win32.Registry]::CurrentUser } } }
function Get-RegValueAny([string]$Hive, [string]$Path, [string]$Name) {
    try { $k = (Get-HiveRoot $Hive).OpenSubKey($Path); if (-not $k) { return $null }; $v = $k.GetValue($Name, $null, 'DoNotExpandEnvironmentNames'); $k.Close(); return $v } catch { return $null }
}
function Remove-RegValueAny([string]$Hive, [string]$Path, [string]$Name) {
    try { $k = (Get-HiveRoot $Hive).OpenSubKey($Path, $true); if ($k) { $k.DeleteValue($Name, $false); $k.Close() } } catch {}
}
function Set-RegValueAny([string]$Hive, [string]$Path, [string]$Name, $Value, [string]$Kind = 'DWord') {
    $k = (Get-HiveRoot $Hive).CreateSubKey($Path)
    $k.SetValue($Name, $(if ($Kind -eq 'DWord') { [int]$Value } else { [string]$Value }), [Microsoft.Win32.RegistryValueKind]$Kind); $k.Close()
}
function Save-OrigReg([string]$Key, [string]$Hive, [string]$Path, [string]$Name) {
    $v = Get-RegValueAny $Hive $Path $Name
    Save-OdValue $Key $(if ($null -eq $v) { $null } elseif ($v -is [string]) { "s|$v" } else { "d|$v" })
}
# $Default: Windows-Standard bei unbekanntem Original. '__delete__' = Wert entfernen, $null = nichts tun
function Restore-OrigReg([string]$Key, [string]$Hive, [string]$Path, [string]$Name, $Default) {
    if ((Get-OdBackup).ContainsKey($Key)) {
        $v = Pop-OdValue $Key
        if ($null -eq $v) { Remove-RegValueAny $Hive $Path $Name; return }
        $s = [string]$v
        if ($s -like 's|*') { Set-RegValueAny $Hive $Path $Name $s.Substring(2) 'String' }
        elseif ($s -like 'd|*') { Set-RegValueAny $Hive $Path $Name ([int]$s.Substring(2)) 'DWord' }
        else { Set-RegValueAny $Hive $Path $Name ([int]$s) 'DWord' }
        return
    }
    if ($null -eq $Default) { throw 'TuneRig kennt den ursprünglichen Wert nicht (vor Version 1.6.0 geändert). Bitte in den Windows-Einstellungen zurückstellen.' }
    if ($Default -eq '__delete__') { Remove-RegValueAny $Hive $Path $Name }
    elseif ($Default -is [string]) { Set-RegValueAny $Hive $Path $Name $Default 'String' }
    else { Set-RegValueAny $Hive $Path $Name $Default 'DWord' }
}
function Save-OrigPower([string]$Key, [string]$Sub, [string]$Setting) {
    $v = Get-PowerValue $Sub $Setting
    if ($v -ge 0) { Save-OdValue $Key $v }
}
function Restore-OrigPower([string]$Key, [string]$Sub, [string]$Setting, $Default) {
    $v = if ((Get-OdBackup).ContainsKey($Key)) { Pop-OdValue $Key } else { $Default }
    if ($null -eq $v -or [int]$v -lt 0) { throw 'TuneRig kennt den ursprünglichen Wert nicht (vor Version 1.6.0 geändert). Bitte in den Windows-Energieoptionen zurückstellen.' }
    Set-PowerValue $Sub $Setting ([int]$v)
}
function Get-DxGlobalPart([string]$Name) {
    foreach ($p in ((Get-DxGlobal) -split ';')) { if ($p -match '^(.+?)=(.*)$' -and $Matches[1] -eq $Name) { return $Matches[2] } }
    return $null
}
function Remove-DxGlobalValue([string]$Name) {
    $parts = [ordered]@{}
    foreach ($p in ((Get-DxGlobal) -split ';')) { if ($p -match '^(.+?)=(.*)$' -and $Matches[1] -ne $Name) { $parts[$Matches[1]] = $Matches[2] } }
    $txt = (($parts.Keys | ForEach-Object { "$_=$($parts[$_])" }) -join ';')
    if ($txt) { Set-RegString 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' ($txt + ';') } else { Remove-RegValueAny 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' }
}
function Save-OrigDx([string]$Key, [string]$Name) { Save-OdValue $Key (Get-DxGlobalPart $Name) }
function Restore-OrigDx([string]$Key, [string]$Name) {
    $v = if ((Get-OdBackup).ContainsKey($Key)) { Pop-OdValue $Key } else { $null }
    if ($null -eq $v) { Remove-DxGlobalValue $Name } else { Set-DxGlobalValue $Name ([string]$v) }
}

$script:OdBoostNames = @{ 0 = 'Aus'; 1 = 'Ein'; 2 = 'Aggressiv'; 3 = 'Effizient'; 4 = 'Effizient aggressiv'; 5 = 'Aggressiv (garantiert)'; 6 = 'Effizient aggressiv (garantiert)' }
$script:OdIncNames = @{ 0 = 'Ideal (stufenweise)'; 1 = 'Einzeln'; 2 = 'Sofort auf Maximum'; 3 = 'Ideal aggressiv' }

$script:OdLevels = @(
    @{ No = 1; Name = 'Sanft'; Short = 'Prozessor reagiert schneller'
       Desc = 'Der Prozessor taktet schneller hoch und bevorzugt Leistung statt Strom sparen. Kaum spürbare Nebenwirkungen.'
       Risk = 'Etwas mehr Stromverbrauch und Wärme.' }
    @{ No = 2; Name = 'Spürbar'; Short = 'Kein Heruntertakten, weniger Hintergrundlast'
       Desc = 'Der Prozessor bleibt immer auf vollem Takt, Windows komprimiert keinen Arbeitsspeicher mehr und die Suche indiziert nicht mehr im Hintergrund.'
       Risk = 'Deutlich mehr Stromverbrauch im Leerlauf, lautere Lüfter, langsamere Dateisuche.' }
    @{ No = 3; Name = 'Maximal'; Short = 'Ohne Leerlauf und ohne Sicherheitsbremsen'
       Desc = 'Die Prozessorkerne gehen nie in den Ruhezustand, Schutzfunktionen gegen Prozessor-Angriffe (Spectre/Meltdown) und die virtualisierungsbasierte Sicherheit werden abgeschaltet.'
       Risk = 'Viel Wärme und Stromverbrauch auch ohne Last. Der PC ist schlechter gegen bestimmte Angriffe geschützt. Nur für reine Spiele-PCs.' }
)

function Get-OverdriveTweakDefs([bool]$IsLaptop) {
    @(
        # ============================ Stufe 1: Sanft ============================
        @{ Id = 'od-boost'; Group = 'overdrive'; Level = 1; Mode = 'overdrive'; Impact = 1; Restart = $false
           Title = 'Turbo-Modus des Prozessors'; Target = 'Aggressiv'; Fix = 'Auf Aggressiv stellen'
           Risk = 'Etwas mehr Wärme und Stromverbrauch unter Last.'
           Benefit = 'Der Prozessor nutzt seinen Turbo-Takt öfter und länger.'
           Desc = 'Windows-Einstellung »Modus zur Prozessorleistungssteigerung«. Sie entscheidet, wie bereitwillig der Prozessor über seinen Grundtakt hinaus beschleunigt. Den Turbo selbst begrenzt weiterhin der Prozessor - es wird nichts über die Werksgrenzen hinaus gesteigert.'
           Applicable = { (Get-PowerValue $script:ProcSub $script:OdPower.Boost) -ge 0 }
           Read = { $v = Get-PowerValue $script:ProcSub $script:OdPower.Boost; if ($script:OdBoostNames.ContainsKey($v)) { $script:OdBoostNames[$v] } else { "Wert $v" } }
           Check = { (Get-PowerValue $script:ProcSub $script:OdPower.Boost) -in 2, 5 }
           Apply = { Set-OdPower 'od-boost' $script:OdPower.Boost 2 }
           Revert = { Restore-OdPower 'od-boost' $script:OdPower.Boost 1 } }
        @{ Id = 'od-epp'; Group = 'overdrive'; Level = 1; Mode = 'overdrive'; Impact = 1; Restart = $false
           Title = 'Leistungs-Vorliebe des Prozessors'; Target = '0 % Stromsparen (volle Leistung)'; Fix = 'Auf volle Leistung stellen'
           Risk = 'Mehr Stromverbrauch, auf Laptops kürzere Akkulaufzeit.'
           Benefit = 'Moderne Prozessoren takten ohne Zögern hoch, statt erst Strom zu sparen.'
           Desc = 'Bei aktuellen Intel- und AMD-Prozessoren regelt der Prozessor seinen Takt weitgehend selbst. Diese Vorliebe (0 = Leistung, 100 = Stromsparen) sagt ihm, wonach er sich richten soll. Gilt auch für Effizienzkerne, sofern vorhanden.'
           Applicable = { (Get-PowerValue $script:ProcSub $script:OdPower.Epp) -ge 0 }
           Read = { "$(Get-PowerValue $script:ProcSub $script:OdPower.Epp) % Stromsparen" }
           Check = { (Get-PowerValue $script:ProcSub $script:OdPower.Epp) -eq 0 }
           Apply = {
               Set-OdPower 'od-epp' $script:OdPower.Epp 0
               if ((Get-PowerValue $script:ProcSub $script:OdPower.Epp1) -ge 0) { Set-OdPower 'od-epp1' $script:OdPower.Epp1 0 } }
           Revert = {
               Restore-OdPower 'od-epp' $script:OdPower.Epp 33
               if (Test-OdChanged 'od-epp1') { Restore-OdPower 'od-epp1' $script:OdPower.Epp1 33 } } }
        @{ Id = 'od-ramp'; Group = 'overdrive'; Level = 1; Mode = 'overdrive'; Impact = 1; Restart = $false
           Title = 'Hochtakten bei Last'; Target = 'Sofort auf Maximum, langsam wieder herunter'; Fix = 'Sofort hochtakten'
           Risk = 'Der Prozessor springt auch bei kurzer Last auf vollen Takt - etwas mehr Wärme.'
           Benefit = 'Weniger Mikroruckler, wenn ein Spiel plötzlich mehr Rechenleistung braucht.'
           Desc = 'Legt fest, wie schnell Windows den Takt bei steigender Last erhöht und bei sinkender Last wieder senkt. Standard ist stufenweise. Wirkt vor allem bei älteren Prozessoren ohne eigene Taktregelung.'
           Applicable = { (Get-PowerValue $script:ProcSub $script:OdPower.IncPol) -ge 0 }
           Read = {
               $i = Get-PowerValue $script:ProcSub $script:OdPower.IncPol
               "Hoch: $(if ($script:OdIncNames.ContainsKey($i)) { $script:OdIncNames[$i] } else { $i })" }
           Check = { (Get-PowerValue $script:ProcSub $script:OdPower.IncPol) -eq 2 -and (Get-PowerValue $script:ProcSub $script:OdPower.DecPol) -eq 1 }
           Apply = { Set-OdPower 'od-ramp' $script:OdPower.IncPol 2; Set-OdPower 'od-ramp-dec' $script:OdPower.DecPol 1 }
           Revert = { Restore-OdPower 'od-ramp' $script:OdPower.IncPol 0; Restore-OdPower 'od-ramp-dec' $script:OdPower.DecPol 0 } }

        # ============================ Stufe 2: Spürbar ============================
        @{ Id = 'od-minstate'; Group = 'overdrive'; Level = 2; Mode = 'overdrive'; Impact = 2; Restart = $false
           Title = 'Mindesttakt des Prozessors'; Target = '100 % (kein Heruntertakten)'; Fix = 'Auf 100 % stellen'
           Risk = 'Deutlich mehr Stromverbrauch und Wärme, auch wenn der PC nichts tut. Lüfter können dauerhaft lauter laufen.' + $(if ($IsLaptop) { ' Laptop: Akku hält spürbar kürzer.' } else { '' })
           Benefit = 'Der Prozessor steht jederzeit mit vollem Takt bereit - keine Verzögerung beim Hochtakten.'
           Desc = 'Windows-Einstellung »Minimaler Leistungszustand des Prozessors«. Standard sind 5 %, damit der Prozessor im Leerlauf Strom spart.'
           Applicable = { (Get-PowerValue $script:ProcSub $script:OdPower.MinState) -ge 0 }
           Read = { "$(Get-PowerValue $script:ProcSub $script:OdPower.MinState) %" }
           Check = { (Get-PowerValue $script:ProcSub $script:OdPower.MinState) -ge 100 }
           Apply = { Set-OdPower 'od-minstate' $script:OdPower.MinState 100 }
           Revert = { Restore-OdPower 'od-minstate' $script:OdPower.MinState 5 } }
        @{ Id = 'od-memcomp'; Group = 'overdrive'; Level = 2; Mode = 'overdrive'; Impact = 1; Restart = $true
           Title = 'Arbeitsspeicher-Komprimierung'; Target = 'Ausgeschaltet'; Fix = 'Ausschalten'
           Risk = 'Ist der Arbeitsspeicher voll, lagert Windows früher auf die SSD aus. Nur sinnvoll ab 16 GB Arbeitsspeicher.'
           Benefit = 'Der Prozessor muss keinen Speicher mehr im Hintergrund packen und entpacken.'
           Desc = 'Windows komprimiert selten genutzten Arbeitsspeicher, um Platz zu sparen. Das kostet Rechenzeit. Mit viel Arbeitsspeicher ist es unnötig. Wirkt nach einem Neustart.'
           Applicable = { ((Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).TotalPhysicalMemory -ge 15GB) -and (Get-Command Get-MMAgent -ErrorAction SilentlyContinue) }
           Read = { if ((Get-MMAgent).MemoryCompression) { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { -not (Get-MMAgent).MemoryCompression }
           Apply = { Save-OdValue 'od-memcomp' 1; Disable-MMAgent -MemoryCompression -ErrorAction Stop }
           Revert = { [void](Pop-OdValue 'od-memcomp'); Enable-MMAgent -MemoryCompression -ErrorAction Stop } }
        @{ Id = 'od-search'; Group = 'overdrive'; Level = 2; Mode = 'overdrive'; Impact = 1; Restart = $false
           Title = 'Suchindex im Hintergrund'; Target = 'Ausgeschaltet'; Fix = 'Ausschalten'
           Risk = 'Die Suche im Startmenü und im Explorer findet Dateien langsamer. Programme werden weiterhin gefunden.'
           Benefit = 'Keine Festplatten- und Prozessorlast mehr durch das Indizieren, z. B. nach Spiel-Updates.'
           Desc = 'Der Dienst »Windows Search« liest ständig neue Dateien ein, damit die Suche schnell ist. Ausschalten stoppt den Dienst und verhindert seinen Start.'
           Applicable = { [bool](Get-Service WSearch -ErrorAction SilentlyContinue) }
           Read = { $s = Get-Service WSearch; if ([string]$s.StartType -eq 'Disabled') { 'Ausgeschaltet' } else { "Eingeschaltet ($(if ([string]$s.Status -eq 'Running') { 'läuft' } else { 'gestoppt' }))" } }
           Check = { [string](Get-Service WSearch).StartType -eq 'Disabled' }
           Apply = {
               Save-OdValue 'od-search' ([string](Get-Service WSearch).StartType)
               Stop-Service WSearch -Force -ErrorAction SilentlyContinue
               Set-Service WSearch -StartupType Disabled -ErrorAction Stop }
           Revert = {
               $st = [string](Pop-OdValue 'od-search' 'Automatic'); if ($st -notin 'Automatic', 'Manual') { $st = 'Automatic' }
               Set-Service WSearch -StartupType $st -ErrorAction Stop
               Start-Service WSearch -ErrorAction SilentlyContinue } }

        # ============================ Stufe 3: Maximal ============================
        @{ Id = 'od-idle'; Group = 'overdrive'; Level = 3; Mode = 'overdrive'; Impact = 1; Restart = $false
           Title = 'Ruhezustand der Prozessorkerne'; Target = 'Ausgeschaltet (Kerne immer wach)'; Fix = 'Ruhezustand ausschalten'
           Risk = 'Sehr viel mehr Wärme und Stromverbrauch, auch ohne Last. Der Prozessor erreicht dadurch unter Umständen sogar niedrigere Turbo-Takte. Nach dem Spielen zurücksetzen.'
           Benefit = 'Kerne müssen nie aus dem Schlaf aufwachen - minimal geringere Verzögerung.'
           Desc = 'Windows-Einstellung »Prozessorleerlauf deaktivieren«. Für Laptops nicht verfügbar, weil sie die Wärme nicht abführen können.'
           Applicable = { -not $IsLaptop -and (Get-PowerValue $script:ProcSub $script:OdPower.Idle) -ge 0 }
           Read = { if ((Get-PowerValue $script:ProcSub $script:OdPower.Idle) -eq 1) { 'Ausgeschaltet (Kerne immer wach)' } else { 'Eingeschaltet (Standard)' } }
           Check = { (Get-PowerValue $script:ProcSub $script:OdPower.Idle) -eq 1 }
           Apply = { Set-OdPower 'od-idle' $script:OdPower.Idle 1 }
           Revert = { Restore-OdPower 'od-idle' $script:OdPower.Idle 0 } }
        @{ Id = 'od-mitig'; Group = 'overdrive'; Level = 3; Mode = 'overdrive'; Impact = 2; Restart = $true
           Title = 'Schutz vor Spectre und Meltdown'; Target = 'Ausgeschaltet'; Fix = 'Schutz ausschalten'
           Risk = 'Sicherheitslücke: Schadsoftware auf dem PC könnte Speicher anderer Programme auslesen, z. B. Passwörter. Nicht auf PCs mit sensiblen Daten verwenden.'
           Benefit = 'Je nach Prozessor 2 bis 15 % mehr Leistung - vor allem bei älteren Intel-Prozessoren (bis etwa 9. Generation). Bei neuen Prozessoren kaum Unterschied.'
           Desc = 'Windows bremst bestimmte Prozessor-Funktionen, um Angriffe über die Lücken Spectre und Meltdown zu verhindern. Das Abschalten erfolgt über die von Microsoft dokumentierten Registry-Werte FeatureSettingsOverride und FeatureSettingsOverrideMask. Wirkt nach einem Neustart.'
           Read = {
               $o = Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverride' $null; $m = Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverrideMask' $null
               if ($o -eq 3 -and $m -eq 3) { 'Ausgeschaltet' } else { 'Eingeschaltet (Standard)' } }
           Check = { (Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverride' $null) -eq 3 -and (Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverrideMask' $null) -eq 3 }
           Apply = {
               Save-OdValue 'od-mitig' (Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverride' $null)
               Save-OdValue 'od-mitig-mask' (Get-RegValue 'HKLM' $script:OdMemKey 'FeatureSettingsOverrideMask' $null)
               Set-RegDword 'HKLM' $script:OdMemKey 'FeatureSettingsOverride' 3
               Set-RegDword 'HKLM' $script:OdMemKey 'FeatureSettingsOverrideMask' 3 }
           Revert = {
               Restore-OdReg 'od-mitig' $script:OdMemKey 'FeatureSettingsOverride'
               Restore-OdReg 'od-mitig-mask' $script:OdMemKey 'FeatureSettingsOverrideMask' } }
        @{ Id = 'od-vbs'; Group = 'overdrive'; Level = 3; Mode = 'overdrive'; Impact = 2; Restart = $true
           Title = 'Virtualisierungsbasierte Sicherheit (VBS)'; Target = 'Ausgeschaltet'; Fix = 'VBS ausschalten'
           Risk = 'Windows schützt Anmeldedaten und den Systemkern nicht mehr in einem abgeschotteten Bereich. Ist VBS per UEFI-Sperre erzwungen, bleibt es aktiv.'
           Benefit = 'Laut Microsoft und Tests in manchen Spielen 5 bis 10 % mehr FPS, weil Windows den Systemkern nicht mehr zusätzlich abschirmt.'
           Desc = 'VBS ist die Grundlage für Speicher-Integrität und Credential Guard. Ausschalten schaltet beides ab. Wirkt nach einem Neustart. Programme wie WSL oder Android-Apps funktionieren weiterhin.'
           Read = {
               $cfg = Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null
               $st = (Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).VirtualizationBasedSecurityStatus
               if ($cfg -eq 0 -and $st -eq 2) { 'Ausgeschaltet - wirkt nach dem Neustart' } elseif ($st -eq 2) { 'Aktiv' } else { 'Nicht aktiv' } }
           Check = {
               $cfg = Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null
               if ($cfg -eq 0) { return $true }
               (Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).VirtualizationBasedSecurityStatus -ne 2 }
           Apply = {
               Save-OdValue 'od-vbs' (Get-RegValue 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' $null)
               Set-RegDword 'HKLM' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' 0 }
           Revert = { Restore-OdReg 'od-vbs' $script:OdVbsKey 'EnableVirtualizationBasedSecurity' } }
    )
}

# Nur lesen: Hinweise für echtes Übertakten, das nur im BIOS oder mit Hersteller-Tools geht
function Get-OverdriveInfo {
    $ram = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
    $cfg = @($ram | ForEach-Object { [int]$_.ConfiguredClockSpeed } | Where-Object { $_ -gt 0 } | Sort-Object -Unique)
    $type = @($ram | ForEach-Object { [int]$_.SMBIOSMemoryType } | Select-Object -First 1)[0]
    $ddr = switch ($type) { 26 { 'DDR4' } 34 { 'DDR5' } default { '' } }
    $speed = if ($cfg.Count) { $cfg[0] } else { 0 }
    # JEDEC-Grundtakte: läuft der Speicher genau darauf, ist XMP/EXPO vermutlich aus
    $base = ($ddr -eq 'DDR4' -and $speed -gt 0 -and $speed -le 2666) -or ($ddr -eq 'DDR5' -and $speed -gt 0 -and $speed -le 4800)
    $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1).Name
    $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { [string]$_.Name } | Where-Object { $_ -match 'NVIDIA|AMD|Radeon|Intel\(R\) Arc' })
    [pscustomobject]@{ RamType = $ddr; RamSpeed = $speed; RamBase = [bool]$base; Cpu = [string]$cpu; Gpus = $gpus; Laptop = (Test-IsLaptop) }
}

# ============================================================================
#  Schnellcheck für die Gesamtwertung auf der Startseite (liest nur, dauert wenige Sekunden)
#  Jeder Befund kostet Punkte; 100 = alles in Ordnung.
# ============================================================================
function Get-QuickHealth {
    $items = New-Object System.Collections.ArrayList
    function Add-Q([int]$Level, [string]$Title, [int]$Penalty, [string]$Step) {
        [void]$items.Add([pscustomobject]@{ Level = $Level; Title = $Title; Penalty = $Penalty; Step = $Step })
    }

    # Speicherplatz auf dem Systemlaufwerk
    try {
        $sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'" -ErrorAction Stop
        $pct = 100.0 * [double]$sys.FreeSpace / [math]::Max(1.0, [double]$sys.Size)
        if ($pct -lt 10) { Add-Q 3 ("Systemlaufwerk fast voll – nur {0:0} % frei" -f $pct) 25 'cleanup' }
        elseif ($pct -lt 20) { Add-Q 2 ("Wenig Platz auf dem Systemlaufwerk – {0:0} % frei" -f $pct) 10 'cleanup' }
    } catch {}

    # Laufwerke mit Warnstatus
    try {
        $bad = @(Get-PhysicalDisk -ErrorAction Stop | Where-Object { [string]$_.HealthStatus -match '^(Warning|Unhealthy|1|2)$' })
        foreach ($d in $bad) { Add-Q 3 "Laufwerk meldet Probleme: $($d.FriendlyName)" 30 'system' }
    } catch {}

    # Geräte mit Treiberproblemen (22 = vom Nutzer deaktiviert, 45 = nicht angeschlossen)
    try {
        $err = @(Get-CimInstance Win32_PnPEntity -Filter 'ConfigManagerErrorCode <> 0' -ErrorAction Stop |
                 Where-Object { $_.ConfigManagerErrorCode -notin 22, 45 -and [string]$_.PNPDeviceID -notmatch '^(SWD|ROOT|HTREE)\\' })
        if ($err.Count -gt 0) { Add-Q 3 $(if ($err.Count -eq 1) { "1 Gerät ohne funktionierenden Treiber" } else { "$($err.Count) Geräte ohne funktionierenden Treiber" }) ([math]::Min(30, 12 * $err.Count)) 'drivers' }
    } catch {}

    # Software des Grafikkarten-Herstellers
    try { foreach ($s in @(Get-GpuSoftwareCheck | Where-Object { $_.Level -ge 2 })) { Add-Q 2 "$($s.Product) fehlt" 15 'drivers' } } catch {}

    # Leistungseinstellungen
    try {
        $open = @(Get-Tweaks (Test-IsLaptop) | Where-Object { -not $_.Optimal -and -not $_.Optional })
        if ($open.Count -gt 0) { Add-Q 2 $(if ($open.Count -eq 1) { "1 Einstellung bremst deinen PC" } else { "$($open.Count) Einstellungen bremsen deinen PC" }) ([math]::Min(20, 5 * $open.Count)) 'settings' }
    } catch {}

    # Datenmüll
    try {
        $junk = 0L
        foreach ($id in 'usertemp', 'wintemp', 'wudl') { $junk += [long](@(Measure-Cleanup $id)[-1]).Size }
        if ($junk -ge 5GB) { Add-Q 2 ("{0} Datenmüll" -f (Format-Bytes $junk)) 10 'cleanup' }
        elseif ($junk -ge 1GB) { Add-Q 1 ("{0} Datenmüll" -f (Format-Bytes $junk)) 5 'cleanup' }
    } catch {}

    # Lange nicht neu gestartet
    try {
        $boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime
        $days = [int]((Get-Date) - $boot).TotalDays
        if ($days -ge 14) { Add-Q 1 "Seit $days Tagen nicht neu gestartet" 5 '' }
    } catch {}

    # Wiederherstellungspunkt der letzten 30 Tage
    try {
        $last = @(Get-PCORestorePoints | Where-Object { $_.Date } | Sort-Object Date -Descending | Select-Object -First 1)
        if ($last.Count -eq 0 -or ((Get-Date) - $last[0].Date).TotalDays -gt 30) { Add-Q 1 'Kein aktueller Wiederherstellungspunkt' 5 'safety' }
    } catch {}

    $score = [math]::Max(0, 100 - (($items | Measure-Object Penalty -Sum).Sum))
    $rating = if ($score -ge 90) { @{ Text = 'Sehr gut'; Level = 0 } } elseif ($score -ge 75) { @{ Text = 'Gut'; Level = 0 } } elseif ($score -ge 50) { @{ Text = 'Verbesserungswürdig'; Level = 2 } } else { @{ Text = 'Kritisch'; Level = 3 } }
    [pscustomobject]@{ Score = [int]$score; Rating = $rating.Text; Level = $rating.Level; Items = @($items | Sort-Object @{ e = { $_.Penalty }; Descending = $true }); Time = Get-Date }
}
