﻿# ============================================================================
#  TuneRig (portabel) - Startseite und Checks (Regulärer Check, Performance Boost, Overdrive)
#  Wird vom Hauptprogramm geladen. Nutzt dessen Funktionen ($ui, Start-Work ...).
# ============================================================================

# ---------------------------------------------------------------------------
#  Einstellungen speichern (zuletzt gewählte Ansicht)
# ---------------------------------------------------------------------------

function Get-AppSettings {
    try {
        if (Test-Path -LiteralPath $script:SettingsPath) { return (Get-Content -LiteralPath $script:SettingsPath -Raw | ConvertFrom-Json) }
    } catch {}
    return [pscustomobject]@{ SkipWelcome = $false; LastMode = 'wizard'; Theme = 'dark' }
}

function Save-AppSettings([string]$Mode) {
    try {
        New-Item -ItemType Directory -Force -Path (Split-Path $script:SettingsPath) | Out-Null
        [pscustomobject]@{ SkipWelcome = [bool]$ui.ChkSkipWelcome.IsChecked; LastMode = $Mode; Theme = $script:ThemeMode; LastCheck = $script:LastCheck; BackupMode = (Get-BackupMode) } |
            ConvertTo-Json | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    } catch {}
}

# ---------------------------------------------------------------------------
#  Seitenwechsel
# ---------------------------------------------------------------------------
function Show-Page([string]$Name) {
    # Seit 2.0 ist das Dashboard die Startseite (die alte Startseite bleibt unsichtbar im Hintergrund)
    if ($Name -eq 'welcome') { $Name = 'home' }
    $prev = $script:State.Page
    if ($Name -eq 'home' -and $prev -in 'wizard', 'expert' -and (Get-Command Reset-HomeCache -ErrorAction SilentlyContinue)) { Reset-HomeCache }
    $script:State.Page = $Name
    $ui.HomePage.Visibility = if ($Name -eq 'home') { 'Visible' } else { 'Collapsed' }
    $ui.WelcomePage.Visibility = 'Collapsed'
    $ui.WizardPage.Visibility = if ($Name -eq 'wizard') { 'Visible' } else { 'Collapsed' }
    $ui.ExpertPage.Visibility = if ($Name -eq 'expert') { 'Visible' } else { 'Collapsed' }
    $mode = switch ($Name) { 'wizard' { Get-ModeName $script:Wiz.Mode } 'expert' { 'Alle Werkzeuge' } default { 'Startseite' } }
    $ui.ModeLabel.Text = Format-Caps $mode
    $ui.BtnNavHome.Tag = if ($Name -eq 'home') { 'active' } else { $null }
    $ui.BtnNavGuided.Tag = if ($Name -eq 'wizard' -and $script:Wiz.Mode -eq 'normal') { 'active' } else { $null }
    $ui.BtnNavBoost.Tag = if ($Name -eq 'wizard' -and $script:Wiz.Mode -eq 'gaming') { 'active' } else { $null }
    $ui.BtnNavOverdrive.Tag = if ($Name -eq 'wizard' -and $script:Wiz.Mode -eq 'overdrive') { 'active' } else { $null }
    $ui.BtnNavExpert.Tag = if ($Name -eq 'expert') { 'active' } else { $null }
    if ($Name -ne 'home') { Save-AppSettings $Name }
    if ($Name -eq 'home' -and (Get-Command Show-Home -ErrorAction SilentlyContinue)) { Show-Home }
}

# Springt zu einem Bereich - im Assistenten zum Schritt, sonst zum passenden Reiter
function Show-Area([string]$Id) {
    if ($script:State.Page -eq 'wizard' -and $Id -notin 'uninstall', 'junk', 'storage', 'leftovers') {
        $wizId = if ($Id -eq 'gpu') { 'settings' } else { $Id }
        for ($i = 0; $i -lt $script:WizSteps.Count; $i++) { if ($script:WizSteps[$i].Id -eq $wizId) { Show-WizStep $i; return } }
    }
    # Außerhalb der Checks: die Bereichsseiten des Dashboards (Expertenansicht nur, wo es keine gibt)
    if ($script:State.Page -ne 'expert' -and (Get-Command Open-HomeArea -ErrorAction SilentlyContinue) -and (Open-HomeArea $Id)) { return }
    Show-Tool $Id
}

# ---------------------------------------------------------------------------
#  Grundbausteine (Farben und Schriften kommen aus Theme.ps1)
# ---------------------------------------------------------------------------
function New-Thickness([double]$l, [double]$t, [double]$r, [double]$b) { New-Object Windows.Thickness($l, $t, $r, $b) }
function Get-ThemeStyle([string]$Key) { [Windows.Application]::Current.Resources[$Key] }
function Set-Card($Border) { $Border.Style = Get-ThemeStyle 'Card'; return $Border }

# Text in einer Schriftrolle. -Color ist immer ein Farb-Token (ink, ink-muted, success ...).
# Ohne -Role wird die Rolle aus der Größe abgeleitet: >=24 h2, >=19 h3, >=15 fett title, 14 body, sonst small.
function New-Text([string]$Text, [double]$Size = 14, [switch]$Bold, [string]$Color = 'ink', [double]$Top = 0, [string]$Role = '') {
    $t = New-Object Windows.Controls.TextBlock
    $t.Text = $Text; $t.TextWrapping = 'Wrap'
    if (-not $Role) { $Role = if ($Size -ge 24) { 'h2' } elseif ($Size -ge 19) { 'h3' } elseif ($Size -ge 15 -and $Bold) { 'title' } elseif ($Size -ge 14) { 'body' } else { 'small' } }
    Set-TypeRole $t $Role
    if ($Bold -and $Role -in 'body', 'small') { $t.FontWeight = [Windows.FontWeights]::Medium }
    Set-ThemeRef $t Foreground $Color
    $t.Margin = New-Thickness 0 $Top 0 0
    return $t
}

# Button, der beim Klick einen Skriptblock mit Daten ausführt.
# Alle Buttons sind Sekundär-Buttons; der eine Primär-Button pro Ansicht sitzt in der Box »Dein nächster Schritt«.
function New-ActionButton([string]$Label, [scriptblock]$Do, $Data = $null, [switch]$Primary) {
    $b = New-Object Windows.Controls.Button
    $b.Content = $Label
    $b.Tag = @{ Do = $Do; Data = $Data }
    $b.Margin = New-Thickness 0 8 8 0
    $b.Add_Click({
        $t = $this.Tag
        try { & $t.Do $t.Data } catch { Show-Error ($_.Exception.Message) }
    })
    return $b
}

# Macht einen Button zum Primär-Button (Fläche accent, Versalien)
function Set-PrimaryButton($Button) {
    if (-not $Button) { return }
    $Button.Style = Get-ThemeStyle 'Primary'
    $Button.Content = ([string]$Button.Content).ToUpper()
}

# Karte mit Status: Linien-Icon + Label, Titel, Text, optional »Was tun?«, Zusatzinhalt und Buttons
function New-Card {
    param([int]$Level = 1, [string]$Title, [string]$Text = '', [string]$Help = '', [string]$HelpTitle = 'Was tun?',
          $Extra = $null, $Buttons = @(), [switch]$NoBadge)
    $sc = New-StateCard $Level ($Level -ge 1) (New-Thickness 16 16 16 16)
    $border = $sc.Outer
    $border.Margin = New-Thickness 0 0 0 12
    $sp = New-Object Windows.Controls.StackPanel
    if (-not $NoBadge) {
        $hp = New-Object Windows.Controls.StackPanel; $hp.Orientation = 'Horizontal'
        $ic = New-LineIcon $script:LevelIconKind[$Level] $script:LevelToken[$Level] 16; $ic.Margin = New-Thickness 0 0 8 0
        [void]$hp.Children.Add($ic)
        [void]$hp.Children.Add((New-Label $script:LevelWord[$Level] $script:LevelToken[$Level]))
        [void]$sp.Children.Add($hp)
    }
    [void]$sp.Children.Add((New-Text $Title -Role 'title' -Top 8))
    if ($Text) { [void]$sp.Children.Add((New-Text $Text -Role 'small' -Top 4)) }
    if ($Help) {
        $hb = Set-Card (New-Object Windows.Controls.Border)
        Set-ThemeRef $hb Background 'surface-raised'
        $hb.Padding = New-Thickness 12 8 12 8; $hb.Margin = New-Thickness 0 8 0 0
        $hs = New-Object Windows.Controls.StackPanel
        [void]$hs.Children.Add((New-Label $HelpTitle))
        [void]$hs.Children.Add((New-Text $Help -Role 'small' -Top 4))
        $hb.Child = $hs
        [void]$sp.Children.Add($hb)
    }
    if ($Extra) { foreach ($e in @($Extra)) { if ($e) { [void]$sp.Children.Add($e) } } }
    $btns = @($Buttons | Where-Object { $_ })
    if ($btns.Count -gt 0) {
        $wp = New-Object Windows.Controls.WrapPanel
        foreach ($b in $btns) { [void]$wp.Children.Add($b) }
        [void]$sp.Children.Add($wp)
    }
    $sc.Inner.Child = $sp
    return $border
}

function Add-Wiz($element) { if ($element) { [void]$ui.WizContent.Children.Add($element) } }

function New-CheckRow([string]$Text, [bool]$Checked, [string]$Sub = '', [bool]$Enabled = $true) {
    $cb = New-Object Windows.Controls.CheckBox
    $cb.IsChecked = $Checked; $cb.IsEnabled = $Enabled
    $cb.Margin = New-Thickness 0 8 0 0
    $sp = New-Object Windows.Controls.StackPanel
    [void]$sp.Children.Add((New-Text $Text 13 -Bold))
    if ($Sub) { [void]$sp.Children.Add((New-Text $Sub -Role 'small' -Color 'ink-muted')) }
    $cb.Content = $sp
    return $cb
}

# Wandelt die Aktionen eines Prüfergebnisses in Buttons um
function Get-FindingButtons($f) {
    @($f.Actions) | Where-Object { $_ } | ForEach-Object { New-ActionButton $_.L { param($d) Invoke-Target $d } $_.T }
}

function Add-FindingCards($findings, [switch]$CompactOk) {
    $list = @($findings | Where-Object { $_ } | Sort-Object @{ e = { $_.Level }; Descending = $true })
    $ok = @($list | Where-Object { $_.Level -eq 0 })
    foreach ($f in $list) {
        if ($CompactOk -and $f.Level -eq 0) { continue }
        Add-Wiz (New-Card -Level $f.Level -Title $f.Title -Text $f.Detail -Help $f.Help -Buttons (Get-FindingButtons $f))
    }
    if ($CompactOk -and $ok.Count -gt 0) {
        $text = ($ok | ForEach-Object { $_.Title + $(if ($_.Detail) { ' – ' + $_.Detail } else { '' }) }) -join "`n"
        Add-Wiz (New-Card -Level 0 -Title 'Diese Punkte sind in Ordnung' -Text $text)
    }
}

# Führt das Ziel einer Aktion aus (siehe Core.ps1: $script:FindingHelp)
function Invoke-Target([string]$Target) {
    switch -regex ($Target) {
        '^open:(.+)$' { Open-Target $Matches[1]; break }
        '^web:(.+)$' { Open-Target $Matches[1]; break }
        '^search:(.+)$' { Open-Target ('https://www.google.com/search?q=' + [uri]::EscapeDataString($Matches[1])); break }
        '^goto:(.+)$' { Show-Area $Matches[1]; break }
        '^wu$' {
            if ($script:State.Page -eq 'wizard' -and $script:WizSteps[$script:Wiz.Index].Id -eq 'drivers') { Start-WizDriverSearch }
            elseif ($script:State.Page -eq 'home') { Show-HomePage 'drivers'; Start-HomeDriverSearch }
            else { Show-Area 'drivers' }
            break
        }
        '^vendor$' { Open-VendorPages; break }
        '^recheck$' { Invoke-WizRecheck; break }
    }
}

function Open-VendorPages {
    $names = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ' '
    $opened = 0
    if ($names -match 'NVIDIA') { Open-Target 'https://www.nvidia.com/de-de/software/nvidia-app/'; $opened++ }
    if ($names -match 'AMD|Radeon') { Open-Target 'https://www.amd.com/de/support/download/drivers.html'; $opened++ }
    if ($names -match 'Intel') { Open-Target 'https://www.intel.de/content/www/de/de/support/detect.html'; $opened++ }
    if ($opened -eq 0) { Show-Info 'Der Hersteller der Grafikkarte wurde nicht erkannt. Such auf der Webseite deines PC- oder Laptop-Herstellers nach Treibern für dein Modell.' }
}

function Get-VendorButtons([string[]]$GpuNames) {
    $n = $GpuNames -join ' '
    $defs = @(
        @{ Rx = 'NVIDIA'; L = 'NVIDIA App'; U = 'https://www.nvidia.com/de-de/software/nvidia-app/' }
        @{ Rx = 'AMD|Radeon'; L = 'AMD Software: Adrenalin Edition'; U = 'https://www.amd.com/de/support/download/drivers.html' }
        @{ Rx = 'Intel'; L = 'Intel Driver & Support Assistant'; U = 'https://www.intel.de/content/www/de/de/support/detect.html' }
    )
    # Nur die Hersteller der eingebauten Grafikkarten zeigen (alle drei nur, wenn nichts erkannt wurde)
    $relevant = @($defs | Where-Object { $n -match $_.Rx })
    if ($relevant.Count -gt 0) { $defs = $relevant }
    $buttons = @()
    foreach ($d in $defs) {
        $mine = $n -match $d.Rx
        $label = if ($mine) { "$($d.L)  (deine Grafikkarte)" } else { $d.L }
        $buttons += New-ActionButton $label { param($u) Open-Target $u } $d.U -Primary:$mine
    }
    return $buttons
}

# ---------------------------------------------------------------------------
#  Wiederherstellungspunkte anzeigen und löschen
# ---------------------------------------------------------------------------
$script:RpXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Sicherungen verwalten" Width="920" Height="760" MinWidth="700" MinHeight="560"
        WindowStartupLocation="CenterOwner" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <DockPanel Margin="32,24">
    <TextBlock DockPanel.Dock="Top" Style="{StaticResource H3}" Text="Sicherungen"/>
    <DockPanel DockPanel.Dock="Bottom" Margin="0,16,0,0">
      <Button x:Name="RpClose" DockPanel.Dock="Right" Content="Schließen" Margin="0"/>
      <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
        <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Vor Änderungen:" VerticalAlignment="Center" Margin="0,0,8,8"/>
        <ComboBox x:Name="RpMode" Width="300" Margin="0,0,8,8">
          <ComboBoxItem Tag="ask" Content="Jedes Mal fragen"/>
          <ComboBoxItem Tag="always" Content="Immer eine Sicherung anlegen"/>
          <ComboBoxItem Tag="never" Content="Nie eine Sicherung anlegen"/>
        </ComboBox>
      </StackPanel>
    </DockPanel>
    <Border DockPanel.Dock="Bottom" Style="{StaticResource Card}" Margin="0,16,0,0">
      <StackPanel>
        <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Dateisicherungen von TuneRig"/>
        <TextBlock x:Name="FbInfo" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" TextWrapping="Wrap" Margin="0,8,0,8"/>
        <WrapPanel>
          <Button x:Name="FbDelete" Content="Alle Dateisicherungen löschen"/>
          <Button x:Name="FbOpen" Content="Ordner öffnen"/>
        </WrapPanel>
      </StackPanel>
    </Border>
    <Border DockPanel.Dock="Top" Style="{StaticResource Card}" Margin="0,12,0,0">
      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" TextWrapping="Wrap" Text="Ein Wiederherstellungspunkt ist ein Speicherstand von Windows: Damit setzt du den PC auf genau diesen Zeitpunkt zurück. Deine persönlichen Dateien bleiben erhalten. Ein gelöschter Punkt lässt sich nicht zurückholen."/>
    </Border>
    <WrapPanel DockPanel.Dock="Bottom" Margin="0,12,0,0">
      <Button x:Name="RpCreate" Content="Jetzt einen Punkt anlegen"/>
      <Button x:Name="RpDelete" Content="Ausgewählte löschen"/>
      <Button x:Name="RpOurs" Content="Alle von TuneRig auswählen"/>
      <Button x:Name="RpOld" Content="Alle außer dem neuesten auswählen"/>
      <Button x:Name="RpNone" Content="Auswahl aufheben"/>
      <Button x:Name="RpRestore" Content="PC auf einen Punkt zurücksetzen …"/>
    </WrapPanel>
    <TextBlock x:Name="RpInfo" DockPanel.Dock="Bottom" Style="{StaticResource Small}" Margin="0,12,0,0"/>
    <DataGrid x:Name="RpGrid" Margin="0,16,0,0" MinHeight="140">
      <DataGrid.Columns>
        <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
        <DataGridTextColumn Header="Erstellt am" Binding="{Binding A}" Width="150" IsReadOnly="True"/>
        <DataGridTextColumn Header="Beschreibung" Binding="{Binding B}" Width="*" IsReadOnly="True"/>
        <DataGridTextColumn Header="Anlass" Binding="{Binding C}" Width="160" IsReadOnly="True"/>
        <DataGridTextColumn Header="Erstellt von" Binding="{Binding D}" Width="160" IsReadOnly="True"/>
      </DataGrid.Columns>
    </DataGrid>
  </DockPanel>
</Window>
'@

function Update-RestorePointList {
    $d = $script:RpDlg
    $points = @(Get-PCORestorePoints | Where-Object { $_ })
    $rows = $points | ForEach-Object {
        New-Row -A $_.DateText -B $_.Description -C $_.Type -D $(if ($_.ByUs) { 'TuneRig' } else { 'Windows / Programme' }) -Tag $_
    }
    Set-Items ($d.FindName('RpGrid')) $rows
    $d.FindName('RpInfo').Text = if ($points.Count -eq 0) {
        'Keine Wiederherstellungspunkte vorhanden – oder der Computerschutz ist aus. TuneRig schaltet ihn ein, sobald es einen Punkt anlegt.'
    } else { "$($points.Count) Wiederherstellungspunkt(e) vorhanden. Der neueste steht oben." }
}

# ---------------------------------------------------------------------------
#  Sicherungen: vorher fragen, Einstellung merken, Dateisicherungen verwalten
# ---------------------------------------------------------------------------
function Get-BackupMode {
    if (-not $script:BackupMode) {
        $s = Get-AppSettings
        $script:BackupMode = if ($s.PSObject.Properties['BackupMode'] -and $s.BackupMode -in 'ask', 'always', 'never') { [string]$s.BackupMode } else { 'ask' }
    }
    return $script:BackupMode
}
function Set-BackupMode([string]$Mode) {
    $script:BackupMode = $Mode
    Save-AppSettings $(if ($script:State.Page -notin 'welcome', 'home') { $script:State.Page } else { (Get-AppSettings).LastMode })
}

function Get-FileBackupInfo {
    $files = @(Get-ChildItem -LiteralPath $script:BackupRoot -File -Recurse -Force -ErrorAction SilentlyContinue)
    $dirs = @(Get-ChildItem -LiteralPath $script:BackupRoot -Directory -Force -ErrorAction SilentlyContinue)
    [pscustomobject]@{ Count = $dirs.Count; Files = $files.Count; Size = [long]($files | Measure-Object Length -Sum).Sum }
}

$script:BackupAskXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Sicherung anlegen?" Width="560" SizeToContent="Height" ResizeMode="NoResize"
        WindowStartupLocation="CenterOwner" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <StackPanel Margin="32,24">
    <TextBlock Style="{StaticResource H3}" Text="Vorher eine Sicherung anlegen?"/>
    <TextBlock x:Name="BaWhat" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" TextWrapping="Wrap" Margin="0,12,0,0"/>
    <TextBlock Style="{StaticResource Small}" TextWrapping="Wrap" Margin="0,12,0,0"
               Text="Mit Sicherung legt TuneRig einen Wiederherstellungspunkt an (etwa 1 Minute) und sichert gelöschte Registry-Einträge als Datei. Damit lässt sich die Änderung rückgängig machen. Ohne Sicherung geht das nicht. Gelöschte Dateien landen in beiden Fällen im Papierkorb, soweit er sie aufnehmen kann."/>
    <CheckBox x:Name="BaRemember" Margin="0,16,0,0" Content="Meine Wahl merken (änderbar unter »Sicherungen verwalten«)"/>
    <WrapPanel Margin="0,24,0,0">
      <Button x:Name="BaYes" Style="{StaticResource Primary}" Content="MIT SICHERUNG FORTFAHREN"/>
      <Button x:Name="BaNo" Content="Ohne Sicherung fortfahren"/>
      <Button x:Name="BaCancel" Content="Abbrechen"/>
    </WrapPanel>
  </StackPanel>
</Window>
'@

# Fragt, ob vor einer Änderung gesichert werden soll. Rückgabe: 'always' (mit Sicherung), 'never' (ohne) oder $null (abgebrochen)
function Show-BackupChoice([string]$Description) {
    $script:BaDlg = [Windows.Markup.XamlReader]::Parse($script:BackupAskXaml)
    $d = $script:BaDlg
    $d.Owner = $window
    Set-WindowBranding $d
    Set-CapsLabels $d
    $d.FindName('BaWhat').Text = "Anstehende Änderung: $Description"
    $script:BaResult = $null
    $d.FindName('BaYes').Add_Click({ $script:BaResult = 'always'; $script:BaDlg.Close() })
    $d.FindName('BaNo').Add_Click({ $script:BaResult = 'never'; $script:BaDlg.Close() })
    $d.FindName('BaCancel').Add_Click({ $script:BaDlg.Close() })
    [void]$d.ShowDialog()
    if ($script:BaResult -and $d.FindName('BaRemember').IsChecked) { Set-BackupMode $script:BaResult }
    return $script:BaResult
}

function Update-FileBackupInfo {
    $i = Get-FileBackupInfo
    $script:RpDlg.FindName('FbInfo').Text = if ($i.Files -eq 0) { 'Keine Dateisicherungen vorhanden.' } else {
        "$($i.Count) Sicherung(en) mit $($i.Files) Datei(en), zusammen $(Format-Bytes $i.Size). Das sind gelöschte Registry-Einträge (.reg) und geplante Aufgaben (.xml) aus dem Entfernen von Resten. Ein Doppelklick auf eine .reg-Datei stellt den Eintrag wieder her." }
    $script:RpDlg.FindName('FbDelete').IsEnabled = $i.Files -gt 0
}

function Show-RestorePointManager {
    $script:RpDlg = [Windows.Markup.XamlReader]::Parse($script:RpXaml)
    $script:RpDlg.Owner = $window
    Set-WindowBranding $script:RpDlg
    Set-CapsLabels $script:RpDlg
    Update-RestorePointList
    Update-FileBackupInfo

    $combo = $script:RpDlg.FindName('RpMode')
    $mode = Get-BackupMode
    foreach ($ci in $combo.Items) { if ($ci.Tag -eq $mode) { $combo.SelectedItem = $ci } }
    $combo.Add_SelectionChanged({ $m = [string]$script:RpDlg.FindName('RpMode').SelectedItem.Tag; if ($m) { Set-BackupMode $m } })
    $script:RpDlg.FindName('FbOpen').Add_Click({
        New-Item -ItemType Directory -Force -Path $script:BackupRoot | Out-Null
        try { Start-Process explorer.exe -ArgumentList "`"$script:BackupRoot`"" } catch {}
    })
    $script:RpDlg.FindName('FbDelete').Add_Click({
        $i = Get-FileBackupInfo
        $answer = [Windows.MessageBox]::Show($script:RpDlg, "Alle $($i.Files) Dateisicherungen ($(Format-Bytes $i.Size)) werden endgültig gelöscht.`n`nDanach lassen sich bereits entfernte Registry-Einträge und Aufgaben nicht mehr per Doppelklick zurückholen. Wiederherstellungspunkte sind davon nicht betroffen.`n`nFortfahren?", 'Dateisicherungen löschen', 'YesNo', 'Warning')
        if ($answer -ne 'Yes') { return }
        $fail = 0
        foreach ($x in @(Get-ChildItem -LiteralPath $script:BackupRoot -Force -ErrorAction SilentlyContinue)) {
            try { Remove-Item -LiteralPath $x.FullName -Recurse -Force -ErrorAction Stop } catch { $fail++ }
        }
        Update-FileBackupInfo
        Add-WizLog 'Dateisicherungen gelöscht'
        [void][Windows.MessageBox]::Show($script:RpDlg, $(if ($fail) { "Erledigt. $fail Element(e) konnten nicht gelöscht werden." } else { 'Alle Dateisicherungen wurden gelöscht.' }), 'Dateisicherungen', 'OK', 'Information')
    })
    $script:RpDlg.FindName('RpCreate').Add_Click({
        if ($script:Job) { [void][Windows.MessageBox]::Show($script:RpDlg, 'Bitte warten, bis der aktuelle Vorgang fertig ist.', 'Sicherungen', 'OK', 'Information'); return }
        $script:RpDlg.FindName('RpInfo').Text = 'Erstelle Wiederherstellungspunkt ... (bis zu einer Minute)'
        Start-Work -Status 'Erstelle Wiederherstellungspunkt ...' -Script { New-PCORestorePoint 'Manuell' } -OnDone {
            param($r) $res = @($r)[-1]
            if ($res.Ok) { $script:State.LastRestore = Get-Date; Add-WizLog 'Wiederherstellungspunkt erstellt' }
            Set-Status $res.Message
            if ($script:RpDlg -and $script:RpDlg.IsVisible) { Update-RestorePointList; if (-not $res.Ok) { $script:RpDlg.FindName('RpInfo').Text = $res.Message } }
        }
    })
    $script:RpDlg.FindName('RpOurs').Add_Click({ foreach ($r in @(Get-Rows ($script:RpDlg.FindName('RpGrid')))) { $r.IsSelected = [bool]$r.Tag.ByUs } })

    $script:RpDlg.FindName('RpClose').Add_Click({ $script:RpDlg.Close() })
    $script:RpDlg.FindName('RpRestore').Add_Click({ Open-Target 'rstrui.exe' })
    $script:RpDlg.FindName('RpNone').Add_Click({ foreach ($r in @(Get-Rows ($script:RpDlg.FindName('RpGrid')))) { $r.IsSelected = $false } })
    $script:RpDlg.FindName('RpOld').Add_Click({
        $rows = @(Get-Rows ($script:RpDlg.FindName('RpGrid')))
        for ($i = 0; $i -lt $rows.Count; $i++) { $rows[$i].IsSelected = $i -gt 0 }
    })
    $script:RpDlg.FindName('RpDelete').Add_Click({
        $rows = @(Get-Rows ($script:RpDlg.FindName('RpGrid')))
        $sel = @($rows | Where-Object { $_.IsSelected })
        if ($sel.Count -eq 0) { [void][Windows.MessageBox]::Show($script:RpDlg, 'Setz bei den Punkten, die gelöscht werden sollen, einen Haken.', 'Wiederherstellungspunkte', 'OK', 'Information'); return }
        $list = ($sel | ForEach-Object { "- $($_.A)   $($_.B)" }) -join "`n"
        $warn = if ($sel.Count -eq $rows.Count) { "`n`nAchtung: Danach gibt es keinen Punkt mehr, zu dem du zurückkehren kannst." } else { '' }
        $answer = [Windows.MessageBox]::Show($script:RpDlg, "Diese Wiederherstellungspunkte werden endgültig gelöscht:`n`n$list$warn`n`nFortfahren?", 'Wiederherstellungspunkte löschen', 'YesNo', 'Warning')
        if ($answer -ne 'Yes') { return }
        $res = Remove-PCORestorePoints @($sel | ForEach-Object { [int]$_.Tag.Sequence })
        # Wurde der Punkt dieser Sitzung gelöscht, vor der nächsten Änderung einen neuen anlegen
        if ($script:State.LastRestore -and ($sel | Where-Object { $_.Tag.ByUs -and $_.Tag.Date -and $_.Tag.Date -ge $script:State.LastRestore.AddMinutes(-2) })) { $script:State.LastRestore = $null }
        if ($res.Ok -gt 0) { Add-WizLog "$($res.Ok) Wiederherstellungspunkt(e) gelöscht" }
        Update-RestorePointList
        $msg = "$($res.Ok) Punkt(e) gelöscht."
        if ($res.Failed -gt 0) { $msg += " $($res.Failed) konnte(n) nicht gelöscht werden." }
        [void][Windows.MessageBox]::Show($script:RpDlg, $msg, 'Wiederherstellungspunkte', 'OK', 'Information')
    })
    [void]$script:RpDlg.ShowDialog()
    if ($script:State.Page -eq 'wizard' -and $script:WizSteps[$script:Wiz.Index].Id -eq 'safety') { Show-WizStep $script:Wiz.Index }
}

# ---------------------------------------------------------------------------
#  Ablauf der Checks (Modus normal = Regulärer Check, gaming = Performance Boost, overdrive = Overdrive)
# ---------------------------------------------------------------------------
function Get-ModeName([string]$Mode) { switch ($Mode) { 'gaming' { 'Performance Boost' } 'overdrive' { 'Overdrive' } default { 'Regulärer Check' } } }
$script:Wiz = @{ Index = 0; Visited = @{}; Data = @{}; Log = (New-Object System.Collections.ArrayList); NeedsRestart = $false; Checks = @(); Baseline = @{}; Changes = (New-Object System.Collections.ArrayList); Mode = 'normal' }

$script:StepsNormal = @(
    @{ Id = 'welcome'; Name = 'Willkommen'; Analyze = $false
       Title = 'Willkommen'; Sub = 'In 5 kurzen Schritten prüft TuneRig deinen PC – und verbessert ihn, wenn du willst.'
       Intro = '' }
    @{ Id = 'safety'; Name = 'Windows-Sicherung'; Analyze = $false
       Title = 'Windows-Sicherung'; Sub = 'Erst absichern, dann verbessern.'
       Intro = 'Ein Wiederherstellungspunkt ist wie ein Speicherstand in einem Spiel: Funktioniert nach einer Änderung etwas nicht wie gewünscht, setzt Windows damit alles auf den heutigen Zustand zurück. Deine persönlichen Dateien bleiben dabei immer erhalten.' }
    @{ Id = 'system'; Name = 'Dein PC'; Analyze = $true
       Title = 'Dein PC'; Sub = 'Welche Hardware steckt in deinem PC – und bremst etwas davon?'
       Intro = 'TuneRig liest Prozessor, Arbeitsspeicher, Grafikkarte, Laufwerke und Windows-Version aus und prüft, ob genug Speicherplatz frei ist. Dabei wird nichts verändert.' }
    @{ Id = 'drivers'; Name = 'Treiber'; Analyze = $true
       Title = 'Treiber'; Sub = 'Sind alle Geräte richtig eingerichtet?'
       Intro = 'Treiber sind kleine Programme, mit denen Windows deine Hardware steuert – z. B. Grafikkarte, WLAN oder Sound. Fehlt ein Treiber, funktioniert das Gerät nicht richtig. Bei Grafikkarten gehört außerdem die Software des Herstellers dazu: Sie hält den Treiber aktuell.' }
    @{ Id = 'settings'; Name = 'Leistung'; Analyze = $true
       Title = 'Leistung'; Sub = 'Ist Windows auf Leistung eingestellt – und nutzen deine Spiele die starke Grafikkarte?'
       Intro = 'Windows ist ab Werk oft auf Stromsparen eingestellt. Dann drosselt sich zum Beispiel der Prozessor oder Geräte werden zeitweise abgeschaltet. Das kostet Leistung und kann zu Rucklern führen. Viele PCs haben außerdem zwei Grafikkarten: eine stromsparende im Prozessor (integriert) und eine leistungsstarke (dediziert). Für Spiele sollte immer die starke Karte arbeiten - Windows entscheidet das pro Spiel, leider nicht immer richtig.' }
    @{ Id = 'cleanup'; Name = 'Aufräumen'; Analyze = $true
       Title = 'Aufräumen'; Sub = 'Unnötige Dateien entfernen und Platz schaffen.'
       Intro = 'Windows und Programme legen ständig Zwischendateien an: Reste von Installationen, alte Update-Pakete, Fehlerberichte oder Browser-Zwischenspeicher. Diese Dateien braucht niemand mehr. Deine persönlichen Dateien sind nie betroffen.' }
    @{ Id = 'summary'; Name = 'Zusammenfassung'; Analyze = $false
       Title = 'Zusammenfassung'; Sub = 'Das wurde erledigt - und das ist noch offen.'
       Intro = '' }
)
$script:WizSteps = $script:StepsNormal

function Add-WizLog([string]$Text) { [void]$script:Wiz.Log.Add(('{0:HH:mm} Uhr  -  {1}' -f (Get-Date), $Text)) }

function Reset-Wizard([string]$Mode = 'normal') {
    $script:Wiz.Mode = $Mode
    $script:WizSteps = switch ($Mode) { 'gaming' { $script:StepsGaming } 'overdrive' { $script:StepsOverdrive } default { $script:StepsNormal } }
    $ui.WizSideTitle.Text = Format-Caps (Get-ModeName $Mode)
    $script:Wiz.OdAck = $false
    if (-not $script:Wiz.OdLevel) { $script:Wiz.OdLevel = 1 }
    $script:Wiz.Index = 0; $script:Wiz.Visited = @{}; $script:Wiz.Data = @{}; $script:Wiz.NeedsRestart = $false
    $script:Wiz.Log.Clear(); $script:Wiz.Changes.Clear(); $script:Wiz.SoftwareSkipped = $false
    $script:Wiz.Baseline = @{ Free = (Get-FreeSystemBytes) }
}

function Update-WizSidebar {
    $ui.WizSidebar.Children.Clear()
    $ui.WizProgressSegments.Children.Clear()
    $last = $script:WizSteps.Count - 1
    for ($k = 0; $k -lt $script:WizSteps.Count; $k++) {
        $step = $script:WizSteps[$k]
        $isCurrent = $k -eq $script:Wiz.Index
        $visited = [bool]$script:Wiz.Visited[$k]
        $b = New-Object Windows.Controls.Button
        $b.Style = Get-ThemeStyle 'NavItem'
        $b.Tag = if ($isCurrent) { 'current' } elseif ($visited) { 'done' } else { $null }
        $row = New-Object Windows.Controls.DockPanel
        $icon = if ($isCurrent) { New-LineIcon 'chevron' 'accent' 16 } elseif ($visited) { New-LineIcon 'check' 'success' 16 } else { New-LineIcon 'dot' 'line' 16 }
        $icon.Margin = New-Thickness 0 0 12 0
        [Windows.Controls.DockPanel]::SetDock($icon, 'Left'); [void]$row.Children.Add($icon)
        $t = New-Object Windows.Controls.TextBlock; $t.Text = $step.Name; $t.VerticalAlignment = 'Center'
        [void]$row.Children.Add($t)
        $b.Content = $row
        [Windows.Automation.AutomationProperties]::SetName($b, $step.Name + $(if ($isCurrent) { ' (aktueller Schritt)' } elseif ($visited) { ' (erledigt)' } else { '' }))
        $b.IsEnabled = $visited -or $isCurrent
        $b.Add_Click({ $t = [int]$this.CommandParameter; if ($t -ne $script:Wiz.Index) { Request-WizLeave $t 'zum gewählten Schritt wechseln' } })
        $b.CommandParameter = $k
        [void]$ui.WizSidebar.Children.Add($b)
        # Segmentierte Fortschrittsanzeige (ohne Willkommen und Zusammenfassung)
        if ($k -gt 0 -and $k -lt $last) {
            $seg = New-Object Windows.Controls.Border
            $seg.Height = 6; $seg.Width = [Math]::Floor(220 / [Math]::Max(1, $last - 1)) - 4; $seg.Margin = New-Thickness 0 0 4 0
            $seg.CornerRadius = New-Object Windows.CornerRadius(1)
            Set-ThemeRef $seg Background $(if ($k -le $script:Wiz.Index) { 'accent' } else { 'line' })
            [void]$ui.WizProgressSegments.Children.Add($seg)
        }
    }
    $ui.WizProgressText.Text = if ($script:Wiz.Index -eq 0) { 'Bereit zum Start' } elseif ($script:Wiz.Index -eq $last) { 'Alle Schritte durchlaufen' } else { "Schritt $($script:Wiz.Index) von $($last - 1)" }
}

function Show-WizStep([int]$Index) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    if ($script:State.Page -ne 'wizard') { Show-Page 'wizard' }
    if ($script:Wiz.Index -ne $Index) { $script:Wiz.CleanupDone = $false; $script:Wiz.UpdateChecks = @() }
    $script:Wiz.Index = $Index
    $script:Wiz.Visited[$Index] = $true
    if (-not $script:Wiz.Baseline.ContainsKey('Free')) { $script:Wiz.Baseline['Free'] = Get-FreeSystemBytes }
    $step = $script:WizSteps[$Index]
    $modeName = Get-ModeName $script:Wiz.Mode
    $ui.WizStepNo.Text = Format-Caps $(if ($Index -eq 0) { $modeName } elseif ($Index -eq $script:WizSteps.Count - 1) { 'Geschafft' } else { "Schritt $Index von $($script:WizSteps.Count - 2)" })
    $ui.WizTitle.Text = $step.Title
    $ui.WizSub.Text = $step.Sub
    $ui.WizIntro.Text = $step.Intro
    $ui.WizIntroExp.IsExpanded = $false
    $ui.WizIntroExp.Visibility = if ($step.Intro) { 'Visible' } else { 'Collapsed' }
    $ui.WizNavHint.Text = ''
    $ui.WizBack.IsEnabled = $Index -gt 0
    $ui.WizNext.Content = if ($Index -eq $script:WizSteps.Count - 1) { 'Fertig' } elseif ($Index -eq 0) { 'Check starten  ›' } else { 'Weiter  ›' }
    $ui.WizRecheck.Visibility = if ($step.Analyze) { 'Visible' } else { 'Collapsed' }
    Update-WizSidebar
    $ui.WizContent.Children.Clear()
    $script:Wiz.Checks = @()
    $ui.WizScroll.ScrollToTop()

    switch ($step.Id) {
        'welcome' { Show-WizWelcome }
        'safety' { Show-WizSafety }
        'system' { if ($script:Wiz.Data.ContainsKey('system')) { Show-WizSystem } else { Start-WizLoad 'system' } }
        'drivers' {
            if (-not $script:Wiz.Data.ContainsKey('gpusw')) { Start-WizLoad 'gpusw' }
            elseif (Test-SoftwareGate) { Show-WizSoftwareGate }
            elseif ($script:Wiz.Data.ContainsKey('drivers')) { Show-WizDrivers } else { Start-WizLoad 'drivers' }
        }
        'settings' { if ($script:Wiz.Data.ContainsKey('settings') -and $script:Wiz.Data.ContainsKey('gpu')) { Show-WizSettings } else { Start-WizLoad 'settings' } }
        'cleanup' { if ($script:Wiz.Data.ContainsKey('cleanup')) { Show-WizCleanup } else { Start-WizLoad 'cleanup' } }
        'summary' { Show-WizSummary }
        'g-welcome' { Show-WizGamingWelcome }
        'o-welcome' { Show-WizOverdriveWelcome }
        default { if ($script:Wiz.Data.ContainsKey($step.Id)) { Show-WizStepContent $step.Id } else { Start-WizLoad $step.Id } }
    }
    Update-WizNavHint
}

function Show-WizStepContent([string]$Id) {
    switch ($Id) {
        'g-display' { Show-WizGamingDisplay }
        'g-system' { Show-WizGamingSystem }
        'g-startup' { Show-WizGamingStartup }
        'g-network' { Show-WizGamingNetwork }
        'o-tune' { Show-WizOverdrive }
    }
}

function Invoke-WizRecheck {
    $id = $script:WizSteps[$script:Wiz.Index].Id
    [void]$script:Wiz.Data.Remove($id)
    if ($id -eq 'drivers') { [void]$script:Wiz.Data.Remove('driverSearch'); [void]$script:Wiz.Data.Remove('driverUpdates'); [void]$script:Wiz.Data.Remove('gpusw') }
    if ($id -eq 'settings') { [void]$script:Wiz.Data.Remove('gpu') }
    Show-WizStep $script:Wiz.Index
}

# Startet die Prüfung eines Schritts im Hintergrund und zeigt danach das Ergebnis
$script:WizLoaders = @{
    system   = @{ Text = 'Lese Hardware-Informationen ...'; Script = { Get-SystemAnalysis } }
    gpusw    = @{ Text = 'Prüfe zuerst, ob die Software deines Grafikkarten-Herstellers installiert ist …'; Script = { [pscustomobject]@{ Items = @(try { Get-GpuSoftwareCheck } catch { }) } } }
    drivers  = @{ Text = 'Prüfe Geräte und Treiber ... (dauert etwa 20 bis 60 Sekunden)'
                  Script = {
                      $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue; $bb = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue
                      $oem = "$($cs.Manufacturer) $($cs.Model)".Trim()
                      $sup = if ($oem -and $oem -notmatch 'System manufacturer|System Product|To Be Filled|Default string|O\.E\.M') { $oem } else { "$($bb.Manufacturer) $($bb.Product)".Trim() }
                      [pscustomobject]@{ Drv = (Get-DriverAnalysis); Gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }); Support = $sup } } }
    settings = @{ Text = 'Prüfe Energie- und Windows-Einstellungen, Grafikkarten und Spiele ...'
                  Script = {
                      $l = Test-IsLaptop
                      $tw = @(Get-Tweaks $l)
                      Report 'Prüfe Grafikkarten und suche installierte Spiele ...'
                      [pscustomobject]@{ Tweaks = $tw; Laptop = $l; GpuData = [pscustomobject]@{ Gpu = (Get-GpuAnalysis $l); Games = @(Find-Games); Laptop = $l } } } }
    cleanup  = @{ Text = 'Berechne, wie viel Speicherplatz frei werden kann ...'
                  Script = { [pscustomobject]@{ Measures = @(foreach ($d in Get-CleanupDefs) { if ($d.Id -ne 'winsxs') { Report "Prüfe: $($d.Name) ..."; Measure-Cleanup $d.Id } }) } } }
}

# ---------------------------------------------------------------------------
#  PERFORMANCE BOOST (intern: gaming): eigene Schrittfolge (nutzt Windows-Sicherung, Treiber und Leistung mit)
# ---------------------------------------------------------------------------
function Get-StepDef([string]$Id) { $script:StepsNormal | Where-Object { $_.Id -eq $Id } | Select-Object -First 1 }

$script:StepsGaming = @(
    @{ Id = 'g-welcome'; Name = 'Willkommen'; Analyze = $false
       Title = 'Performance Boost'; Sub = 'Holt deutlich mehr Leistung aus deinem PC heraus – für Spiele und Online-Gaming.'; Intro = '' }
    (Get-StepDef 'safety')
    (Get-StepDef 'drivers')
    (Get-StepDef 'settings')
    @{ Id = 'g-display'; Name = 'Bild & Steuerung'; Analyze = $true
       Title = 'Bild & Steuerung'; Sub = 'Zeigt dein Monitor alle Bilder, die die Grafikkarte liefert?'
       Intro = 'Viele Gaming-Monitore laufen ungewollt mit 60 Hz, obwohl sie 144 Hz oder mehr können - dann sieht man nur einen Teil der Bilder. Außerdem geht es um die Mausbeschleunigung, die präzises Zielen erschwert.' }
    @{ Id = 'g-system'; Name = 'Prozessor & System'; Analyze = $true
       Title = 'Prozessor & System'; Sub = 'Feinschliff an Prozessor, SSD und Windows.'
       Intro = 'Hier geht es um Einstellungen, die Windows für Stromsparen oder Sicherheit trifft und die in Spielen Leistung kosten können. Empfohlene Punkte sind unbedenklich. Optionale Punkte haben Nebenwirkungen und sind nur für Erfahrene gedacht.' }
    @{ Id = 'g-startup'; Name = 'Autostart'; Analyze = $true
       Title = 'Autostart'; Sub = 'Welche Programme starten unnötig mit Windows?'
       Intro = 'Jedes Programm, das mit Windows startet, läuft auch beim Spielen im Hintergrund und kostet Arbeitsspeicher und Rechenzeit. Abgeschaltete Programme lassen sich jederzeit von Hand starten - und hier mit einem Klick wieder einschalten.' }
    @{ Id = 'g-network'; Name = 'Internet & Ping'; Analyze = $true
       Title = 'Internet & Ping'; Sub = 'Wie stabil ist deine Verbindung – und was lässt sich verbessern?'
       Intro = 'Der Ping zum Spielserver hängt vor allem von der Entfernung und dem Internetanbieter ab - das kann kein Programm ändern. Was sich verbessern lässt: Aussetzer und Ping-Spitzen durch Energiesparfunktionen, Upload-Verbrauch durch Windows und falsche Einstellungen alter Tuning-Programme.' }
    (Get-StepDef 'summary')
)

$script:GamingStepDesc = @{
    safety = 'einen Speicherstand für Windows anlegen'; drivers = 'Treiber und Grafik-Software prüfen'; settings = 'Energie, Windows-Grundeinstellungen und Grafikkarte'
    'g-display' = 'Bildwiederholrate und Maus'; 'g-system' = 'Prozessor, SSD und Windows-Feinheiten'
    'g-startup' = 'unnötige Autostart-Programme abschalten'; 'g-network' = 'Ping messen, Netzwerk optimieren, DNS testen'
}

$script:WizLoaders['g-display'] = @{ Text = 'Prüfe Bildschirme und Maus ...'
    Script = { $l = Test-IsLaptop; [pscustomobject]@{ Tweaks = @(Get-GamingTweaks 'display' $l); Displays = @(Get-DisplayInfo) } } }
$script:WizLoaders['g-system'] = @{ Text = 'Prüfe Prozessor- und Systemeinstellungen ... (bis zu 30 Sekunden)'
    Script = { $l = Test-IsLaptop; [pscustomobject]@{ Tweaks = @(Get-GamingTweaks 'system' $l); Laptop = $l } } }
$script:WizLoaders['g-startup'] = @{ Text = 'Lese die Autostart-Programme ...'
    Script = { [pscustomobject]@{ Items = @(Get-StartupItems) } } }
$script:WizLoaders['g-network'] = @{ Text = 'Prüfe Internetverbindung, Ping und DNS ... (etwa 30 Sekunden)'
    Script = { $l = Test-IsLaptop; [pscustomobject]@{ Tweaks = @(Get-GamingTweaks 'network' $l); Net = (Get-NetworkStatus) } } }

# --------------------------- Darstellung ---------------------------
$script:ModeLabel = @{ recommended = 'Empfohlen'; optional = 'Optional (mit Nebenwirkung)'; experimental = 'Experimentell' }

function New-GamingRow($t) {
    if ($t.Optimal) {
        $before = Get-TweakBefore $t
        $btn = if ($before -and $t.CanRevert) { New-ActionButton 'Zurücksetzen' { param($id) $script:State.WizAfter = $null; Invoke-WizGamingTweaks @($id) -Revert } $t.Id }
        return New-ItemRow -Level 0 -Compact -Title $t.Title -Now $t.State -NowLabel 'Jetzt:' -Before $before -Buttons @($btn)
    }
    $btn = New-ActionButton $t.Fix {
        param($id)
        $t = @($script:Wiz.Data[$script:WizSteps[$script:Wiz.Index].Id].Tweaks | Where-Object { $_.Id -eq $id })[0]
        if ($t.Mode -ne 'recommended' -and -not (Confirm-Action ("{0}`n`nNebenwirkung: {1}`n`nTrotzdem anwenden? Du kannst es hier jederzeit zurücksetzen." -f $t.Title, $t.Risk))) { return }
        $script:State.WizAfter = $null
        Invoke-WizGamingTweaks @($id)
    } $t.Id -Primary:($t.Mode -eq 'recommended')
    $benefit = $t.Benefit + $(if ($t.Restart) { ' (wirkt nach einem Neustart)' } else { '' })
    $lvl = if ($t.Mode -eq 'recommended') { 2 } else { 1 }
    New-ItemRow -Level $lvl -Title $t.Title -Now $t.State -Target $t.Target -Benefit $benefit -Impact $t.Impact -Risk $t.Risk -More $t.Desc -Buttons @($btn)
}

function Add-GamingBanner($tw, [string]$OkHeadline = 'Alle empfohlenen Optimierungen sind aktiv') {
    $rec = @($tw | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal })
    $more = @($tw | Where-Object { $_.Mode -ne 'recommended' -and -not $_.Optimal })
    if ($rec.Count -gt 0) {
        $label = if ($rec.Count -eq 1) { $rec[0].Fix } else { "Jetzt alle $($rec.Count) anwenden" }
        $top = ($rec | Sort-Object Impact -Descending | Select-Object -First 1)
        Add-NextStep -Level 2 -Headline $(if ($rec.Count -eq 1) { '1 Optimierung empfohlen' } else { "$($rec.Count) Optimierungen empfohlen" }) `
            -Text ("Größter Gewinn: $($top.Title) - $($top.Benefit)`nAlles lässt sich hier wieder zurücksetzen.") `
            -Primary (New-ActionButton $label {
                $ids = @($script:Wiz.Data[$script:WizSteps[$script:Wiz.Index].Id].Tweaks | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal } | ForEach-Object { $_.Id })
                $script:State.WizAfter = $null
                Invoke-WizGamingTweaks $ids
            } -Primary) -Secondary (New-SkipButton)
        return $true
    }
    $txt = if ($more.Count -gt 0) { "Unten gibt es $($more.Count) weitere Optimierung(en) für noch mehr Leistung – mit Nebenwirkungen. Sie sind nur für Erfahrene gedacht und nicht nötig." } else { 'Hier ist nichts mehr zu tun.' }
    Add-NextStep -Level 0 -Headline $OkHeadline -Text $txt -Primary (New-NextButton)
    return $false
}

function Add-GamingRows($tw) {
    $rec = @($tw | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal } | Sort-Object Impact -Descending)
    $opt = @($tw | Where-Object { $_.Mode -eq 'optional' -and -not $_.Optimal } | Sort-Object Impact -Descending)
    $exp = @($tw | Where-Object { $_.Mode -eq 'experimental' -and -not $_.Optimal })
    $changed = @($tw | Where-Object { $_.Optimal -and (Get-TweakBefore $_) })
    $same = @($tw | Where-Object { $_.Optimal -and -not (Get-TweakBefore $_) })

    if ($rec.Count) { Add-Section "Empfohlen ($($rec.Count))"; foreach ($t in $rec) { Add-Wiz (New-GamingRow $t) } }
    if ($changed.Count) { Add-Section 'In diesem Check optimiert'; foreach ($t in $changed) { Add-Wiz (New-GamingRow $t) } }
    if ($opt.Count) {
        Add-Section "Für noch mehr Leistung - mit Nebenwirkungen ($($opt.Count))"
        Add-Wiz (New-Text 'Nur anwenden, wenn du die Nebenwirkung in Kauf nimmst. Jeder Punkt lässt sich hier wieder zurücksetzen.' -Role 'small' -Color 'ink-muted')
        foreach ($t in $opt) { $r = New-GamingRow $t; $r.Margin = New-Thickness 0 8 0 0; Add-Wiz $r }
    }
    if ($exp.Count) {
        $sp = New-Object Windows.Controls.StackPanel
        [void]$sp.Children.Add((New-Text 'Diese Tweaks sind in Gaming-Foren beliebt, ihre Wirkung ist aber nicht belegt. Ausprobieren auf eigene Verantwortung – jederzeit zurücksetzbar.' -Role 'small' -Color 'ink-muted'))
        foreach ($t in $exp) { $r = New-GamingRow $t; $r.Margin = New-Thickness 0 8 0 0; [void]$sp.Children.Add($r) }
        Add-Wiz (New-ExpanderBox "Experimentell - Wirkung umstritten ($($exp.Count))" $sp)
    }
    Add-OkExpander "Bereits optimal ($($same.Count))" ($same | ForEach-Object { "$($_.Title):  $($_.State)" })
}

function Show-WizGamingWelcome {
    Add-NextStep -Level 1 -Headline 'Starte den Performance Boost' `
        -Text 'Dauer: 10–15 Minuten. Der Performance Boost geht tiefer als der Reguläre Check und holt das Maximum heraus – nur mit bewährten Einstellungen. Was zu tun ist, steht immer genau hier.' `
        -Primary (New-ActionButton 'Jetzt starten' { Invoke-WizNext })
    Add-Section 'So läuft es ab'
    $n = 0
    foreach ($s in $script:WizSteps) {
        if ($s.Id -in 'g-welcome', 'summary') { continue }
        $n++
        Add-Wiz (New-NumberRow ([string]$n) $s.Name $script:GamingStepDesc[$s.Id])
    }
    Add-Section 'Was ist anders als beim Regulären Check?'
    foreach ($l in @(
            'Jede Optimierung zeigt ihre Wirkung in drei Stufen (leicht, spürbar, deutlich) und mögliche Nebenwirkungen.',
            'Empfohlene Optimierungen sind unbedenklich. Optionale und experimentelle werden nie automatisch angewendet.',
            'Fast alles lässt sich hier mit »Zurücksetzen« rückgängig machen – zusätzlich gibt es den Wiederherstellungspunkt.',
            'Am Ende siehst du Vorher – Nachher, auch für Ping und Bildwiederholrate.')) {
        Add-Wiz (New-ColoredLine $l 0 0)
    }
    $sp = New-Object Windows.Controls.StackPanel
    [void]$sp.Children.Add((New-Text 'Diese oft empfohlenen »Tricks« bringen nichts oder schaden. TuneRig verwendet sie deshalb nicht:' -Role 'small' -Color 'ink-muted'))
    foreach ($m in $script:GamingMyths) { [void]$sp.Children.Add((New-LabeledLine ($m.T + ':') $m.W 'danger')) }
    Add-Wiz (New-ExpanderBox 'Bewusst nicht enthalten - und warum' $sp)
}

function Show-WizGamingDisplay {
    $d = $script:Wiz.Data['g-display']
    $tw = @($d.Tweaks)
    Register-TweakBefore $tw
    [void](Add-GamingBanner $tw 'Bild und Steuerung sind optimal eingestellt')
    $disp = @($d.Displays)
    if ($disp.Count) {
        Add-Section 'Deine Bildschirme'
        foreach ($x in $disp) {
            $ok = $x.Hz -ge $x.MaxHz
            $name = if ($x.Monitor) { $x.Monitor } else { "Bildschirm $($x.No)" }
            Add-Wiz (New-ItemRow -Level $(if ($ok) { 0 } else { 2 }) -Compact -Title "Bildschirm $($x.No): $name" `
                -Now ("{0} × {1}  ·  {2} Hz  (möglich: {3} Hz)" -f $x.Width, $x.Height, $x.Hz, $x.MaxHz) -NowLabel '')
        }
    }
    Add-GamingRows $tw
    $tips = New-Object Windows.Controls.StackPanel
    foreach ($l in @(
            'Spiele im Vollbildmodus starten und die native Auflösung des Monitors wählen.',
            'Mit G-Sync/FreeSync: V-Sync im Spiel ausschalten und die Bildrate 3 bis 5 FPS unter die Hz-Zahl begrenzen.',
            'Bietet das Spiel NVIDIA Reflex oder AMD Anti-Lag an: einschalten - das senkt die Verzögerung spürbar.',
            'Monitor per DisplayPort an die Grafikkarte anschließen. Ältere HDMI-Kabel schaffen oft keine hohen Hz-Zahlen.',
            'Im Menü des Monitors einen Gaming-Modus bzw. »Overdrive« aktivieren, falls vorhanden.')) {
        [void]$tips.Children.Add((New-ColoredLine $l 1 0))
    }
    Add-Wiz (New-ExpanderBox 'Tipps für das Spiel und den Monitor (von Hand)' $tips)
}

function Show-WizGamingSystem {
    $d = $script:Wiz.Data['g-system']
    $tw = @($d.Tweaks)
    Register-TweakBefore $tw
    [void](Add-GamingBanner $tw 'Prozessor und System sind optimal eingestellt')
    if ($d.Laptop) { Add-Wiz (New-ItemRow -Level 1 -Compact -Title 'Hinweis für Laptops' -Now 'Spiel am Netzteil. Mehr Leistung bedeutet kürzere Akkulaufzeit und einen lauteren Lüfter.' -NowLabel '') }
    Add-GamingRows $tw
}

function Show-WizGamingStartup {
    $items = @($script:Wiz.Data['g-startup'].Items | Where-Object { $_ })
    $off = @($items | Where-Object { $_.Enabled -and $_.Class -eq 'off' })
    $neutral = @($items | Where-Object { $_.Enabled -and $_.Class -eq 'neutral' })
    $keep = @($items | Where-Object { $_.Enabled -and $_.Class -eq 'keep' })
    $disabled = @($items | Where-Object { -not $_.Enabled })

    if ($off.Count -gt 0) {
        Add-NextStep -Level 2 -Headline $(if ($off.Count -eq 1) { '1 Programm startet unnötig mit Windows' } else { "$($off.Count) Programme starten unnötig mit Windows" }) `
            -Text 'Empfehlung: abschalten. Du kannst sie weiterhin ganz normal starten, wenn du sie brauchst – nur nicht mehr automatisch.' `
            -Primary (New-ActionButton $(if ($off.Count -eq 1) { "$($off[0].Name) abschalten" } else { "Jetzt alle $($off.Count) abschalten" }) {
                $script:State.WizAfter = $null
                Invoke-WizStartup @($script:Wiz.Data['g-startup'].Items | Where-Object { $_.Enabled -and $_.Class -eq 'off' } | ForEach-Object { $_.Id }) $false
            } -Primary) -Secondary (New-SkipButton)
    } else {
        Add-NextStep -Level 0 -Headline 'Keine unnötigen Autostart-Programme gefunden' `
            -Text $(if ($neutral.Count) { "Unten stehen $($neutral.Count) weitere Programme – schalte nur ab, was du kennst und nicht brauchst." } else { 'Hier ist nichts zu tun.' }) -Primary (New-NextButton)
    }

    if ($off.Count) {
        Add-Section "Empfohlen abzuschalten ($($off.Count))"
        foreach ($i in $off) {
            Add-Wiz (New-ItemRow -Level 2 -Compact -Title $i.Name -Now 'Startet automatisch mit Windows' -Target 'Nur bei Bedarf von Hand starten' `
                -Benefit 'Schnellerer Windows-Start, mehr freier Arbeitsspeicher beim Spielen.' -More ("Befehl: " + $i.Command) `
                -Buttons @(New-ActionButton 'Abschalten' { param($id) $script:State.WizAfter = $null; Invoke-WizStartup @($id) $false } $i.Id -Primary))
        }
    }
    if ($neutral.Count) {
        $sp = New-Object Windows.Controls.StackPanel
        [void]$sp.Children.Add((New-Text 'Nur abschalten, wenn du das Programm kennst und nicht automatisch brauchst.' -Role 'small' -Color 'ink-muted'))
        foreach ($i in $neutral) {
            $r = New-ItemRow -Level 1 -Compact -Title $i.Name -Now $i.Command -NowLabel 'Befehl:' `
                -Buttons @(New-ActionButton 'Abschalten' { param($id) $script:State.WizAfter = $null; Invoke-WizStartup @($id) $false } $i.Id)
            $r.Margin = New-Thickness 0 8 0 0
            [void]$sp.Children.Add($r)
        }
        Add-Wiz (New-ExpanderBox "Weitere Autostart-Programme ($($neutral.Count))" $sp)
    }
    if ($disabled.Count) {
        $sp = New-Object Windows.Controls.StackPanel
        foreach ($i in $disabled) {
            $r = New-ItemRow -Level 0 -Compact -Title $i.Name -Now 'Abgeschaltet' -NowLabel 'Jetzt:' `
                -Buttons @(New-ActionButton 'Wieder einschalten' { param($id) $script:State.WizAfter = $null; Invoke-WizStartup @($id) $true } $i.Id)
            $r.Margin = New-Thickness 0 8 0 0
            [void]$sp.Children.Add($r)
        }
        Add-Wiz (New-ExpanderBox "Abgeschaltet ($($disabled.Count))" $sp 'ok')
    }
    Add-OkExpander "Wichtig – bleiben eingeschaltet ($($keep.Count))" ($keep | ForEach-Object { "$($_.Name)  (Treiber, Sicherheit oder Geräte-Software)" })
}

function Show-WizGamingNetwork {
    $d = $script:Wiz.Data['g-network']
    $tw = @($d.Tweaks)
    $net = $d.Net
    Register-TweakBefore $tw
    $rec = @($tw | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal })

    if (-not $net.Connected) {
        Add-NextStep -Level 3 -Headline 'Keine Internetverbindung gefunden' -Text 'Verbinde den PC mit dem Internet und klick dann auf »Erneut prüfen«.' `
            -Primary (New-RecheckButton 'Erneut prüfen') -Secondary (New-SkipButton)
    } elseif ($rec.Count -gt 0) {
        [void](Add-GamingBanner $tw)
    } elseif ($net.Wifi) {
        Add-NextStep -Level 2 -Headline 'Tipp: Mit Netzwerkkabel spielen' `
            -Text 'Alle Einstellungen sind optimiert. Der größte verbleibende Gewinn: ein LAN-Kabel zum Router. WLAN ist die häufigste Ursache für Ping-Spitzen und Aussetzer.' `
            -Primary (New-NextButton)
    } else {
        [void](Add-GamingBanner $tw 'Deine Verbindung ist optimal eingestellt')
    }

    if ($net.Connected) {
        Add-Section 'Deine Verbindung'
        Add-Wiz (New-ItemRow -Level $(if ($net.Wifi) { 2 } else { 0 }) -Title $(if ($net.Wifi) { 'Verbindung: WLAN' } else { 'Verbindung: Netzwerkkabel (LAN)' }) `
            -Now ("$($net.Desc)  ·  $($net.Speed)") -NowLabel 'Adapter:' `
            -Target $(if ($net.Wifi) { 'Netzwerkkabel (LAN) zum Router' } else { '' }) `
            -Benefit $(if ($net.Wifi) { 'Stabilerer Ping und keine Aussetzer - mehr als jede Einstellung bringen kann.' } else { '' }) `
            -More $(if ($net.Wifi) { 'Geht kein Kabel: Router näher an den PC stellen, das 5-GHz-WLAN statt 2,4 GHz nutzen und Wände bzw. Metall zwischen Router und PC vermeiden.' } else { '' }))

        $pg = $net.PingGw; $pn = $net.PingNet
        $bad = ($pn.Loss -gt 0) -or ($pn.Jitter -gt 10) -or ($pg.Avg -gt 10)
        $now = if ($pn.Avg -lt 0) { 'Keine Antwort aus dem Internet (Ping blockiert?)' } else {
            "Router: $($pg.Avg) ms  ·  Internet: $($pn.Avg) ms  ·  Schwankung: $($pn.Jitter) ms  ·  Verlust: $($pn.Loss) %" }
        Add-Wiz (New-ItemRow -Level $(if ($bad) { 2 } else { 0 }) -Title 'Ping (Reaktionszeit)' -Now $now -NowLabel 'Gemessen:' `
            -Do $(if ($bad) { 'Downloads und Streams im Heimnetz pausieren, WLAN durch Kabel ersetzen, Router neu starten.' } else { '' }) `
            -More 'Router: Zeit bis zum eigenen Router - sollte unter 5 ms liegen (mit Kabel meist 1 ms). Internet: Zeit bis zu einem schnellen Server (Cloudflare). Schwankung: wie stark der Ping springt - entscheidend für ruckelfreies Online-Spielen, gut sind unter 5 ms. Verlust: verlorene Pakete - sollten 0 % sein. Den Ping zum Spielserver bestimmen vor allem Entfernung und Internetanbieter.' `
            -Buttons @(New-RecheckButton 'Neu messen'))

        # DNS
        $cur = @($net.Dns | Where-Object { $_.Name -eq 'Aktuell' })[0]
        $best = @($net.Dns | Where-Object { $_.Name -ne 'Aktuell' } | Sort-Object Ms | Select-Object -First 1)[0]
        $script:State.DnsBest = $best; $script:State.DnsIf = $net.IfIndex
        $all = ($net.Dns | ForEach-Object { "$($_.Name) ($($_.P)): $($_.Ms) ms" }) -join "`n"
        $isPublic = $net.CurrentDnsName -in @($script:PublicDns | ForEach-Object { $_.Name })
        $resetBtn = if ($isPublic) { New-ActionButton 'Wieder automatisch (Router)' { Start-WizDnsChange $true } }
        if ($cur -and $best -and ($best.Ms + 10) -lt $cur.Ms) {
            Add-Wiz (New-ItemRow -Level 1 -Title 'Schnellerer DNS-Server verfügbar (optional)' -Now "$($net.CurrentDnsName): $($cur.Ms) ms" -Target "$($best.Name): $($best.Ms) ms" `
                -Benefit 'Webseiten, Launcher und Spiele-Logins finden ihre Server etwas schneller. Der Ping im Spiel ändert sich dadurch nicht.' `
                -More ("Gemessene Antwortzeiten:`n$all`n`nDer DNS-Server übersetzt Namen wie »steampowered.com« in Adressen. Zurück auf automatisch geht hier jederzeit.") `
                -Buttons @((New-ActionButton "$($best.Name) verwenden" { Start-WizDnsChange $false }), $resetBtn))
        } else {
            Add-Wiz (New-ItemRow -Level 0 -Compact -Title 'DNS-Server: schnell genug' -Now "$($net.CurrentDnsName)$(if ($cur) { ": $($cur.Ms) ms" })" -NowLabel 'Aktuell:' `
                -More "Gemessene Antwortzeiten:`n$all" -Buttons @($resetBtn))
        }
    }
    Add-GamingRows $tw
}

# ---------------------------------------------------------------------------
#  OVERDRIVE: über die sicheren Empfehlungen hinaus - 3 Stufen, nur mit bestätigtem Risiko
# ---------------------------------------------------------------------------
$script:StepsOverdrive = @(
    @{ Id = 'o-welcome'; Name = 'Stufe & Risiko'; Analyze = $false
       Title = 'Overdrive'; Sub = 'Übertakten und Tuning – mehr Leistung, als Windows von sich aus erlaubt. Auf eigenes Risiko.'; Intro = '' }
    (Get-StepDef 'safety')
    @{ Id = 'o-tune'; Name = 'Tuning & Übertakten'; Analyze = $true
       Title = 'Tuning & Übertakten'; Sub = 'Erst Windows auf maximale Leistung stellen, dann Prozessor, Grafikkarte und Arbeitsspeicher übertakten.'
       Intro = 'Overdrive ändert Energie-, Speicher- und Sicherheitseinstellungen von Windows, damit der Prozessor jederzeit seinen vollen Takt nutzt. Das Übertakten über die Werksgrenzen hinaus (Takt und Spannung) geht nur im BIOS oder mit der Software des Herstellers – unten steht für deine Hardware, wie das geht. TuneRig merkt sich jeden ursprünglichen Wert und stellt ihn beim Zurücksetzen wieder her.' }
    (Get-StepDef 'summary')
)
$script:WizLoaders['o-tune'] = @{ Text = 'Prüfe Prozessor-, Speicher- und Sicherheitseinstellungen ...'
    Script = { $l = Test-IsLaptop; [pscustomobject]@{ Tweaks = @(Get-GamingTweaks 'overdrive' $l); Info = (Get-OverdriveInfo) } } }

function Get-OdLevelDef([int]$No) { @($script:OdLevels | Where-Object { $_.No -eq $No })[0] }

function New-OdLevelCard([int]$No, [bool]$Selected, $Titles) {
    $lv = Get-OdLevelDef $No
    $b = New-Object Windows.Controls.Border
    $b.Style = Get-ThemeStyle 'Card'
    $b.Padding = New-Thickness 20 20 20 20
    if ($Selected) { Set-ThemeRef $b BorderBrush 'accent'; $b.BorderThickness = New-Thickness 2 2 2 2 }
    $dp = New-Object Windows.Controls.DockPanel
    # unten: Auswahl-Button bzw. Kennzeichnung »Ausgewählt«
    if ($Selected) {
        $sel = New-Object Windows.Controls.StackPanel; $sel.Orientation = 'Horizontal'; $sel.Margin = New-Thickness 0 16 0 0
        $ic = New-LineIcon 'check' 'accent-text' 16; $ic.Margin = New-Thickness 0 0 8 0; [void]$sel.Children.Add($ic)
        [void]$sel.Children.Add((New-Label 'Ausgewählt'))
        [Windows.Controls.DockPanel]::SetDock($sel, 'Bottom'); [void]$dp.Children.Add($sel)
    } else {
        $btn = New-ActionButton "Stufe $No wählen" { param($n) $script:Wiz.OdLevel = [int]$n; $script:Wiz.OdAck = $false; Show-WizStep $script:Wiz.Index } $No
        $btn.Margin = New-Thickness 0 16 0 0; $btn.HorizontalAlignment = 'Left'
        [Windows.Controls.DockPanel]::SetDock($btn, 'Bottom'); [void]$dp.Children.Add($btn)
    }
    $sp = New-Object Windows.Controls.StackPanel
    $head = New-Object Windows.Controls.DockPanel
    $meter = New-SegmentMeter $No 3; [Windows.Controls.DockPanel]::SetDock($meter, 'Right'); [void]$head.Children.Add($meter)
    [void]$head.Children.Add((New-Label "Stufe $No"))
    [void]$sp.Children.Add($head)
    [void]$sp.Children.Add((New-Text $lv.Name -Role 'h3' -Top 8))
    [void]$sp.Children.Add((New-Text $lv.Short -Role 'title' -Top 4))
    [void]$sp.Children.Add((New-Text $lv.Desc -Role 'small' -Color 'ink-muted' -Top 8))
    $l = New-Label $(if ($No -gt 1) { "Zusätzlich zu Stufe $($No - 1)" } else { 'Ändert' }); $l.Margin = New-Thickness 0 16 0 4
    [void]$sp.Children.Add($l)
    foreach ($t in @($Titles)) { [void]$sp.Children.Add((New-ColoredLine $t 1 0)) }
    $r = New-ColoredLine $lv.Risk 2 0; $r.Margin = New-Thickness 0 12 0 0
    [void]$sp.Children.Add($r)
    [void]$dp.Children.Add($sp)
    $b.Child = $dp
    return $b
}

function Show-WizOverdriveWelcome {
    $lvl = [int]$script:Wiz.OdLevel; if ($lvl -lt 1 -or $lvl -gt 3) { $lvl = 1; $script:Wiz.OdLevel = 1 }
    $start = New-ActionButton "Overdrive Stufe $lvl starten" { Invoke-WizNext }
    $start.IsEnabled = [bool]$script:Wiz.OdAck
    $script:State.OdStartButton = $start
    Add-NextStep -Level 2 -Headline 'Overdrive ist nur für dich, wenn du Risiken bewusst eingehst' `
        -Text 'Overdrive geht über die sicheren Empfehlungen des Regulären Checks und des Performance Boost hinaus. Wähle eine Stufe und bestätige unten die Risiken. Für die meisten PCs reicht der Performance Boost völlig.' `
        -Primary $start -Secondary (New-ActionButton 'Lieber Performance Boost' { Open-WizMode 'gaming' })

    Add-Section 'Wähle die Intensität'
    $defs = @(Get-OverdriveTweakDefs (Test-IsLaptop))
    $grid = New-Object Windows.Controls.Grid
    for ($i = 0; $i -lt 5; $i++) {
        $c = New-Object Windows.Controls.ColumnDefinition
        $c.Width = if ($i % 2) { New-Object Windows.GridLength(16) } else { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) }
        $grid.ColumnDefinitions.Add($c)
    }
    foreach ($n in 1..3) {
        $titles = @($defs | Where-Object { $_.Level -eq $n } | ForEach-Object { $_.Title })
        $card = New-OdLevelCard $n ($n -eq $lvl) $titles
        [Windows.Controls.Grid]::SetColumn($card, ($n - 1) * 2)
        [void]$grid.Children.Add($card)
    }
    Add-Wiz $grid

    Add-Section 'Was Overdrive macht – und was nicht'
    foreach ($l in @(
            'Hebt Limits auf, die Windows zugunsten von Stromverbrauch, Temperatur oder Sicherheit setzt.',
            'Zeigt dir für deine Hardware, wie du Prozessor, Grafikkarte und Arbeitsspeicher übertaktest – im BIOS bzw. mit der Software des Herstellers.',
            'TuneRig selbst ändert keine Spannungen. Ein Hardwareschaden durch die Windows-Einstellungen ist daher sehr unwahrscheinlich.',
            'Merkt sich jeden ursprünglichen Wert. »Zurücksetzen« stellt ihn wieder her – auch nach einem Neustart oder Update von TuneRig.',
            'Legt vor der ersten Änderung einen Wiederherstellungspunkt an.')) {
        Add-Wiz (New-ColoredLine $l 0 0)
    }
    Add-Section 'Die Risiken'
    foreach ($l in @(
            'Mehr Wärme, Stromverbrauch und Lüftergeräusch – auch wenn der PC nichts tut (ab Stufe 2).',
            'Weniger Schutz vor bestimmten Angriffen auf Prozessor und Systemkern (Stufe 3). Nicht auf PCs mit sensiblen Daten, für Online-Banking oder für die Arbeit.',
            'Auf Laptops deutlich kürzere Akkulaufzeit. Stufe 3 lässt den Leerlauf auf Laptops bewusst aus.',
            'Wie viel Leistung du gewinnst, hängt stark vom Prozessor ab. Bei manchen PCs ist kaum ein Unterschied messbar.')) {
        Add-Wiz (New-ColoredLine $l 2 0)
    }

    $ack = New-Object Windows.Controls.CheckBox
    $ack.Margin = New-Thickness 0 24 0 0
    $tb = New-Object Windows.Controls.TextBlock
    $tb.Text = 'Ich habe die Risiken verstanden und gehe sie bewusst ein. Ich weiß, dass ich jede Änderung hier zurücksetzen kann.'
    $tb.TextWrapping = 'Wrap'
    Set-TypeRole $tb 'body'; Set-ThemeRef $tb Foreground 'ink'
    $ack.Content = $tb
    $ack.IsChecked = [bool]$script:Wiz.OdAck
    $ack.Add_Click({
        $script:Wiz.OdAck = [bool]$this.IsChecked
        if ($script:State.OdStartButton) { $script:State.OdStartButton.IsEnabled = $script:Wiz.OdAck }
        if ($script:Wiz.OdAck) { Add-WizLog "Overdrive: Risiken bestätigt (Stufe $($script:Wiz.OdLevel))" }
    })
    Add-Wiz $ack
}

# Zeile einer Overdrive-Einstellung: offen = Hinweis mit Nebenwirkung, aktiv = mit »Zurücksetzen«
function New-OdRow($t) {
    if ($t.Optimal) {
        $btn = if ($t.ByTuneRig -and $t.CanRevert) { New-ActionButton 'Zurücksetzen' { param($id) $script:State.WizAfter = $null; Invoke-WizGamingTweaks @($id) -Revert } $t.Id }
        $now = $t.State + $(if ($t.ByTuneRig) { '  (von TuneRig gesetzt)' } else { '  (war schon so eingestellt)' })
        return New-ItemRow -Level 0 -Compact -Title $t.Title -Now $now -NowLabel 'Jetzt:' -Buttons @($btn)
    }
    $btn = New-ActionButton $t.Fix {
        param($id)
        $t = @($script:Wiz.Data['o-tune'].Tweaks | Where-Object { $_.Id -eq $id })[0]
        if (-not (Confirm-Action ("{0}`n`nRisiko: {1}`n`nTrotzdem anwenden? Du kannst es hier jederzeit zurücksetzen." -f $t.Title, $t.Risk) 'Overdrive')) { return }
        $script:State.WizAfter = $null
        Invoke-WizGamingTweaks @($id)
    } $t.Id
    $benefit = $t.Benefit + $(if ($t.Restart) { ' (wirkt nach einem Neustart)' } else { '' })
    New-ItemRow -Level 1 -Title $t.Title -Now $t.State -Target $t.Target -Benefit $benefit -Risk $t.Risk -More $t.Desc -Buttons @($btn)
}

function Show-WizOverdrive {
    $d = $script:Wiz.Data['o-tune']
    $tw = @($d.Tweaks | Where-Object { $_ })
    $lvl = [int]$script:Wiz.OdLevel
    $lv = Get-OdLevelDef $lvl
    $sel = @($tw | Where-Object { $_.Level -le $lvl })
    $open = @($sel | Where-Object { -not $_.Optimal })
    $mine = @($tw | Where-Object { $_.Optimal -and $_.ByTuneRig -and $_.CanRevert })

    $change = New-ActionButton 'Stufe ändern' { Request-WizLeave 0 'zur Stufenwahl' }
    if ($open.Count -gt 0) {
        $restart = @($open | Where-Object { $_.Restart }).Count -gt 0
        Add-NextStep -Level 2 -Headline ("Stufe {0} – {1}: {2} Änderung{3} offen" -f $lvl, $lv.Name, $open.Count, $(if ($open.Count -eq 1) { '' } else { 'en' })) `
            -Text ("Risiko: $($lv.Risk)" + $(if ($restart) { ' Ein Teil wirkt erst nach einem Neustart.' } else { '' }) + ' Vor der ersten Änderung legt TuneRig einen Wiederherstellungspunkt an.') `
            -Primary (New-ActionButton "Stufe $lvl anwenden" {
                $lvl = [int]$script:Wiz.OdLevel
                $items = @($script:Wiz.Data['o-tune'].Tweaks | Where-Object { $_.Level -le $lvl -and -not $_.Optimal })
                $list = ($items | ForEach-Object { "–  $($_.Title): $($_.Target)" }) -join "`n"
                $q = "Overdrive Stufe $lvl ändert:`n`n$list`n`nRisiko: $((Get-OdLevelDef $lvl).Risk)`n`nJetzt anwenden?"
                if (-not (Confirm-Action $q 'Overdrive anwenden')) { return }
                $script:State.WizAfter = $null
                Invoke-WizGamingTweaks @($items | ForEach-Object { $_.Id })
            }) -Secondary $change
    } else {
        Add-NextStep -Level 0 -Headline "Stufe $lvl – $($lv.Name) ist aktiv" `
            -Text 'Teste jetzt deine Spiele. Wird der PC zu warm, zu laut oder läuft etwas instabil: unten einzelne Punkte oder alles zurücksetzen.' `
            -Primary (New-NextButton) -Secondary $change
    }
    if ($d.Info.Laptop) { Add-Wiz (New-ItemRow -Level 2 -Compact -Title 'Hinweis für Laptops' -Now 'Nur am Netzteil nutzen und auf die Temperatur achten. Im Akkubetrieb kostet Overdrive viel Laufzeit.' -NowLabel '') }

    foreach ($n in 1..$lvl) {
        $rows = @($tw | Where-Object { $_.Level -eq $n })
        if (-not $rows.Count) { continue }
        Add-Section ("Stufe {0} – {1}" -f $n, (Get-OdLevelDef $n).Name)
        foreach ($t in $rows) { $r = New-OdRow $t; $r.Margin = New-Thickness 0 0 0 8; Add-Wiz $r }
    }
    $higher = @($tw | Where-Object { $_.Level -gt $lvl })
    if ($higher.Count) {
        $sp = New-Object Windows.Controls.StackPanel
        [void]$sp.Children.Add((New-Text 'Gehören zu einer höheren Stufe. Einzeln anwendbar – mit dem jeweiligen Risiko.' -Role 'small' -Color 'ink-muted'))
        foreach ($t in $higher) { $r = New-OdRow $t; $r.Margin = New-Thickness 0 8 0 0; [void]$sp.Children.Add($r) }
        Add-Wiz (New-ExpanderBox "Höhere Stufen ($($higher.Count))" $sp)
    }
    if ($mine.Count) {
        Add-Section 'Alles zurücksetzen'
        Add-Wiz (New-ItemRow -Level 1 -Compact -Title ("{0} Overdrive-Einstellung{1} von TuneRig aktiv" -f $mine.Count, $(if ($mine.Count -eq 1) { '' } else { 'en' })) `
            -Now 'Stellt alle ursprünglichen Werte wieder her.' -NowLabel '' `
            -Buttons @(New-ActionButton 'Overdrive komplett zurücksetzen' {
                $ids = @($script:Wiz.Data['o-tune'].Tweaks | Where-Object { $_.Optimal -and $_.ByTuneRig -and $_.CanRevert } | ForEach-Object { $_.Id })
                if (-not (Confirm-Action "Alle $($ids.Count) Overdrive-Einstellungen auf ihre ursprünglichen Werte zurücksetzen?" 'Overdrive zurücksetzen')) { return }
                $script:State.WizAfter = $null
                Invoke-WizGamingTweaks $ids -Revert
            }))
    }

    # Übertakten: Anleitung für die erkannte Hardware (TuneRig ändert hier nichts)
    $info = $d.Info
    $sp = New-Object Windows.Controls.StackPanel
    [void]$sp.Children.Add((New-Text 'Takt und Spannung über die Werksgrenzen hinaus lassen sich nicht sicher aus Windows heraus ändern. Das geht im BIOS oder mit der Software des Herstellers. Erhöhe in kleinen Schritten und teste nach jeder Änderung.' -Role 'small' -Color 'ink-muted'))
    if ($info.RamSpeed -gt 0) {
        $ramNow = ("{0} · {1} MT/s" -f $(if ($info.RamType) { $info.RamType } else { 'Arbeitsspeicher' }), $info.RamSpeed)
        $row = if ($info.RamBase) {
            New-ItemRow -Level 1 -Compact -Title 'Arbeitsspeicher läuft vermutlich ohne XMP/EXPO' -Now $ramNow -NowLabel 'Aktuell:' `
                -Do 'Im BIOS das Speicherprofil einschalten: XMP (Intel) bzw. EXPO oder DOCP (AMD). Das ist der einfachste und sicherste Leistungsgewinn – oft 5 bis 15 % mehr FPS.'
        } else { New-ItemRow -Level 0 -Compact -Title 'Arbeitsspeicher' -Now ($ramNow + '  (läuft schneller als der Grundtakt)') -NowLabel 'Aktuell:' }
        $row.Margin = New-Thickness 0 8 0 0; [void]$sp.Children.Add($row)
    }
    foreach ($g in @($info.Gpus)) {
        $how = if ($g -match 'NVIDIA') { 'NVIDIA App > System > Leistung > Automatisches Tuning. Ermittelt stabile Werte selbst und ist jederzeit zurücksetzbar.' }
               elseif ($g -match 'AMD|Radeon') { 'AMD Software > Leistung > Tuning > »GPU übertakten« (automatisch). Jederzeit zurücksetzbar.' }
               else { 'Intel Graphics Software > Leistung. Nur in kleinen Schritten erhöhen.' }
        $row = New-ItemRow -Level 1 -Compact -Title "Grafikkarte: $g" -Now $how -NowLabel 'So geht es:'
        $row.Margin = New-Thickness 0 8 0 0; [void]$sp.Children.Add($row)
    }
    $cpuHow = if ($info.Cpu -match 'AMD|Ryzen') { 'Im BIOS »Precision Boost Overdrive« (PBO) aktivieren – oder in AMD Ryzen Master.' } else { 'Im BIOS die Leistungsgrenzen (Power Limits) anheben. Übertakten des Multiplikators geht nur bei K-Modellen.' }
    $row = New-ItemRow -Level 1 -Compact -Title "Prozessor: $($info.Cpu)" -Now ($cpuHow + ' Temperaturen dabei im Blick behalten, z. B. mit HWiNFO – dauerhaft über 90 °C ist zu viel.') -NowLabel 'So geht es:'
    $row.Margin = New-Thickness 0 8 0 0; [void]$sp.Children.Add($row)
    Add-Section 'Übertakten – Prozessor, Grafikkarte, Arbeitsspeicher'
    Add-Wiz $sp
}

# --------------------------- Aktionen ---------------------------
function Invoke-WizGamingTweaks([string[]]$Ids, [switch]$Revert) {
    $stepId = $script:WizSteps[$script:Wiz.Index].Id
    $tw = @($script:Wiz.Data[$stepId].Tweaks | Where-Object { $Ids -contains $_.Id })
    if ($tw.Count -eq 0) { return }
    $isOd = $stepId -eq 'o-tune'
    $script:State.Pending = @{ Ids = @($tw | ForEach-Object { $_.Id }); StepId = $stepId; Group = $(if ($isOd) { 'overdrive' } else { $stepId -replace '^g-', '' }); Revert = [bool]$Revert
                               Restart = [bool]($tw | Where-Object { $_.Restart }); Area = $(if ($isOd) { 'Overdrive' } else { 'Performance Boost' }) }
    Invoke-WithRestorePoint $(if ($isOd) { 'TuneRig Overdrive' } else { 'TuneRig Performance Boost' }) {
        $pd = $script:State.Pending
        Start-Work -Status $(if ($pd.Revert) { 'Setze zurück ...' } else { 'Optimiere ... (der Bildschirm oder die Verbindung kann kurz aussetzen)' }) `
            -Arguments @(@($pd.Ids), $pd.Group, $pd.Revert) -Script {
                $e = @(Invoke-GamingTweaks $A[0] -Revert:$A[2])
                [pscustomobject]@{ Errors = $e; Tweaks = @(Get-GamingTweaks $A[1] (Test-IsLaptop)); Displays = $(if ($A[1] -eq 'display') { @(Get-DisplayInfo) } else { $null }) }
            } -OnDone {
                param($r) $r = @($r)[-1]
                $pd = $script:State.Pending
                $data = $script:Wiz.Data[$pd.StepId]
                $data.Tweaks = $r.Tweaks
                if ($r.Displays) { $data.Displays = $r.Displays }
                foreach ($id in $pd.Ids) {
                    $nt = @($r.Tweaks | Where-Object { $_.Id -eq $id })[0]
                    if (-not $nt) { continue }
                    if ($pd.Revert) { Add-WizChange $pd.Area "$($nt.Title): zurückgesetzt" "Jetzt: $($nt.State)" -1; Add-WizLog "Zurückgesetzt: $($nt.Title)" }
                    elseif ($nt.Optimal) { Add-WizChange $pd.Area "$($nt.Title): $($nt.State)" $nt.Benefit $nt.Impact; Add-WizLog "$($pd.Area): $($nt.Title)" }
                }
                if ($pd.Restart) { $script:Wiz.NeedsRestart = $true }
                $errs = @($r.Errors | Where-Object { $_ })
                if ($errs.Count) { Show-Info ("Nicht alles ließ sich ändern:`n`n" + ($errs -join "`n")) }
                Set-Status $(if ($pd.Restart) { 'Erledigt. Ein Teil wirkt erst nach einem Neustart - der Button dafür kommt am Ende des Checks.' } else { 'Erledigt.' })
                Complete-WizAction
            }
    }
}

function Invoke-WizStartup([string[]]$Ids, [bool]$Enable) {
    $script:State.Pending = @{ Ids = @($Ids); Enable = $Enable }
    Start-Work -Status $(if ($Enable) { 'Schalte Autostart wieder ein ...' } else { 'Schalte Autostart-Programme ab ...' }) -Arguments @(@($Ids), $Enable) -Script {
        foreach ($id in $A[0]) { Set-StartupItemState $id $A[1] }
        [pscustomobject]@{ Items = @(Get-StartupItems) }
    } -OnDone {
        param($r)
        $script:Wiz.Data['g-startup'] = @($r)[-1]
        $pd = $script:State.Pending
        $n = @($pd.Ids).Count
        if ($pd.Enable) { Add-WizChange 'Autostart' "$n Autostart-Programm(e) wieder eingeschaltet" '' -1 }
        else { Add-WizChange 'Autostart' "$n Autostart-Programm(e) abgeschaltet" 'Schnellerer Windows-Start, mehr freier Arbeitsspeicher beim Spielen.' 1 }
        Add-WizLog "Autostart: $n Programm(e) $(if ($pd.Enable) { 'eingeschaltet' } else { 'abgeschaltet' })"
        Set-Status 'Erledigt.'
        Complete-WizAction
    }
}

function Start-WizDnsChange([bool]$Reset) {
    $best = $script:State.DnsBest
    $msg = if ($Reset) { 'Der DNS-Server wird wieder automatisch vom Router bezogen. Fortfahren?' } else { "Als DNS-Server wird $($best.Name) ($($best.P)) eingetragen.`n`nDas betrifft nur diese Netzwerkverbindung und lässt sich hier jederzeit zurücksetzen. Fortfahren?" }
    if (-not (Confirm-Action $msg)) { return }
    $script:State.Pending = @{ Reset = $Reset; Name = $best.Name }
    Start-Work -Status 'Ändere DNS-Server ...' -Arguments @($script:State.DnsIf, $best.P, $best.S, $Reset) -Script {
        if ($A[3]) { Reset-GamingDns $A[0] } else { Set-GamingDns $A[0] $A[1] $A[2] }
        'OK'
    } -OnDone {
        if ($script:State.Pending.Reset) { Add-WizChange 'Internet' 'DNS-Server wieder automatisch' '' -1 }
        else { Add-WizChange 'Internet' "DNS-Server: $($script:State.Pending.Name)" 'Webseiten und Launcher finden ihre Server etwas schneller.' -1 }
        Invoke-WizRecheck
    }
}

function Start-WizLoad([string]$Id) {
    $script:State.LoadId = $Id
    $l = $script:WizLoaders[$Id]
    Start-Work -Status $l.Text -Script $l.Script -OnDone {
        param($r)
        $id = $script:State.LoadId
        $res = @($r)[-1]
        if ($id -eq 'settings') {
            # Leistung = Einstellungen + Grafikkarte & Spiele (intern zwei Datenbereiche)
            $script:Wiz.Data['gpu'] = $res.GpuData
            Register-WizBaseline 'gpu' $res.GpuData
            $res = [pscustomobject]@{ Tweaks = $res.Tweaks; Laptop = $res.Laptop }
        }
        $script:Wiz.Data[$id] = $res
        Register-WizBaseline $id $script:Wiz.Data[$id]
        switch ($id) {
            'system' { Show-WizSystem } 'drivers' { Show-WizDrivers } 'settings' { Show-WizSettings }
            'gpusw' { Show-WizStep $script:Wiz.Index; return }
            'cleanup' { Show-WizCleanup }
            default { Show-WizStepContent $id }
        }
        Update-WizNavHint
        Set-Status 'Prüfung abgeschlossen. Was zu tun ist, steht oben unter »Dein nächster Schritt«.'
    }
}

# ---------------------------------------------------------------------------
#  Bausteine des Layouts
#  Jeder Schritt: oben die Box »Dein nächster Schritt« (genau eine Aufgabe, ein Primär-Button),
#  darunter Karten mit  Aktuell / Empfohlen / Vorteil  und Sekundär-Buttons rechts.
#  Längere Erklärungen stehen hinter »Mehr erfahren«.
# ---------------------------------------------------------------------------
function New-StatusIcon([int]$Level, [double]$Size = 24) {
    $i = New-LineIcon $script:LevelIconKind[$Level] $script:LevelToken[$Level] $Size
    $i.VerticalAlignment = 'Top'; $i.Margin = New-Thickness 0 0 16 0
    [Windows.Automation.AutomationProperties]::SetName($i, $script:LevelWord[$Level])
    return $i
}

# Zeile »Bezeichnung:  Text« - die Bezeichnung in einem Farb-Token
function New-LabeledLine([string]$Label, [string]$Text, [string]$Color = 'ink-muted') {
    $tb = New-Object Windows.Controls.TextBlock
    $tb.TextWrapping = 'Wrap'; $tb.Margin = New-Thickness 0 4 0 0
    Set-TypeRole $tb 'small'
    Set-ThemeRef $tb Foreground 'ink'
    if ($Label) {
        $r1 = New-Object Windows.Documents.Run -ArgumentList ($Label + '  ')
        $r1.FontWeight = [Windows.FontWeights]::Medium
        Set-ThemeRef $r1 Foreground $Color
        $tb.Inlines.Add($r1)
    }
    $tb.Inlines.Add((New-Object Windows.Documents.Run -ArgumentList $Text))
    return $tb
}

function New-MoreInfo([string]$Text, [string]$Header = 'Mehr erfahren') {
    $e = New-Object Windows.Controls.Expander
    $e.Header = $Header; $e.Margin = New-Thickness 0 4 0 0; $e.FontSize = 13
    $e.Content = New-Text $Text -Role 'small' -Color 'ink-muted'
    return $e
}

function Get-FirstSentence([string]$Text) {
    if (-not $Text) { return '' }
    $m = [regex]::Match($Text, '^.+?[.!?](?=\s|$)')
    if ($m.Success) { return $m.Value } else { return $Text }
}

# Wirkung als segmentierte Anzeige (1-3) mit Text
function New-ImpactLine([int]$Impact) {
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Orientation = 'Horizontal'; $sp.Margin = New-Thickness 0 6 0 0
    $l = New-Text 'Wirkung:' -Role 'small' -Color 'ink-muted'; $l.FontWeight = [Windows.FontWeights]::Medium; $l.Margin = New-Thickness 0 0 8 0
    [void]$sp.Children.Add($l)
    if ($Impact -ge 1) { $m = New-SegmentMeter $Impact 3; $m.Margin = New-Thickness 0 0 8 0; [void]$sp.Children.Add($m) }
    [void]$sp.Children.Add((New-Text $script:ImpactText[$Impact] -Role 'small'))
    return $sp
}

# Eine Empfehlung bzw. ein Ergebnis als Karte
function New-ItemRow {
    param([int]$Level = 2, [string]$Title, [string]$Now = '', [string]$NowLabel = 'Aktuell:', [string]$Target = '', [string]$Before = '',
          [string]$Do = '', [string]$Benefit = '', [int]$Impact = -9, [string]$Risk = '', [string]$More = '', $Buttons = @(), $Extra = $null, [switch]$Compact)
    $sc = New-StateCard $Level ($Level -ge 1) $(if ($Compact) { New-Thickness 16 12 16 12 } else { New-Thickness 16 16 16 16 })
    $card = $sc.Outer
    $card.Margin = New-Thickness 0 0 0 8

    $grid = New-Object Windows.Controls.Grid
    foreach ($w in 'Auto', '*', 'Auto') {
        $c = New-Object Windows.Controls.ColumnDefinition
        $c.Width = if ($w -eq '*') { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { [Windows.GridLength]::Auto }
        $grid.ColumnDefinitions.Add($c)
    }
    $icon = New-StatusIcon $Level
    [Windows.Controls.Grid]::SetColumn($icon, 0); [void]$grid.Children.Add($icon)

    $sp = New-Object Windows.Controls.StackPanel
    $sp.VerticalAlignment = 'Center'
    [void]$sp.Children.Add((New-Text $Title -Role 'title'))
    if ($Now) { [void]$sp.Children.Add((New-LabeledLine $NowLabel $Now $script:LevelToken[$Level])) }
    if ($Target) { [void]$sp.Children.Add((New-LabeledLine 'Empfohlen:' $Target 'accent-text')) }
    if ($Before) { [void]$sp.Children.Add((New-LabeledLine 'Vorher:' $Before 'ink-muted')) }
    if ($Do) { [void]$sp.Children.Add((New-LabeledLine 'So geht es:' $Do 'ink-muted')) }
    if ($Benefit) { [void]$sp.Children.Add((New-LabeledLine 'Vorteil:' $Benefit 'ink-muted')) }
    if ($Impact -ge 0 -and $script:ImpactText[$Impact]) { [void]$sp.Children.Add((New-ImpactLine $Impact)) }
    if ($Risk) { [void]$sp.Children.Add((New-LabeledLine 'Nebenwirkung:' $Risk 'warning')) }
    if ($Extra) { foreach ($e in @($Extra)) { if ($e) { [void]$sp.Children.Add($e) } } }
    if ($More) { [void]$sp.Children.Add((New-MoreInfo $More)) }
    [Windows.Controls.Grid]::SetColumn($sp, 1); [void]$grid.Children.Add($sp)

    $btns = @($Buttons | Where-Object { $_ })
    if ($btns.Count -gt 0) {
        $bp = New-Object Windows.Controls.StackPanel
        $bp.Margin = New-Thickness 16 0 0 0; $bp.VerticalAlignment = 'Center'
        foreach ($b in $btns) { $b.Margin = New-Thickness 0 4 0 4; $b.MinWidth = 200; [void]$bp.Children.Add($b) }
        [Windows.Controls.Grid]::SetColumn($bp, 2); [void]$grid.Children.Add($bp)
    }
    $sc.Inner.Child = $grid
    return $card
}

# Große Box oben: »Dein nächster Schritt« mit dem einzigen Primär-Button der Ansicht
function Add-NextStep {
    param([int]$Level = 2, [string]$Headline, [string]$Text = '', $Primary = $null, $Secondary = $null)
    $sc = New-StateCard $Level $true (New-Thickness 24 24 24 24)
    $b = $sc.Outer
    Set-ThemeRef $b Background 'surface-raised'
    $b.Margin = New-Thickness 0 0 0 24
    $grid = New-Object Windows.Controls.Grid
    $c0 = New-Object Windows.Controls.ColumnDefinition; $c0.Width = [Windows.GridLength]::Auto
    $c1 = New-Object Windows.Controls.ColumnDefinition; $c1.Width = New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star)
    $grid.ColumnDefinitions.Add($c0); $grid.ColumnDefinitions.Add($c1)
    $badge = New-HexBadge $Level 48
    $badge.VerticalAlignment = 'Top'; $badge.Margin = New-Thickness 0 0 20 0
    [Windows.Automation.AutomationProperties]::SetName($badge, $script:LevelWord[$Level])
    [void]$grid.Children.Add($badge)
    $sp = New-Object Windows.Controls.StackPanel
    [void]$sp.Children.Add((New-Label 'Dein nächster Schritt'))
    [void]$sp.Children.Add((New-Text $Headline -Role 'h3' -Top 8))
    if ($Text) { [void]$sp.Children.Add((New-Text $Text -Role 'body' -Color 'ink-muted' -Top 8)) }
    $wp = New-Object Windows.Controls.WrapPanel
    $wp.Margin = New-Thickness 0 16 0 0
    if ($Primary) { Set-PrimaryButton $Primary; $Primary.Margin = New-Thickness 0 0 12 0; [void]$wp.Children.Add($Primary) }
    if ($Secondary) { $Secondary.MinHeight = 44; $Secondary.Margin = New-Thickness 0 0 12 0; [void]$wp.Children.Add($Secondary) }
    if ($wp.Children.Count -gt 0) { [void]$sp.Children.Add($wp) }
    [Windows.Controls.Grid]::SetColumn($sp, 1); [void]$grid.Children.Add($sp)
    $sc.Inner.Child = $grid
    Add-Wiz $b
}

function Add-Section([string]$Text) {
    $t = New-Label $Text
    $t.Margin = New-Thickness 0 24 0 12
    Add-Wiz $t
}

# Kopf eines Aufklappbereichs mit Linien-Icon
function New-ExpanderHeader([string]$Text, [string]$Icon = '', [string]$Token = 'ink-muted') {
    if (-not $Icon) { return $Text }
    $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'
    $i = New-LineIcon $Icon $Token 16; $i.Margin = New-Thickness 0 0 8 0
    [void]$sp.Children.Add($i)
    $t = New-Object Windows.Controls.TextBlock; $t.Text = $Text; $t.VerticalAlignment = 'Center'
    [void]$sp.Children.Add($t)
    return $sp
}

# Aufklappbare Liste mit allem, was in Ordnung ist (standardmäßig zugeklappt)
function Add-OkExpander([string]$Header, $Lines) {
    $l = @($Lines | Where-Object { $_ })
    if ($l.Count -eq 0) { return }
    $e = New-Object Windows.Controls.Expander
    $e.Header = New-ExpanderHeader $Header 'ok' 'success'
    $e.Margin = New-Thickness 0 8 0 12
    $sp = New-Object Windows.Controls.StackPanel
    foreach ($x in $l) { [void]$sp.Children.Add((New-Text $x -Role 'small' -Top 4)) }
    $e.Content = $sp
    Add-Wiz $e
}

function New-ExpanderBox([string]$Header, $Content, [string]$Icon = '') {
    $e = New-Object Windows.Controls.Expander
    $e.Header = New-ExpanderHeader $Header $Icon
    $e.Margin = New-Thickness 0 8 0 12
    $wrap = New-Object Windows.Controls.Border
    $wrap.Margin = New-Thickness 0 8 0 0
    $wrap.Child = $Content
    $e.Content = $wrap
    return $e
}

# Standard-Buttons der Box »Dein nächster Schritt«
function New-NextButton([string]$Label = 'Weiter zum nächsten Schritt') { New-ActionButton $Label { Invoke-WizNext } }
function New-SkipButton([string]$Label = 'Überspringen') { New-ActionButton $Label { Go-WizTarget ($script:Wiz.Index + 1) } }
function New-RecheckButton([string]$Label = 'Erledigt? Erneut prüfen') { New-ActionButton $Label { Invoke-WizRecheck } }

# Hinweis unten in der Leiste: Was ist in diesem Schritt noch offen?
function Set-WizNavHint([string]$Text, [int]$Level) {
    $ui.WizNavHint.Text = $Text
    Set-ThemeRef $ui.WizNavHint Foreground $(if ($Level -eq 1) { 'ink-muted' } else { $script:LevelToken[$Level] })
    $ui.WizNavIcon.Content = if ($Text) { New-LineIcon $script:LevelIconKind[$Level] $script:LevelToken[$Level] 16 } else { $null }
}

function Update-WizNavHint {
    $step = $script:WizSteps[$script:Wiz.Index]
    Set-WizNavHint '' 1
    if ($step.Id -in 'welcome', 'g-welcome', 'o-welcome', 'summary') { return }
    if ($step.Id -eq 'drivers' -and (Test-SoftwareGate)) { Set-WizNavHint 'Installiere zuerst die Software des Herstellers' 3; return }
    if ($step.Analyze -and -not $script:Wiz.Data.ContainsKey($step.Id)) { return }
    $p = @(Get-WizPending $step.Id | Where-Object { $_ })
    $ch = @($p | Where-Object { $_.Kind -eq 'change' -and $_.Rec }).Count
    $inf = @($p | Where-Object { $_.Kind -eq 'info' }).Count
    if ($ch -gt 0) { Set-WizNavHint "Noch $ch Empfehlung(en) offen" 2 }
    elseif ($inf -gt 0) { Set-WizNavHint "$inf Punkt(e) zum selbst Erledigen" 1 }
    else { Set-WizNavHint 'Alles erledigt – weiter mit »Weiter«' 0 }
}

function Invoke-WizNext {
    $idx = $script:Wiz.Index
    if ($idx -ge $script:WizSteps.Count - 1) { Complete-WizardRun; return }
    Request-WizLeave ($idx + 1) 'weiter'
}

# ---------------------------------------------------------------------------
#  Die einzelnen Schritte
# ---------------------------------------------------------------------------
function New-NumberRow([string]$No, [string]$Title, [string]$Desc) {
    $dp = New-Object Windows.Controls.DockPanel
    $dp.Margin = New-Thickness 0 0 0 12
    $c = New-Object Windows.Controls.Border
    $c.Width = 32; $c.Height = 32; $c.CornerRadius = New-Object Windows.CornerRadius(4)
    Set-ThemeRef $c Background 'surface-raised'; Set-ThemeRef $c BorderBrush 'line'; $c.BorderThickness = New-Thickness 1 1 1 1
    $c.Margin = New-Thickness 0 0 16 0; $c.VerticalAlignment = 'Top'
    $n = New-Text $No -Role 'metric-small'; $n.HorizontalAlignment = 'Center'; $n.VerticalAlignment = 'Center'
    $c.Child = $n
    [Windows.Controls.DockPanel]::SetDock($c, 'Left'); [void]$dp.Children.Add($c)
    $sp = New-Object Windows.Controls.StackPanel; $sp.VerticalAlignment = 'Center'
    [void]$sp.Children.Add((New-Text $Title -Role 'title'))
    if ($Desc) { [void]$sp.Children.Add((New-Text $Desc -Role 'small' -Color 'ink-muted')) }
    [void]$dp.Children.Add($sp)
    return $dp
}

function Show-WizWelcome {
    Add-NextStep -Level 1 -Headline 'Starte den Check' `
        -Text 'Dauer: 5–10 Minuten. In jedem Schritt steht genau hier, was du tun sollst – meist reicht ein Klick.' `
        -Primary (New-ActionButton 'Jetzt starten' { Invoke-WizNext })

    Add-Section 'So läuft es ab'
    $steps = @(
        @('1', 'Windows-Sicherung', 'einen Speicherstand für Windows anlegen'),
        @('2', 'Dein PC', 'Hardware und Speicherplatz prüfen'),
        @('3', 'Treiber', 'fehlende Treiber finden'),
        @('4', 'Leistung', 'Windows auf Leistung stellen, Spiele auf die starke Grafikkarte legen'),
        @('5', 'Aufräumen', 'unnötige Dateien löschen'))
    foreach ($s in $steps) { Add-Wiz (New-NumberRow $s[0] $s[1] $s[2]) }

    Add-Section 'Die Symbole bedeuten'
    $wp = New-Object Windows.Controls.WrapPanel
    foreach ($x in @(@(0, 'In Ordnung'), @(1, 'Hinweis'), @(2, 'Verbesserung möglich'), @(3, 'Problem'))) {
        $dp = New-Object Windows.Controls.StackPanel; $dp.Orientation = 'Horizontal'; $dp.Margin = New-Thickness 0 0 24 8
        $i = New-StatusIcon $x[0] 20; $i.Margin = New-Thickness 0 0 8 0; $i.VerticalAlignment = 'Center'
        [void]$dp.Children.Add($i)
        $t = New-Text $x[1] 14; $t.VerticalAlignment = 'Center'
        [void]$dp.Children.Add($t)
        [void]$wp.Children.Add($dp)
    }
    Add-Wiz $wp
    $safe = New-ColoredLine 'Nichts ändert sich ohne deine Zustimmung. Vor jeder Änderung legt TuneRig automatisch einen Wiederherstellungspunkt an.' 0
    $safe.Margin = New-Thickness 0 16 0 0
    Add-Wiz $safe
}

function Show-WizSafety {
    if ($script:State.LastRestore) {
        Add-NextStep -Level 0 -Headline 'Dein PC ist abgesichert' `
            -Text ('Der Wiederherstellungspunkt von {0:HH:mm} Uhr ist da. Du kannst gefahrlos weitermachen.' -f $script:State.LastRestore) `
            -Primary (New-NextButton)
    } else {
        Add-NextStep -Level 2 -Headline 'Leg zuerst einen Wiederherstellungspunkt an' `
            -Text 'Damit lässt sich jede spätere Änderung mit wenigen Klicks rückgängig machen. Dauert etwa 1 Minute. Deine Dateien bleiben unberührt.' `
            -Primary (New-ActionButton 'Jetzt absichern' { $script:State.WizAfter = $null; Invoke-WizRestorePoint }) `
            -Secondary (New-SkipButton 'Überspringen')
    }

    Add-Wiz (New-ItemRow -Level 1 -Title 'Nach einer Änderung funktioniert etwas nicht?' `
        -Do 'Systemwiederherstellung öffnen und den Punkt »TuneRig« auswählen.' `
        -Benefit 'Windows ist wieder wie vorher. Fotos und Dokumente bleiben erhalten.' `
        -Buttons @(New-ActionButton 'Systemwiederherstellung öffnen' { Open-Target 'rstrui.exe' }))

    $points = @(Get-PCORestorePoints | Where-Object { $_ })
    $sp = New-Object Windows.Controls.StackPanel
    if ($points.Count -eq 0) { [void]$sp.Children.Add((New-Text 'Noch keine Wiederherstellungspunkte vorhanden.' 13)) }
    foreach ($pt in ($points | Select-Object -First 6)) { [void]$sp.Children.Add((New-Text ($pt.DateText + '   ' + $pt.Description) -Role 'small' -Top 4)) }
    if ($points.Count -gt 6) { [void]$sp.Children.Add((New-Text "… und $($points.Count - 6) weitere" -Role 'small' -Color 'ink-muted' -Top 4)) }
    $mb = New-ActionButton 'Alle anzeigen und verwalten (auch löschen)' { Show-RestorePointManager }
    $mb.HorizontalAlignment = 'Left'
    [void]$sp.Children.Add($mb)
    Add-Wiz (New-ExpanderBox "Vorhandene Wiederherstellungspunkte anzeigen ($($points.Count))" $sp)
}

$script:PartExplain = @{
    'Betriebssystem' = 'Die Windows-Version.'
    'Gerätetyp' = 'Laptops sparen Strom für den Akku, Desktop-PCs dürfen voll aufdrehen.'
    'Prozessor' = 'Das Gehirn des PCs.'
    'Arbeitsspeicher' = 'Das Kurzzeitgedächtnis (RAM). 16 GB sind für die meisten ideal.'
    'Grafik' = 'Erzeugt das Bild. Für Spiele die wichtigste Hardware.'
    'Mainboard' = 'Die Hauptplatine, auf der die gesamte Hardware steckt.'
    'BIOS/UEFI' = 'Die Grundsoftware des Mainboards. Sie startet vor Windows.'
    'Laufwerke' = 'Speicher für Windows, Programme und Dateien. SSDs sind viel schneller als HDDs.'
}

function Add-FindingRows($findings) {
    foreach ($f in @($findings | Where-Object { $_ } | Sort-Object @{ e = { $_.Level }; Descending = $true })) {
        $more = (@($f.Detail, $f.Help) | Where-Object { $_ }) -join "`n`n"
        Add-Wiz (New-ItemRow -Level $f.Level -Title $f.Title -Now (Get-FirstSentence $f.Detail) -Do $f.Do -Benefit $f.Benefit -More $more -Buttons (Get-FindingButtons $f))
    }
}

function Show-WizSystem {
    $d = $script:Wiz.Data['system']
    $issues = @($d.Findings | Where-Object { $_.Level -ge 2 })
    $hints = @($d.Findings | Where-Object { $_.Level -eq 1 })
    $ok = @($d.Findings | Where-Object { $_.Level -eq 0 })

    if ($issues.Count -gt 0) {
        $lvl = ($issues | Measure-Object Level -Maximum).Maximum
        Add-NextStep -Level $lvl -Headline "$($issues.Count) Punkt(e) bremsen deinen PC" `
            -Text 'Diese Punkte lassen sich nicht per Klick beheben. Unten steht jeweils, was zu tun ist. Du kannst den Schritt auch überspringen.' `
            -Primary (New-NextButton)
        Add-Section 'Das bremst deinen PC'
        Add-FindingRows $issues
    } else {
        Add-NextStep -Level 0 -Headline 'Dein PC ist gut ausgestattet' -Text 'Hier ist nichts zu tun.' -Primary (New-NextButton)
    }
    if ($hints.Count -gt 0) {
        Add-Section 'Hinweise (nicht dringend)'
        Add-FindingRows $hints
    }

    # Hardware kompakt
    Add-Section 'Deine Hardware'
    $card = New-Object Windows.Controls.Border
    [void](Set-Card $card)
    $card.Padding = New-Thickness 14 8 14 10; $card.Margin = New-Thickness 0 0 0 8
    $grid = New-Object Windows.Controls.StackPanel
    foreach ($s in @($d.Summary)) {
        $row = New-Object Windows.Controls.DockPanel
        $row.Margin = New-Thickness 0 4 0 0
        $label = New-Text $s.Label -Role 'small' -Bold -Color 'ink-muted'
        $label.Width = 150
        if ($script:PartExplain.ContainsKey($s.Label)) { $label.ToolTip = $script:PartExplain[$s.Label]; $row.ToolTip = $script:PartExplain[$s.Label] }
        [Windows.Controls.DockPanel]::SetDock($label, 'Left')
        [void]$row.Children.Add($label)
        [void]$row.Children.Add((New-Text $(if ($s.Value) { [string]$s.Value } else { '-' }) 13))
        [void]$grid.Children.Add($row)
    }
    $card.Child = $grid
    Add-Wiz $card
    Add-OkExpander "In Ordnung ($($ok.Count))" ($ok | ForEach-Object { $_.Title + $(if ($_.Detail) { ' – ' + $_.Detail } else { '' }) })
}

function New-ColoredLine([string]$Text, [int]$Level, [double]$Indent = 0, [switch]$Bold) {
    $dp = New-Object Windows.Controls.DockPanel
    $dp.Margin = New-Thickness $Indent 4 0 0
    $i = New-LineIcon $script:LevelIconKind[$Level] $script:LevelToken[$Level] 16
    $i.Margin = New-Thickness 0 2 8 0; $i.VerticalAlignment = 'Top'
    [Windows.Controls.DockPanel]::SetDock($i, 'Left'); [void]$dp.Children.Add($i)
    [void]$dp.Children.Add((New-Text $Text -Role 'small' -Bold:$Bold))
    return $dp
}

function New-DriverOverview($devices) {
    $overview = New-Object Windows.Controls.StackPanel
    foreach ($grp in ($devices | Group-Object Category)) {
        $items = @($grp.Group)
        $hw = @($items | Where-Object { $_.Class -ne 'SOFTWARE' })
        $head = if ($hw.Count -gt 0) { "$($grp.Name)  ($($hw.Count))" } else { $grp.Name }
        [void]$overview.Children.Add((New-Text $head 14 -Bold -Top 10))
        foreach ($i in $items) {
            $detail = $i.Status
            if ($i.Version) { $detail += ", Version $($i.Version)" }
            if ($i.Date) { $detail += " vom $($i.Date)" }
            [void]$overview.Children.Add((New-ColoredLine ("{0}   -   {1}" -f $i.Device, $detail) $i.Level 12))
        }
    }
    return $overview
}

# Offizielle Support-Seiten bekannter PC- und Mainboard-Hersteller (keine Suchmaschine -> keine Werbung für Drittanbieter)
$script:SupportPages = @(
    @{ Rx = 'ASUS'; Name = 'ASUS'; U = 'https://www.asus.com/de/support/' }
    @{ Rx = 'Micro-Star|MSI'; Name = 'MSI'; U = 'https://de.msi.com/support' }
    @{ Rx = 'Gigabyte'; Name = 'Gigabyte'; U = 'https://www.gigabyte.com/de/Support' }
    @{ Rx = 'ASRock'; Name = 'ASRock'; U = 'https://www.asrock.com/support/index.de.asp' }
    @{ Rx = 'Dell|Alienware'; Name = 'Dell'; U = 'https://www.dell.com/support/home/de-de' }
    @{ Rx = 'HP|Hewlett'; Name = 'HP'; U = 'https://support.hp.com/de-de/drivers' }
    @{ Rx = 'Lenovo'; Name = 'Lenovo'; U = 'https://pcsupport.lenovo.com/de/de' }
    @{ Rx = 'Acer'; Name = 'Acer'; U = 'https://www.acer.com/de-de/support' }
    @{ Rx = 'Medion'; Name = 'Medion'; U = 'https://www.medion.com/de/service/start/' }
)

# Konkrete Hilfe, wenn Windows Update keinen Treiber für ein Gerät findet
function Get-DeviceHelp($t) {
    $id = [string]$t.DeviceId
    if ($id -match 'VEN_1022') {
        return @{ Label = 'AMD Chipsatz-Treiber herunterladen'; Url = 'https://www.amd.com/de/support/download/drivers.html'
                  Text = 'Das Gerät gehört zum AMD-Chipsatz. Lade auf der AMD-Seite den Chipsatz-Treiber für dein Mainboard herunter und installiere ihn.' }
    }
    if ($id -match 'VEN_8086') {
        return @{ Label = 'Intel Driver & Support Assistant'; Url = 'https://www.intel.de/content/www/de/de/support/detect.html'
                  Text = 'Das Gerät stammt von Intel. Der Intel Driver & Support Assistant erkennt es und installiert den passenden Treiber.' }
    }
    $sup = [string]$script:Wiz.Data['drivers'].Support
    $page = $script:SupportPages | Where-Object { $sup -match $_.Rx } | Select-Object -First 1
    if ($page) {
        return @{ Label = "Support-Seite von $($page.Name) öffnen"; Url = $page.U
                  Text = "Lade den Treiber von der Support-Seite für dein Gerät ($sup) herunter. Meist hilft der Chipsatz-Treiber." }
    }
    $q = if ($sup) { "$sup Treiber Download" } else { 'Mainboard Chipsatz Treiber Download' }
    return @{ Label = 'Support-Seite suchen'; Url = ('https://www.google.com/search?q=' + [uri]::EscapeDataString($q))
              Text = "Lade den Treiber von der Support-Seite deines PC- bzw. Mainboard-Herstellers$(if ($sup) { " ($sup)" }) herunter – meist hilft der Chipsatz-Treiber. Öffne in den Suchergebnissen nur die offizielle Seite des Herstellers, keine Anzeigen." }
}

# Ist eine Treiberaufgabe nach der Suche nur noch von Hand lösbar?
function Test-DriverTodoManual($t) {
    $s = $script:Wiz.Data['driverSearch']
    return ($t.Kind -eq 'wu' -and $s -and $s.Ok -and @($script:Wiz.Data['driverUpdates'] | Where-Object { $_ }).Count -eq 0)
}

# ---------------------------------------------------------------------------
#  Vor der Treiberprüfung: Ist die Software des Grafikkarten-Herstellers installiert?
#  Fehlt sie, muss sie zuerst installiert werden. Überspringen nur mit ausdrücklicher Bestätigung.
# ---------------------------------------------------------------------------
function Get-MissingVendorSoftware { @($script:Wiz.Data['gpusw'].Items | Where-Object { $_ -and $_.Level -ge 2 }) }
function Test-SoftwareGate { $script:Wiz.Data.ContainsKey('gpusw') -and -not $script:Wiz.SoftwareSkipped -and (Get-MissingVendorSoftware).Count -gt 0 }

function Confirm-SkipVendorSoftware {
    $miss = @(Get-MissingVendorSoftware)
    $names = ($miss | ForEach-Object { '- ' + $_.Product + '  (für ' + $_.Device + ')' }) -join "`n"
    $msg = "Die Software deines Grafikkarten-Herstellers fehlt:`n`n$names`n`n" +
           "Sie wird zwingend empfohlen. Ohne sie fehlen der passende Original-Treiber, automatische Treiber-Updates und wichtige Einstellungen (z. B. G-Sync/FreeSync, Spielprofile). Das kann Leistung kosten und zu Bildfehlern führen.`n`n" +
           "Wirklich ohne die Hersteller-Software fortfahren?"
    $r = [Windows.MessageBox]::Show($window, $msg, 'Hersteller-Software fehlt', 'YesNo', 'Warning', 'No')
    if ($r -ne 'Yes') { return $false }
    $script:Wiz.SoftwareSkipped = $true
    Add-WizLog ('Hersteller-Software übersprungen: ' + (($miss | ForEach-Object { $_.Product }) -join ', '))
    return $true
}

function Show-WizSoftwareGate {
    $miss = @(Get-MissingVendorSoftware)
    $one = $miss.Count -eq 1
    $a = @($miss[0].Finding.Actions | Where-Object { $_ })
    $prim = if ($a.Count) { New-ActionButton 'Jetzt herunterladen' { param($x) Invoke-Target $x } $a[0].T } else { $null }
    Add-NextStep -Level 3 -Headline $(if ($one) { "Zuerst: $($miss[0].Product) installieren" } else { 'Zuerst: Software der Grafikkarten-Hersteller installieren' }) `
        -Text ('Bevor die Treiber geprüft werden, muss die Software deines Grafikkarten-Herstellers installiert sein. Sie bringt den passenden Original-Treiber gleich mit und hält ihn automatisch aktuell. ' +
               'Erst danach geht es hier weiter.') `
        -Primary $prim -Secondary (New-ActionButton 'Installiert? Erneut prüfen' { Invoke-WizRecheck })

    Add-Section 'So gehst du vor'
    Add-Wiz (New-NumberRow '1' 'Herunterladen' 'Klick auf »Jetzt herunterladen«. Die offizielle Seite des Herstellers öffnet sich im Browser.')
    Add-Wiz (New-NumberRow '2' 'Installieren' 'Öffne die heruntergeladene Datei und folge dem Installationsprogramm. Bei NVIDIA und AMD kommt der Grafiktreiber gleich mit.')
    Add-Wiz (New-NumberRow '3' 'Erneut prüfen' 'Komm zurück in dieses Fenster und klick oben auf »Installiert? Erneut prüfen«. Dann startet die Treiberprüfung.')

    Add-Section $(if ($one) { 'Zwingend erforderlich' } else { "Zwingend erforderlich ($($miss.Count))" })
    foreach ($m in $miss) {
        $btns = @(); $first = $true
        foreach ($x in @($m.Finding.Actions | Where-Object { $_ })) { $btns += New-ActionButton $x.L { param($y) Invoke-Target $y } $x.T -Primary:$first; $first = $false }
        Add-Wiz (New-ItemRow -Level 3 -Title $m.Product -Now "Nicht installiert – gehört zu deiner Grafikkarte $($m.Device)" -NowLabel 'Aktuell:' -Target 'Installiert (nur von der offiziellen Herstellerseite)' `
            -Benefit 'Original-Treiber, automatische Treiber-Updates und alle Grafik-Einstellungen (z. B. G-Sync/FreeSync, Spielprofile).' -More ($m.Finding.Detail + "`n`n" + $m.Finding.Help) -Buttons $btns)
    }
    $ok = @($script:Wiz.Data['gpusw'].Items | Where-Object { $_ -and $_.Level -eq 0 })
    foreach ($o in $ok) { Add-Wiz (New-ItemRow -Level 0 -Compact -Title $o.Product -Now $o.Status -NowLabel '') }

    # Überspringen: bewusst klein und nur mit Warnung
    $skip = New-ActionButton 'Ohne Hersteller-Software mit der Treiberprüfung fortfahren (nicht empfohlen)' {
        if (Confirm-SkipVendorSoftware) { Show-WizStep $script:Wiz.Index }
    }
    $skip.HorizontalAlignment = 'Left'; $skip.Margin = New-Thickness 0 18 0 0
    Add-Wiz $skip
}

function Show-WizDrivers {
    $d = $script:Wiz.Data['drivers']
    $todo = @($d.Drv.Todo | Where-Object { $_ })
    $devices = @($d.Drv.Drivers | Where-Object { $_ })
    $hwCount = @($devices | Where-Object { $_.Class -ne 'SOFTWARE' }).Count
    $search = $script:Wiz.Data['driverSearch']
    $ups = @($script:Wiz.Data['driverUpdates'] | Where-Object { $_ })

    # Box »Dein nächster Schritt« - das Ergebnis einer Suche hat Vorrang
    if ($search -and -not $search.Ok) {
        Add-NextStep -Level 2 -Headline 'Die Suche bei Windows Update hat nicht geklappt' `
            -Text "Grund: $($search.Error)`nPrüf die Internetverbindung und versuch es noch einmal." `
            -Primary (New-ActionButton 'Erneut suchen' { Start-WizDriverSearch }) -Secondary (New-SkipButton)
    } elseif ($ups.Count -gt 0) {
        Add-NextStep -Level 2 -Headline $(if ($ups.Count -eq 1) { 'Windows Update hat 1 passenden Treiber gefunden' } else { "Windows Update hat $($ups.Count) passende Treiber gefunden" }) `
            -Text 'Installiere sie jetzt. Vorher legt TuneRig einen Wiederherstellungspunkt an und prüft danach, ob alles behoben ist.' `
            -Primary (New-ActionButton $(if ($ups.Count -eq 1) { 'Jetzt installieren' } else { "Jetzt alle $($ups.Count) installieren" }) { Start-WizDriverInstallSelected }) `
            -Secondary (New-SkipButton)
    } elseif ($todo.Count -gt 0) {
        $first = $todo[0]
        if (Test-DriverTodoManual $first) {
            $h = Get-DeviceHelp $first
            Add-NextStep -Level $first.Level -Headline "Windows Update hat keinen Treiber für »$($first.Device)« gefunden" `
                -Text ("So geht es weiter: " + $h.Text + "`nKlick nach der Installation auf »Erneut prüfen«.") `
                -Primary (New-ActionButton $h.Label { param($u) Open-Target $u } $h.Url) -Secondary (New-SkipButton)
        } else {
            $a = @($first.Actions | Where-Object { $_ })
            $prim = if ($a.Count) { New-ActionButton $a[0].L { param($x) Invoke-Target $x } $a[0].T } else { $null }
            $head = if ($todo.Count -gt 1) { "Aufgabe 1 von $($todo.Count): $($first.Title)" } else { $first.Title }
            $after = if ($first.Kind -eq 'wu') { "`nDie Suche dauert 1 bis 3 Minuten. Das Ergebnis erscheint danach genau hier." } else { "`nKlick nach der Installation auf »Erneut prüfen«." }
            Add-NextStep -Level $first.Level -Headline $head -Text ("Vorteil: " + $first.Benefit + $after) -Primary $prim -Secondary (New-SkipButton)
        }
    } else {
        $okSw = @($d.Drv.Software | Where-Object { $_.Level -eq 0 } | ForEach-Object { $_.Product })
        $txt = "Alle $hwCount Geräte haben einen funktionierenden Treiber."
        if ($okSw.Count) { $txt += " Die Software deiner Grafikkarte ($($okSw -join ', ')) ist installiert und hält den Grafiktreiber aktuell." }
        if ($search -and $search.Ok) { $txt += ' Windows Update bietet keine neueren Treiber an.' }
        Add-NextStep -Level 0 -Headline 'Kein Handlungsbedarf bei den Treibern' -Text $txt -Primary (New-NextButton)
    }

    # Gefundene Treiber (Auswahl)
    if ($ups.Count -gt 0) {
        Add-Section "Gefundene Treiber ($($ups.Count))"
        $sp = New-Object Windows.Controls.StackPanel
        $script:Wiz.UpdateChecks = @()
        foreach ($u in $ups) {
            $cb = New-CheckRow $u.Title $true ("Hersteller: {0}   ·   Treiberdatum: {1}" -f $u.Manufacturer, $u.Date)
            $script:Wiz.UpdateChecks += @{ Cb = $cb; Id = $u.Id; Title = $u.Title }
            [void]$sp.Children.Add($cb)
        }
        [void]$sp.Children.Add((New-Text 'Empfehlung: alle installieren. Nimm den Haken weg, wenn du einen Treiber nicht willst.' -Role 'small' -Color 'ink-muted' -Top 8))
        $card = New-Object Windows.Controls.Border
        [void](Set-Card $card)
        $card.Padding = New-Thickness 14 6 14 12; $card.Margin = New-Thickness 0 0 0 8
        $card.Child = $sp
        Add-Wiz $card
    }

    # Aufgaben
    if ($todo.Count -gt 0) {
        Add-Section "Deine Aufgaben ($($todo.Count))"
        $nr = 0
        foreach ($t in $todo) {
            $nr++
            $more = [string]$t.Detail
            if ($t.DeviceId) { $more += "`n`nGeräte-ID: $($t.DeviceId)`nMit dieser Kennung findet ein Fachmann den passenden Treiber." }
            if (Test-DriverTodoManual $t) {
                $h = Get-DeviceHelp $t
                Add-Wiz (New-ItemRow -Level $t.Level -Title "$nr.  $($t.Title)" -Now 'Windows Update hat keinen passenden Treiber gefunden.' -NowLabel 'Ergebnis:' `
                    -Do $h.Text -Benefit $t.Benefit -More $more `
                    -Buttons @((New-ActionButton $h.Label { param($u) Open-Target $u } $h.Url), (New-ActionButton 'Geräte-Manager öffnen' { Open-Target 'devmgmt.msc' })))
            } else {
                $btns = @(); $firstBtn = $true
                foreach ($x in @($t.Actions | Where-Object { $_ })) { $btns += New-ActionButton $x.L { param($y) Invoke-Target $y } $x.T -Primary:$firstBtn; $firstBtn = $false }
                $do = if ($t.Kind -eq 'wu' -and $ups.Count -gt 0) { 'Passende Treiber wurden gefunden - oben installieren.' } else { '' }
                Add-Wiz (New-ItemRow -Level $t.Level -Title "$nr.  $($t.Title)" -Now (Get-FirstSentence $t.Detail) -NowLabel 'Problem:' -Do $do -Benefit $t.Benefit -More $more -Buttons $btns)
            }
        }
    }

    # Wichtiger Hinweis - kurz, Details aufklappbar
    Add-Wiz (New-ItemRow -Level 2 -Title 'Wichtig: Nur originale Treiber installieren' `
        -Now 'Treiber nur über Windows Update oder die Seite bzw. App des Herstellers installieren.' -NowLabel 'Regel:' `
        -Benefit 'Schutz vor Leistungseinbußen, Abstürzen und Schadsoftware durch falsche Treiber.' `
        -More 'Meide Treiber-Updater, Treiber-Pakete und Download-Seiten von Drittanbietern. Dort gibt es oft falsche, veraltete oder veränderte Treiber – die Folge können massive Leistungseinbußen, Abstürze oder Schadsoftware sein. Die Adresse im Browser muss auf nvidia.com, amd.com, intel.de / intel.com oder die Seite deines PC-Herstellers enden. Die Buttons in TuneRig führen immer direkt dorthin.')

    # Optional: neuere Treiber
    Add-Section 'Optional'
    $buttons = @()
    if (-not $search) { $buttons += New-ActionButton 'Bei Windows Update suchen' { Start-WizDriverSearch } }
    $buttons += @(Get-VendorButtons $d.Gpus)
    $now = if ($search) { 'Windows Update wurde bereits durchsucht - das Ergebnis steht oben.' } else { 'Windows Update durchsuchen (1 bis 3 Minuten). Es wird noch nichts installiert.' }
    Add-Wiz (New-ItemRow -Level 1 -Title 'Nach neueren Treibern suchen' -Now $now -NowLabel 'Was passiert:' `
        -Benefit 'Neuere Treiber können Fehler beheben und etwas mehr Leistung bringen.' -Buttons $buttons)

    Add-Wiz (New-ExpanderBox "Installierte Treiber anzeigen ($hwCount Geräte)" (New-DriverOverview $devices))
}

function Start-WizDriverSearch {
    Start-Work -Status 'Suche bei Windows Update nach Treibern ... (1 bis 3 Minuten)' -Script {
        try { [pscustomobject]@{ Ok = $true; Error = ''; Updates = @(Search-DriverUpdates) } }
        catch { [pscustomobject]@{ Ok = $false; Error = $_.Exception.Message; Updates = @() } }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $script:Wiz.Data['driverSearch'] = [pscustomobject]@{ Ok = [bool]$r.Ok; Error = [string]$r.Error }
        $script:Wiz.Data['driverUpdates'] = @($r.Updates | Where-Object { $_ })
        $n = @($script:Wiz.Data['driverUpdates']).Count
        $wuTodo = @($script:Wiz.Data['drivers'].Drv.Todo | Where-Object { $_ -and $_.Kind -eq 'wu' }).Count
        $msg = if (-not $r.Ok) { "Die Suche hat nicht geklappt.`n`nGrund: $($r.Error)`n`nPrüf die Internetverbindung und versuch es noch einmal." }
               elseif ($n -gt 0) { "Windows Update hat $n passende(n) Treiber gefunden.`n`nDu kannst sie jetzt oben mit einem Klick installieren." }
               elseif ($wuTodo -gt 0) { "Windows Update hat keinen passenden Treiber gefunden.`n`nOben steht jetzt, wie du den Treiber stattdessen bekommst." }
               else { "Windows Update bietet keine neueren Treiber an. Deine Treiber sind aktuell." }
        Set-Status ($msg -replace "`n+", ' ')
        Show-WizStep $script:Wiz.Index
        Show-Info $msg 'Ergebnis der Treibersuche'
    }
}

function Start-WizDriverInstallSelected {
    $sel = @($script:Wiz.UpdateChecks | Where-Object { $_.Cb.IsChecked })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens einen Treiber anhaken (unter »Gefundene Treiber«).'; return }
    if (-not (Confirm-Action "$($sel.Count) Treiber werden jetzt installiert.`n`nVorher wird ein Wiederherstellungspunkt erstellt. Während der Installation kann der Bildschirm kurz schwarz werden oder flackern - das ist normal.`n`nFortfahren?")) { return }
    $script:State.WizAfter = $null
    Invoke-WizDriverInstall @($sel | ForEach-Object { $_.Id })
}

# ---------------------------------------------------------------------------
#  Änderungen ausführen (von Buttons im Schritt oder aus dem Weiter-Dialog)
#  Nach Abschluss wird $script:State.WizAfter ausgeführt (z. B. "zum nächsten Schritt"),
#  sonst wird der aktuelle Schritt neu angezeigt.
# ---------------------------------------------------------------------------
function Complete-WizAction {
    $after = $script:State.WizAfter
    $script:State.WizAfter = $null
    if ($after) { & $after } else { Show-WizStep $script:Wiz.Index }
}

function Invoke-WizDriverInstall([string[]]$Ids) {
    $script:State.Pending = @{ Ids = @($Ids) }
    Invoke-WithRestorePoint 'Treiber-Updates' {
        Start-Work -Status 'Installiere Treiber ... (bitte den PC nicht ausschalten)' -Arguments @(, $script:State.Pending.Ids) -Script { Install-DriverUpdates $A[0] } -OnDone {
            param($r) $msg = [string](@($r)[-1])
            Add-WizLog "Treiber installiert: $msg"
            Add-WizChange 'Treiber' 'Treiber über Windows Update installiert' $msg 0
            if ($msg -match 'neu') { $script:Wiz.NeedsRestart = $true }
            [void]$script:Wiz.Data.Remove('driverUpdates'); [void]$script:Wiz.Data.Remove('drivers'); [void]$script:Wiz.Data.Remove('driverSearch')
            Show-Info $msg 'Treiber-Updates'
            Complete-WizAction
        }
    }
}

function Invoke-WizTweaks([string[]]$Ids) {
    $tw = @($script:Wiz.Data['settings'].Tweaks | Where-Object { $Ids -contains $_.Id })
    $script:State.Pending = @{ Ids = @($tw | ForEach-Object { $_.Id }); Names = @($tw | ForEach-Object { $_.Title }); Restart = [bool]($tw | Where-Object { $_.Restart }) }
    Invoke-WithRestorePoint 'Leistungseinstellungen' {
        Start-Work -Status 'Wende Einstellungen an ...' -Arguments @(, $script:State.Pending.Ids) -Script {
            $e = @(Invoke-Tweaks $A[0]); $l = Test-IsLaptop
            [pscustomobject]@{ Errors = $e; Tweaks = @(Get-Tweaks $l); Laptop = $l }
        } -OnDone {
            param($r) $r = @($r)[-1]
            $errs = @($r.Errors | Where-Object { $_ })
            foreach ($n in $script:State.Pending.Names) { Add-WizLog "Einstellung verbessert: $n" }
            foreach ($id in $script:State.Pending.Ids) {
                $nt = @($r.Tweaks | Where-Object { $_.Id -eq $id })[0]
                if ($nt -and $nt.Optimal) { Add-WizChange 'Einstellungen' "$($nt.Title): $($nt.State)" $nt.Benefit $(if ($script:ImpactLevel.ContainsKey($id)) { $script:ImpactLevel[$id] } else { 1 }) }
            }
            if ($script:State.Pending.Restart) { $script:Wiz.NeedsRestart = $true }
            $script:Wiz.Data['settings'] = [pscustomobject]@{ Tweaks = $r.Tweaks; Laptop = $r.Laptop }
            if ($errs.Count -gt 0) { Show-Info ("Einige Einstellungen konnten nicht geändert werden:`n" + ($errs -join "`n")) }
            Set-Status $(if ($script:State.Pending.Restart) { 'Erledigt. Ein Teil wirkt erst nach einem Neustart - der Button dafür kommt am Ende des Checks.' } else { 'Erledigt. Die Einstellungen sind übernommen.' })
            Complete-WizAction
        }
    }
}

# Leistung: erst Einstellungen (mit Wiederherstellungspunkt), danach Spiele auf Hohe Leistung
function Invoke-WizPerformance([string[]]$TweakIds, [string[]]$Exes) {
    $TweakIds = @($TweakIds | Where-Object { $_ }); $Exes = @($Exes | Where-Object { $_ })
    if ($TweakIds.Count -eq 0) { Set-WizGamesHigh $Exes; return }
    if ($Exes.Count -gt 0) {
        $script:State.ChainAfter = $script:State.WizAfter
        $script:State.ChainGames = $Exes
        $script:State.WizAfter = { $script:State.WizAfter = $script:State.ChainAfter; Set-WizGamesHigh $script:State.ChainGames }
    }
    Invoke-WizTweaks $TweakIds
}

function Set-WizGamesHigh([string[]]$Exes) {
    $games = @($script:Wiz.Data['gpu'].Games)
    foreach ($g in $games | Where-Object { $Exes -contains $_.Exe }) {
        try { Set-GpuHighPerformance $g.Exe; Add-WizLog "Hohe Leistung für Spiel: $($g.Name)"; Add-WizChange 'Grafikkarte' "$($g.Name): Hohe Leistung" 'Das Spiel läuft jetzt immer auf der starken Grafikkarte - mehr FPS, flüssigeres Bild.' 3 } catch { Show-Error "$($g.Name): $($_.Exception.Message)" }
    }
    foreach ($g in $games) { $g.Preference = Get-GpuPreference $g.Exe }
    Set-Status 'Erledigt. Bereits laufende Spiele bitte einmal neu starten.'
    Complete-WizAction
}

function Invoke-WizCleanup([string[]]$Ids) {
    Start-Work -Status 'Räume auf ... (Dateien, die gerade benutzt werden, werden übersprungen)' -Arguments @(, @($Ids)) -Script {
        $freed = 0L
        foreach ($id in $A[0]) { Report "Räume auf: $id ..."; $freed += [long](@(Invoke-Cleanup $id)[-1]) }
        [pscustomobject]@{ Freed = $freed; Measures = @(foreach ($d in Get-CleanupDefs) { if ($d.Id -ne 'winsxs') { Measure-Cleanup $d.Id } }) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Add-WizLog "Aufgeräumt: $(Format-Bytes $r.Freed) freigegeben"
        Add-WizChange 'Aufräumen' "$(Format-Bytes $r.Freed) Speicherplatz freigegeben" 'Mehr Platz für Windows-Updates und Programme.' -1
        $script:Wiz.Data['cleanup'] = [pscustomobject]@{ Measures = $r.Measures }
        $script:Wiz.CleanupDone = $true
        $script:Wiz.LastFreed = [long]$r.Freed
        Complete-WizAction
    }
}

# Noch nicht übernommene Änderungen eines Schritts (für die Rückfrage beim Klick auf Weiter)
function New-Pending([string]$Kind, [string]$Id, [string]$Text, [string]$Detail, [bool]$Rec = $true) {
    [pscustomobject]@{ Kind = $Kind; Id = $Id; Text = $Text; Detail = $Detail; Rec = $Rec }
}

# Offene Punkte eines Schritts für die Rückfrage beim Verlassen.
#   change = kann TuneRig direkt erledigen (mit Häkchen im Dialog)
#   info   = muss der Nutzer selbst erledigen (Download, Kabel umstecken ...)
function Get-WizPending([string]$Id) {
    switch ($Id) {
        'safety' {
            if (-not $script:State.LastRestore) {
                New-Pending 'change' 'restore' 'Wiederherstellungspunkt erstellen (empfohlen)' 'Dauert etwa eine Minute. Damit lässt sich jede spätere Änderung rückgängig machen.'
            }
        }
        'system' {
            $d = $script:Wiz.Data['system']; if (-not $d) { return }
            foreach ($f in @($d.Findings | Where-Object { $_.Level -ge 2 })) { New-Pending 'info' '' $f.Title $f.Help }
        }
        'drivers' {
            if (Test-SoftwareGate) {
                foreach ($m in @(Get-MissingVendorSoftware)) { New-Pending 'info' '' "$($m.Product) installieren (zwingend empfohlen)" 'Download-Button im Schritt Treiber - danach »Erneut prüfen«.' }
                return
            }
            $d = $script:Wiz.Data['drivers']
            if ($d) {
                foreach ($t in @($d.Drv.Todo | Where-Object { $_ })) {
                    $how = if (Test-DriverTodoManual $t) { 'Windows Update hat nichts gefunden - Treiber von der Herstellerseite laden (Button im Schritt).' } else { 'Im Schritt über den Button: ' + (@($t.Actions)[0].L) }
                    New-Pending 'info' '' $t.Title $how
                }
            }
            foreach ($c in @($script:Wiz.UpdateChecks | Where-Object { $_ -and $_.Cb.IsChecked })) {
                New-Pending 'change' $c.Id "Treiber installieren: $($c.Title)" 'über Windows Update'
            }
        }
        'settings' {
            $d = $script:Wiz.Data['settings']
            if ($d) {
                foreach ($t in @($d.Tweaks | Where-Object { -not $_.Optimal })) {
                    New-Pending 'change' $t.Id ($t.Title + $(if ($t.Optional) { '  (optional, nicht vorausgewählt)' } else { '' })) `
                        ("Aktuell: $($t.State)  →  Empfohlen: $($t.Target)" + $(if ($t.Restart) { '  -  wirkt nach einem Neustart' } else { '' })) (-not $t.Optional)
                }
            }
            Get-WizPending 'settings-gpu'
        }
        'settings-gpu' {
            $d = $script:Wiz.Data['gpu']; if (-not $d) { return }
            foreach ($f in @($d.Gpu.Findings | Where-Object { $_.Level -ge 2 })) { New-Pending 'info' '' $f.Title $f.Help }
            if (@($d.Gpu.Gpus).Count -ge 2 -and @($d.Gpu.Gpus | Where-Object { $_.Discrete }).Count) {
                foreach ($g in @($d.Games | Where-Object { $_.Preference -ne 'Hohe Leistung' })) {
                    New-Pending 'change' $g.Exe "Hohe Leistung für $($g.Name)" "Aktuell: $($g.Preference)"
                }
            }
        }
        { $_ -in 'g-display', 'g-system', 'g-network' } {
            $d = $script:Wiz.Data[$Id]; if (-not $d) { return }
            foreach ($t in @($d.Tweaks | Where-Object { -not $_.Optimal })) {
                $suffix = switch ($t.Mode) { 'optional' { '  (optional, mit Nebenwirkung)' } 'experimental' { '  (experimentell)' } default { '' } }
                New-Pending 'change' $t.Id ($t.Title + $suffix) ("Aktuell: $($t.State)  →  Empfohlen: $($t.Target)") ($t.Mode -eq 'recommended')
            }
        }
        'g-startup' {
            $d = $script:Wiz.Data['g-startup']; if (-not $d) { return }
            foreach ($i in @($d.Items | Where-Object { $_.Enabled -and $_.Class -eq 'off' })) { New-Pending 'change' $i.Id "Autostart abschalten: $($i.Name)" 'Startet nicht mehr automatisch mit Windows' }
        }
        'cleanup' {
            if ($script:Wiz.CleanupDone) { return }
            $d = $script:Wiz.Data['cleanup']; if (-not $d) { return }
            $measure = @{}; foreach ($m in @($d.Measures)) { $measure[$m.Id] = $m }
            # Unter 200 MB gilt Aufräumen als nicht nötig - dann keine Empfehlung (passend zur Box oben)
            $sel = @($script:Wiz.Checks | Where-Object { $_.Cb.IsChecked -eq $true -and $measure[$_.Id] -and $measure[$_.Id].Size -gt 1MB })
            $sum = 0L; foreach ($c in $sel) { $sum += [long]$measure[$c.Id].Size }
            foreach ($c in $sel) { New-Pending 'change' $c.Id "Aufräumen: $($c.Name)" "$(Format-Bytes $measure[$c.Id].Size) werden freigegeben" ($sum -ge 200MB) }
        }
    }
}

function Invoke-WizRestorePoint {
    Start-Work -Status 'Erstelle Wiederherstellungspunkt ... (dauert etwa eine Minute)' -Script { New-PCORestorePoint ('TuneRig ' + (Get-ModeName $script:Wiz.Mode)) } -OnDone {
        param($r) $res = @($r)[-1]
        if ($res.Ok) { $script:State.LastRestore = Get-Date; Add-WizLog 'Wiederherstellungspunkt erstellt'; Add-WizChange 'Windows-Sicherung' 'Wiederherstellungspunkt erstellt' 'Alle Änderungen lassen sich rückgängig machen.' -1; Set-Status $res.Message }
        else { Show-Info ($res.Message + "`n`nDu kannst trotzdem weitermachen. Vor jeder Änderung versucht TuneRig es erneut.") 'Wiederherstellungspunkt' }
        Complete-WizAction
    }
}

function Invoke-WizApply([string]$StepId, [string[]]$Ids) {
    switch ($StepId) {
        'safety' { Invoke-WizRestorePoint }
        'settings' {
            $tweakIds = @($script:Wiz.Data['settings'].Tweaks | ForEach-Object { $_.Id })
            Invoke-WizPerformance @($Ids | Where-Object { $tweakIds -contains $_ }) @($Ids | Where-Object { $tweakIds -notcontains $_ })
        }
        'cleanup' { Invoke-WizCleanup $Ids }
        'drivers' { Invoke-WizDriverInstall $Ids }
        { $_ -in 'g-display', 'g-system', 'g-network' } { Invoke-WizGamingTweaks $Ids }
        'g-startup' { Invoke-WizStartup $Ids $false }
    }
}

$script:ChangeXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Bevor es weitergeht" Width="700" SizeToContent="Height" MaxHeight="800" ResizeMode="NoResize"
        WindowStartupLocation="CenterOwner" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <DockPanel Margin="32,24">
    <TextBlock DockPanel.Dock="Top" x:Name="CdTitle" Style="{StaticResource H3}"/>
    <TextBlock DockPanel.Dock="Top" x:Name="CdIntro" Style="{StaticResource Small}" Margin="0,8,0,0"/>
    <StackPanel DockPanel.Dock="Bottom" Margin="0,24,0,0">
      <Button x:Name="CdApply" Style="{StaticResource Primary}" HorizontalContentAlignment="Center" Margin="0,0,0,8"/>
      <Button x:Name="CdSkip" Content="Überspringen (nichts ändern)" Margin="0,0,0,8"/>
      <Button x:Name="CdStay" Content="Zurück zum Schritt" Margin="0"/>
    </StackPanel>
    <Border Style="{StaticResource Card}" Margin="0,16,0,0" Padding="16,8,16,16">
      <ScrollViewer VerticalScrollBarVisibility="Auto" MaxHeight="400">
        <StackPanel x:Name="CdList"/>
      </ScrollViewer>
    </Border>
  </DockPanel>
</Window>
'@

# Zeigt die offenen Änderungen und gibt zurück: Choice = apply | skip | stay, Ids = ausgewählte Änderungen
function Show-ChangeDialog($Items, [string]$TargetText = 'weiter') {
    $script:CdDlg = [Windows.Markup.XamlReader]::Parse($script:ChangeXaml)
    $script:CdDlg.Owner = $window
    # Auf kleinen Bildschirmen (z. B. 1366 × 768) nie über den Bildschirmrand hinaus
    $wa = [Windows.SystemParameters]::WorkArea
    $script:CdDlg.MaxHeight = [Math]::Min(800.0, $wa.Height * 0.92); $script:CdDlg.Width = [Math]::Min(700.0, $wa.Width * 0.95)
    Set-WindowBranding $script:CdDlg
    $script:CdResult = @{ Choice = 'stay'; Ids = @() }
    $script:CdChecks = @()
    $changes = @($Items | Where-Object { $_.Kind -eq 'change' })
    $infos = @($Items | Where-Object { $_.Kind -eq 'info' })
    $list = $script:CdDlg.FindName('CdList')

    if ($changes.Count -gt 0) {
        $script:CdDlg.FindName('CdTitle').Text = 'Es gibt noch offene Änderungen'
        $script:CdDlg.FindName('CdIntro').Text = 'In diesem Schritt ist noch nicht alles übernommen. TuneRig kann die angehakten Punkte jetzt für dich erledigen. Nimm den Haken bei allem weg, was du nicht willst. Vor Änderungen an Windows legt TuneRig automatisch einen Wiederherstellungspunkt an.'
        $h = New-Label 'Das erledigt TuneRig für dich'; $h.Margin = New-Thickness 0 8 0 0; [void]$list.Children.Add($h)
        foreach ($it in $changes) {
            $cb = New-CheckRow $it.Text ([bool]$it.Rec) $it.Detail
            $script:CdChecks += @{ Cb = $cb; Id = $it.Id }
            [void]$list.Children.Add($cb)
        }
        $script:CdDlg.FindName('CdApply').Content = ("Jetzt anwenden und $TargetText").ToUpper()
        $script:CdDlg.FindName('CdSkip').Content = if ($TargetText -eq 'weiter') { 'Überspringen (nichts ändern)' } else { "Ohne Änderungen $TargetText" }
    } else {
        $script:CdDlg.FindName('CdTitle').Text = 'Es gibt noch offene Punkte'
        $script:CdDlg.FindName('CdIntro').Text = 'Diese Punkte kann TuneRig nicht automatisch erledigen – meist ist ein Download oder ein Handgriff am PC nötig. Die passenden Buttons findest du im Schritt. Wenn du überspringst, bleibt alles, wie es ist; die Zusammenfassung am Ende listet die Punkte noch einmal auf.'
        $script:CdDlg.FindName('CdApply').Visibility = 'Collapsed'
        $script:CdDlg.FindName('CdSkip').Content = if ($TargetText -eq 'weiter') { 'Überspringen' } else { "Trotzdem $TargetText" }
        $script:CdDlg.FindName('CdStay').Content = 'Zurück zum Schritt'
    }
    if ($infos.Count -gt 0) {
        $h = New-Label 'Das erledigst du selbst (Buttons im Schritt)'; $h.Margin = New-Thickness 0 16 0 0; [void]$list.Children.Add($h)
        foreach ($it in $infos) {
            [void]$list.Children.Add((New-LabeledLine '–' $it.Text 'ink-muted'))
            if ($it.Detail) { $t = New-Text $it.Detail -Role 'small' -Color 'ink-muted'; $t.Margin = New-Thickness 16 0 0 0; [void]$list.Children.Add($t) }
        }
    }
$script:CdDlg.FindName('CdApply').Add_Click({
        $ids = @($script:CdChecks | Where-Object { $_.Cb.IsChecked -eq $true } | ForEach-Object { $_.Id })
        $script:CdResult = if ($ids.Count -gt 0) { @{ Choice = 'apply'; Ids = $ids } } else { @{ Choice = 'skip'; Ids = @() } }
        $script:CdDlg.Close()
    })
    $script:CdDlg.FindName('CdSkip').Add_Click({ $script:CdResult = @{ Choice = 'skip'; Ids = @() }; $script:CdDlg.Close() })
    $script:CdDlg.FindName('CdStay').Add_Click({ $script:CdResult = @{ Choice = 'stay'; Ids = @() }; $script:CdDlg.Close() })
    [void]$script:CdDlg.ShowDialog()
    return $script:CdResult
}

# Schritt »Leistung«: Windows-Einstellungen + Grafikkarte & Spiele in einem Schritt
function Get-WizGpuState {
    $d = $script:Wiz.Data['gpu']
    $gpus = @($d.Gpu.Gpus)
    $dedicated = @($gpus | Where-Object { $_.Discrete }).Count
    $multi = $gpus.Count -gt 1 -and $dedicated -ge 1
    $games = @($d.Games)
    [pscustomobject]@{
        Gpus = $gpus; Dedicated = $dedicated; Multi = $multi; Games = $games
        OpenGames = @(if ($multi) { $games | Where-Object { $_.Preference -ne 'Hohe Leistung' } })
        Problems = @(@($d.Gpu.Findings) | Where-Object { $_ -and $_.Level -ge 2 } | Sort-Object @{ e = { $_.Level }; Descending = $true })
    }
}

function Show-WizSettings {
    $d = $script:Wiz.Data['settings']
    $tweaks = @($d.Tweaks)
    Register-TweakBefore $tweaks
    $open = @($tweaks | Where-Object { -not $_.Optimal -and -not $_.Optional })
    $optional = @($tweaks | Where-Object { -not $_.Optimal -and $_.Optional })
    $good = @($tweaks | Where-Object { $_.Optimal })
    $changed = @($good | Where-Object { Get-TweakBefore $_ })
    $same = @($good | Where-Object { -not (Get-TweakBefore $_) })
    $gs = Get-WizGpuState
    $nAct = $open.Count + $gs.OpenGames.Count

    # Box »Dein nächster Schritt«: alles, was TuneRig selbst erledigen kann, mit einem Klick
    if ($nAct -gt 0) {
        $headline = if ($open.Count -eq 0) {
            if ($gs.OpenGames.Count -eq 1) { '1 Spiel nutzt evtl. die schwächere Grafikkarte' } else { "$($gs.OpenGames.Count) Spiele nutzen evtl. die schwächere Grafikkarte" }
        } elseif ($nAct -eq 1) { '1 Einstellung bremst deinen PC' } else { "$nAct Punkte bremsen deinen PC" }
        $label = if ($nAct -eq 1 -and $open.Count -eq 1) { $open[0].Fix } elseif ($nAct -eq 1) { 'Auf Hohe Leistung stellen' } else { "Jetzt alle $nAct verbessern" }
        $text = if ($open.Count -eq 0) { 'Stell sie auf »Hohe Leistung«. Vorteil: mehr FPS und ein flüssigeres Bild, weil immer die starke Grafikkarte arbeitet.' }
                else { 'Empfehlung: verbessern. Vorher legt TuneRig automatisch einen Wiederherstellungspunkt an – alles lässt sich rückgängig machen.' }
        Add-NextStep -Level 2 -Headline $headline -Text $text -Primary (New-ActionButton $label {
                $tw = @($script:Wiz.Data['settings'].Tweaks | Where-Object { -not $_.Optimal -and -not $_.Optional })
                $gm = @((Get-WizGpuState).OpenGames)
                $names = @($tw | ForEach-Object { '- ' + $_.Title }) + @($gm | ForEach-Object { '- Hohe Leistung für ' + $_.Name })
                if (-not (Confirm-Action ("Das wird verbessert:`n`n{0}`n`nFortfahren?" -f ($names -join "`n")))) { return }
                $script:State.WizAfter = $null
                Invoke-WizPerformance @($tw | ForEach-Object { $_.Id }) @($gm | ForEach-Object { $_.Exe })
            }) -Secondary (New-SkipButton)
    } elseif ($gs.Problems.Count -gt 0) {
        $f = $gs.Problems[0]
        $a = @($f.Actions | Where-Object { $_ })
        $prim = if ($a.Count) { New-ActionButton $a[0].L { param($x) Invoke-Target $x } $a[0].T } else { New-RecheckButton }
        Add-NextStep -Level $f.Level -Headline $f.Title -Text ("So beheben: " + $f.Do + $(if ($f.Benefit) { "`nVorteil: " + $f.Benefit } else { '' })) `
            -Primary $prim -Secondary $(if ($a.Count) { New-RecheckButton } else { $null })
    } else {
        $gpuText = if ($gs.Multi) { 'Deine Spiele nutzen die starke Grafikkarte.' } elseif ($gs.Dedicated -ge 1) { 'Deine Grafikkarte arbeitet automatisch für alle Spiele.' } else { 'Dein PC nutzt die im Prozessor eingebaute Grafik – dafür ist nichts einzustellen.' }
        Add-NextStep -Level 0 -Headline 'Windows ist auf Leistung eingestellt' -Text "$gpuText Hier ist nichts zu tun." -Primary (New-NextButton)
    }

    if ($open.Count -gt 0) {
        Add-Section 'Das bremst deinen PC'
        if ($d.Laptop -and ($open | Where-Object { $_.Id -eq 'power' })) {
            Add-Wiz (New-ItemRow -Level 1 -Compact -Title 'Hinweis für Laptops' -Now 'Mehr Leistung bedeutet kürzere Akkulaufzeit und einen etwas lauteren Lüfter.' -NowLabel '')
        }
        foreach ($t in $open) {
            $benefit = $t.Benefit + $(if ($t.Restart) { ' (wirkt nach einem Neustart)' } else { '' })
            $btn = New-ActionButton $t.Fix {
                param($id)
                $script:State.WizAfter = $null
                Invoke-WizTweaks @($id)
            } $t.Id
            Add-Wiz (New-ItemRow -Level 2 -Title $t.Title -Now $t.State -Target $t.Target -Benefit $benefit -More ($t.Problem + ' ' + $t.Desc) -Buttons @($btn))
        }
    }

    if ($changed.Count -gt 0) {
        Add-Section 'In diesem Check verbessert'
        foreach ($t in $changed) { Add-Wiz (New-ItemRow -Level 0 -Compact -Title $t.Title -Now $t.State -NowLabel 'Jetzt:' -Before (Get-TweakBefore $t)) }
    }

    Show-WizGpuSection $gs

    if ($optional.Count -gt 0) {
        $sp = New-Object Windows.Controls.StackPanel
        [void]$sp.Children.Add((New-Text 'Nicht nötig – nur für sehr schwache PCs sinnvoll.' -Role 'small' -Color 'ink-muted'))
        foreach ($t in $optional) {
            $btn = New-ActionButton 'Trotzdem anwenden' {
                param($id)
                $t = @($script:Wiz.Data['settings'].Tweaks | Where-Object { $_.Id -eq $id })[0]
                if (-not (Confirm-Action ("{0} ändern?`n`n{1}" -f $t.Title, $t.Benefit))) { return }
                $script:State.WizAfter = $null
                Invoke-WizTweaks @($id)
            } $t.Id
            $row = New-ItemRow -Level 1 -Title $t.Title -Now $t.State -Target $t.Target -Benefit $t.Benefit -Buttons @($btn)
            $row.Margin = New-Thickness 0 8 0 0
            [void]$sp.Children.Add($row)
        }
        Add-Wiz (New-ExpanderBox "Optionale Einstellungen anzeigen ($($optional.Count))" $sp)
    }

    Add-OkExpander "Bereits optimal eingestellt ($($same.Count))" ($same | ForEach-Object { "$($_.Title):  $($_.State)" })
}

# Teil »Grafikkarte & Spiele« im Schritt Leistung
function Show-WizGpuSection($gs) {
    if ($gs.Problems.Count -gt 0) {
        Add-Section 'Das bremst deine Spiele'
        Add-FindingRows $gs.Problems
    }

    Add-Section 'Deine Grafikkarten'
    foreach ($g in $gs.Gpus) {
        $typ = if ($g.Discrete) { 'Dediziert (leistungsstark)' } else { 'Integriert (stromsparend)' }
        $info = "$typ  ·  Speicher: $(if ($g.Vram -gt 0) { Format-Bytes $g.Vram } else { 'unbekannt' })  ·  Monitor angeschlossen: $(if ($g.Display) { 'Ja' } else { 'Nein' })"
        Add-Wiz (New-ItemRow -Level $(if ($g.HasDriver) { 0 } else { 3 }) -Compact -Title $g.Name -Now $info -NowLabel '')
    }
    if (-not $gs.Multi) {
        $hint = if ($gs.Dedicated -ge 1) { 'Nur eine Grafikkarte vorhanden - alle Spiele nutzen automatisch diese. Hier ist nichts einzustellen.' } else { 'Keine dedizierte Grafikkarte vorhanden - Spiele nutzen die im Prozessor eingebaute Grafik.' }
        Add-Wiz (New-Text $hint -Role 'small' -Color 'ink-muted' -Top 4)
        return
    }

    Add-Section "Deine Spiele ($($gs.Games.Count))"
    if ($gs.Games.Count -eq 0) {
        Add-Wiz (New-Text 'Keine Spiele aus Steam, Epic Games oder GOG gefunden. Füg ein Spiel unten selbst hinzu.' -Role 'small' -Color 'ink-muted')
    }
    foreach ($g in $gs.Games) {
        $high = $g.Preference -eq 'Hohe Leistung'
        $btn = if (-not $high) {
            New-ActionButton 'Auf Hohe Leistung stellen' { param($exe) $script:State.WizAfter = $null; Set-WizGamesHigh @($exe) } $g.Exe
        }
        $now = if ($high) { 'Hohe Leistung (starke Grafikkarte)' } else { "$($g.Preference) - nutzt evtl. die schwache Grafikkarte" }
        Add-Wiz (New-ItemRow -Level $(if ($high) { 0 } else { 2 }) -Compact -Title $g.Name -Now $now -NowLabel 'Aktuell:' -Target $(if (-not $high) { 'Hohe Leistung (starke Grafikkarte)' } else { '' }) -Buttons @($btn))
    }
    $add = New-ActionButton '+  Weiteres Spiel hinzufügen ...' {
        $dlg = New-Object Microsoft.Win32.OpenFileDialog
        $dlg.Title = 'Programmdatei des Spiels auswählen (meist im Installationsordner des Spiels)'
        $dlg.Filter = 'Programme (*.exe)|*.exe'
        if (-not $dlg.ShowDialog($window)) { return }
        $name = (Get-Item -LiteralPath $dlg.FileName).VersionInfo.ProductName
        if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($dlg.FileName) }
        $gd = $script:Wiz.Data['gpu']
        $gd.Games = @($gd.Games) + [pscustomobject]@{ Name = $name; Source = 'Manuell'; Exe = $dlg.FileName; Preference = (Get-GpuPreference $dlg.FileName) }
        Show-WizStep $script:Wiz.Index
    }
    $add.HorizontalAlignment = 'Left'
    Add-Wiz $add
}

function Update-GroupCheck($parent) {
    $kids = @($parent.Tag.Children | Where-Object { $_.IsEnabled })
    $on = @($kids | Where-Object { $_.IsChecked -eq $true }).Count
    if ($on -eq $kids.Count) { $parent.IsChecked = $true; $parent.Tag.Mixed = $false }
    elseif ($on -eq 0) { $parent.IsChecked = $false; $parent.Tag.Mixed = $false }
    else { $parent.IsChecked = $null; $parent.Tag.Mixed = $true }
}

# Warum ein Cache leer ist - damit fehlende Einträge nicht wie ein Fehler wirken
$script:EmptyCacheReason = @{
    'browser-chrome' = 'Chrome ist nicht installiert oder der Cache ist leer'
    'browser-edge' = 'Edge-Cache ist leer'
    'browser-brave' = 'Brave ist nicht installiert'
    'browser-firefox' = 'Firefox ist nicht installiert'
    'shader-dx' = 'noch keine DirectX-Daten gespeichert'
    'shader-nvidia' = 'keine NVIDIA-Grafikkarte bzw. Cache leer'
    'shader-amd' = 'keine AMD-Grafikkarte bzw. Cache leer'
}

function New-CleanupGroup([string]$GroupId, $Children, $Measure) {
    $g = $script:CleanupGroups[$GroupId]
    $avail = @($Children | Where-Object { $m = $Measure[$_.Id]; $m -and $m.Count -gt 0 })
    $size = 0L; foreach ($k in $avail) { $size += [long]$Measure[$k.Id].Size }
    $defaultOn = [bool]@($Children)[0].Sel -and $avail.Count -gt 0
    $box = New-Object Windows.Controls.StackPanel
    $label = if ($avail.Count -gt 0) { "{0}   -   {1}   (Häkchen wählt alle aus / ab)" -f $g.Name, (Format-Bytes $size) } else { "$($g.Name)   -   nichts zu löschen" }
    $parent = New-CheckRow $label $defaultOn $g.Desc ($avail.Count -gt 0)
    [void]$box.Children.Add($parent)
    $sub = New-Object Windows.Controls.StackPanel
    $sub.Margin = New-Thickness 28 0 0 0
    $cbs = @()
    foreach ($k in @($Children)) {
        $m = $Measure[$k.Id]
        $has = $m -and $m.Count -gt 0
        $text = if ($has) { "{0}   -   {1}  ({2} Dateien)" -f $k.Short, (Format-Bytes $m.Size), $m.Count }
                else { "{0}   -   nicht vorhanden ({1})" -f $k.Short, $script:EmptyCacheReason[$k.Id] }
        $cb = New-CheckRow $text ($defaultOn -and $has) '' $has
        if (-not $has) { $cb.Opacity = 0.6 }
        $cb.Tag = $parent
        $cb.Add_Click({ Update-GroupCheck $this.Tag })
        if ($has) { $script:Wiz.Checks += @{ Cb = $cb; Id = $k.Id; Name = $k.Name } }
        $cbs += $cb
        [void]$sub.Children.Add($cb)
    }
    $parent.Tag = @{ Children = $cbs; Mixed = $false }
    $parent.Add_Click({
        $t = $this.Tag
        if ($t.Mixed) { $this.IsChecked = $true; $t.Mixed = $false }
        foreach ($c in $t.Children) { if ($c.IsEnabled) { $c.IsChecked = [bool]$this.IsChecked } }
    })
    [void]$box.Children.Add($sub)
    return $box
}

function Start-WizCleanupSelected {
    $sel = @($script:Wiz.Checks | Where-Object { $_.Cb.IsChecked -eq $true })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens einen Bereich anhaken (unter »Was wird gelöscht?«).'; return }
    if (-not (Confirm-Action ("Diese Bereiche werden jetzt geleert:`n`n{0}`n`nFortfahren?" -f (($sel | ForEach-Object { '- ' + $_.Name }) -join "`n")))) { return }
    $script:State.WizAfter = $null
    Invoke-WizCleanup @($sel | ForEach-Object { $_.Id })
}

function Show-WizCleanup {
    $d = $script:Wiz.Data['cleanup']
    $defs = @(Get-CleanupDefs | Where-Object { $_.Id -ne 'winsxs' })
    $measure = @{}; foreach ($m in @($d.Measures)) { $measure[$m.Id] = $m }
    $total = 0L; $shader = 0L
    foreach ($x in $defs) {
        if (-not $measure.ContainsKey($x.Id)) { continue }
        if ($x.Sel) { $total += [long]$measure[$x.Id].Size }
        if ($x.Group -eq 'shader') { $shader += [long]$measure[$x.Id].Size }
    }

    if ($script:Wiz.CleanupDone) {
        Add-NextStep -Level 0 -Headline "Aufgeräumt: $(Format-Bytes $script:Wiz.LastFreed) freigegeben" -Text 'Dateien, die gerade in Benutzung sind, wurden übersprungen – das ist normal.' -Primary (New-NextButton)
    } elseif ($total -ge 200MB) {
        Add-NextStep -Level 2 -Headline "Etwa $(Format-Bytes $total) können frei werden" `
            -Text 'Empfehlung: jetzt aufräumen. Gelöscht werden nur überflüssige Dateien - Fotos, Dokumente und Passwörter bleiben unberührt.' `
            -Primary (New-ActionButton 'Jetzt aufräumen' { Start-WizCleanupSelected }) -Secondary (New-SkipButton)
    } else {
        Add-NextStep -Level 0 -Headline "Kaum Datenmüll vorhanden ($(Format-Bytes $total))" -Text 'Aufräumen ist nicht nötig.' `
            -Primary (New-NextButton) -Secondary (New-ActionButton 'Trotzdem aufräumen' { Start-WizCleanupSelected })
    }

    $running = @(Get-RunningBrowsers)
    if ($running.Count -gt 0 -and -not $script:Wiz.CleanupDone) {
        Add-Wiz (New-ItemRow -Level 1 -Compact -Title "Tipp: $($running -join ', ') vorher schließen" `
            -Now 'Ein geöffneter Browser kann seinen Zwischenspeicher nicht vollständig freigeben.' -NowLabel '' `
            -Buttons @(New-RecheckButton 'Geschlossen? Neu berechnen'))
    }

    # Auswahl (nur Bereiche, die etwas enthalten)
    $panel = New-Object Windows.Controls.StackPanel
    $script:Wiz.Checks = @()
    $groupsDone = @{}
    foreach ($x in $defs) {
        if ($x.Group) {
            if ($groupsDone.ContainsKey($x.Group)) { continue }
            $groupsDone[$x.Group] = $true
            [void]$panel.Children.Add((New-CleanupGroup $x.Group @($defs | Where-Object { $_.Group -eq $x.Group }) $measure))
            continue
        }
        $m = $measure[$x.Id]
        if (-not $m -or $m.Count -eq 0) { continue }
        $cb = New-CheckRow ("{0}   -   {1}" -f $x.Name, (Format-Bytes $m.Size)) $x.Sel $x.Desc
        $script:Wiz.Checks += @{ Cb = $cb; Id = $x.Id; Name = $x.Name }
        [void]$panel.Children.Add($cb)
    }
    $note = 'Empfohlenes ist bereits angehakt. Papierkorb und Shader-Cache sind absichtlich nicht ausgewählt.'
    if ($shader -gt 0) { $note += " Der Shader-Cache ($(Format-Bytes $shader)) ist nicht mitgezählt, weil er Spiele beschleunigt." }
    [void]$panel.Children.Add((New-Text $note -Role 'small' -Color 'ink-muted' -Top 12))
    Add-Wiz (New-ExpanderBox 'Was wird gelöscht? (Auswahl ändern)' $panel)

    # Hilfe bei Rucklern
    $shaderIds = @($defs | Where-Object { $_.Group -eq 'shader' -and $measure[$_.Id] -and $measure[$_.Id].Count -gt 0 } | ForEach-Object { $_.Id })
    if ($shaderIds.Count -gt 0) {
        $script:State.ShaderIds = $shaderIds
        $tip = ''
        if ($shaderIds -contains 'shader-nvidia') { $tip += ' Vorbeugend: In der NVIDIA App die Shader-Cache-Größe erhöhen (z. B. 10 GB).' }
        if ($shaderIds -contains 'shader-amd') { $tip += ' In der AMD Software gibt es dafür auch »Shader-Cache zurücksetzen«.' }
        $row = New-ItemRow -Level 1 -Title 'Shader-Cache leeren' `
            -Now 'Nur sinnvoll, wenn ein Spiel nach einem Spiel- oder Treiber-Update dauerhaft ruckelt oder Grafikfehler zeigt.' -NowLabel 'Wann:' `
            -Benefit 'Das Spiel baut seine Grafikdaten neu auf und läuft danach wieder flüssig.' `
            -More ('Direkt nach dem Leeren ruckeln Spiele kurz, bis der Cache neu aufgebaut ist (meist einige Minuten Spielzeit). Spielstände und Einstellungen bleiben erhalten.' + $tip) `
            -Buttons @(New-ActionButton 'Shader-Cache leeren' {
                if (-not (Confirm-Action "Der Shader-Cache wird geleert.`n`nBeim nächsten Start ruckeln Spiele kurz, bis der Cache neu aufgebaut ist.`n`nFortfahren?")) { return }
                $script:State.WizAfter = $null
                Invoke-WizCleanup $script:State.ShaderIds
            })
        Add-Wiz (New-ExpanderBox 'Ruckelt ein Spiel seit einem Update? Hier klicken' $row)
    }

    # Was belegt den Rest? -> Speicherplatz-Analyse
    Add-Section 'Wo steckt der restliche Platz?'
    Add-Wiz (New-ItemRow -Level 1 -Compact -Title 'Speicherplatz analysieren' `
        -Now 'Zeigt, welche Ordner, Dateitypen und Dateien deine Laufwerke belegen – zum Hineinklicken. Ändert nichts.' -NowLabel '' `
        -Buttons @(New-ActionButton 'Analyse öffnen' { if ($script:Job) { return }; Show-Tool 'storage'; Set-Status 'Zurück zum Check geht es oben in der Leiste – dein Fortschritt bleibt erhalten.' }))
}

function Show-WizSummary {
    # Offene Punkte mit dem Schritt, in dem sie erledigt werden
    $open = @()
    $sys = $script:Wiz.Data['system']
    if ($sys) { $open += @($sys.Findings | Where-Object { $_.Level -ge 2 } | ForEach-Object { @{ Text = $_.Title; Do = $_.Do; Step = 'system' } }) }
    $drv = $script:Wiz.Data['drivers']
    if ($drv) { $open += @($drv.Drv.Todo | Where-Object { $_ } | ForEach-Object { @{ Text = $_.Title; Do = ''; Step = 'drivers' } }) }
    $set = $script:Wiz.Data['settings']
    if ($set) { $open += @($set.Tweaks | Where-Object { -not $_.Optimal -and -not $_.Optional } | ForEach-Object { @{ Text = "$($_.Title) verbessern"; Do = ''; Step = 'settings' } }) }
    $gpu = $script:Wiz.Data['gpu']
    if ($gpu) {
        $open += @($gpu.Gpu.Findings | Where-Object { $_.Level -ge 2 } | ForEach-Object { @{ Text = $_.Title; Do = $_.Do; Step = 'settings' } })
        if (@($gpu.Gpu.Gpus).Count -gt 1 -and @($gpu.Gpu.Gpus | Where-Object { $_.Discrete }).Count) {
            $n = @($gpu.Games | Where-Object { $_.Preference -ne 'Hohe Leistung' }).Count
            if ($n -gt 0) { $open += @{ Text = "$n Spiel(e) auf Hohe Leistung stellen"; Do = ''; Step = 'settings' } }
        }
    }
    foreach ($gid in 'g-display', 'g-system', 'g-network') {
        $gd = $script:Wiz.Data[$gid]
        if ($gd) { $open += @($gd.Tweaks | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal } | ForEach-Object { @{ Text = "$($_.Title): $($_.Fix)"; Do = ''; Step = $gid } }) }
    }
    $gs = $script:Wiz.Data['g-startup']
    if ($gs) { $n = @($gs.Items | Where-Object { $_.Enabled -and $_.Class -eq 'off' }).Count; if ($n) { $open += @{ Text = "$n unnötige(s) Autostart-Programm(e) abschalten"; Do = ''; Step = 'g-startup' } } }
    $skipped = @($script:WizSteps | Where-Object { $_.Analyze -and -not $script:Wiz.Data.ContainsKey($_.Id) })
    $script:State.FirstOpenStep = if ($open.Count) { $open[0].Step } elseif ($skipped.Count) { $skipped[0].Id } else { '' }

    if ($script:Wiz.NeedsRestart) {
        Add-NextStep -Level 2 -Headline 'Starte den PC jetzt neu' -Text 'Erst dann werden alle Änderungen wirksam. Speichere vorher offene Dateien.' `
            -Primary (New-ActionButton 'Jetzt neu starten' {
                if (Confirm-Action 'Der PC startet in 10 Sekunden neu. Hast du alle offenen Dateien gespeichert?') { shutdown.exe /r /t 10 /c "TuneRig: Neustart, damit die Änderungen wirksam werden." }
            }) -Secondary (New-ActionButton 'Später neu starten' { Complete-WizardRun })
    } elseif ($open.Count -gt 0 -or $skipped.Count -gt 0) {
        $n = $open.Count + $skipped.Count
        Add-NextStep -Level 2 -Headline $(if ($n -eq 1) { 'Fast geschafft - 1 Punkt ist noch offen' } else { "Fast geschafft - $n Punkte sind noch offen" }) `
            -Text 'Ein Klick auf »Zum Schritt« bringt dich direkt dorthin. Wenn du nichts mehr ändern willst, beende den Check einfach.' `
            -Primary (New-ActionButton 'Zum ersten offenen Punkt' { Show-Area $script:State.FirstOpenStep }) `
            -Secondary (New-ActionButton 'Check beenden' { Complete-WizardRun })
    } else {
        Add-NextStep -Level 0 -Headline 'Fertig. Dein PC ist gut eingestellt' -Text 'Wiederhole den Check alle paar Monate oder nach großen Windows-Updates.' `
            -Primary (New-ActionButton 'Check beenden' { Complete-WizardRun })
    }

    if ($open.Count -gt 0 -or $skipped.Count -gt 0) {
        Add-Section 'Noch offen'
        foreach ($o in $open) {
            Add-Wiz (New-ItemRow -Level 2 -Compact -Title $o.Text -Do $o.Do -Buttons @(New-ActionButton 'Zum Schritt  ›' { param($s) Show-Area $s } $o.Step))
        }
        foreach ($s in $skipped) {
            Add-Wiz (New-ItemRow -Level 1 -Compact -Title "Nicht geprüft: $($s.Name)" -Buttons @(New-ActionButton 'Jetzt prüfen  ›' { param($id) Show-Area $id } $s.Id))
        }
    }

    Add-Section 'Dein Ergebnis'
    $card = New-Object Windows.Controls.Border
    [void](Set-Card $card)
    $card.Padding = New-Thickness 16 12 16 14; $card.Margin = New-Thickness 0 0 0 8
    $card.Child = New-ResultPanel
    Add-Wiz $card

    Add-Section 'Weitere Werkzeuge'
    Add-Wiz (New-ItemRow -Level 1 -Compact -Title 'Programme sauber deinstallieren' -Now 'Entfernt ein Programm samt übrig gebliebener Ordner und Einträge.' -NowLabel '' `
        -Buttons @(New-ActionButton 'Öffnen  ›' { Show-Area 'uninstall' }))
    Add-Wiz (New-ItemRow -Level 1 -Compact -Title 'Alle Werkzeuge (für Erfahrene)' -Now 'Junk-Dateien-Suche, Energiesparpläne, vollständige Treiberliste und mehr.' -NowLabel '' `
        -Buttons @(New-ActionButton 'Öffnen  ›' { Show-Area 'overview' }))
}

# ---------------------------------------------------------------------------
#  Vorher-Nachher-Ergebnis
#  Ausgangswerte werden beim ersten Prüfen eines Schritts gemerkt, jede Änderung wird mit
#  einer ehrlichen Einschätzung ihrer Wirkung protokolliert.
# ---------------------------------------------------------------------------
# Wirkung je Einstellung: 3 = deutlich, 2 = spürbar, 1 = leicht, 0 = mehr Stabilität, -1 = keine Leistungsänderung
$script:ImpactLevel = @{ power = 2; gamedvr = 2; gamemode = 1; hags = 1; windowed = 1; pcie = 1; usb = 0; visual = 1 }
$script:ImpactText = @{ 3 = 'deutlich'; 2 = 'spürbar'; 1 = 'leicht'; 0 = 'mehr Stabilität'; -1 = '' }

function Get-FreeSystemBytes { try { [long](New-Object IO.DriveInfo $env:SystemDrive).AvailableFreeSpace } catch { 0L } }

function Add-WizChange([string]$Area, [string]$Title, [string]$Effect, [int]$Impact = -1) {
    [void]$script:Wiz.Changes.Add([pscustomobject]@{ Area = $Area; Title = $Title; Effect = $Effect; Impact = $Impact })
}

function Register-WizBaseline([string]$Id, $Data) {
    if (-not $Data -or $script:Wiz.Baseline.ContainsKey($Id)) { return }
    switch ($Id) {
        'settings' {
            $req = @($Data.Tweaks | Where-Object { -not $_.Optional })
            $script:Wiz.Baseline['settings'] = @{ Ok = @($req | Where-Object { $_.Optimal }).Count; Total = $req.Count }
        }
        'drivers' { $script:Wiz.Baseline['drivers'] = @{ Todo = @($Data.Drv.Todo | Where-Object { $_ }).Count } }
        { $_ -in 'g-display', 'g-system', 'g-network' } {
            $rec = @($Data.Tweaks | Where-Object { $_.Mode -eq 'recommended' })
            $script:Wiz.Baseline[$Id] = @{ Ok = @($rec | Where-Object { $_.Optimal }).Count; Total = $rec.Count }
            if ($Id -eq 'g-network' -and $Data.Net.Connected -and $Data.Net.PingNet.Avg -ge 0) { $script:Wiz.Baseline['ping'] = @{ Avg = $Data.Net.PingNet.Avg; Jitter = $Data.Net.PingNet.Jitter; Time = $Data.Net.Time } }
            if ($Id -eq 'g-display') { $script:Wiz.Baseline['hz'] = (@($Data.Displays) | ForEach-Object { "$($_.Hz) Hz" }) -join ' / ' }
        }
        'g-startup' { $script:Wiz.Baseline['g-startup'] = @{ Active = @($Data.Items | Where-Object { $_.Enabled }).Count } }
        'gpu' {
            $multi = @($Data.Gpu.Gpus).Count -gt 1 -and @($Data.Gpu.Gpus | Where-Object { $_.Discrete }).Count -gt 0
            $g = @($Data.Games)
            $script:Wiz.Baseline['gpu'] = @{ Multi = [bool]$multi; High = @($g | Where-Object { $_.Preference -eq 'Hohe Leistung' }).Count; Total = $g.Count }
        }
    }
}

function Get-WizComparison {
    $rows = @()
    $b = $script:Wiz.Baseline
    if ($b.ContainsKey('settings') -and $script:Wiz.Data['settings']) {
        $req = @($script:Wiz.Data['settings'].Tweaks | Where-Object { -not $_.Optional })
        $now = @($req | Where-Object { $_.Optimal }).Count
        $rows += @{ Label = 'Einstellungen auf Leistung'; Before = "$($b.settings.Ok) von $($b.settings.Total)"; After = "$now von $($req.Count)"; Better = $now -gt $b.settings.Ok }
    }
    if ($b.ContainsKey('drivers')) {
        $after = if ($script:Wiz.Data['drivers']) { [string]@($script:Wiz.Data['drivers'].Drv.Todo | Where-Object { $_ }).Count } else { 'nicht erneut geprüft' }
        $rows += @{ Label = 'Offene Treiber-Aufgaben'; Before = [string]$b.drivers.Todo; After = $after; Better = ($after -match '^\d+$' -and [int]$after -lt $b.drivers.Todo) }
    }
    if ($b.ContainsKey('gpu') -and $b.gpu.Multi -and $script:Wiz.Data['gpu']) {
        $g = @($script:Wiz.Data['gpu'].Games)
        if ($g.Count -gt 0) {
            $high = @($g | Where-Object { $_.Preference -eq 'Hohe Leistung' }).Count
            $rows += @{ Label = 'Spiele auf der starken Grafikkarte'; Before = "$($b.gpu.High) von $($b.gpu.Total)"; After = "$high von $($g.Count)"; Better = $high -gt $b.gpu.High }
        }
    }
    # Gaming
    $gOk = 0; $gTot = 0; $gOk0 = 0; $gTot0 = 0
    foreach ($gid in 'g-display', 'g-system', 'g-network') {
        if ($b.ContainsKey($gid) -and $script:Wiz.Data[$gid]) {
            $rec = @($script:Wiz.Data[$gid].Tweaks | Where-Object { $_.Mode -eq 'recommended' })
            $gOk += @($rec | Where-Object { $_.Optimal }).Count; $gTot += $rec.Count; $gOk0 += $b[$gid].Ok; $gTot0 += $b[$gid].Total
        }
    }
    if ($gTot -gt 0) { $rows += @{ Label = 'Gaming-Optimierungen (empfohlene)'; Before = "$gOk0 von $gTot0"; After = "$gOk von $gTot"; Better = $gOk -gt $gOk0 } }
    $allOn = 0; $allOn0 = 0
    foreach ($gid in 'g-display', 'g-system', 'g-network') { if ($script:Wiz.Data[$gid]) { $allOn += @($script:Wiz.Data[$gid].Tweaks | Where-Object { $_.Mode -ne 'recommended' -and $_.Optimal }).Count } }
    if ($b.ContainsKey('hz') -and $script:Wiz.Data['g-display']) {
        $now = (@($script:Wiz.Data['g-display'].Displays) | ForEach-Object { "$($_.Hz) Hz" }) -join ' / '
        $rows += @{ Label = 'Bildwiederholrate'; Before = $b.hz; After = $now; Better = $now -ne $b.hz }
    }
    if ($b.ContainsKey('g-startup') -and $script:Wiz.Data['g-startup']) {
        $now = @($script:Wiz.Data['g-startup'].Items | Where-Object { $_.Enabled }).Count
        $rows += @{ Label = 'Autostart-Programme'; Before = [string]$b['g-startup'].Active; After = [string]$now; Better = $now -lt $b['g-startup'].Active }
    }
    if ($b.ContainsKey('ping') -and $script:Wiz.Data['g-network'] -and $script:Wiz.Data['g-network'].Net.Time -ne $b.ping.Time -and $script:Wiz.Data['g-network'].Net.PingNet.Avg -ge 0) {
        $pn = $script:Wiz.Data['g-network'].Net.PingNet
        $rows += @{ Label = 'Ping ins Internet (Schwankung)'; Before = "$($b.ping.Avg) ms ($($b.ping.Jitter))"; After = "$($pn.Avg) ms ($($pn.Jitter))"
                    Better = ($pn.Avg -lt $b.ping.Avg - 1) -or ($pn.Jitter -lt $b.ping.Jitter - 1) }
    }
    if ($b.ContainsKey('Free')) {
        $now = Get-FreeSystemBytes
        $rows += @{ Label = "Freier Speicher auf $env:SystemDrive"; Before = (Format-Bytes $b.Free); After = (Format-Bytes $now); Better = $now -gt ($b.Free + 50MB) }
    }
    return $rows
}

function New-MetricTile([string]$Label, [string]$Value, [string]$Before, [bool]$Better) {
    $b = Set-Card (New-Object Windows.Controls.Border)
    $b.Width = 286; $b.Margin = New-Thickness 0 0 12 12
    $sp = New-Object Windows.Controls.StackPanel
    [void]$sp.Children.Add((New-Label $Label))
    $v = New-Text $Value -Role 'metric' -Top 8
    $v.TextWrapping = 'NoWrap'; $v.TextTrimming = 'CharacterEllipsis'
    if ($Value.Length -gt 11) { $v.FontSize = 22; $v.LineHeight = 28 }
    [void]$sp.Children.Add($v)
    $d = New-Object Windows.Controls.StackPanel; $d.Orientation = 'Horizontal'; $d.Margin = New-Thickness 0 8 0 0
    if ($Better) {
        $arrow = New-Text '↑' -Role 'metric-small' -Color 'success'; $arrow.Margin = New-Thickness 0 0 6 0
        [void]$d.Children.Add($arrow)
    }
    [void]$d.Children.Add((New-Text $(if ($Better) { "besser · vorher $Before" } else { "vorher $Before" }) -Role 'small' -Color $(if ($Better) { 'success' } else { 'ink-muted' })))
    [void]$sp.Children.Add($d)
    $b.Child = $sp
    return $b
}

function New-ResultPanel {
    $sp = New-Object Windows.Controls.StackPanel
    $changes = @($script:Wiz.Changes)

    # Vorher - Nachher als Kennzahlen
    $rows = @(Get-WizComparison)
    if ($rows.Count -gt 0) {
        [void]$sp.Children.Add((New-Label 'Vorher – nachher'))
        $wp = New-Object Windows.Controls.WrapPanel; $wp.Margin = New-Thickness 0 12 0 0
        foreach ($r in $rows) { [void]$wp.Children.Add((New-MetricTile $r.Label $r.After $r.Before ([bool]$r.Better))) }
        [void]$sp.Children.Add($wp)
    }

    # Was wurde geändert?
    $h = New-Label 'Was geändert wurde'; $h.Margin = New-Thickness 0 12 0 8
    [void]$sp.Children.Add($h)
    if ($changes.Count -eq 0) {
        [void]$sp.Children.Add((New-Text 'In diesem Check wurde nichts geändert.' -Role 'small' -Color 'ink-muted'))
    }
    foreach ($c in $changes) {
        $dp = New-Object Windows.Controls.DockPanel
        $dp.Margin = New-Thickness 0 8 0 0
        if ($c.Impact -ge 1) {
            $m = New-SegmentMeter ([int]$c.Impact) 3; $m.Margin = New-Thickness 16 4 0 0; $m.VerticalAlignment = 'Top'
            $m.ToolTip = "Wirkung: $($script:ImpactText[[int]$c.Impact])"
            [Windows.Controls.DockPanel]::SetDock($m, 'Right'); [void]$dp.Children.Add($m)
        }
        $i = New-LineIcon 'check' 'success' 16; $i.Margin = New-Thickness 0 2 8 0; $i.VerticalAlignment = 'Top'
        [Windows.Controls.DockPanel]::SetDock($i, 'Left'); [void]$dp.Children.Add($i)
        $left = New-Object Windows.Controls.StackPanel
        [void]$left.Children.Add((New-Text $c.Title -Role 'small' -Bold))
        if ($c.Effect) { [void]$left.Children.Add((New-Text $c.Effect -Role 'small' -Color 'ink-muted')) }
        [void]$dp.Children.Add($left)
        [void]$sp.Children.Add($dp)
    }

    # Gesamteinschätzung
    if ($changes.Count -gt 0) {
        $max = ($changes | Measure-Object -Property Impact -Maximum).Maximum
        $summary = switch ([int]$max) {
            3 { 'Deutlich mehr Leistung in Spielen – vor allem, weil Spiele jetzt die starke Grafikkarte nutzen.' }
            2 { 'Spürbar flüssigere Bedienung und mehr Leistung unter Last, z. B. in Spielen und beim Programmstart.' }
            1 { 'Leichte Verbesserungen – vor allem weniger Verzögerungen und Ruckler.' }
            0 { 'Vor allem mehr Stabilität: weniger Aussetzer und Gerätefehler.' }
            default { 'Dein PC ist aufgeräumt und abgesichert. An der Geschwindigkeit ändert sich dadurch kaum etwas.' }
        }
        $box = Set-Card (New-Object Windows.Controls.Border)
        Set-ThemeRef $box Background 'surface-raised'
        $box.Margin = New-Thickness 0 16 0 0
        $bs = New-Object Windows.Controls.StackPanel
        [void]$bs.Children.Add((New-Label 'Gesamteinschätzung'))
        [void]$bs.Children.Add((New-Text $summary -Role 'body' -Top 8))
        if ($script:Wiz.NeedsRestart) { [void]$bs.Children.Add((New-ColoredLine 'Ein Teil der Änderungen wirkt erst nach einem Neustart.' 2)) }
        [void]$bs.Children.Add((New-Text 'Wie viel schneller dein PC genau wird, hängt von Hardware und Programmen ab. Exakte Werte wie Bilder pro Sekunde misst nur ein Benchmark.' -Role 'small' -Color 'ink-muted' -Top 8))
        $box.Child = $bs
        [void]$sp.Children.Add($box)
    }
    return $sp
}

function Show-ResultDialog {
    $w = New-Object Windows.Window
    $w.Title = 'Dein Ergebnis'; $w.Width = [Math]::Min(960.0, [Windows.SystemParameters]::WorkArea.Width * 0.95); $w.SizeToContent = 'Height'
    $w.MaxHeight = [Windows.SystemParameters]::WorkArea.Height * 0.9
    $w.WindowStartupLocation = 'CenterOwner'; $w.Owner = $window; $w.ResizeMode = 'NoResize'; $w.UseLayoutRounding = $true
    Set-ThemeRef $w Background 'ground'; Set-ThemeRef $w Foreground 'ink'
    $w.SetResourceReference([Windows.Controls.Control]::FontFamilyProperty, 'FontSans')
    Set-WindowBranding $w
    $root = New-Object Windows.Controls.DockPanel
    $root.Margin = New-Thickness 32 24 32 24
    $btn = New-Object Windows.Controls.Button
    $btn.Content = 'Schließen'; Set-PrimaryButton $btn; $btn.MinWidth = 160
    $btn.HorizontalAlignment = 'Right'; $btn.Margin = New-Thickness 0 16 0 0
    $btn.Add_Click({ $script:ResDlg.Close() })
    [Windows.Controls.DockPanel]::SetDock($btn, 'Bottom'); [void]$root.Children.Add($btn)
    $head = New-Text 'Geschafft. Das hat der Check gebracht' -Role 'h2'
    [Windows.Controls.DockPanel]::SetDock($head, 'Top'); [void]$root.Children.Add($head)
    $sv = New-Object Windows.Controls.ScrollViewer
    $sv.VerticalScrollBarVisibility = 'Auto'; $sv.Margin = New-Thickness 0 16 0 0
    $sv.Content = New-ResultPanel
    [void]$root.Children.Add($sv)
    $w.Content = $root
    $script:ResDlg = $w
    [void]$w.ShowDialog()
}

# Check beenden: Ergebnis zeigen (wenn etwas geändert wurde) und zur Startseite
function Complete-WizardRun {
    if (@($script:Wiz.Changes).Count -gt 0) { Show-ResultDialog }
    # Bis zur Zusammenfassung durchlaufen = vollständiger Check
    if ($script:Wiz.Visited[$script:WizSteps.Count - 1]) { $script:LastCheck = (Get-Date).ToString('o'); Save-AppSettings 'wizard' }
    Show-Page 'welcome'
    Start-QuickHealth
}

# ---------------------------------------------------------------------------
#  Ereignisse: Startseite, Kopfleiste, Navigation im Assistenten
# ---------------------------------------------------------------------------
# Öffnet einen Check. Läuft er schon, geht es dort weiter; läuft ein anderer, wird vorher gefragt.
function Open-WizMode([string]$Mode) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    if ($script:Wiz.Started -and $script:Wiz.Mode -eq $Mode) { Show-Page 'wizard'; Show-WizStep $script:Wiz.Index; return }
    if ($script:Wiz.Started -and $script:Wiz.Index -gt 0 -and $script:Wiz.Index -lt $script:WizSteps.Count - 1) {
        $q = "Gerade läuft: {0} (Schritt {1}).`n`nZu »{2}« wechseln? Bereits vorgenommene Änderungen bleiben erhalten; »{0}« beginnt beim nächsten Mal von vorn." -f (Get-ModeName $script:Wiz.Mode), $script:Wiz.Index, (Get-ModeName $Mode)
        if (-not (Confirm-Action $q 'Check wechseln')) { return }
    }
    Reset-Wizard $Mode
    $script:Wiz.Started = $true
    Show-Page 'wizard'; Show-WizStep 0
}

$ui.BtnStartGuided.Add_Click({ Open-WizMode 'normal' })
$ui.BtnStartGaming.Add_Click({ Open-WizMode 'gaming' })
$ui.BtnStartOverdrive.Add_Click({ Open-WizMode 'overdrive' })
$ui.BtnStartExpert.Add_Click({ Show-Page 'expert' })
$ui.BtnNavHome.Add_Click({ Show-HomePage 'dash' })
$ui.BtnNavGuided.Add_Click({ Open-WizMode 'normal' })
$ui.BtnNavBoost.Add_Click({ Open-WizMode 'gaming' })
$ui.BtnNavOverdrive.Add_Click({ Open-WizMode 'overdrive' })
$ui.BtnNavExpert.Add_Click({ Show-Page 'expert' })
# Hilfe: siehe Dashboard.ps1

function Go-WizTarget([int]$Target) { if ($Target -lt 0) { Complete-WizardRun } else { Show-WizStep $Target } }

# Prüft vor jedem Verlassen eines Schritts, ob noch etwas offen ist, und fragt nach.
# $Target: Index des Zielschritts, -1 = zurück zur Startseite
function Request-WizLeave([int]$Target, [string]$TargetText = 'weiter', [string]$ConfirmIfClean = '') {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $stepId = $script:WizSteps[$script:Wiz.Index].Id
    # Overdrive: weiter nur mit ausdrücklich bestätigtem Risiko
    if ($stepId -eq 'o-welcome' -and $Target -gt $script:Wiz.Index -and -not $script:Wiz.OdAck) {
        Show-Info 'Overdrive geht über die sicheren Empfehlungen hinaus. Bestätige zuerst unten, dass du die Risiken verstanden hast und bewusst eingehst.' 'Overdrive'
        return
    }
    # Fehlende Hersteller-Software: vorwärts nur mit ausdrücklicher Bestätigung
    if ($stepId -eq 'drivers' -and $Target -gt $script:Wiz.Index -and (Test-SoftwareGate)) {
        if (-not (Confirm-SkipVendorSoftware)) { return }
        Go-WizTarget $Target; return
    }
    $pending = @(Get-WizPending $stepId | Where-Object { $_ })
    $relevant = @($pending | Where-Object { $_.Kind -eq 'info' -or $_.Rec })
    if ($relevant.Count -eq 0) {
        if ($ConfirmIfClean -and -not (Confirm-Action $ConfirmIfClean)) { return }
        Go-WizTarget $Target; return
    }
    $r = Show-ChangeDialog $pending $TargetText
    if ($r.Choice -eq 'stay') { return }
    if ($r.Choice -eq 'apply') {
        $script:State.WizTarget = $Target
        $script:State.WizAfter = { Go-WizTarget $script:State.WizTarget }
        Invoke-WizApply $stepId $r.Ids
        return
    }
    Go-WizTarget $Target
}

$ui.WizNext.Add_Click({ Invoke-WizNext })
$ui.WizBack.Add_Click({ if ($script:Wiz.Index -gt 0) { Request-WizLeave ($script:Wiz.Index - 1) 'zurück' } })
$ui.WizRecheck.Add_Click({ Invoke-WizRecheck })
$ui.WizExit.Add_Click({
    Request-WizLeave -1 'den Check beenden' "$(Get-ModeName $script:Wiz.Mode) beenden?`n`nDu kannst ihn jederzeit oben in der Leiste wieder aufrufen – bereits geprüfte Schritte bleiben erhalten."
})

# ===========================================================================
#  Startseite: Gesamtwertung (Schnellcheck) und wechselnde Tipps
# ===========================================================================
$script:LastCheck = try { [string](Get-AppSettings).LastCheck } catch { '' }

# Segmentierte Leistungsanzeige wie im Logo: aktive Segmente in accent, Nadel in accent, Nabe in ink
function New-HealthGauge([int]$Score) {
    $inv = [Globalization.CultureInfo]::InvariantCulture
    $c = New-Object Windows.Controls.Canvas
    $c.Width = 160; $c.Height = 140
    $cx = 80.0; $cy = 76.0; $r = 62.0; $n = 18; $start = 135.0; $span = 270.0; $gap = 4.0
    $filled = [math]::Round($n * $Score / 100.0)
    $pt = { param($deg, $rad) $a = $deg * [math]::PI / 180; @(($cx + $rad * [math]::Cos($a)), ($cy + $rad * [math]::Sin($a))) }
    for ($i = 0; $i -lt $n; $i++) {
        $a0 = $start + $i * $span / $n + $gap / 2; $a1 = $start + ($i + 1) * $span / $n - $gap / 2
        $p0 = & $pt $a0 $r; $p1 = & $pt $a1 $r
        $seg = New-Object Windows.Shapes.Path
        $seg.Data = [Windows.Media.Geometry]::Parse([string]::Format($inv, 'M {0:0.##},{1:0.##} A {2:0.##},{2:0.##} 0 0 1 {3:0.##},{4:0.##}', $p0[0], $p0[1], $r, $p1[0], $p1[1]))
        $seg.StrokeThickness = 10
        Set-ThemeRef $seg Stroke $(if ($i -lt $filled) { 'accent' } else { 'line' })
        [void]$c.Children.Add($seg)
    }
    if ($Score -ge 0) {
        $tip = & $pt ($start + $span * $Score / 100.0) ($r - 20)
        $needle = New-Object Windows.Shapes.Line
        $needle.X1 = $cx; $needle.Y1 = $cy; $needle.X2 = $tip[0]; $needle.Y2 = $tip[1]
        $needle.StrokeThickness = 5; $needle.StrokeStartLineCap = 'Round'; $needle.StrokeEndLineCap = 'Round'
        Set-ThemeRef $needle Stroke 'accent'
        [void]$c.Children.Add($needle)
    }
    $hub = New-Object Windows.Shapes.Ellipse
    $hub.Width = 14; $hub.Height = 14
    Set-ThemeRef $hub Fill 'ink'
    [Windows.Controls.Canvas]::SetLeft($hub, $cx - 7); [Windows.Controls.Canvas]::SetTop($hub, $cy - 7)
    [void]$c.Children.Add($hub)
    [Windows.Automation.AutomationProperties]::SetName($c, $(if ($Score -ge 0) { "Systemzustand $Score von 100" } else { 'Systemzustand wird ermittelt' }))
    return $c
}

function Show-QuickHealth($h) {
    $script:HealthData = $h
    Invoke-UiHook 'health'
    $ui.HealthGauge.Content = New-HealthGauge $(if ($h) { $h.Score } else { -1 })
    $ui.HealthItems.Children.Clear()
    if (-not $h) {
        $ui.HealthScore.Text = '–'; $ui.HealthRating.Text = 'Wird bewertet …'; Set-ThemeRef $ui.HealthRating Foreground 'ink'
        $ui.HealthSummary.Text = 'Der Schnellcheck läuft im Hintergrund und dauert nur wenige Sekunden.'
        return
    }
    $ui.HealthScore.Text = [string]$h.Score
    $ui.HealthRating.Text = $h.Rating
    Set-ThemeRef $ui.HealthRating Foreground $script:LevelToken[$h.Level]

    # Letzter vollständiger Check - als Anstoß, regelmäßig zu prüfen
    $days = $null
    if ($script:LastCheck) { try { $days = [int]((Get-Date) - [datetime]::Parse($script:LastCheck, [Globalization.CultureInfo]::InvariantCulture, 'RoundtripKind')).TotalDays } catch {} }
    $when = if ($null -eq $days) { 'Noch nie vollständig mit TuneRig geprüft.' } elseif ($days -eq 0) { 'Letzter vollständiger Check: heute.' } elseif ($days -eq 1) { 'Letzter vollständiger Check: gestern.' } else { "Letzter vollständiger Check: vor $days Tagen." }
    $hint = if (@($h.Items).Count -eq 0) { 'Der Schnellcheck findet nichts. Der Reguläre Check geht ins Detail.' }
            elseif ($h.Score -lt 75) { 'Der Reguläre Check behebt das meiste mit wenigen Klicks.' }
            else { 'Ein paar Punkte lassen sich noch verbessern.' }
    if ($null -eq $days -or $days -gt 60) { $hint = 'Zeit für einen Check – ' + $hint.Substring(0, 1).ToLower() + $hint.Substring(1) }
    $ui.HealthSummary.Text = "$when $hint"

    $shown = @($h.Items | Select-Object -First 4)
    foreach ($i in $shown) { [void]$ui.HealthItems.Children.Add((New-ColoredLine $i.Title $i.Level)) }
    if (@($h.Items).Count -gt 4) { [void]$ui.HealthItems.Children.Add((New-Text "… und $(@($h.Items).Count - 4) weitere" -Role 'small' -Color 'ink-muted' -Top 4)) }
    if ($shown.Count -eq 0) { [void]$ui.HealthItems.Children.Add((New-ColoredLine 'Speicher, Treiber, Einstellungen und Laufwerke in Ordnung' 0)) }
}

# Schnellcheck in einem eigenen Hintergrund-Thread - blockiert die Oberfläche nicht
# Holt das Ergebnis eines fertigen Schnellchecks ab und zeigt es an (einmal pro Lauf)
function Receive-QuickHealth {
    $j = $script:HealthJob
    if (-not $j -or $j.Done -or -not $j.Handle.IsCompleted) { return $false }
    $j.Done = $true
    $res = $null
    try { $res = @($j.PS.EndInvoke($j.Handle))[-1] } catch {}
    try { $j.PS.Runspace.Close(); $j.PS.Dispose() } catch {}
    $ui.BtnHealthRefresh.IsEnabled = $true
    if ($res) { Show-QuickHealth $res }
    else {
        $ui.HealthGauge.Content = New-HealthGauge -1
        $ui.HealthScore.Text = '–'; $ui.HealthRating.Text = 'Nicht verfügbar'
        $ui.HealthSummary.Text = 'Der Schnellcheck konnte nicht ausgeführt werden. Der Reguläre Check prüft alles im Detail.'
    }
    return $true
}

# Startet den Schnellcheck - oder übernimmt einen bereits laufenden (z. B. aus der Ladesequenz)
function Start-QuickHealth {
    if (-not ($script:HealthJob -and -not $script:HealthJob.Done)) {
        Show-QuickHealth $null
        $script:HealthJob = New-QuickHealthJob
    }
    $ui.BtnHealthRefresh.IsEnabled = $false
    if (-not $script:HealthTimer) {
        $script:HealthTimer = New-Object Windows.Threading.DispatcherTimer
        $script:HealthTimer.Interval = [TimeSpan]::FromMilliseconds(400)
        $script:HealthTimer.Add_Tick({ if (Receive-QuickHealth) { $script:HealthTimer.Stop() } })
    }
    $script:HealthTimer.Start()
}

$ui.BtnHealthCheck.Add_Click({ Open-WizMode 'normal' })
$ui.BtnHealthRefresh.Add_Click({ Start-QuickHealth })

# --- Wechselnde Tipps -------------------------------------------------------
#   A = optionale Aktion: guided, gaming, overdrive, storage, leftovers, uninstall, restore, theme
$script:Tips = @(
    @{ T = 'Stell deine Spiele im Schritt Leistung auf »Hohe Leistung« – dann arbeitet immer die starke Grafikkarte.' }
    @{ T = 'Lass die NVIDIA App bzw. AMD Software installiert: Sie hält deinen Grafiktreiber automatisch aktuell.' }
    @{ T = 'Läuft dein Monitor mit 60 statt 144 Hz? Der Performance Boost stellt das mit einem Klick um.'; A = 'gaming'; L = 'Performance Boost starten' }
    @{ T = 'Der Performance Boost misst deinen Ping und findet Aussetzer durch WLAN-Energiesparen.'; A = 'gaming'; L = 'Performance Boost starten' }
    @{ T = 'Overdrive ist zum Übertakten: Es stellt Windows auf maximale Leistung und zeigt, wie du CPU, GPU und RAM übertaktest. Nur auf eigenes Risiko.'; A = 'overdrive'; L = 'Overdrive ansehen' }
    @{ T = 'Vor jeder Änderung legt TuneRig einen Wiederherstellungspunkt an – du kannst alles rückgängig machen.' }
    @{ T = 'Alte Wiederherstellungspunkte belegen Platz. Behalte den neuesten und lösch den Rest.'; A = 'restore'; L = 'Punkte verwalten' }
    @{ T = 'Programme ohne Reste entfernen: TuneRig sucht nach der Deinstallation übrig gebliebene Ordner und Einträge.'; A = 'uninstall'; L = 'Deinstallation öffnen' }
    @{ T = 'Shader-Cache nur leeren, wenn ein Spiel nach einem Update dauerhaft ruckelt – sonst verkürzt er Ladezeiten.' }
    @{ T = 'Ein Netzwerkkabel bringt beim Online-Gaming mehr als jede Einstellung.' }
    @{ T = 'Autostart-Programme kosten beim Spielen Arbeitsspeicher. Der Performance Boost zeigt, welche du abschalten kannst.'; A = 'gaming'; L = 'Performance Boost starten' }
    @{ T = 'Weniger als 10 % freier Speicher bremsen Windows. Der Schritt Aufräumen schafft Platz.' }
    @{ T = 'Schon lange deinstalliert, aber nicht ganz weg? Die Reste-Suche findet übrig gebliebene Ordner und Einträge alter Programme und Spiele – nur mit Beleg.'; A = 'leftovers'; L = 'Reste suchen' }
    @{ T = 'Was belegt deine Festplatte? Die Speicherplatz-Analyse zeigt es nach Ordnern, Dateitypen und größten Dateien.'; A = 'storage'; L = 'Speicherplatz analysieren' }
    @{ T = 'Installiere Treiber nur über Windows Update oder beim Hersteller – nie über Treiber-Updater von Drittanbietern.' }
    @{ T = 'Prüfe deinen PC alle paar Monate und nach großen Windows-Updates. Ein Check dauert 5–10 Minuten.'; A = 'guided'; L = 'Check starten' }
    @{ T = 'Laptop? Spiel am Netzteil – im Akkubetrieb drosselt Windows die Leistung.' }
    @{ T = 'Starte den PC nach Treiber-Updates neu. Viele Änderungen wirken erst danach.' }
    @{ T = 'Oben rechts wechselst du zwischen dunklem und hellem Design.'; A = 'theme'; L = 'Design wechseln' }
)
$script:TipIndex = Get-Random -Maximum $script:Tips.Count

function Show-Tip([int]$Index) {
    $n = $script:Tips.Count
    $script:TipIndex = (($Index % $n) + $n) % $n
    $t = $script:Tips[$script:TipIndex]
    $ui.TipText.Text = $t.T
    $ui.TipCounter.Text = '{0}/{1}' -f ($script:TipIndex + 1), $n
    if ($t.A) { $ui.TipAction.Content = $t.L; $ui.TipAction.Tag = $t.A; $ui.TipAction.Visibility = 'Visible' } else { $ui.TipAction.Visibility = 'Collapsed' }
    $fade = New-Object Windows.Media.Animation.DoubleAnimation(0.0, 1.0, (New-Object Windows.Duration([TimeSpan]::FromMilliseconds(450))))
    $ui.TipText.BeginAnimation([Windows.UIElement]::OpacityProperty, $fade)
}

$ui.TipIcon.Content = New-LineIcon 'info' 'accent-text' 20
$ui.TipPrev.Add_Click({ Show-Tip ($script:TipIndex - 1); $script:TipTimer.Stop(); $script:TipTimer.Start() })
$ui.TipNext.Add_Click({ Show-Tip ($script:TipIndex + 1); $script:TipTimer.Stop(); $script:TipTimer.Start() })
$ui.TipAction.Add_Click({
    switch ([string]$this.Tag) {
        'guided' { Open-WizMode 'normal' }
        'gaming' { Open-WizMode 'gaming' }
        'overdrive' { Open-WizMode 'overdrive' }
        'uninstall' { Show-Tool 'uninstall' }
        'storage' { Show-Tool 'storage' }
        'leftovers' { Show-Tool 'leftovers' }
        'restore' { Show-RestorePointManager }
        'theme' { $ui.BtnTheme.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent))) }
    }
})
# Alle 12 Sekunden ein neuer Tipp; solange die Maus auf der Leiste ist, bleibt er stehen
$script:TipTimer = New-Object Windows.Threading.DispatcherTimer
$script:TipTimer.Interval = [TimeSpan]::FromSeconds(12)
$script:TipTimer.Add_Tick({ if ($ui.WelcomePage.IsVisible -and -not $ui.TipBar.IsMouseOver) { Show-Tip ($script:TipIndex + 1) } })
Show-Tip $script:TipIndex
$script:TipTimer.Start()
Show-QuickHealth $null
