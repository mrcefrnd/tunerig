﻿# ============================================================================
#  TuneRig 2.0: Dashboard und Bereichsseiten
#  Alles wird im Code gebaut und in HomeHost (Seite HomePage) angezeigt.
#  Grundsatz: wenig Text. Erklärungen stecken im Info-Symbol, der Zustand
#  steht immer als Symbol + Wort da, pro Ansicht gibt es genau einen Primär-Button.
#  Die Logik (Prüfen, Ändern, Sichern) ist dieselbe wie in der Expertenansicht.
# ============================================================================
$script:H2 = @{
    Page = 'dash'; Sub = @{ perf = 'settings'; prog = 'installed' }
    Settings = $null; Want = @{}; Gpu = $null; Games = $null; GameWant = @{}; Startup = $null; StartWant = @{}
    Clean = $null; CleanSel = @{}; Drv = $null; Upd = $null; UpdSel = @{}
    Od = $null; OdWant = @{}; OdAccepted = $false; Opt = $null; Search = ''; Open = @{}; Live = $null
}

# ---------------------------------------------------------------------------
#  Bausteine
# ---------------------------------------------------------------------------
function Add-To($Parent, $Child) { if ($Child) { if ($Parent -is [Windows.Controls.Panel]) { [void]$Parent.Children.Add($Child) } else { $Parent.Child = $Child } }; return $Child }
function New-Stack([string]$Orientation = 'Vertical', [double]$Top = 0) {
    $s = New-Object Windows.Controls.StackPanel; $s.Orientation = $Orientation; $s.Margin = New-Thickness 0 $Top 0 0; return $s
}
function New-Dock { $d = New-Object Windows.Controls.DockPanel; $d.LastChildFill = $true; return $d }
function Set-Dock($El, [string]$Side) { [Windows.Controls.DockPanel]::SetDock($El, $Side); return $El }

# Klick mit Daten: $Do bekommt ($Data, $Sender). Lokale Variablen der aufrufenden Funktion gibt es im Handler nicht.
function Add-HClick($Ctrl, [scriptblock]$Do, $Data = $null) {
    $Ctrl.Tag = @{ Do = $Do; Data = $Data }
    $Ctrl.Add_Click({ $t = $this.Tag; try { & $t.Do $t.Data $this } catch { Show-Error ($_.Exception.Message) } })
    return $Ctrl
}
function New-HButton([string]$Label, [scriptblock]$Do, $Data = $null, [switch]$Primary, [string]$Icon = '') {
    $b = New-Object Windows.Controls.Button
    if ($Primary) { $b.Style = Get-ThemeStyle 'Primary'; $Label = $Label.ToUpper() }
    $b.Margin = New-Thickness 0 0 0 0
    if ($Icon) {
        $sp = New-Stack 'Horizontal'
        $ic = New-LineIcon $Icon $(if ($Primary) { 'on-accent' } else { 'ink' }) 16; $ic.Margin = New-Thickness 0 0 8 0; $ic.VerticalAlignment = 'Center'
        [void]$sp.Children.Add($ic)
        $t = New-Object Windows.Controls.TextBlock; $t.Text = $Label; $t.VerticalAlignment = 'Center'; [void]$sp.Children.Add($t)
        $b.Content = $sp
        [Windows.Automation.AutomationProperties]::SetName($b, $Label)
    } else { $b.Content = $Label }
    return (Add-HClick $b $Do $Data)
}
function New-Link([string]$Text, [scriptblock]$Do, $Data = $null, [switch]$Accent) {
    $b = New-Object Windows.Controls.Button
    $b.Style = Get-ThemeStyle $(if ($Accent) { 'AccentLink' } else { 'LinkBtn' })
    $b.Content = $Text
    return (Add-HClick $b $Do $Data)
}
# Info-Symbol: Erklärung erscheint beim Darüberfahren oder Anklicken
function New-Info([string]$Text) {
    if (-not $Text) { return $null }
    $b = New-Object Windows.Controls.Button
    $b.Style = Get-ThemeStyle 'InfoBtn'
    $tt = New-Object Windows.Controls.ToolTip
    $tb = New-Object Windows.Controls.TextBlock; $tb.Text = $Text; $tb.TextWrapping = 'Wrap'; $tb.MaxWidth = 340
    $tt.Content = $tb
    $b.ToolTip = $tt
    [Windows.Automation.AutomationProperties]::SetName($b, "Erklärung: $Text")
    $b.Add_Click({ $t = $this.ToolTip; $t.PlacementTarget = $this; $t.IsOpen = -not $t.IsOpen })
    $b.Add_LostFocus({ $this.ToolTip.IsOpen = $false })
    return $b
}
function New-Switch([bool]$On, [string]$Name) {
    $s = New-Object Windows.Controls.Primitives.ToggleButton
    $s.Style = Get-ThemeStyle 'Switch'
    $s.IsChecked = $On
    [Windows.Automation.AutomationProperties]::SetName($s, $Name)
    return $s
}
function New-HCard($Child = $null, [double]$Pad = 20, [double]$Bottom = 16) {
    $c = Set-Card (New-Object Windows.Controls.Border)
    $c.Padding = New-Thickness $Pad $Pad $Pad $Pad; $c.Margin = New-Thickness 0 0 0 $Bottom
    if ($Child) { $c.Child = $Child }
    return $c
}
# Zustand immer als Symbol + Wort (nie nur Farbe)
function New-StateTag([int]$Level, [string]$Text, [double]$Size = 16) {
    $sp = New-Stack 'Horizontal'
    $ic = New-LineIcon $script:LevelIconKind[$Level] $script:LevelToken[$Level] $Size; $ic.Margin = New-Thickness 0 0 6 0; $ic.VerticalAlignment = 'Center'
    [void]$sp.Children.Add($ic)
    $t = New-Text $Text -Role 'small' -Color $script:LevelToken[$Level]; $t.VerticalAlignment = 'Center'; $t.TextWrapping = 'NoWrap'
    [void]$sp.Children.Add($t)
    return $sp
}
function New-Tag([string]$Text, [string]$Token = 'ink-muted') {
    $t = New-Label $Text $Token; $t.VerticalAlignment = 'Center'; $t.Margin = New-Thickness 12 0 0 0; return $t
}
function New-Mono([string]$Text, [double]$Size = 14, [string]$Token = 'ink') {
    $t = New-Text $Text -Role 'metric-small' -Color $Token; $t.FontSize = $Size; $t.LineHeight = $Size + 6; $t.VerticalAlignment = 'Center'; $t.TextWrapping = 'NoWrap'
    return $t
}
function New-Section([string]$Text, [double]$Top = 8) { $l = New-Label $Text; $l.Margin = New-Thickness 0 $Top 0 8; return $l }
function New-RowLine { $b = New-Object Windows.Controls.Border; $b.Height = 1; Set-ThemeRef $b Background 'line'; return $b }

# Kopf jeder Bereichsseite: »← Dashboard«, Titel, rechts Zustand bzw. Aktion
function New-PageHead([string]$Title, $Right = $null) {
    $d = New-Dock; $d.Margin = New-Thickness 0 0 0 16
    if ($Right) { $Right.VerticalAlignment = 'Bottom'; [void]$d.Children.Add((Set-Dock $Right 'Right')) }
    $sp = New-Stack
    [void]$sp.Children.Add((New-Link '← Dashboard' { Show-HomePage 'dash' }))
    $h = New-Text $Title -Role 'h1' -Top 6
    [void]$sp.Children.Add($h)
    [void]$d.Children.Add($sp)
    return $d
}
# Unterbereiche als Reiterzeile (aktiver Bereich mit orangefarbener Linie)
function New-SubNav($Items, [string]$Current, [string]$Group) {
    $b = New-Object Windows.Controls.Border; $b.BorderThickness = New-Thickness 0 0 0 1; Set-ThemeRef $b BorderBrush 'line'; $b.Margin = New-Thickness 0 0 0 20
    $sp = New-Stack 'Horizontal'
    foreach ($i in $Items) {
        $x = New-Object Windows.Controls.Button
        $x.Style = Get-ThemeStyle 'TopNav'; $x.Height = 44; $x.Margin = New-Thickness 0 0 16 0
        $x.Content = $i[1].ToUpper()
        if ($i[0] -eq $Current) { $x.Tag = 'active' }
        $x.CommandParameter = "$Group|$($i[0])"
        $x.Add_Click({ $p = ([string]$this.CommandParameter).Split('|'); $script:H2.Sub[$p[0]] = $p[1]; Show-Home -Top })
        [void]$sp.Children.Add($x)
    }
    $b.Child = $sp
    return $b
}
function New-Loading([string]$Text) {
    $sp = New-Stack
    $t = New-Text $Text -Role 'body' -Color 'ink-muted'
    [void]$sp.Children.Add($t)
    $live = New-Text '' -Role 'small' -Color 'ink-muted' -Top 4
    $script:H2.Live = $live
    [void]$sp.Children.Add($live)
    $pb = New-Object Windows.Controls.ProgressBar; $pb.IsIndeterminate = $true; $pb.Margin = New-Thickness 0 12 0 0
    [void]$sp.Children.Add($pb)
    return (New-HCard $sp)
}

# Aktionsleiste unten (bleibt beim Scrollen stehen)
function Set-HomeBar([string]$Text, [string]$Primary = '', [scriptblock]$OnPrimary = $null, [bool]$Enabled = $true, $Extra = @()) {
    $bar = $ui.HomeBar; $host2 = $ui.HomeBarHost
    if ($script:H2.BarTarget -eq 'expert') { $bar = $ui.LoBar; $host2 = $ui.LoBarHost }
    if (-not $Text -and -not $Primary) { $bar.Visibility = 'Collapsed'; $host2.Content = $null; return }
    $d = New-Dock
    $right = New-Stack 'Horizontal'
    foreach ($e in @($Extra | Where-Object { $_ })) { $e.Margin = New-Thickness 0 0 12 0; [void]$right.Children.Add($e) }
    if ($Primary) { $p = New-HButton $Primary $OnPrimary -Primary; $p.IsEnabled = $Enabled; [void]$right.Children.Add($p) }
    [void]$d.Children.Add((Set-Dock $right 'Right'))
    $t = New-Text $Text -Role 'body'; $t.VerticalAlignment = 'Center'
    [void]$d.Children.Add($t)
    $host2.Content = $d
    $bar.Visibility = 'Visible'
}
function Get-BackupNote { switch (Get-BackupMode) { 'always' { 'vorher wird gesichert' } 'never' { 'ohne Sicherung' } default { 'Sicherung auf Wunsch' } } }

# ---------------------------------------------------------------------------
#  Schalterliste: eine Zeile je Einstellung (Schalter, Name, Info, Kennzeichen, Wirkung)
#  Items: @{ Id; Title; Tip; Tag; TagToken; Impact; On; CanOff; CanOn }
#  $Want: gewünschter Zustand je Id; $OnChange läuft nach jedem Umschalten
# ---------------------------------------------------------------------------
function New-ToggleCard($Items, [hashtable]$Want, [scriptblock]$OnChange, [bool]$Locked = $false) {
    $card = New-HCard $null 0 16
    $sp = New-Stack
    $first = $true
    foreach ($it in $Items) {
        if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }
        $first = $false
        $row = New-Dock; $row.Margin = New-Thickness 16 12 16 12
        $on = if ($Want.ContainsKey($it.Id)) { [bool]$Want[$it.Id] } else { [bool]$it.On }
        $sw = New-Switch $on $it.Title
        $sw.Margin = New-Thickness 0 0 16 0
        $can = if ($it.On) { [bool]$it.CanOff } else { [bool]$it.CanOn }
        if ($Locked -or -not $can) {
            $sw.IsEnabled = $false
            $lt = if ($it.LockTip) { $it.LockTip } elseif (-not $Locked -and $it.On) { 'Entspricht schon dem Windows-Standard – hier gibt es nichts zurückzusetzen.' } else { '' }
            if ($lt) { [Windows.Controls.ToolTipService]::SetShowOnDisabled($sw, $true); $sw.ToolTip = $lt }
        }
        $sw.CommandParameter = @{ Id = $it.Id; Want = $Want; OnChange = $OnChange }
        $sw.Add_Click({ $p = $this.CommandParameter; $p.Want[$p.Id] = [bool]$this.IsChecked; if ($p.OnChange) { & $p.OnChange } })
        [void]$row.Children.Add((Set-Dock $sw 'Left'))
        if ($it.Impact -ge 1) { $m = New-SegmentMeter ([int]$it.Impact) 3 'ink'; $m.Margin = New-Thickness 16 0 0 0; [Windows.Automation.AutomationProperties]::SetName($m, "Wirkung $($it.Impact) von 3"); [void]$row.Children.Add((Set-Dock $m 'Right')) }
        if ($it.Tag) { [void]$row.Children.Add((Set-Dock (New-Tag $it.Tag $(if ($it.TagToken) { $it.TagToken } else { 'ink-muted' })) 'Right')) }
        $mid = New-Stack 'Horizontal'; $mid.VerticalAlignment = 'Center'
        $t = New-Text $it.Title -Role 'body'; $t.VerticalAlignment = 'Center'; $t.TextWrapping = 'NoWrap'; $t.TextTrimming = 'CharacterEllipsis'
        [void]$mid.Children.Add($t)
        $i = New-Info $it.Tip; if ($i) { $i.Margin = New-Thickness 4 0 0 0; [void]$mid.Children.Add($i) }
        [void]$row.Children.Add($mid)
        [void]$sp.Children.Add($row)
    }
    $card.Child = $sp
    return $card
}
function Get-WantChanges($Items, [hashtable]$Want) {
    $on = @(); $off = @()
    foreach ($it in $Items) {
        if (-not $Want.ContainsKey($it.Id)) { continue }
        $w = [bool]$Want[$it.Id]
        if ($w -and -not $it.On) { $on += $it } elseif (-not $w -and $it.On) { $off += $it }
    }
    return @{ On = $on; Off = $off; Count = $on.Count + $off.Count }
}

# ---------------------------------------------------------------------------
#  Navigation
# ---------------------------------------------------------------------------
function Show-HomePage([string]$Page, [string]$Sub = '') {
    $script:H2.Page = $Page
    if ($Sub) { $g = if ($Page -eq 'perf') { 'perf' } else { 'prog' }; $script:H2.Sub[$g] = $Sub }
    if ($script:State.Page -ne 'home') { Show-Page 'home' } else { Show-Home -Top }
    $ui.HomeScroll.ScrollToTop()
}
function Open-HomeArea([string]$Id) {
    switch ($Id) {
        { $_ -in 'drivers', 'updates' } { Show-HomePage 'drivers'; return $true }
        { $_ -in 'settings', 'gaming' } { Show-HomePage 'perf' 'settings'; return $true }
        { $_ -in 'gpu', 'games' } { Show-HomePage 'perf' 'gpu'; return $true }
        'startup' { Show-HomePage 'perf' 'startup'; return $true }
        { $_ -in 'cleanup', 'storage' } { Show-HomePage 'storage'; return $true }
        'uninstall' { Show-HomePage 'prog' 'installed'; return $true }
        'leftovers' { Show-HomePage 'prog' 'orphans'; return $true }
        'overdrive' { Show-HomePage 'overdrive'; return $true }
        'overview' { Show-HomePage 'dash'; return $true }
    }
    return $false
}
# Zeichnet die aktuelle Seite neu (bei Datenänderungen bleibt die Scrollposition erhalten)
function Show-Home([switch]$Top) {
    $off = $ui.HomeScroll.VerticalOffset
    $script:H2.Live = $null; $script:H2.NeedLoad = $false
    Set-HomeBar ''
    $root = New-Stack
    try {
        switch ($script:H2.Page) {
            'optimize' { Build-Optimize $root }
            'perf' { Build-Perf $root }
            'storage' { Build-Storage $root }
            'prog' { Build-Prog $root }
            'drivers' { Build-Drivers $root }
            'overdrive' { Build-Overdrive $root }
            default { $script:H2.Page = 'dash'; Build-Dash $root }
        }
    } catch {
        [void]$root.Children.Add((New-HCard (New-Text ("Diese Ansicht konnte nicht aufgebaut werden: " + $_.Exception.Message) -Role 'small' -Color 'danger')))
    }
    $ui.HomeHost.Content = $root
    if (-not $Top) { $ui.HomeScroll.UpdateLayout(); $ui.HomeScroll.ScrollToVerticalOffset($off) }
}
function Test-HomeOn([string]$Page) { $script:State.Page -eq 'home' -and $script:H2.Page -eq $Page }

# Live-Anzeige des Fortschritts und der Schritte beim Optimieren
$script:H2Timer = New-Object Windows.Threading.DispatcherTimer
$script:H2Timer.Interval = [TimeSpan]::FromMilliseconds(400)
$script:H2Timer.Add_Tick({
    $l = $script:H2.Live
    if ($l -and $l.Text -ne $script:Sync.Status) { $l.Text = $script:Sync.Status }
    if ($script:H2.NeedLoad -and -not $script:Job -and $script:State.Page -eq 'home') { Show-Home; return }
    $o = $script:H2.Opt
    if ($o -and $o.Phase -eq 'run' -and -not $o.Asking) {
        if (-not $o.Started -and -not $script:Job) { $o.Phase = 'plan'; if (Test-HomeOn 'optimize') { Show-Home } }
        elseif (Test-HomeOn 'optimize') { Update-OptSteps }
    }
})
$script:H2Timer.Start()

# ===========================================================================
#  DASHBOARD
# ===========================================================================
$script:H2Todo = @{
    cleanup  = @{ Tip = 'Windows braucht freien Platz für Updates und Zwischendateien. Wird er knapp, wird der PC spürbar langsamer.'; L = 'Aufräumen'; P = 'storage' }
    system   = @{ Tip = 'Das Laufwerk meldet selbst einen Fehler. Sichere wichtige Dateien und prüf es mit dem Programm des Herstellers.'; L = 'Ansehen'; P = 'storage' }
    drivers  = @{ Tip = 'Ohne passenden Treiber oder Hersteller-Software arbeitet ein Gerät langsam oder gar nicht. TuneRig nutzt nur Windows Update und die Hersteller.'; L = 'Beheben'; P = 'drivers' }
    settings = @{ Tip = 'Windows ist ab Werk auf Stromsparen eingestellt. Diese Einstellungen bringen mehr Leistung und lassen sich jederzeit zurücksetzen.'; L = 'Ansehen'; P = 'perf' }
    safety   = @{ Tip = 'Ein Wiederherstellungspunkt setzt Windows auf einen früheren Stand zurück. Deine Dateien bleiben erhalten.'; L = 'Sicherungen'; P = 'backup' }
    restart  = @{ Tip = 'Ein Neustart beendet hängende Programme und schließt Updates ab. Speichere vorher offene Dateien.'; L = ''; P = '' }
}

function New-DashTile([string]$Icon, [string]$Name, [string]$Value, [int]$Level, [string]$State, [string]$Page, [string]$Tip) {
    $b = New-Object Windows.Controls.Button
    $b.Style = Get-ThemeStyle 'TileBtn'; $b.Padding = New-Thickness 16 16 16 16; $b.Margin = New-Thickness 0 0 12 0
    $sp = New-Stack
    $ic = New-LineIcon $Icon 'ink' 24; $ic.HorizontalAlignment = 'Left'
    [void]$sp.Children.Add($ic)
    [void]$sp.Children.Add((New-Text $Name -Role 'title' -Top 12))
    $v = New-Mono $Value 20; $v.Margin = New-Thickness 0 6 0 0; $v.TextTrimming = 'CharacterEllipsis'
    [void]$sp.Children.Add($v)
    $st = New-StateTag $Level $State 14; $st.Margin = New-Thickness 0 10 0 0
    [void]$sp.Children.Add($st)
    $b.Content = $sp
    if ($Tip) { $b.ToolTip = $Tip }
    [Windows.Automation.AutomationProperties]::SetName($b, "$Name, $Value, $State")
    return (Add-HClick $b { param($p) Show-HomePage $p } $Page)
}

function Build-Dash($root) {
    $h = $script:HealthData
    $m = if ($h -and $h.Metrics) { $h.Metrics } else { $null }
    $items = if ($h) { @($h.Items) } else { @() }

    # --- Systemzustand + PC OPTIMIEREN ---
    $g = New-Object Windows.Controls.Grid
    foreach ($w in 'Auto', '*', 'Auto') { $c = New-Object Windows.Controls.ColumnDefinition; $c.Width = if ($w -eq '*') { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { [Windows.GridLength]::Auto }; $g.ColumnDefinitions.Add($c) }
    $gauge = New-Object Windows.Controls.ContentControl; $gauge.Content = New-HealthGauge $(if ($h) { $h.Score } else { -1 }); $gauge.VerticalAlignment = 'Center'
    [void]$g.Children.Add($gauge)
    $mid = New-Stack; $mid.Margin = New-Thickness 24 0 24 0; $mid.VerticalAlignment = 'Center'
    [void]$mid.Children.Add((New-Label 'Systemzustand'))
    $sc = New-Stack 'Horizontal' 8
    $scoreT = New-Text $(if ($h) { [string]$h.Score } else { '–' }) -Role 'metric'; [void]$sc.Children.Add($scoreT)
    $mx = New-Mono ' / 100' 14 'ink-muted'; $mx.VerticalAlignment = 'Bottom'; $mx.Margin = New-Thickness 4 0 16 6; [void]$sc.Children.Add($mx)
    $rt = New-Text $(if ($h) { $h.Rating } else { 'Wird bewertet …' }) -Role 'h3' -Color $(if ($h) { $script:LevelToken[$h.Level] } else { 'ink' }); $rt.VerticalAlignment = 'Center'
    [void]$sc.Children.Add($rt)
    [void]$mid.Children.Add($sc)
    $sum = if (-not $h) { 'Der Schnellcheck läuft – dauert nur ein paar Sekunden.' } elseif ($items.Count -eq 0) { 'Alles in Ordnung.' } elseif ($items.Count -eq 1) { '1 Sache kannst du verbessern.' } else { "$($items.Count) Dinge kannst du verbessern." }
    [void]$mid.Children.Add((New-Text $sum -Role 'body' -Color 'ink-muted' -Top 4))
    [Windows.Controls.Grid]::SetColumn($mid, 1); [void]$g.Children.Add($mid)
    $act = New-Stack; $act.VerticalAlignment = 'Center'
    $pb = New-HButton 'PC optimieren' { Start-Optimize } -Primary -Icon 'bolt'; $pb.MinWidth = 240; $pb.MinHeight = 48
    [void]$act.Children.Add($pb)
    $note = New-Text "ca. 3 Minuten · $(Get-BackupNote)" -Role 'small' -Color 'ink-muted' -Top 8; $note.HorizontalAlignment = 'Center'
    [void]$act.Children.Add($note)
    $re = New-Link 'Neu bewerten' { Start-QuickHealth; Show-Home }; $re.HorizontalAlignment = 'Center'; $re.Margin = New-Thickness 0 4 0 0
    if ($script:HealthJob -and -not $script:HealthJob.Done) { $re.IsEnabled = $false }
    [void]$act.Children.Add($re)
    [Windows.Controls.Grid]::SetColumn($act, 2); [void]$g.Children.Add($act)
    [void]$root.Children.Add((New-HCard $g 24 16))

    # --- Was du verbessern kannst ---
    if ($items.Count) {
        $card = New-HCard $null 0 16
        $sp = New-Stack
        $first = $true
        foreach ($i in @($items | Select-Object -First 6)) {
            if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
            $key = if ($i.Step) { [string]$i.Step } else { 'restart' }
            $def = $script:H2Todo[$key]; if (-not $def) { $def = @{ Tip = ''; L = 'Ansehen'; P = 'dash' } }
            $row = New-Dock; $row.Margin = New-Thickness 16 10 16 10
            $ic = New-LineIcon $script:LevelIconKind[[int]$i.Level] $script:LevelToken[[int]$i.Level] 20; $ic.Margin = New-Thickness 0 0 12 0; $ic.VerticalAlignment = 'Center'
            [void]$row.Children.Add((Set-Dock $ic 'Left'))
            if ($def.L) {
                $btn = New-HButton $def.L { param($p) if ($p -eq 'backup') { Show-RestorePointManager } else { Show-HomePage $p } } $def.P
                $btn.MinHeight = 36; $btn.Padding = New-Thickness 14 6 14 7; $btn.MinWidth = 120
                [void]$row.Children.Add((Set-Dock $btn 'Right'))
            }
            $mp = New-Stack 'Horizontal'; $mp.VerticalAlignment = 'Center'
            $tt = New-Text $i.Title -Role 'body'; $tt.VerticalAlignment = 'Center'; [void]$mp.Children.Add($tt)
            $inf = New-Info $def.Tip; if ($inf) { $inf.Margin = New-Thickness 4 0 0 0; [void]$mp.Children.Add($inf) }
            [void]$row.Children.Add($mp)
            [void]$sp.Children.Add($row)
        }
        $card.Child = $sp
        [void]$root.Children.Add($card)
    }

    # --- Wie willst du optimieren? (die geführten Checks wie bisher) ---
    Add-DashModes $root

    # --- Bereiche ---
    [void]$root.Children.Add((New-Section 'Bereiche' 8))
    $ug = New-Object Windows.Controls.Primitives.UniformGrid; $ug.Columns = 5; $ug.Margin = New-Thickness 0 0 -12 16
    $unk = -not $m
    # Leistung
    $open = if ($unk) { -1 } else { [int]$m.OpenTweaks }
    [void]$ug.Children.Add((New-DashTile 'bolt' 'Leistung' $(if ($open -lt 0) { '–' } elseif ($open -eq 0) { 'Optimal' } else { "$open offen" }) $(if ($open -lt 0) { 1 } elseif ($open -gt 0) { 2 } else { 0 }) $(if ($open -lt 0) { 'Wird geprüft' } elseif ($open -gt 0) { 'Verbesserbar' } else { 'Alles aktiv' }) 'perf' 'Einstellungen, Grafikkarte und Autostart'))
    # Speicherplatz
    $free = if ($unk) { -1L } else { [long]$m.SysFree }
    $pct = if ($free -ge 0) { 100.0 * $free / [math]::Max(1.0, [double]$m.SysSize) } else { -1 }
    [void]$ug.Children.Add((New-DashTile 'drive' 'Speicherplatz' $(if ($free -lt 0) { '–' } else { "$(Format-Bytes $free) frei" }) $(if ($pct -lt 0) { 1 } elseif ($pct -lt 10) { 3 } elseif ($pct -lt 20) { 2 } else { 0 }) $(if ($pct -lt 0) { 'Wird geprüft' } elseif ($pct -lt 10) { 'Fast voll' } elseif ($pct -lt 20) { 'Wird knapp' } else { 'Genug Platz' }) 'storage' 'Aufräumen und große Dateien finden'))
    # Treiber
    $di = if ($unk) { -1 } else { [int]$m.DriverIssues + [int]$m.GpuSwMissing }
    [void]$ug.Children.Add((New-DashTile 'chip' 'Treiber' $(if ($di -lt 0) { '–' } elseif ($di -eq 0) { 'Alles ok' } elseif ($di -eq 1) { '1 Problem' } else { "$di Probleme" }) $(if ($di -lt 0) { 1 } elseif ([int]$m.DriverIssues -gt 0) { 3 } elseif ($di -gt 0) { 2 } else { 0 }) $(if ($di -lt 0) { 'Wird geprüft' } elseif ($di -gt 0) { 'Handeln nötig' } else { 'In Ordnung' }) 'drivers' 'Treiber, Hersteller-Software und Updates'))
    # Programme
    $pc = if ($unk) { -1 } else { [int]$m.Programs }
    [void]$ug.Children.Add((New-DashTile 'grid' 'Programme' $(if ($pc -lt 0) { '–' } else { "$pc installiert" }) 1 'Reste suchen' 'prog' 'Deinstallieren ohne Reste, alte Reste finden'))
    # Overdrive
    [void]$ug.Children.Add((New-DashTile 'flame' 'Overdrive' 'Übertakten' 2 'Eigenes Risiko' 'overdrive' 'Grenzen aufheben – nur auf eigenes Risiko'))
    [void]$root.Children.Add($ug)

    # --- Fußzeile ---
    $f = New-Dock; $f.Margin = New-Thickness 0 8 0 0
    $ex = New-Link 'Expertenansicht mit allen Werkzeugen →' { Show-Page 'expert' } -Accent
    [void]$f.Children.Add((Set-Dock $ex 'Right'))
    $lr = if ($m -and $m.LastRestore) { $d = [int]((Get-Date) - [datetime]$m.LastRestore).TotalDays; if ($d -le 0) { 'heute' } elseif ($d -eq 1) { 'gestern' } else { "vor $d Tagen" } } elseif ($m) { 'keine' } else { '…' }
    $fl = New-Stack 'Horizontal'
    $ft = New-Text "Letzte Sicherung: $lr" -Role 'small' -Color 'ink-muted'; $ft.VerticalAlignment = 'Center'; [void]$fl.Children.Add($ft)
    $fm = New-Link 'Verwalten' { Show-RestorePointManager } -Accent; $fm.Margin = New-Thickness 12 0 0 0; [void]$fl.Children.Add($fm)
    [void]$f.Children.Add($fl)
    [void]$root.Children.Add($f)
}
$script:UiHooks['health'] = { if (Test-HomeOn 'dash') { Show-Home } }

# Die vier Wege, den PC zu optimieren - jeder mit eigener Kennfarbe, Leistungsgewinn und Dauer
function Add-DashModes($root) {
    $hd = New-Stack 'Horizontal'; $hd.Margin = New-Thickness 0 8 0 8
    $l = New-Label 'Wie willst du optimieren?'; $l.VerticalAlignment = 'Center'; [void]$hd.Children.Add($l)
    $i = New-Info '»PC optimieren« oben ist der schnelle Weg: ein Plan, ein Klick. Die Checks gehen Schritt für Schritt vor – du entscheidest bei jedem Punkt selbst, was geändert wird.'; $i.Margin = New-Thickness 4 -6 0 -6; [void]$hd.Children.Add($i)
    [void]$root.Children.Add($hd)
    $ug = New-Object Windows.Controls.Primitives.UniformGrid; $ug.Columns = 4; $ug.Margin = New-Thickness 0 0 -12 24
    $defs = @(
        @{ M = 'normal'; Icon = 'check'; Tok = 'ink'; Tag = 'Empfohlen für alle'; TagTok = 'ink-muted'; Name = 'Regulärer Check'; Text = 'Prüft und verbessert Schritt für Schritt. Du entscheidest bei jedem Punkt.'; Gain = 1; Time = '5 Schritte · 5–10 Min.' }
        @{ M = 'gaming'; Icon = 'flame'; Tok = 'accent'; Tag = 'Für Spiele'; TagTok = 'accent-text'; Name = 'Performance Boost'; Text = 'Geht tiefer: Bildrate, Maus, Prozessor, Autostart, Internet.'; Gain = 2; Time = 'ca. 10–15 Min.' }
        @{ M = 'overdrive'; Icon = 'bolt'; Tok = 'warning'; Tag = 'Eigenes Risiko'; TagTok = 'warning'; Name = 'Overdrive'; Text = 'Übertakten und Tuning in 3 Stufen. Mit Anleitung für CPU, GPU und RAM.'; Gain = 3; Time = '3 Stufen · ca. 10 Min.' }
        @{ M = 'expert'; Icon = 'grid'; Tok = 'ink-muted'; Tag = 'Für Erfahrene'; TagTok = 'ink-muted'; Name = 'Alle Werkzeuge'; Text = 'Jede Funktion einzeln, in Reitern. Volle Kontrolle.'; Gain = 0; Time = 'ohne Führung' }
    )
    foreach ($d in $defs) {
        $card = New-HCard $null 16 0; $card.Margin = New-Thickness 0 0 12 0
        $dp = New-Dock
        $running = $d.M -ne 'expert' -and $script:Wiz.Started -and $script:Wiz.Mode -eq $d.M -and $script:Wiz.Index -gt 0
        $btn = New-HButton $(if ($d.M -eq 'expert') { 'Öffnen' } elseif ($running) { 'Fortsetzen' } else { 'Starten' }) { param($m) if ($m -eq 'expert') { Show-Page 'expert' } else { Open-WizMode $m } } $d.M -Icon 'arrow'
        $btn.HorizontalAlignment = 'Left'; $btn.Margin = New-Thickness 0 16 0 0
        [void]$dp.Children.Add((Set-Dock $btn 'Bottom'))
        $sp = New-Stack
        $h = New-Stack 'Horizontal'
        $ic = New-LineIcon $d.Icon $d.Tok 20; $ic.Margin = New-Thickness 0 0 8 0; $ic.VerticalAlignment = 'Center'; [void]$h.Children.Add($ic)
        $tg = New-Label $d.Tag $d.TagTok; $tg.VerticalAlignment = 'Center'; [void]$h.Children.Add($tg)
        [void]$sp.Children.Add($h)
        [void]$sp.Children.Add((New-Text $d.Name -Role 'h3' -Top 10))
        [void]$sp.Children.Add((New-Text $d.Text -Role 'small' -Color 'ink-muted' -Top 4))
        $g = New-Stack 'Horizontal' 10
        if ($d.Gain -ge 1) { $mtr = New-SegmentMeter $d.Gain 3 $(if ($d.M -eq 'normal') { 'ink' } else { $d.Tok }); $mtr.Margin = New-Thickness 0 0 10 0; [Windows.Automation.AutomationProperties]::SetName($mtr, "Leistungsgewinn $($d.Gain) von 3"); [void]$g.Children.Add($mtr) }
        [void]$g.Children.Add((New-Text $d.Time -Role 'small' -Color 'ink-muted'))
        [void]$sp.Children.Add($g)
        [void]$dp.Children.Add($sp)
        $card.Child = $dp
        [void]$ug.Children.Add($card)
    }
    [void]$root.Children.Add($ug)
}

# ===========================================================================
#  PC OPTIMIEREN: prüfen → Plan zeigen (Haken setzen) → sichern → anwenden → vorher/nachher
# ===========================================================================
function Start-Optimize {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $h = $script:HealthData
    $script:H2.Opt = @{ Phase = 'scan'; Data = $null; Sel = @{}; Started = $false; Result = $null
                        Before = @{ Score = $(if ($h) { $h.Score } else { -1 }); Free = $(if ($h -and $h.Metrics) { [long]$h.Metrics.SysFree } else { -1L }); Open = $(if ($h -and $h.Metrics) { [int]$h.Metrics.OpenTweaks } else { -1 }) } }
    Show-HomePage 'optimize'
    Start-Work -Cancellable -Status 'Prüfe, was sich verbessern lässt …' -Script {
        $l = Test-IsLaptop
        Report 'Prüfe Einstellungen …'; $set = @(Get-AllSettings $l)
        Report 'Prüfe Treiber … (bis zu einer Minute)'; $drv = Get-DriverAnalysis
        $clean = foreach ($d in @(Get-CleanupDefs)) {
            Report "Berechne: $($d.Name) …"
            $x = @(Measure-Cleanup $d.Id)[-1]
            [pscustomobject]@{ Id = $d.Id; Name = $d.Name; Desc = $d.Desc; Sel = [bool]$d.Sel; Size = [long]$x.Size; Count = [int]$x.Count }
        }
        [pscustomobject]@{ Settings = $set; Todo = @($drv.Todo); Devices = @($drv.Drivers).Count; Clean = @($clean); Browsers = @(Get-RunningBrowsers); Laptop = $l }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $o = $script:H2.Opt
        $o.Data = $r
        $script:State.Settings = @($r.Settings | Where-Object { $_ })
        $o.Sel = @{}
        # Vorausgewählt: nur Empfohlenes ohne Nebenwirkung und die Standard-Bereiche beim Aufräumen. Alles andere wählst du selbst.
        foreach ($s in @(Get-OptSettings)) { $o.Sel["s:$($s.Id)"] = $s.Mode -eq 'recommended' -and -not $s.Risk }
        foreach ($c in @($r.Clean)) { $o.Sel["c:$($c.Id)"] = $c.Sel -and ($c.Size -gt 0) -and -not ($c.Id -like 'browser-*' -and @($r.Browsers).Count) }
        $o.Phase = 'plan'
        Set-Status 'Prüfung fertig. Wähle aus, was verbessert werden soll.'
        if (Test-HomeOn 'optimize') { Show-Home -Top }
    } -OnCancel { $script:H2.Opt = $null; Set-Status 'Abgebrochen.'; if (Test-HomeOn 'optimize') { Show-HomePage 'dash' } }
}
# Alle noch nicht aktiven Einstellungen: erst Empfohlenes (sichere zuerst), dann Optionales und Experimentelles
function Get-OptSettings {
    $d = $script:H2.Opt.Data; if (-not $d) { return @() }
    @($d.Settings | Where-Object { $_ -and -not $_.Optimal } | Sort-Object @{ e = { @{ recommended = 0; optional = 1; experimental = 2 }[$_.Mode] } }, @{ e = { [bool]$_.Risk } }, @{ e = { -[int]$_.Impact } })
}
function Get-OptCount { @($script:H2.Opt.Sel.Keys | Where-Object { $script:H2.Opt.Sel[$_] }).Count }

$script:OptStepDefs = @(
    @{ Name = 'Prüfen'; Wait = 'Treiber, Einstellungen, Datenmüll' }
    @{ Name = 'Sicherung'; Wait = 'Wiederherstellungspunkt' }
    @{ Name = 'Einstellungen'; Wait = 'Auf Leistung stellen' }
    @{ Name = 'Aufräumen'; Wait = 'Datenmüll löschen' }
)
# Zustand je Schritt: 0 wartet, 1 läuft, 2 fertig, 3 übersprungen
function Get-OptStepStates {
    $o = $script:H2.Opt; $st = $script:Sync.Status
    switch ($o.Phase) {
        'scan' { return @(1, 0, 0, 0) }
        'plan' { return @(2, 0, 0, 0) }
        'run' {
            if (-not $o.Started) { return @(2, 1, 0, 0) }
            $b = if ($o.Backup) { 2 } else { 3 }
            if ($st -match '^(Räume|Bereinige|Bewerte)') { return @(2, $b, 2, 1) }
            return @(2, $b, 1, 0)
        }
        default { $b = if ($o.Backup) { 2 } else { 3 }; return @(2, $b, 2, 2) }
    }
}
function Get-OptStepDetail([int]$i, [int]$State) {
    $o = $script:H2.Opt; $r = $o.Result
    if ($State -eq 3) { return 'Ohne Sicherung (deine Einstellung)' }
    if ($State -ne 2) { return $script:OptStepDefs[$i].Wait }
    switch ($i) {
        0 { $n = @(Get-OptSettings | Where-Object { $_.Mode -eq 'recommended' }).Count; $t = @($o.Data.Todo).Count; "$n Einstellung(en) offen · $(if ($t) { "$t Treiber-Aufgabe(n)" } else { 'Treiber in Ordnung' })" }
        1 { 'Wiederherstellungspunkt vorhanden' }
        2 { if ($r) { $e = @($r.Errors).Count; "$($r.SetCount) Einstellung(en) umgestellt" + $(if ($e) { " · $e Hinweis(e)" } else { '' }) } else { $script:OptStepDefs[$i].Wait } }
        3 { if ($r) { "$(Format-Bytes $r.Freed) freigegeben" } else { $script:OptStepDefs[$i].Wait } }
    }
}
function Update-OptSteps {
    $els = $script:H2.OptEls; if (-not $els) { return }
    $states = Get-OptStepStates
    for ($i = 0; $i -lt 4; $i++) {
        $s = $states[$i]; $e = $els[$i]
        if ($e.State -eq $s) { continue }
        $e.State = $s
        $tok = switch ($s) { 2 { 'success' } 1 { 'accent-text' } default { 'ink-muted' } }
        $e.Icon.Content = New-LineIcon $(switch ($s) { 2 { 'check' } 1 { 'refresh' } 3 { 'minus' } default { 'dot' } }) $tok 22
        $e.Detail.Text = Get-OptStepDetail $i $s
        $e.Word.Text = switch ($s) { 2 { 'fertig' } 1 { 'läuft' } 3 { 'übersprungen' } default { 'wartet' } }
        Set-ThemeRef $e.Word Foreground $tok
        Set-ThemeRef $e.Seg Background $(switch ($s) { 2 { 'success' } 1 { 'accent' } 3 { 'ink-muted' } default { 'line' } })
    }
}

function Build-Optimize($root) {
    $o = $script:H2.Opt
    if (-not $o) { $script:H2.Page = 'dash'; Build-Dash $root; return }
    [void]$root.Children.Add((New-Label 'PC optimieren'))
    $head = switch ($o.Phase) { 'scan' { 'Prüfe deinen PC …' } 'plan' { 'Das wird verbessert' } 'run' { 'Optimiere …' } default { 'Fertig. Dein PC ist optimiert.' } }
    [void]$root.Children.Add((New-Text $head -Role 'h1' -Top 8))
    # Fortschritt in vier Segmenten
    $segs = New-Object Windows.Controls.Primitives.UniformGrid; $segs.Columns = 4; $segs.Rows = 1; $segs.Margin = New-Thickness 0 14 0 24
    $els = @()
    for ($i = 0; $i -lt 4; $i++) {
        $b = New-Object Windows.Controls.Border; $b.Height = 6; $b.CornerRadius = New-Object Windows.CornerRadius(1); $b.Margin = New-Thickness 0 0 4 0
        Set-ThemeRef $b Background 'line'; [void]$segs.Children.Add($b)
        $els += @{ Seg = $b; State = -1 }
    }
    [void]$root.Children.Add($segs)

    $cols = New-Object Windows.Controls.Grid
    foreach ($w in 3, 24, 2) { $c = New-Object Windows.Controls.ColumnDefinition; $c.Width = if ($w -eq 24) { New-Object Windows.GridLength(24) } else { New-Object Windows.GridLength($w, [Windows.GridUnitType]::Star) }; $cols.ColumnDefinitions.Add($c) }
    # Schritte
    $stepCard = New-HCard $null 0 16; $sp = New-Stack
    for ($i = 0; $i -lt 4; $i++) {
        if ($i) { [void]$sp.Children.Add((New-RowLine)) }
        $row = New-Dock; $row.Margin = New-Thickness 20 16 20 16
        $ic = New-Object Windows.Controls.ContentControl; $ic.Width = 32; $ic.Margin = New-Thickness 0 0 12 0; $ic.VerticalAlignment = 'Center'
        [void]$row.Children.Add((Set-Dock $ic 'Left'))
        $word = New-Mono '' 14 'ink-muted'; [void]$row.Children.Add((Set-Dock $word 'Right'))
        $tx = New-Stack; $tx.VerticalAlignment = 'Center'
        [void]$tx.Children.Add((New-Text $script:OptStepDefs[$i].Name -Role 'h3'))
        $det = New-Text '' -Role 'small' -Color 'ink-muted'; [void]$tx.Children.Add($det)
        [void]$row.Children.Add($tx)
        [void]$sp.Children.Add($row)
        $els[$i].Icon = $ic; $els[$i].Detail = $det; $els[$i].Word = $word
    }
    $stepCard.Child = $sp
    [void]$cols.Children.Add($stepCard)
    $script:H2.OptEls = $els
    Update-OptSteps

    # Rechte Spalte: je nach Phase Fortschritt, Plan-Zusammenfassung oder vorher → nachher
    $side = New-Stack
    if ($o.Phase -in 'scan', 'run') {
        [void]$side.Children.Add((New-Loading $(if ($o.Phase -eq 'scan') { 'Nur lesen – noch ändert sich nichts.' } else { 'Bitte lass TuneRig kurz arbeiten.' })))
    } else {
        $res = New-Stack
        [void]$res.Children.Add((New-Label 'Vorher → nachher'))
        $b = $o.Before; $a = if ($o.Result -and $o.Result.Health) { $o.Result.Health } else { $null }
        $am = if ($a) { $a.Metrics } else { $null }
        $rows = @(
            , @('Systemzustand', $(if ($b.Score -ge 0) { [string]$b.Score } else { '–' }), $(if ($a) { [string]$a.Score } else { '…' }))
            , @("Freier Platz auf $env:SystemDrive", $(if ($b.Free -ge 0) { Format-Bytes $b.Free } else { '–' }), $(if ($am -and $am.SysFree -ge 0) { Format-Bytes $am.SysFree } else { '…' }))
            , @('Offene Empfehlungen', $(if ($b.Open -ge 0) { [string]$b.Open } else { '–' }), $(if ($am -and $am.OpenTweaks -ge 0) { [string]$am.OpenTweaks } else { '…' }))
        )
        foreach ($x in $rows) {
            $d = New-Dock; $d.Margin = New-Thickness 0 16 0 0
            $v = New-Stack 'Horizontal'
            [void]$v.Children.Add((New-Mono $x[1] 18 'ink-muted'))
            [void]$v.Children.Add((New-Mono '  →  ' 18 'ink-muted'))
            [void]$v.Children.Add((New-Mono $x[2] 18 $(if ($a) { 'success' } else { 'ink-muted' })))
            [void]$d.Children.Add((Set-Dock $v 'Right'))
            $n = New-Text $x[0] -Role 'body' -Color 'ink-muted'; $n.VerticalAlignment = 'Center'; [void]$d.Children.Add($n)
            [void]$res.Children.Add($d)
        }
        if ($o.Phase -eq 'done' -and $o.Result) {
            if ($o.Result.Restart) { $w = New-StateTag 1 'Einige Änderungen wirken erst nach einem Neustart.'; $w.Margin = New-Thickness 0 20 0 0; [void]$res.Children.Add($w) }
            foreach ($e in @($o.Result.Errors | Select-Object -First 3)) { $w = New-StateTag 2 ([string]$e); $w.Margin = New-Thickness 0 8 0 0; ($w.Children[1]).TextWrapping = 'Wrap'; [void]$res.Children.Add($w) }
        }
        [void]$side.Children.Add((New-HCard $res 24 16))
    }
    [Windows.Controls.Grid]::SetColumn($side, 2); [void]$cols.Children.Add($side)
    [void]$root.Children.Add($cols)

    if ($o.Phase -eq 'plan') { Build-OptPlan $root }
    elseif ($o.Phase -eq 'done') {
        $t = @($o.Data.Todo)
        if ($t.Count) {
            $d = New-Dock
            [void]$d.Children.Add((Set-Dock (New-HButton 'Treiber ansehen' { Show-HomePage 'drivers' }) 'Right'))
            $st = New-StateTag ([int](@($t | Measure-Object Level -Maximum).Maximum)) "$($t.Count) Treiber-Aufgabe(n) machst du selbst – nur mit Original-Treibern."; $st.VerticalAlignment = 'Center'
            [void]$d.Children.Add($st)
            [void]$root.Children.Add((New-HCard $d 16 16))
        }
        Set-HomeBar 'Alles lässt sich zurücksetzen – unten rechts unter »Sicherungen«.' 'Fertig' { $script:H2.Opt = $null; Show-HomePage 'dash' }
    }
}

function Build-OptPlan($root) {
    $o = $script:H2.Opt; $d = $o.Data
    $all = @(Get-OptSettings)
    $sets = @($all | Where-Object { $_.Mode -eq 'recommended' }); $extra = @($all | Where-Object { $_.Mode -ne 'recommended' })
    $clean = @($d.Clean | Where-Object { $_.Size -gt 0 -or $_.Id -eq 'winsxs' } | Sort-Object @{ e = { -not $_.Sel } }, @{ e = { -[long]$_.Size } })
    # Treiber: nur anzeigen, nie automatisch installieren
    $todo = @($d.Todo)
    $dc = New-Dock
    if ($todo.Count) {
        [void]$dc.Children.Add((Set-Dock (New-HButton 'Ansehen' { Show-HomePage 'drivers' }) 'Right'))
        $lv = [int](@($todo | Measure-Object Level -Maximum).Maximum)
        $st = New-StateTag $lv "Treiber: $($todo.Count) Aufgabe(n) – erledigst du auf der Treiber-Seite"
    } else { $st = New-StateTag 0 "Treiber: alle $($d.Devices) Geräte in Ordnung" }
    $st.VerticalAlignment = 'Center'; [void]$dc.Children.Add($st)
    [void]$root.Children.Add((New-HCard $dc 16 16))

    if ($sets.Count -eq 0 -and $extra.Count -eq 0 -and $clean.Count -eq 0) {
        [void]$root.Children.Add((New-HCard (New-StateTag 0 'Dein PC ist schon optimal eingestellt. Hier gibt es nichts zu tun.') 16 16))
        Set-HomeBar '' 'Fertig' { $script:H2.Opt = $null; Show-HomePage 'dash' }
        return
    }
    if ($sets.Count) {
        [void]$root.Children.Add((New-Section 'Einstellungen'))
        $card = New-HCard $null 0 16; $sp = New-Stack; $first = $true
        foreach ($s in $sets) {
            if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
            $tip = $s.Benefit + $(if ($s.Risk) { "`nNebenwirkung: $($s.Risk)" } else { '' }) + "`nJetzt: $($s.State)"
            $tag = if ($s.Risk) { @('Nebenwirkung', 'warning') } elseif ($s.Restart) { @('Neustart', 'ink-muted') } else { @('', '') }
            [void]$sp.Children.Add((New-OptCheck "s:$($s.Id)" $s.Title $tip ([int]$s.Impact) '' $tag[0] $tag[1]))
        }
        $card.Child = $sp; [void]$root.Children.Add($card)
    }
    # Optionales und Experimentelles: aufklappbar, nie vorausgewählt
    if ($extra.Count) {
        $on = [bool]$script:H2.Open['optx']
        $hd = New-Stack 'Horizontal'; $hd.Margin = New-Thickness 0 8 0 8
        [void]$hd.Children.Add((New-Link $(if ($on) { "Weitere Einstellungen ($($extra.Count)) ausblenden" } else { "Weitere Einstellungen ($($extra.Count)) anzeigen – optional, mit Nebenwirkung" }) { $script:H2.Open['optx'] = -not $script:H2.Open['optx']; Show-Home } -Accent))
        $hi = New-Info 'Optional = bringt etwas, hat aber eine Nebenwirkung. Experimentell = Wirkung umstritten. Nichts davon ist vorausgewählt – du entscheidest.'; $hi.Margin = New-Thickness 4 0 0 0; [void]$hd.Children.Add($hi)
        [void]$root.Children.Add($hd)
        if ($on) {
            $card = New-HCard $null 0 16; $sp = New-Stack; $first = $true
            foreach ($s in $extra) {
                if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
                $tip = $s.Benefit + $(if ($s.Risk) { "`nNebenwirkung: $($s.Risk)" } else { '' }) + "`nJetzt: $($s.State)"
                $tag = if ($s.Mode -eq 'experimental') { @('Experimentell', 'warning') } else { @('Optional', 'ink-muted') }
                [void]$sp.Children.Add((New-OptCheck "s:$($s.Id)" $s.Title $tip ([int]$s.Impact) '' $tag[0] $tag[1]))
            }
            $card.Child = $sp; [void]$root.Children.Add($card)
        }
    }
    if ($clean.Count) {
        [void]$root.Children.Add((New-Section 'Aufräumen'))
        $card = New-HCard $null 0 16; $sp = New-Stack; $first = $true
        foreach ($c in $clean) {
            if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
            $busyB = $c.Id -like 'browser-*' -and @($d.Browsers).Count
            [void]$sp.Children.Add((New-OptCheck "c:$($c.Id)" $c.Name $c.Desc 0 $(if ($c.Id -eq 'winsxs') { 'erst danach messbar' } else { Format-Bytes $c.Size }) $(if ($busyB) { 'Browser offen' } elseif (-not $c.Sel) { 'Optional' } else { '' }) $(if ($busyB) { 'warning' } else { 'ink-muted' })))
        }
        $card.Child = $sp; [void]$root.Children.Add($card)
    }
    # Lieber selbst Schritt für Schritt?
    $alt = New-Stack 'Horizontal'; $alt.Margin = New-Thickness 0 8 0 0
    [void]$alt.Children.Add((New-Text 'Lieber Schritt für Schritt?' -Role 'small' -Color 'ink-muted'))
    foreach ($m in @(@('normal', 'Regulärer Check'), @('gaming', 'Performance Boost'))) { $l = New-Link $m[1] { param($x) $script:H2.Opt = $null; Open-WizMode $x } $m[0] -Accent; $l.Margin = New-Thickness 16 0 0 0; [void]$alt.Children.Add($l) }
    [void]$root.Children.Add($alt)
    Update-OptBar
}
function New-OptCheck([string]$Key, [string]$Title, [string]$Tip, [int]$Impact, [string]$Value, [string]$Tag = '', [string]$TagToken = 'ink-muted') {
    $row = New-Dock; $row.Margin = New-Thickness 16 10 16 10
    $cb = New-Object Windows.Controls.CheckBox; $cb.IsChecked = [bool]$script:H2.Opt.Sel[$Key]; $cb.VerticalAlignment = 'Center'; $cb.Margin = New-Thickness 0 0 4 0
    [Windows.Automation.AutomationProperties]::SetName($cb, $Title)
    $cb.CommandParameter = $Key
    $cb.Add_Click({ $script:H2.Opt.Sel[[string]$this.CommandParameter] = [bool]$this.IsChecked; Update-OptBar })
    [void]$row.Children.Add((Set-Dock $cb 'Left'))
    if ($Value) { $v = New-Mono $Value 14 'ink-muted'; $v.Margin = New-Thickness 16 0 0 0; [void]$row.Children.Add((Set-Dock $v 'Right')) }
    if ($Impact -ge 1) { $m = New-SegmentMeter $Impact 3 'ink'; $m.Margin = New-Thickness 16 0 0 0; [Windows.Automation.AutomationProperties]::SetName($m, "Wirkung $Impact von 3"); [void]$row.Children.Add((Set-Dock $m 'Right')) }
    if ($Tag) { [void]$row.Children.Add((Set-Dock (New-Tag $Tag $TagToken) 'Right')) }
    $mp = New-Stack 'Horizontal'; $mp.VerticalAlignment = 'Center'
    $t = New-Text $Title -Role 'body'; $t.VerticalAlignment = 'Center'; [void]$mp.Children.Add($t)
    $i = New-Info $Tip; if ($i) { $i.Margin = New-Thickness 4 0 0 0; [void]$mp.Children.Add($i) }
    [void]$row.Children.Add($mp)
    return $row
}
function Update-OptBar {
    $n = Get-OptCount
    $cancel = New-HButton 'Abbrechen' { $script:H2.Opt = $null; Show-HomePage 'dash' }
    Set-HomeBar "$n Änderung(en) · $(Get-BackupNote)" 'Jetzt optimieren' { Invoke-Optimize } ($n -gt 0) @($cancel)
}
function Invoke-Optimize {
    $o = $script:H2.Opt
    if (-not $o -or $o.Phase -ne 'plan' -or $script:Job) { return }
    $ids = @(Get-OptSettings | Where-Object { $o.Sel["s:$($_.Id)"] } | ForEach-Object { $_.Id })
    $cids = @($o.Data.Clean | Where-Object { $o.Sel["c:$($_.Id)"] } | ForEach-Object { $_.Id })
    if ($ids.Count + $cids.Count -eq 0) { return }
    $o.Ids = $ids; $o.CleanIds = $cids
    $o.Restart = [bool](@(Get-OptSettings | Where-Object { $ids -contains $_.Id -and $_.Restart }).Count)
    $o.Phase = 'run'; $o.Started = $false; $o.Asking = $true
    Show-Home -Top
    try {
        Invoke-WithRestorePoint 'TuneRig: PC optimieren' { Start-OptimizeApply }
    } finally { $o.Asking = $false }
}
function Start-OptimizeApply {
    $o = $script:H2.Opt
    $o.Phase = 'run'; $o.Started = $true; $o.Backup = [bool]$script:State.Backup
    Start-Work -Status 'Stelle Einstellungen um …' -Arguments @(@($o.Ids), @($o.CleanIds)) -Script {
        $e = @(); if (@($A[0]).Count) { $e = @(Invoke-AllSettings $A[0]) }
        $freed = 0L
        foreach ($id in @($A[1])) { Report "Räume auf: $id …"; try { $freed += [long](@(Invoke-Cleanup $id)[-1]) } catch { $e += "Aufräumen ($id): $($_.Exception.Message)" } }
        Report 'Bewerte den Systemzustand neu …'
        [pscustomobject]@{ Errors = @($e | Where-Object { $_ }); Freed = $freed; Health = (Get-QuickHealth) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $o = $script:H2.Opt
        $o.Result = @{ Errors = @($r.Errors); Freed = [long]$r.Freed; Health = $r.Health; SetCount = @($o.Ids).Count; Restart = $o.Restart }
        $o.Phase = 'done'
        $script:LastCheck = (Get-Date).ToString('o'); Save-AppSettings 'home'
        $script:H2.Settings = $null
        if ($r.Health) { Show-QuickHealth $r.Health }
        Set-Status "Fertig: $(@($o.Ids).Count) Einstellung(en) umgestellt, $(Format-Bytes $r.Freed) freigegeben."
        if (Test-HomeOn 'optimize') { Show-Home -Top }
    }
}

# Nach dem Assistenten oder der Expertenansicht können sich Einstellungen geändert haben: neu einlesen
function Reset-HomeCache {
    foreach ($k in 'Settings', 'Gpu', 'Games', 'Startup', 'Clean', 'Od') { $script:H2[$k] = $null }
    foreach ($k in 'Want', 'GameWant', 'StartWant', 'OdWant') { $script:H2[$k] = @{} }
}

# ===========================================================================
#  LEISTUNG: Einstellungen · Grafikkarte · Autostart
# ===========================================================================
function Get-PerfItems {
    @($script:H2.Settings | Where-Object { $_ } | Sort-Object @{ e = { $script:SetGroupOrder[$_.Group] } }, @{ e = { @{ recommended = 0; optional = 1; experimental = 2 }[$_.Mode] } }, Title | ForEach-Object {
        $tip = $_.Benefit + $(if ($_.Risk) { "`nNebenwirkung: $($_.Risk)" } else { '' }) + "`nJetzt: $($_.State)" + $(if ($_.Restart) { "`nWirkt nach einem Neustart." } else { '' })
        @{ Id = $_.Id; Title = $_.Title; Tip = $tip; Group = $_.Group; On = [bool]$_.Optimal; CanOff = [bool]$_.CanRevert; CanOn = $true; Impact = [int]$_.Impact
           Tag = $(switch ($_.Mode) { 'recommended' { 'Empfohlen' } 'optional' { 'Optional' } default { 'Experimentell' } }); TagToken = $(if ($_.Mode -eq 'experimental') { 'warning' } else { 'ink-muted' }); Src = $_ }
    })
}
function Start-PerfLoad {
    if ($script:Job) { return }
    Start-Work -Status 'Prüfe alle Leistungs-Einstellungen … (bis zu einer Minute)' -Script { @(Get-AllSettings (Test-IsLaptop)) } -OnDone {
        param($r)
        $script:H2.Settings = @($r | Where-Object { $_ }); $script:H2.Want = @{}
        $script:State.Settings = $script:H2.Settings
        try { [void](Show-SettingsGrid) } catch {}
        Set-Status "$(@($script:H2.Settings).Count) Einstellungen geprüft."
        if (Test-HomeOn 'perf') { Show-Home }
    }
}
function Build-Perf($root) {
    $sub = $script:H2.Sub.perf
    $right = New-Stack 'Horizontal'
    if ($sub -eq 'settings' -and $script:H2.Settings) {
        $open = @($script:H2.Settings | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal }).Count
        $st = if ($open) { New-StateTag 2 "$open Empfehlung(en) offen" } else { New-StateTag 0 'Alle Empfehlungen aktiv' }
        $st.VerticalAlignment = 'Center'; $st.Margin = New-Thickness 0 0 16 0; [void]$right.Children.Add($st)
    }
    $g = New-HButton 'Für Spiele optimieren' { Open-WizMode 'gaming' } -Icon 'flame'
    $g.ToolTip = 'Performance Boost: führt Schritt für Schritt durch alle Spiele-Optimierungen, misst Ping und Bildrate.'
    [void]$right.Children.Add($g)
    [void]$root.Children.Add((New-PageHead 'Leistung' $right))
    [void]$root.Children.Add((New-SubNav @(@('settings', 'Einstellungen'), @('gpu', 'Grafikkarte'), @('startup', 'Autostart')) $sub 'perf'))
    switch ($sub) {
        'gpu' { Build-PerfGpu $root }
        'startup' { Build-PerfStartup $root }
        default {
            if ($null -eq $script:H2.Settings) {
                [void]$root.Children.Add((New-Loading 'Prüfe alle Einstellungen …'))
                if (-not $script:Job) { Start-PerfLoad } else { $script:H2.NeedLoad = $true }
                return
            }
            $items = @(Get-PerfItems)
            $qa = New-Stack 'Horizontal'; $qa.Margin = New-Thickness 0 0 0 4
            [void]$qa.Children.Add((New-Link 'Alle Empfehlungen einschalten' { foreach ($it in @(Get-PerfItems)) { if ($it.Src.Mode -eq 'recommended' -and -not $it.On) { $script:H2.Want[$it.Id] = $true } }; Show-Home } -Accent))
            $qi = New-Info 'Schaltet alle als »Empfohlen« markierten Einstellungen ein. Optionales und Experimentelles wählst du einzeln. Angewendet wird erst mit »Jetzt anwenden«.'; $qi.Margin = New-Thickness 4 0 0 0; [void]$qa.Children.Add($qi)
            [void]$root.Children.Add($qa)
            foreach ($grp in @($items | Group-Object { $_.Group } | Sort-Object { $script:SetGroupOrder[$_.Name] })) {
                [void]$root.Children.Add((New-Section $script:SetGroupName[$grp.Name]))
                [void]$root.Children.Add((New-ToggleCard @($grp.Group) $script:H2.Want { Update-PerfBar }))
            }
            Update-PerfBar
        }
    }
}
function Update-PerfBar {
    $c = Get-WantChanges @(Get-PerfItems) $script:H2.Want
    $reset = New-HButton 'Zurücksetzen' { $script:H2.Want = @{}; Show-Home }
    $reset.IsEnabled = $c.Count -gt 0
    Set-HomeBar "$($c.Count) Änderung(en) · $(Get-BackupNote)" 'Jetzt anwenden' { Invoke-PerfApply } ($c.Count -gt 0) @($reset)
}
function Invoke-PerfApply {
    $c = Get-WantChanges @(Get-PerfItems) $script:H2.Want
    if ($c.Count -eq 0 -or $script:Job) { return }
    $lines = @()
    foreach ($x in $c.On) { $lines += "+  $($x.Title)" + $(if ($x.Src.Risk) { "`n     Nebenwirkung: $($x.Src.Risk)" } else { '' }) }
    foreach ($x in $c.Off) { $lines += "–  $($x.Title) (zurück auf deinen früheren Wert)" }
    $unknown = @($c.Off | Where-Object { -not $_.Src.ByTuneRig })
    $warn = if ($unknown.Count) { "`n`nBei diesen kennt TuneRig deinen früheren Wert nicht. Sie gehen auf den Windows-Standard:`n" + (($unknown | ForEach-Object { '-  ' + $_.Title }) -join "`n") } else { '' }
    if (-not (Confirm-Action ("Diese Einstellungen werden geändert:`n`n" + ($lines -join "`n") + "$warn`n`nFortfahren?") 'Leistung')) { return }
    $script:State.Pending = @{ On = @($c.On | ForEach-Object { $_.Id }); Off = @($c.Off | ForEach-Object { $_.Id }); Restart = [bool](@($c.On + $c.Off | Where-Object { $_.Src.Restart }).Count) }
    Invoke-WithRestorePoint 'Leistungs-Einstellungen' {
        Start-Work -Status 'Ändere Einstellungen …' -Arguments @(@($script:State.Pending.On), @($script:State.Pending.Off)) -Script {
            $e = @()
            if (@($A[0]).Count) { $e += @(Invoke-AllSettings $A[0]) }
            if (@($A[1]).Count) { $e += @(Invoke-AllSettings $A[1] -Revert) }
            [pscustomobject]@{ Errors = @($e | Where-Object { $_ }); Settings = @(Get-AllSettings (Test-IsLaptop)) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            $script:H2.Settings = @($r.Settings | Where-Object { $_ }); $script:H2.Want = @{}
            $script:State.Settings = $script:H2.Settings; try { [void](Show-SettingsGrid) } catch {}
            $errs = @($r.Errors)
            $msg = if ($errs.Count) { "Erledigt, mit Hinweisen:`n" + ($errs -join "`n") } else { 'Alle Änderungen sind übernommen.' }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen wirken erst nach einem Neustart." }
            Set-Status (($msg -split "`n")[0])
            if (Test-HomeOn 'perf') { Show-Home }
            if ($errs.Count -or $script:State.Pending.Restart) { Show-Info $msg 'Leistung' }
            Start-QuickHealth
        }
    }
}

# --- Grafikkarte ---
function Get-GameItems {
    $multi = @($script:H2.Gpu.Gpus).Count -gt 1
    @($script:H2.Games | Where-Object { $_ } | Sort-Object Name | ForEach-Object {
        @{ Id = [string]$_.Exe; Title = [string]$_.Name; Tip = "$($_.Exe)`nJetzt: $($_.Preference)"; On = ($_.Preference -eq 'Hohe Leistung'); CanOff = $multi; CanOn = $multi
           LockTip = $(if (-not $multi) { 'Nur eine Grafikkarte – diese Einstellung hat keine Wirkung.' } else { '' })
           Tag = [string]$_.Source; Impact = 0 }
    })
}
function Build-PerfGpu($root) {
    if ($null -eq $script:H2.Gpu) {
        [void]$root.Children.Add((New-Loading 'Prüfe Grafikkarten und suche Spiele …'))
        if (-not $script:Job) {
            Start-Work -Status 'Prüfe Grafikkarten und suche Spiele …' -Script { [pscustomobject]@{ Gpu = (Get-GpuAnalysis (Test-IsLaptop)); Games = @(Find-Games) } } -OnDone {
                param($r) $r = @($r)[-1]
                $script:H2.Gpu = if ($r.Gpu) { $r.Gpu } else { [pscustomobject]@{ Gpus = @(); Findings = @() } }; $script:H2.Games = @($r.Games | Where-Object { $_ }); $script:H2.GameWant = @{}
                try { Show-Gpu $r.Gpu; Show-Games $script:H2.Games } catch {}
                Set-Status "$(@($r.Gpu.Gpus).Count) Grafikkarte(n), $(@($script:H2.Games).Count) Spiel(e) gefunden."
                if (Test-HomeOn 'perf') { Show-Home }
            }
        } else { $script:H2.NeedLoad = $true }
        return
    }
    $gp = $script:H2.Gpu
    foreach ($x in @($gp.Gpus)) {
        $d = New-Dock
        $ic = New-LineIcon 'chip' 'ink' 24; $ic.Margin = New-Thickness 0 0 16 0; $ic.VerticalAlignment = 'Center'
        [void]$d.Children.Add((Set-Dock $ic 'Left'))
        $kind = if ($x.Discrete) { 'Dediziert' } else { 'Integriert' }
        [void]$d.Children.Add((Set-Dock (New-Tag $kind $(if ($x.Discrete) { 'accent-text' } else { 'ink-muted' })) 'Right'))
        $tx = New-Stack
        [void]$tx.Children.Add((New-Text $x.Name -Role 'title'))
        $info = @(); if ($x.Vram -gt 0) { $info += (Format-Bytes $x.Vram) }; if ($x.Driver) { $info += "Treiber $($x.Driver)" }; if ($x.Display) { $info += "Bildschirm: $($x.Resolution)" }
        [void]$tx.Children.Add((New-Text ($info -join '  ·  ') -Role 'small' -Color 'ink-muted'))
        [void]$d.Children.Add($tx)
        [void]$root.Children.Add((New-HCard $d 16 12))
    }
    foreach ($f in @($gp.Findings | Where-Object { $_.Level -ge 2 })) {
        $d = New-Dock
        $btns = @(Get-FindingButtons $f | Select-Object -First 1)
        foreach ($b in $btns) { $b.Margin = New-Thickness 16 0 0 0; [void]$d.Children.Add((Set-Dock $b 'Right')) }
        $sp = New-Stack 'Horizontal'; $sp.VerticalAlignment = 'Center'
        [void]$sp.Children.Add((New-StateTag $f.Level $f.Title))
        $i = New-Info $f.Detail; if ($i) { $i.Margin = New-Thickness 4 0 0 0; [void]$sp.Children.Add($i) }
        [void]$d.Children.Add($sp)
        [void]$root.Children.Add((New-HCard $d 16 12))
    }
    # Spiele: Schalter an = starke Grafikkarte
    $hd = New-Dock; $hd.Margin = New-Thickness 0 16 0 8
    $add = New-Link 'Spiel hinzufügen' { Add-HomeGame } -Accent
    [void]$hd.Children.Add((Set-Dock $add 'Right'))
    $hs = New-Stack 'Horizontal'
    $hl = New-Label 'Spiele auf der starken Grafikkarte'; $hl.VerticalAlignment = 'Center'; [void]$hs.Children.Add($hl)
    $hi = New-Info 'An = Windows startet das Spiel immer auf der leistungsstarken (dedizierten) Grafikkarte. Wichtig bei Laptops mit zwei Grafikkarten. Laufende Spiele bitte neu starten.'; $hi.Margin = New-Thickness 4 0 0 0; [void]$hs.Children.Add($hi)
    [void]$hd.Children.Add($hs)
    [void]$root.Children.Add($hd)
    $items = @(Get-GameItems)
    if (@($gp.Gpus).Count -le 1) { [void]$root.Children.Add((New-HCard (New-StateTag 0 'Nur eine Grafikkarte: Alle Spiele nutzen sie automatisch.') 16 12)) }
    if ($items.Count -eq 0) { [void]$root.Children.Add((New-HCard (New-Text 'Keine Spiele gefunden. Über »Spiel hinzufügen« wählst du eine .exe selbst aus.' -Role 'small' -Color 'ink-muted') 16 12)) }
    else { [void]$root.Children.Add((New-ToggleCard $items $script:H2.GameWant { Update-GpuBar })) }
    [void]$root.Children.Add((New-Link 'Grafikeinstellungen von Windows öffnen' { Open-Target 'ms-settings:display-advancedgraphics' }))
    Update-GpuBar
}
function Update-GpuBar {
    $c = Get-WantChanges @(Get-GameItems) $script:H2.GameWant
    if (@(Get-GameItems).Count -eq 0) { Set-HomeBar ''; return }
    $reset = New-HButton 'Zurücksetzen' { $script:H2.GameWant = @{}; Show-Home }; $reset.IsEnabled = $c.Count -gt 0
    Set-HomeBar "$($c.Count) Änderung(en)" 'Jetzt anwenden' { Invoke-GpuApply } ($c.Count -gt 0) @($reset)
}
function Invoke-GpuApply {
    $c = Get-WantChanges @(Get-GameItems) $script:H2.GameWant
    if ($c.Count -eq 0) { return }
    $lines = @($c.On | ForEach-Object { "+  $($_.Title): starke Grafikkarte" }) + @($c.Off | ForEach-Object { "–  $($_.Title): Windows entscheidet" })
    if (-not (Confirm-Action ("Grafikkarte für Spiele ändern:`n`n" + ($lines -join "`n") + "`n`nLaufende Spiele bitte danach neu starten. Fortfahren?") 'Grafikkarte')) { return }
    $err = @()
    foreach ($x in $c.On) { try { Set-GpuHighPerformance $x.Id } catch { $err += "$($x.Title): $($_.Exception.Message)" } }
    foreach ($x in $c.Off) { try { Reset-GpuPreference $x.Id } catch { $err += "$($x.Title): $($_.Exception.Message)" } }
    foreach ($g in @($script:H2.Games)) { try { $g.Preference = Get-GpuPreference $g.Exe } catch {} }
    $script:H2.GameWant = @{}
    try { Show-Games $script:H2.Games } catch {}
    Set-Status $(if ($err.Count) { 'Teilweise geändert: ' + ($err -join '; ') } else { 'Geändert. Laufende Spiele bitte neu starten.' })
    Show-Home
}
function Add-HomeGame {
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = 'Spiel oder Programm auswählen'; $dlg.Filter = 'Programme (*.exe)|*.exe'; $dlg.Multiselect = $true
    if (-not $dlg.ShowDialog($window)) { return }
    $list = New-Object System.Collections.ArrayList; foreach ($g in @($script:H2.Games)) { [void]$list.Add($g) }
    foreach ($file in $dlg.FileNames) {
        if (@($list | Where-Object { $_.Exe -ieq $file }).Count) { continue }
        $name = try { (Get-Item -LiteralPath $file).VersionInfo.ProductName } catch { '' }
        if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($file) }
        [void]$list.Add([pscustomobject]@{ Name = $name; Source = 'Manuell'; Exe = $file; Preference = (Get-GpuPreference $file) })
        $script:H2.GameWant[$file] = $true
    }
    $script:H2.Games = @($list)
    Show-Home
}

# --- Autostart ---
function Get-StartItems {
    @($script:H2.Startup | Where-Object { $_ } | ForEach-Object {
        $tag = switch ($_.Class) { 'off' { @('Abschalten empfohlen', 'warning') } 'keep' { @('Wichtig', 'ink-muted') } default { @('Bei Bedarf', 'ink-muted') } }
        @{ Id = [string]$_.Id; Title = [string]$_.Name; Tip = "Startet: $($_.Command)`nEingetragen: $($_.Who)"; On = [bool]$_.Enabled; CanOff = $true; CanOn = $true
           Tag = $tag[0]; TagToken = $tag[1]; Impact = 0; Src = $_ }
    })
}
function Build-PerfStartup($root) {
    if ($null -eq $script:H2.Startup) {
        [void]$root.Children.Add((New-Loading 'Lese die Autostart-Programme …'))
        if (-not $script:Job) {
            Start-Work -Status 'Lese die Autostart-Programme …' -Script { @(Get-StartupItems) } -OnDone {
                param($r) $script:H2.Startup = @($r | Where-Object { $_ }); $script:H2.StartWant = @{}
                try { Show-StartupGrid $script:H2.Startup } catch {}
                Set-Status "$(@($script:H2.Startup).Count) Autostart-Einträge."
                if (Test-HomeOn 'perf') { Show-Home }
            }
        } else { $script:H2.NeedLoad = $true }
        return
    }
    $items = @(Get-StartItems)
    $on = @($items | Where-Object { $_.On }).Count; $rec = @($items | Where-Object { $_.On -and $_.Src.Class -eq 'off' }).Count
    $hd = New-Stack 'Horizontal'; $hd.Margin = New-Thickness 0 0 0 12
    [void]$hd.Children.Add((New-StateTag $(if ($rec) { 2 } else { 0 }) $(if ($rec) { "$on starten mit Windows · $rec davon kannst du abschalten" } else { "$on starten mit Windows · nichts Überflüssiges" })))
    $i = New-Info 'An = startet mit Windows. Weniger Autostart-Programme heißt schnellerer Start und mehr freier Arbeitsspeicher. Treiber und Sicherheits-Software bleiben besser an. Wirkt beim nächsten Windows-Start.'; $i.Margin = New-Thickness 4 0 0 0; [void]$hd.Children.Add($i)
    [void]$root.Children.Add($hd)
    if ($items.Count -eq 0) { [void]$root.Children.Add((New-HCard (New-Text 'Keine Autostart-Programme gefunden.' -Role 'small' -Color 'ink-muted') 16 12)); return }
    [void]$root.Children.Add((New-ToggleCard $items $script:H2.StartWant { Update-StartBar }))
    Update-StartBar
}
function Update-StartBar {
    $c = Get-WantChanges @(Get-StartItems) $script:H2.StartWant
    $reset = New-HButton 'Zurücksetzen' { $script:H2.StartWant = @{}; Show-Home }; $reset.IsEnabled = $c.Count -gt 0
    Set-HomeBar "$($c.Count) Änderung(en) · wirkt beim nächsten Start" 'Jetzt anwenden' { Invoke-StartApply } ($c.Count -gt 0) @($reset)
}
function Invoke-StartApply {
    $c = Get-WantChanges @(Get-StartItems) $script:H2.StartWant
    if ($c.Count -eq 0 -or $script:Job) { return }
    $keep = @($c.Off | Where-Object { $_.Src.Class -eq 'keep' })
    $lines = @($c.Off | ForEach-Object { "–  $($_.Title): startet nicht mehr mit Windows" }) + @($c.On | ForEach-Object { "+  $($_.Title): startet wieder mit Windows" })
    $warn = if ($keep.Count) { "`n`nAchtung: Darunter sind Programme für Treiber, Sicherheit oder Geräte:`n" + (($keep | ForEach-Object { '-  ' + $_.Title }) -join "`n") } else { '' }
    if (-not (Confirm-Action ("Autostart ändern:`n`n" + ($lines -join "`n") + "$warn`n`nFortfahren?") 'Autostart')) { return }
    Start-Work -Status 'Ändere Autostart …' -Arguments @(@($c.Off | ForEach-Object { $_.Id }), @($c.On | ForEach-Object { $_.Id })) -Script {
        foreach ($id in @($A[0])) { Set-StartupItemState $id $false }
        foreach ($id in @($A[1])) { Set-StartupItemState $id $true }
        @(Get-StartupItems)
    } -OnDone {
        param($r) $script:H2.Startup = @($r | Where-Object { $_ }); $script:H2.StartWant = @{}
        try { Show-StartupGrid $script:H2.Startup } catch {}
        Set-Status 'Autostart geändert. Wirkt beim nächsten Windows-Start.'
        if (Test-HomeOn 'perf') { Show-Home }
    }
}

# ===========================================================================
#  SPEICHERPLATZ: Laufwerke · Schnell aufräumen · Größte Brocken
# ===========================================================================
function Start-CleanLoad {
    if ($script:Job) { return }
    Start-Work -Status 'Berechne, wie viel Platz frei werden kann …' -Script {
        foreach ($d in @(Get-CleanupDefs)) {
            Report "Berechne: $($d.Name) …"
            $x = @(Measure-Cleanup $d.Id)[-1]
            [pscustomobject]@{ Id = $d.Id; Name = $d.Name; Desc = $d.Desc; Sel = [bool]$d.Sel; Size = [long]$x.Size; Count = [int]$x.Count }
        }
    } -OnDone {
        param($r)
        $script:H2.Clean = @($r | Where-Object { $_ })
        $script:H2.CleanSel = @{}; foreach ($c in $script:H2.Clean) { $script:H2.CleanSel[$c.Id] = $c.Sel -and $c.Size -gt 0 }
        try { Apply-Measures $script:H2.Clean } catch {}
        Set-Status 'Berechnung abgeschlossen.'
        if (Test-HomeOn 'storage') { Show-Home }
    }
}
function Get-CleanTotal { $t = 0L; foreach ($c in @($script:H2.Clean)) { if ($script:H2.CleanSel[$c.Id] -and $c.Id -ne 'winsxs') { $t += [long]$c.Size } }; return $t }
function Build-Storage($root) {
    [void]$root.Children.Add((New-PageHead 'Speicherplatz'))
    # Laufwerke
    $drives = @(Get-StorageDrives)
    $dc = New-HCard $null 20 20; $dsp = New-Stack
    $first = $true
    foreach ($d in $drives) {
        $used = $d.Size - $d.Free; $pct = 100.0 * $d.Free / [math]::Max(1.0, [double]$d.Size)
        $lvl = if ($pct -lt 10) { 3 } elseif ($pct -lt 20) { 2 } else { 0 }
        $row = New-Stack; if (-not $first) { $row.Margin = New-Thickness 0 16 0 0 }; $first = $false
        $hd = New-Dock
        $an = New-Link 'Analysieren' { param($drv) Start-HomeStorageScan $drv } $d.Drive -Accent; $an.Margin = New-Thickness 16 0 0 0
        [void]$hd.Children.Add((Set-Dock $an 'Right'))
        $fr = New-Mono ("{0} frei von {1}" -f (Format-Bytes $d.Free), (Format-Bytes $d.Size)) 14 $(if ($lvl) { $script:LevelToken[$lvl] } else { 'ink-muted' })
        [void]$hd.Children.Add((Set-Dock $fr 'Right'))
        $nm = $d.Drive + $(if ($d.Label) { "  $($d.Label)" } elseif ($d.System) { '  Windows' } else { '' })
        $nt = New-Text $nm -Role 'title'; $nt.VerticalAlignment = 'Center'; [void]$hd.Children.Add($nt)
        [void]$row.Children.Add($hd)
        $bar = New-StorageBar ($used / [math]::Max(1.0, [double]$d.Size)) $(if ($lvl -eq 3) { 'danger' } elseif ($lvl -eq 2) { 'warning' } else { 'ink-muted' }) 12
        $bar.Margin = New-Thickness 0 8 0 0
        [Windows.Automation.AutomationProperties]::SetName($bar, ("Laufwerk {0}: {1:0} Prozent frei" -f $d.Drive, $pct))
        [void]$row.Children.Add($bar)
        if ($lvl) { $s = New-StateTag $lvl $(if ($lvl -eq 3) { 'Fast voll – Windows wird langsamer' } else { 'Wird knapp' }) 14; $s.Margin = New-Thickness 0 6 0 0; [void]$row.Children.Add($s) }
        [void]$dsp.Children.Add($row)
    }
    $dc.Child = $dsp; [void]$root.Children.Add($dc)

    $cols = New-Object Windows.Controls.Grid
    foreach ($w in 1, 20, 1) { $c = New-Object Windows.Controls.ColumnDefinition; $c.Width = if ($w -eq 20) { New-Object Windows.GridLength(20) } else { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) }; $cols.ColumnDefinitions.Add($c) }
    # Schnell aufräumen
    $cl = New-Stack
    $ch = New-Stack 'Horizontal'
    [void]$ch.Children.Add((New-Label 'Schnell aufräumen'))
    $ci = New-Info 'Löscht Zwischendateien von Windows und Programmen. Nichts Persönliches. Dateien, die gerade benutzt werden, bleiben liegen.'; $ci.Margin = New-Thickness 4 -6 0 -6; [void]$ch.Children.Add($ci)
    [void]$cl.Children.Add($ch)
    if ($null -eq $script:H2.Clean) {
        $l = New-Text 'Berechne …' -Role 'body' -Color 'ink-muted' -Top 8; [void]$cl.Children.Add($l); $script:H2.Live = $l
        if (-not $script:Job) { Start-CleanLoad } else { $script:H2.NeedLoad = $true }
    } else {
        $tot = Get-CleanTotal
        $th = New-Stack 'Horizontal' 8
        [void]$th.Children.Add((New-Mono (Format-Bytes $tot) 36))
        $tf = New-Text 'frei machbar' -Role 'body' -Color 'ink-muted'; $tf.VerticalAlignment = 'Bottom'; $tf.Margin = New-Thickness 10 0 0 6; [void]$th.Children.Add($tf)
        [void]$cl.Children.Add($th)
        $lst = New-Stack 'Vertical' 12
        foreach ($c in @($script:H2.Clean | Sort-Object @{ e = { -[long]$_.Size } })) {
            [void]$lst.Children.Add((New-RowLine))
            $row = New-Dock; $row.Margin = New-Thickness 0 8 0 8
            $cb = New-Object Windows.Controls.CheckBox; $cb.IsChecked = [bool]$script:H2.CleanSel[$c.Id]; $cb.VerticalAlignment = 'Center'
            [Windows.Automation.AutomationProperties]::SetName($cb, $c.Name)
            $cb.CommandParameter = $c.Id
            $cb.Add_Click({ $script:H2.CleanSel[[string]$this.CommandParameter] = [bool]$this.IsChecked; Show-Home })
            [void]$row.Children.Add((Set-Dock $cb 'Left'))
            $sz = New-Mono $(if ($c.Id -eq 'winsxs') { 'erst danach messbar' } elseif ($c.Size -gt 0) { Format-Bytes $c.Size } else { 'leer' }) 14 'ink-muted'
            [void]$row.Children.Add((Set-Dock $sz 'Right'))
            $mp = New-Stack 'Horizontal'; $mp.VerticalAlignment = 'Center'
            $t = New-Text $c.Name -Role 'body'; $t.VerticalAlignment = 'Center'; [void]$mp.Children.Add($t)
            $i = New-Info $c.Desc; if ($i) { $i.Margin = New-Thickness 4 0 0 0; [void]$mp.Children.Add($i) }
            [void]$row.Children.Add($mp)
            [void]$lst.Children.Add($row)
        }
        [void]$cl.Children.Add($lst)
        $jl = New-Link 'Junk-Dateien auf allen Laufwerken suchen' { Show-Tool 'junk' } -Accent; $jl.Margin = New-Thickness 0 12 0 0
        [void]$cl.Children.Add($jl)
        $n = @($script:H2.Clean | Where-Object { $script:H2.CleanSel[$_.Id] }).Count
        Set-HomeBar "$n Bereich(e) ausgewählt · Zwischendateien werden endgültig gelöscht" "$(Format-Bytes $tot) freigeben" { Invoke-HomeClean } ($n -gt 0)
    }
    $cc = New-HCard $cl 20 16; [void]$cols.Children.Add($cc)

    # Größte Brocken
    $bg = New-Stack
    $r = $script:Storage.Result
    [void]$bg.Children.Add((New-Label $(if ($r) { "Größte Brocken auf $($r.Drive)" } else { 'Größte Brocken' })))
    if ($r -and @($script:Storage.Entries).Count) {
        $total = [double][Math]::Max(1L, $r.Size - $r.Free)
        $rank = 0
        foreach ($e in @($script:Storage.Entries | Select-Object -First 6)) { $rank++; $x = New-StorageBigRow $e $rank $total; $x.Margin = New-Thickness -8 4 -8 0; [void]$bg.Children.Add($x) }
        $al = New-Link 'Alles ansehen: Ordner und Dateitypen' { Show-Tool 'storage' } -Accent; $al.Margin = New-Thickness 0 12 0 0
        [void]$bg.Children.Add($al)
    } elseif ($script:Job -and $script:Storage.Drive -and $ui.StorageProgress.Visibility -eq 'Visible') {
        $l = New-Text 'Analysiere …' -Role 'body' -Color 'ink-muted' -Top 8; [void]$bg.Children.Add($l); $script:H2.Live = $l
        $pb = New-Object Windows.Controls.ProgressBar; $pb.IsIndeterminate = $true; $pb.Margin = New-Thickness 0 12 0 0; [void]$bg.Children.Add($pb)
    } else {
        [void]$bg.Children.Add((New-Text 'Zeigt Spiele, Programme, Ordner und Dateien, die am meisten Platz belegen.' -Role 'body' -Color 'ink-muted' -Top 8))
        $sb = New-HButton "$env:SystemDrive analysieren" { Start-HomeStorageScan $env:SystemDrive } -Icon 'search'; $sb.Margin = New-Thickness 0 16 0 0; $sb.HorizontalAlignment = 'Left'
        [void]$bg.Children.Add($sb)
        [void]$bg.Children.Add((New-Text 'Dauert je nach Laufwerk 1–5 Minuten. Ändert nichts.' -Role 'small' -Color 'ink-muted' -Top 8))
    }
    $bc = New-HCard $bg 20 16; [Windows.Controls.Grid]::SetColumn($bc, 2); [void]$cols.Children.Add($bc)
    [void]$root.Children.Add($cols)
}
function Start-HomeStorageScan([string]$Drive) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    if (-not @($script:Storage.Drives).Count) { Update-StorageDrives }
    Start-StorageScan $Drive
    Show-Home
}
function Invoke-HomeClean {
    $sel = @($script:H2.Clean | Where-Object { $script:H2.CleanSel[$_.Id] })
    if ($sel.Count -eq 0 -or $script:Job) { return }
    if ($sel | Where-Object { $_.Id -like 'browser-*' }) {
        $running = @(Get-RunningBrowsers)
        if ($running.Count -gt 0 -and -not (Confirm-Action ("Geöffnet: {0}.`nDer Cache lässt sich dann nur teilweise löschen. Schließ die Browser für ein besseres Ergebnis.`n`nTrotzdem fortfahren?" -f ($running -join ', ')))) { return }
    }
    $list = ($sel | ForEach-Object { '-  ' + $_.Name + $(if ($_.Size -gt 0) { "  ($(Format-Bytes $_.Size))" } else { '' }) }) -join "`n"
    if (-not (Confirm-Action "Diese Bereiche werden aufgeräumt:`n`n$list`n`nZwischendateien werden endgültig gelöscht. Fortfahren?" 'Aufräumen')) { return }
    Start-Work -Status 'Räume auf …' -Arguments @(, @($sel | ForEach-Object { $_.Id })) -Script {
        $freed = 0L
        foreach ($id in $A[0]) { Report "Bereinige: $id …"; $freed += [long](@(Invoke-Cleanup $id)[-1]) }
        $m = foreach ($d in @(Get-CleanupDefs)) { $x = @(Measure-Cleanup $d.Id)[-1]; [pscustomobject]@{ Id = $d.Id; Name = $d.Name; Desc = $d.Desc; Sel = [bool]$d.Sel; Size = [long]$x.Size; Count = [int]$x.Count } }
        [pscustomobject]@{ Freed = $freed; Clean = @($m) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $script:H2.Clean = @($r.Clean | Where-Object { $_ })
        foreach ($c in $script:H2.Clean) { if ($c.Size -le 0) { $script:H2.CleanSel[$c.Id] = $false } }
        try { Apply-Measures $script:H2.Clean } catch {}
        $msg = "Fertig: $(Format-Bytes $r.Freed) freigegeben. Gerade benutzte Dateien wurden übersprungen."
        Set-Status $msg
        if (Test-HomeOn 'storage') { Show-Home }
        Start-QuickHealth
    }
}
$script:UiHooks['storage'] = { if (Test-HomeOn 'storage') { Show-Home } }
# Deinstallieren aus der Speicher-Rangliste: im Dashboard auf der Programmseite, sonst wie bisher
function Open-StorageUninstall([string]$Name) {
    if ($script:State.Page -eq 'home') { $script:H2.Search = $Name; Show-HomePage 'prog' 'installed'; Set-Status "Klick bei »$Name« auf »Deinstallieren«. TuneRig sucht danach nach Resten."; return }
    Show-Tool 'uninstall'
    $ui.TxtSearch.Text = $Name
    Set-Status "Wähle »$Name« in der Liste und klick auf »Jetzt deinstallieren«. TuneRig sucht danach nach Resten."
}

# ===========================================================================
#  PROGRAMME: Installiert · Reste alter Programme
# ===========================================================================
function Build-Prog($root) {
    $sub = $script:H2.Sub.prog
    [void]$root.Children.Add((New-PageHead 'Programme'))
    [void]$root.Children.Add((New-SubNav @(@('installed', 'Installiert'), @('orphans', 'Reste alter Programme')) $sub 'prog'))
    if ($sub -eq 'orphans') { Build-ProgOrphans $root } else { Build-ProgInstalled $root }
}
function Build-ProgInstalled($root) {
    # Reste der letzten Deinstallation zuerst
    $c = $script:LoCache.installed
    $rows = @(Get-LoRows 'installed')
    if ($script:State.Current -and ($rows.Count -or $c.Head -ne 'Gefundene Reste')) {
        $hd = New-Dock; $hd.Margin = New-Thickness 0 0 0 8
        $rs = New-Link 'Erneut suchen' { if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.' } else { Start-LeftoverScan 'Erneute Suche.' } } -Accent
        [void]$hd.Children.Add((Set-Dock $rs 'Right'))
        $l = New-Label "Reste von $($script:State.Current.Name)"; $l.VerticalAlignment = 'Center'; [void]$hd.Children.Add($l)
        [void]$root.Children.Add($hd)
        if ($rows.Count -eq 0 -and @($c.Held).Count -eq 0) { [void]$root.Children.Add((New-HCard (New-Text $c.Head -Role 'body' -Color 'ink-muted') 16 16)) }
        else { Build-LeftoverGroups $root 'installed' $script:State.Current }
        [void]$root.Children.Add((New-Section 'Installierte Programme' 16))
    }
    if (@($script:State.Programs).Count -eq 0) {
        if ($script:H2.ProgTried -and -not $script:Job) { [void]$root.Children.Add((New-HCard (New-Text 'Keine Programme gefunden.' -Role 'body' -Color 'ink-muted') 16 16)); return }
        [void]$root.Children.Add((New-Loading 'Lade installierte Programme …'))
        if (-not $script:Job) { $script:H2.ProgTried = $true; & $script:LoadPrograms } else { $script:H2.NeedLoad = $true }
        return
    }
    # Suche
    $sd = New-Dock; $sd.Margin = New-Thickness 0 0 0 12
    $store = New-Object Windows.Controls.CheckBox; $store.Content = 'Store-Apps zeigen'; $store.IsChecked = [bool]$ui.ChkStore.IsChecked; $store.VerticalAlignment = 'Center'; $store.Margin = New-Thickness 16 0 0 0
    $store.Add_Click({ $ui.ChkStore.IsChecked = [bool]$this.IsChecked; & $script:LoadPrograms; Show-Home })
    [void]$sd.Children.Add((Set-Dock $store 'Right'))
    $tb = New-Object Windows.Controls.TextBox; $tb.Text = $script:H2.Search; $tb.MinHeight = 40; $tb.VerticalContentAlignment = 'Center'
    [Windows.Automation.AutomationProperties]::SetName($tb, 'Programme durchsuchen')
    $tb.ToolTip = 'Name oder Hersteller eingeben'
    [void]$sd.Children.Add($tb)
    [void]$root.Children.Add($sd)
    $list = New-Stack
    $script:H2.ProgList = $list
    $tb.Add_TextChanged({ $script:H2.Search = $this.Text; $script:H2SearchTimer.Stop(); $script:H2SearchTimer.Start() })
    [void]$root.Children.Add($list)
    Update-HomeProgList
}
# Suche erst nach einer kurzen Tipppause auswerten (die Liste kann lang sein)
$script:H2SearchTimer = New-Object Windows.Threading.DispatcherTimer
$script:H2SearchTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$script:H2SearchTimer.Add_Tick({ $script:H2SearchTimer.Stop(); Update-HomeProgList })
function Update-HomeProgList {
    $list = $script:H2.ProgList; if (-not $list) { return }
    $list.Children.Clear()
    $q = ([string]$script:H2.Search).Trim()
    $all = @($script:State.Programs | ForEach-Object { $_.Tag } | Where-Object { $_ })
    if ($q) { $all = @($all | Where-Object { ([string]$_.Name).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or ([string]$_.Publisher).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 }) }
    $all = @($all | Sort-Object Name)
    $cnt = New-Text $(if ($q) { "$($all.Count) Treffer" } else { "$($all.Count) Programme" }) -Role 'small' -Color 'ink-muted'; $cnt.Margin = New-Thickness 0 0 0 8
    [void]$list.Children.Add($cnt)
    if ($all.Count -eq 0) { return }
    $card = New-HCard $null 0 16; $sp = New-Stack; $first = $true
    foreach ($p in @($all | Select-Object -First 300)) {
        if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
        $row = New-Dock; $row.Margin = New-Thickness 16 8 16 8
        $bu = New-HButton 'Deinstallieren' { param($x) & $script:UninstallProgram $x } $p; $bu.MinHeight = 34; $bu.Padding = New-Thickness 12 5 12 6
        $bf = New-Link 'Erzwingen' { param($x) & $script:ForceUninstall $x } $p; $bf.Margin = New-Thickness 0 0 16 0; $bf.VerticalAlignment = 'Center'
        $bf.ToolTip = 'Für Programme, deren Deinstallation nicht funktioniert: zeigt alle Spuren zum Löschen an.'
        [void]$row.Children.Add((Set-Dock $bu 'Right'))
        if ($p.Source -ne 'Store') { [void]$row.Children.Add((Set-Dock $bf 'Right')) }
        $sz = New-Mono $(if ($p.Size -gt 0) { Format-Bytes $p.Size } else { '' }) 14 'ink-muted'; $sz.Width = 90; $sz.TextAlignment = 'Right'; $sz.Margin = New-Thickness 0 0 16 0
        [void]$row.Children.Add((Set-Dock $sz 'Right'))
        $tx = New-Stack; $tx.VerticalAlignment = 'Center'
        $nt = New-Text $p.Name -Role 'body'; $nt.TextTrimming = 'CharacterEllipsis'; $nt.TextWrapping = 'NoWrap'; [void]$tx.Children.Add($nt)
        $meta = @($p.Publisher, $p.Version | Where-Object { $_ }) -join '  ·  '
        if ($meta) { $mt = New-Text $meta -Role 'small' -Color 'ink-muted'; $mt.TextTrimming = 'CharacterEllipsis'; $mt.TextWrapping = 'NoWrap'; [void]$tx.Children.Add($mt) }
        [void]$row.Children.Add($tx)
        [void]$sp.Children.Add($row)
    }
    $card.Child = $sp
    [void]$list.Children.Add($card)
    if ($all.Count -gt 300) { [void]$list.Children.Add((New-Text "… und $($all.Count - 300) weitere. Grenze die Suche ein." -Role 'small' -Color 'ink-muted')) }
}
function Build-ProgOrphans($root) {
    $c = $script:LoCache.orphans
    $rows = @(Get-LoRows 'orphans')
    if ($c.Head -like 'Suche läuft*') { [void]$root.Children.Add((New-Loading 'Durchsuche alle Laufwerke … (einige Minuten)')); return }
    if ($rows.Count -eq 0 -and @($c.Held).Count -eq 0) {
        $sp = New-Stack
        $ic = New-LineIcon 'search' 'ink' 32; $ic.HorizontalAlignment = 'Left'; [void]$sp.Children.Add($ic)
        $searched = $c.Head -ne 'Noch nicht gesucht.'
        $title = if (-not $searched) { 'Reste alter Programme finden' } elseif ($c.Head -like 'Suche abgebrochen*') { 'Suche abgebrochen.' } else { 'Keine Reste gefunden.' }
        [void]$sp.Children.Add((New-Text $title -Role 'h3' -Top 12))
        $ln = New-Stack 'Horizontal' 4
        [void]$ln.Children.Add((New-Text 'Nur mit Beleg. Die Suche ändert nichts.' -Role 'body' -Color 'ink-muted'))
        $i = New-Info ("Gefunden wird nur, was sich belegen lässt: Einträge, deren Programm nicht mehr existiert, Spieleordner, die kein Launcher mehr kennt, Reste früherer Deinstallationen und Datenordner, die nur noch auf entfernte Programme verweisen.`n`n" +
                       "Danach prüft TuneRig jeden Fund gegen die Registry aller Benutzerkonten, laufende Programme, Treiber, Spiele-Launcher, Einstellungsdateien und Nutzungsspuren.")
        $i.Margin = New-Thickness 4 0 0 0; [void]$ln.Children.Add($i)
        [void]$sp.Children.Add($ln)
        $b = New-HButton $(if ($searched) { 'Erneut suchen' } else { 'Reste suchen' }) { Start-HomeOrphanScan } -Primary -Icon 'search'; $b.HorizontalAlignment = 'Left'; $b.Margin = New-Thickness 0 20 0 0
        [void]$sp.Children.Add($b)
        [void]$root.Children.Add((New-HCard $sp 24 16))
        return
    }
    $hd = New-Dock; $hd.Margin = New-Thickness 0 0 0 8
    [void]$hd.Children.Add((Set-Dock (New-Link 'Erneut suchen' { Start-HomeOrphanScan } -Accent) 'Right'))
    $hl = New-Text $c.Head -Role 'small' -Color 'ink-muted'; $hl.VerticalAlignment = 'Center'; [void]$hd.Children.Add($hl)
    [void]$root.Children.Add($hd)
    Build-LeftoverGroups $root 'orphans' $script:State.OrphanP
}

function Start-HomeOrphanScan { if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }; Start-OrphanScan }

# ---------------------------------------------------------------------------
#  Reste: eine klare Empfehlung oben, darunter je Programm eine Zeile.
#  Details (Einträge, Prüfschritte) erst auf Klick. Nicht Empfohlenes ist eingeklappt.
# ---------------------------------------------------------------------------
# safe = nachgewiesen und gegengeprüft (vorausgewählt) · check = nicht empfohlen · later = wird beim Neustart gelöscht
function Get-LoClass($Row) {
    if ($Row.A -eq 'Beim Neustart') { return 'later' }
    if ($Row.A -in 'Zurückgehalten', 'Fehlgeschlagen') { return 'check' }
    if ($Row.Tag.Selected) { 'safe' } else { 'check' }
}
function Get-LoSize($Rows) { $t = 0L; foreach ($x in @($Rows)) { $t += [long]$x.Tag.Size }; $t }
function Get-LoOwner($Row) { if ($Row.Tag.Owner) { [string]$Row.Tag.Owner } else { 'Ohne Programmzuordnung' } }
# Der eine Grund, warum ein Eintrag nicht empfohlen ist (erster Hinweis aus den Prüfschritten)
function Get-LoWhyNot($Row) {
    if ($Row.A -in 'Zurückgehalten', 'Fehlgeschlagen' -and $Row.D) { return [string]$Row.D }
    $c = @($Row.Tag.Checks | Where-Object { $_.State -in 'fail', 'warn' } | Select-Object -First 1)
    if ($c.Count) { return [string]$c[0].Text }
    if ($Row.Tag.Shared) { return 'Wird auch von anderen Programmen genutzt.' }
    return 'Nicht eindeutig nachgewiesen.'
}

function Build-LeftoverGroups($root, [string]$Mode, $P) {
    $script:H2.LoMode = $Mode; $script:H2.LoP = $P
    $rows = @(Get-LoRows $Mode)
    $held = @($script:LoCache[$Mode].Held | Where-Object { $_ })
    $safe = @($rows | Where-Object { (Get-LoClass $_) -eq 'safe' })
    $check = @($rows | Where-Object { (Get-LoClass $_) -eq 'check' })
    $later = @($rows | Where-Object { (Get-LoClass $_) -eq 'later' })
    $progs = @($safe | ForEach-Object { Get-LoOwner $_ } | Sort-Object -Unique)

    # 1. Die Empfehlung in einem Satz
    $sp = New-Stack
    if ($safe.Count) {
        $h = New-Stack 'Horizontal'
        $ic = New-LineIcon 'ok' 'success' 28; $ic.Margin = New-Thickness 0 0 12 0; $ic.VerticalAlignment = 'Center'; [void]$h.Children.Add($ic)
        $t = New-Text ("Empfehlung: {0} löschen – {1}" -f $(if ($safe.Count -eq 1) { '1 Rest' } else { "$($safe.Count) Reste" }), (Format-Bytes (Get-LoSize $safe))) -Role 'h3'; $t.VerticalAlignment = 'Center'
        [void]$h.Children.Add($t)
        [void]$sp.Children.Add($h)
        $sub = "Von $($progs.Count) $(if ($progs.Count -eq 1) { 'Programm' } else { 'Programmen' }), die nicht mehr installiert sind. Jeder Eintrag ist nachgewiesen und gegengeprüft. Klick unten auf den orangefarbenen Button – fertig."
        $st = New-Text $sub -Role 'body' -Color 'ink-muted' -Top 6; $st.Margin = New-Thickness 40 6 0 0
        [void]$sp.Children.Add($st)
    } else {
        $h = New-Stack 'Horizontal'
        $ic = New-LineIcon 'info' 'accent-text' 28; $ic.Margin = New-Thickness 0 0 12 0; $ic.VerticalAlignment = 'Center'; [void]$h.Children.Add($ic)
        $t = New-Text 'Nichts ist sicher löschbar.' -Role 'h3'; $t.VerticalAlignment = 'Center'; [void]$h.Children.Add($t)
        [void]$sp.Children.Add($h)
        $st = New-Text 'Am besten lässt du alles stehen. Du musst nichts tun.' -Role 'body' -Color 'ink-muted'; $st.Margin = New-Thickness 40 6 0 0
        [void]$sp.Children.Add($st)
    }
    [void]$root.Children.Add((New-HCard $sp 20 16))

    if ($later.Count) { $l = New-StateTag 1 "$($later.Count) Einträge werden beim nächsten Neustart gelöscht."; $l.Margin = New-Thickness 0 0 0 12; [void]$root.Children.Add($l) }

    # 2. Empfohlen: je Programm eine Zeile
    if ($safe.Count) {
        [void]$root.Children.Add((New-Section 'Empfohlen zum Löschen'))
        $card = New-HCard $null 0 16; $list = New-Stack; $first = $true
        foreach ($g in @($safe | Group-Object { Get-LoOwner $_ } | Sort-Object @{ e = { -(Get-LoSize $_.Group) } })) {
            if (-not $first) { [void]$list.Children.Add((New-RowLine)) }; $first = $false
            [void]$list.Children.Add((New-LoProgramRow $g.Name @($g.Group) $Mode))
        }
        $card.Child = $list; [void]$root.Children.Add($card)
    }

    # 3. Nicht empfohlen: eingeklappt, jeder Eintrag mit seinem einen Grund
    if ($check.Count) {
        $key = "check|$Mode"; $on = [bool]$script:H2.Open[$key]
        $hd = New-Stack 'Horizontal'; $hd.Margin = New-Thickness 0 8 0 8
        [void]$hd.Children.Add((New-Link $(if ($on) { "Nicht empfohlen ($($check.Count)) ausblenden" } else { "Nicht empfohlen ($($check.Count)) anzeigen" }) { param($k) $script:H2.Open[$k] = -not $script:H2.Open[$k]; Update-LoView } $key -Accent))
        $hi = New-Info 'Für diese Einträge gibt es zwar einen Beleg, aber auch einen Hinweis, dass sie noch gebraucht werden könnten – etwa eigene Dateien oder Spielstände. Lösch sie nur, wenn du dir sicher bist.'; $hi.Margin = New-Thickness 4 0 0 0; [void]$hd.Children.Add($hi)
        [void]$root.Children.Add($hd)
        if ($on) {
            $card = New-HCard $null 0 16; $list = New-Stack; $first = $true
            foreach ($r in @($check | Select-Object -First 200)) {
                if (-not $first) { [void]$list.Children.Add((New-RowLine)) }; $first = $false
                [void]$list.Children.Add((New-LoItem $r.Tag $r (Get-LoWhyNot $r) 2))
            }
            $card.Child = $list; [void]$root.Children.Add($card)
        }
    }

    # 4. Was stehen bleibt: nur eine Zeile, Details auf Wunsch
    if ($held.Count) {
        $key = "held|$Mode"; $on = [bool]$script:H2.Open[$key]
        $hd = New-Stack 'Horizontal'; $hd.Margin = New-Thickness 0 4 0 8
        $ht = New-Text "$($held.Count) weitere Einträge bleiben stehen, weil sie noch gebraucht werden." -Role 'small' -Color 'ink-muted'; $ht.VerticalAlignment = 'Center'; [void]$hd.Children.Add($ht)
        $hl = New-Link $(if ($on) { 'Ausblenden' } else { 'Anzeigen' }) { param($k) $script:H2.Open[$k] = -not $script:H2.Open[$k]; Update-LoView } $key -Accent; $hl.Margin = New-Thickness 12 0 0 0
        [void]$hd.Children.Add($hl)
        [void]$root.Children.Add($hd)
        if ($on) {
            $card = New-HCard $null 0 16; $list = New-Stack; $first = $true
            foreach ($x in @($held | Select-Object -First 200)) {
                if (-not $first) { [void]$list.Children.Add((New-RowLine)) }; $first = $false
                [void]$list.Children.Add((New-LoItem $x.Item $null ([string]$x.Reason) 1))
            }
            $card.Child = $list; [void]$root.Children.Add($card)
        }
    }
    Update-LoBar $Mode $P
}

# Zustand eines Rests in Worten statt Haken: »Wird gelöscht« oder »Bleibt«, daneben der Gegen-Befehl
function New-LoToggle($Rows, [string]$OnLabel = 'Behalten', [string]$OffLabel = 'Doch löschen') {
    $rows = @($Rows); $sel = @($rows | Where-Object { $_.IsSelected }).Count
    $sp = New-Stack 'Horizontal'; $sp.VerticalAlignment = 'Center'
    $state = if ($sel -eq $rows.Count) { @('trash', 'ink', 'Wird gelöscht') } elseif ($sel -eq 0) { @('minus', 'ink-muted', 'Bleibt') } else { @('trash', 'ink', "$sel von $($rows.Count) werden gelöscht") }
    $ic = New-LineIcon $state[0] $state[1] 14; $ic.Margin = New-Thickness 0 0 6 0; $ic.VerticalAlignment = 'Center'; [void]$sp.Children.Add($ic)
    $t = New-Text $state[2] -Role 'small' -Color $state[1]; $t.VerticalAlignment = 'Center'; $t.TextWrapping = 'NoWrap'; $t.MinWidth = 96; [void]$sp.Children.Add($t)
    $all = $sel -eq $rows.Count
    $lk = New-Link $(if ($all) { $OnLabel } else { $OffLabel }) { param($p) foreach ($r in @($p.Rows)) { $r.IsSelected = -not $p.All }; Update-LoView } @{ Rows = $rows; All = $all } -Accent
    $lk.Margin = New-Thickness 16 0 0 0; $lk.VerticalAlignment = 'Center'; $lk.MinWidth = 90
    [void]$sp.Children.Add($lk)
    return $sp
}

# Eine Zeile je Programm: Name, Art der Einträge, Größe, Zustand mit Gegen-Befehl, »Details«
function New-LoProgramRow([string]$Name, $Rows, [string]$Mode) {
    $sp = New-Stack; $sp.Margin = New-Thickness 16 12 16 12
    $d = New-Dock
    $key = "prog|$Mode|$Name"; $on = [bool]$script:H2.Open[$key]
    [void]$d.Children.Add((Set-Dock (New-LoToggle $Rows) 'Right'))
    $sz = New-Mono (Format-Bytes (Get-LoSize $Rows)) 14 'ink-muted'; $sz.Margin = New-Thickness 16 0 16 0
    [void]$d.Children.Add((Set-Dock $sz 'Right'))
    $tx = New-Stack; $tx.VerticalAlignment = 'Center'
    $nt = New-Text $Name -Role 'title'; $nt.TextTrimming = 'CharacterEllipsis'; $nt.TextWrapping = 'NoWrap'; [void]$tx.Children.Add($nt)
    $n = @($Rows).Count
    $kinds = if ($Name -eq 'Ohne Programmzuordnung') { "$n $(if ($n -eq 1) { 'Rest' } else { 'Reste' }) entfernter Programme – Herkunft steht bei jedem Eintrag" } else { "$(if ($Mode -eq 'installed') { 'Gerade entfernt' } else { 'Nicht mehr installiert' }) · $n $(if ($n -eq 1) { 'Rest' } else { 'Reste' }) gehören nachweislich dazu" }
    $kl = New-Stack 'Horizontal'
    $kt = New-Text $kinds -Role 'small' -Color 'ink-muted'; $kt.TextTrimming = 'CharacterEllipsis'; $kt.TextWrapping = 'NoWrap'; $kt.VerticalAlignment = 'Center'; [void]$kl.Children.Add($kt)
    $dl = New-Link $(if ($on) { 'Details ausblenden' } else { 'Details' }) { param($k) $script:H2.Open[$k] = -not $script:H2.Open[$k]; Update-LoView } $key -Accent; $dl.Margin = New-Thickness 12 0 0 0
    [void]$kl.Children.Add($dl)
    [void]$tx.Children.Add($kl)
    [void]$d.Children.Add($tx)
    [void]$sp.Children.Add($d)
    if ($on) {
        $box = New-Stack; $box.Margin = New-Thickness 16 8 0 0
        foreach ($r in @($Rows | Select-Object -First 200)) { [void]$box.Children.Add((New-LoItem $r.Tag $r '' 0)) }
        [void]$sp.Children.Add($box)
    }
    return $sp
}

# Kurzer Name eines Rests (Ordner-/Dateiname bzw. letzter Teil des Registry-Pfads)
function Get-LoShortName($It) {
    $p = ([string]$It.Path).TrimEnd('\')
    if ($It.ValueName) { return [string]$It.ValueName }
    $leaf = ($p -split '\\')[-1]
    if ($leaf) { $leaf } else { $p }
}
function Get-LoIcon($It) { switch -Wildcard ([string]$It.Type) { 'Ordner' { 'folder' } 'Datei' { 'file' } default { 'chip' } } }
# Woher stammt der Rest? – ein Satz
function Get-LoOrigin($It) {
    $own = if ($It.Owner) { [string]$It.Owner } else { 'einem entfernten Programm' }
    $what = if ($It.Reason) { ([string]$It.Reason) } else { [string]$It.Type }
    "$what von $own"
}
# Warum darf er weg? – ein Satz aus Beleg und Prüfungen
function Get-LoWhy($It) {
    $chk = @($It.Checks); $ok = @($chk | Where-Object { $_.State -eq 'ok' }).Count
    $proof = if ($It.Proof) { ([string]$It.Proof).TrimEnd('.') + '. ' } else { '' }
    $use = if ($chk.Count) { "Nichts auf deinem PC nutzt es noch ($ok von $($chk.Count) Prüfungen bestanden)." } else { 'Das Programm ist nicht mehr installiert.' }
    $proof + $use
}

# Ein Eintrag, so einfach wie möglich:
#   [Symbol] Name                                  Größe   Zustand · Befehl
#            Stammt von: Programmordner von VLC media player
#            Darf weg: <Beleg>. Nichts auf deinem PC nutzt es noch (9 von 9 Prüfungen bestanden).
#            Prüfschritte · Ort öffnen
#   $Level 0 = empfohlen, 2 = nicht empfohlen (»Vorsicht:«), 1 = bleibt stehen (»Bleibt, weil:«)
function New-LoItem($It, $Row, [string]$Why, [int]$Level = 0) {
    $sp = New-Stack; $sp.Margin = $(if ($Level -eq 0) { New-Thickness 0 8 0 8 } else { New-Thickness 16 12 16 12 })
    $d = New-Dock
    if ($Row) { [void]$d.Children.Add((Set-Dock (New-LoToggle @($Row) 'Behalten' $(if ($Level -eq 2) { 'Trotzdem löschen' } else { 'Doch löschen' })) 'Right')) }
    $sz = New-Mono $(if ($It.Size -gt 0) { Format-Bytes $It.Size } else { '' }) 13 'ink-muted'; $sz.Margin = New-Thickness 16 0 16 0; $sz.VerticalAlignment = 'Top'
    [void]$d.Children.Add((Set-Dock $sz 'Right'))
    $ic = New-LineIcon (Get-LoIcon $It) 'ink-muted' 18; $ic.Margin = New-Thickness 0 1 12 0; $ic.VerticalAlignment = 'Top'
    [void]$d.Children.Add((Set-Dock $ic 'Left'))
    $tx = New-Stack
    $nm = New-Text (Get-LoShortName $It) -Role 'body'; $nm.FontWeight = [Windows.FontWeights]::Medium; $nm.TextTrimming = 'CharacterEllipsis'; $nm.TextWrapping = 'NoWrap'; $nm.ToolTip = [string]$It.Path
    [void]$tx.Children.Add($nm)
    [void]$tx.Children.Add((New-LabeledLine 'Stammt von:' (Get-LoOrigin $It)))
    switch ($Level) {
        2 { [void]$tx.Children.Add((New-LabeledLine 'Vorsicht:' $Why 'warning')) }
        1 { [void]$tx.Children.Add((New-LabeledLine 'Bleibt, weil:' $Why 'accent-text')) }
        default { [void]$tx.Children.Add((New-LabeledLine 'Darf weg:' (Get-LoWhy $It) 'success')) }
    }
    if ($Row -and $Row.A -eq 'Beim Neustart') { [void]$tx.Children.Add((New-LabeledLine 'Hinweis:' 'Wird beim nächsten Neustart gelöscht.' 'accent-text')) }
    $chk = @($It.Checks)
    $key = "chk|$($It.Type)|$($It.Path)"; $on = [bool]$script:H2.Open[$key]
    $ln = New-Stack 'Horizontal' 4
    if ($chk.Count) { [void]$ln.Children.Add((New-Link $(if ($on) { 'Prüfschritte ausblenden' } else { 'Prüfschritte' }) { param($k) $script:H2.Open[$k] = -not $script:H2.Open[$k]; Update-LoView } $key -Accent)) }
    $op = New-Link 'Ort öffnen' { param($x) Open-LeftoverLocation $x } $It -Accent; $op.Margin = New-Thickness $(if ($chk.Count) { 16 } else { 0 }) 2 0 2; $op.ToolTip = [string]$It.Path
    [void]$ln.Children.Add($op)
    [void]$tx.Children.Add($ln)
    [void]$d.Children.Add($tx)
    [void]$sp.Children.Add($d)
    if ($on -and $chk.Count) {
        $box = New-Object Windows.Controls.Border; $box.CornerRadius = New-Object Windows.CornerRadius(8); $box.Padding = New-Thickness 12 8 12 8; $box.Margin = New-Thickness 30 6 0 4
        Set-ThemeRef $box Background 'surface-raised'
        $bl = New-Stack
        $pp = New-Text ([string]$It.Path) -Role 'small' -Color 'ink-muted'; $pp.Margin = New-Thickness 0 0 0 6; [void]$bl.Children.Add($pp)
        foreach ($c in $chk) {
            $r = New-Dock; $r.Margin = New-Thickness 0 3 0 3
            $k2 = switch ($c.State) { 'ok' { @('ok', 'success') } 'warn' { @('warning', 'warning') } 'fail' { @('danger', 'danger') } default { @('info', 'ink-muted') } }
            $ci = New-LineIcon $k2[0] $k2[1] 16; $ci.Margin = New-Thickness 0 2 10 0; $ci.VerticalAlignment = 'Top'
            [void]$r.Children.Add((Set-Dock $ci 'Left'))
            [void]$r.Children.Add((New-Text ([string]$c.Text) -Role 'small' -Color $(if ($c.State -eq 'info') { 'ink-muted' } else { 'ink' })))
            [void]$bl.Children.Add($r)
        }
        $box.Child = $bl
        [void]$sp.Children.Add($box)
    }
    return $sp
}

function Update-LoBar([string]$Mode, $P) {
    $script:H2.LoMode = $Mode; $script:H2.LoP = $P
    $all = @(Get-LoRows $Mode)
    $sel = @($all | Where-Object { $_.IsSelected })
    $risky = @($sel | Where-Object { (Get-LoClass $_) -ne 'safe' }).Count
    $t = Get-LoSize $sel
    $differs = @($all | Where-Object { [bool]$_.IsSelected -ne ((Get-LoClass $_) -eq 'safe') }).Count -gt 0
    $extra = @()
    if ($differs) { $extra += New-HButton 'Zurück zur Empfehlung' { param($m) foreach ($r in @(Get-LoRows $m)) { $r.IsSelected = (Get-LoClass $r) -eq 'safe' }; Update-LoView } $Mode }
    $txt = if ($sel.Count -eq 0) { 'Nichts zum Löschen ausgewählt.' } else { "Gelöscht werden $($sel.Count) Reste · $(Format-Bytes $t)" + $(if ($risky) { " · davon $risky nicht empfohlen" } else { ' · erst in den Papierkorb' }) }
    Set-HomeBar $txt $(if ($sel.Count -eq 1) { '1 Rest löschen' } else { "$($sel.Count) Reste löschen" }) { Remove-SelectedLeftovers $script:H2.LoMode $script:H2.LoP } ($sel.Count -gt 0) $extra
}
# Zeichnet die Reste neu – im Dashboard oder in der Expertenansicht, je nachdem, wo du gerade bist
function Update-LoView { if ($script:State.Page -eq 'expert') { Show-ExpertLeftovers } else { Show-Home } }
# Expertenansicht › Programme: dieselbe einfache Reste-Ansicht wie im Dashboard (statt der Tabelle mit Haken)
function Show-ExpertLeftovers {
    $mode = Get-LoMode
    $P = if ($mode -eq 'orphans') { $script:State.OrphanP } else { $script:State.Current }
    $c = $script:LoCache[$mode]
    $rows = @(Get-LoRows $mode); $held = @($c.Held | Where-Object { $_ })
    $script:H2.BarTarget = 'expert'
    try {
        $root = New-Stack
        if ($rows.Count -eq 0 -and $held.Count -eq 0) {
            if ($mode -eq 'orphans' -or $c.Head -ne 'Gefundene Reste') { [void]$root.Children.Add((New-Text $c.Head -Role 'body' -Color 'ink-muted')) }
            Set-HomeBar ''
        } else {
            if ($mode -eq 'installed' -and $P) { [void]$root.Children.Add((New-Section "Reste von $($P.Name)" 0)) }
            Build-LeftoverGroups $root $mode $P
        }
        $off = $ui.LoScroll.VerticalOffset
        $ui.LoHost.Content = $root
        $ui.LoScroll.UpdateLayout(); $ui.LoScroll.ScrollToVerticalOffset($off)
    } catch { $ui.LoHost.Content = New-Text ('Ansicht konnte nicht aufgebaut werden: ' + $_.Exception.Message) -Role 'small' -Color 'danger' }
    finally { $script:H2.BarTarget = 'home' }
}
$script:UiHooks['leftovers'] = { if (Test-HomeOn 'prog') { Show-Home } elseif ($script:State.Page -eq 'expert') { Show-ExpertLeftovers } }
$script:UiHooks['programs'] = { if (Test-HomeOn 'prog') { Show-Home } }

# ===========================================================================
#  TREIBER: Aufgaben · Hersteller-Software · Updates von Windows Update
# ===========================================================================
function Start-HomeDriverSearch {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $script:H2.Upd = 'searching'
    if (Test-HomeOn 'drivers') { Show-Home }
    Start-Work -Status 'Suche bei Windows Update nach Treibern … (1–3 Minuten)' -Script { @(Search-DriverUpdates) } -OnDone {
        param($r) $script:H2.Upd = @($r | Where-Object { $_ }); $script:H2.UpdSel = @{}; foreach ($u in $script:H2.Upd) { $script:H2.UpdSel[[string]$u.Id] = $true }
        Set-Status $(if (@($script:H2.Upd).Count) { "$(@($script:H2.Upd).Count) Treiber-Update(s) verfügbar." } else { 'Windows Update bietet keine neueren Treiber an.' })
        if (Test-HomeOn 'drivers') { Show-Home }
    } -OnCancel { $script:H2.Upd = $null; if (Test-HomeOn 'drivers') { Show-Home } }
}
function Build-Drivers($root) {
    $dv = $script:H2.Drv
    $right = $null
    if ($dv) {
        $n = @($dv.Todo).Count
        $right = if ($n) { New-StateTag ([int](@($dv.Todo | Measure-Object Level -Maximum).Maximum)) "$n Aufgabe(n)" } else { New-StateTag 0 'Alles in Ordnung' }
    }
    [void]$root.Children.Add((New-PageHead 'Treiber' $right))
    if (-not $dv) {
        [void]$root.Children.Add((New-Loading 'Prüfe alle Geräte und ihre Treiber … (bis zu einer Minute)'))
        if (-not $script:Job) {
            Start-Work -Status 'Prüfe Treiber …' -Script { Get-DriverAnalysis } -OnDone {
                param($r) $script:H2.Drv = @($r)[-1]
                try { Show-Drivers $script:H2.Drv.Drivers } catch {}
                Set-Status 'Treiber geprüft.'
                if (Test-HomeOn 'drivers') { Show-Home }
            }
        } else { $script:H2.NeedLoad = $true }
        return
    }
    # Aufgaben (zuerst die wichtigsten)
    foreach ($t in @($dv.Todo | Sort-Object @{ e = { $_.Level }; Descending = $true })) {
        $sc = New-StateCard ([int]$t.Level) $true (New-Thickness 16 14 16 14); $sc.Outer.Margin = New-Thickness 0 0 0 12
        $d = New-Dock
        $bp = New-Stack; $bp.VerticalAlignment = 'Center'; $bp.Margin = New-Thickness 16 0 0 0
        foreach ($b in @(Get-FindingButtons $t | Select-Object -First 2)) { $b.Margin = New-Thickness 0 2 0 2; $b.MinWidth = 220; [void]$bp.Children.Add($b) }
        [void]$d.Children.Add((Set-Dock $bp 'Right'))
        $ic = New-LineIcon $script:LevelIconKind[[int]$t.Level] $script:LevelToken[[int]$t.Level] 22; $ic.Margin = New-Thickness 0 0 12 0; $ic.VerticalAlignment = 'Top'
        [void]$d.Children.Add((Set-Dock $ic 'Left'))
        $tx = New-Stack
        $hh = New-Stack 'Horizontal'
        [void]$hh.Children.Add((New-Text $t.Title -Role 'title'))
        $tip = [string]$t.Detail + $(if ($t.Benefit) { "`n`nVorteil: $($t.Benefit)" } else { '' })
        $i = New-Info $tip; if ($i) { $i.Margin = New-Thickness 4 -4 0 -4; [void]$hh.Children.Add($i) }
        [void]$tx.Children.Add($hh)
        if ($t.Device) { [void]$tx.Children.Add((New-Text ([string]$t.Device) -Role 'small' -Color 'ink-muted')) }
        [void]$d.Children.Add($tx)
        $sc.Inner.Child = $d
        [void]$root.Children.Add($sc.Outer)
    }
    if (@($dv.Todo).Count -eq 0) {
        $cnt = @($dv.Drivers | Where-Object { $_.Class -ne 'SOFTWARE' }).Count
        [void]$root.Children.Add((New-HCard (New-StateTag 0 "Alle $cnt Geräte haben einen funktionierenden Treiber.") 16 12))
    }
    foreach ($s in @($dv.Software | Where-Object { $_.Level -eq 0 })) { [void]$root.Children.Add((New-HCard (New-StateTag 0 "$($s.Product) installiert – hält den Grafiktreiber aktuell.") 16 12)) }

    # Treiber-Updates von Windows Update
    [void]$root.Children.Add((New-Section 'Treiber-Updates von Windows Update' 16))
    $u = $script:H2.Upd
    if ($null -eq $u) {
        $d = New-Dock
        [void]$d.Children.Add((Set-Dock (New-HButton 'Nach Updates suchen' { Start-HomeDriverSearch } -Icon 'search') 'Right'))
        $sp = New-Stack 'Horizontal'; $sp.VerticalAlignment = 'Center'
        [void]$sp.Children.Add((New-Text 'Windows Update kennt manchmal neuere Original-Treiber.' -Role 'body' -Color 'ink-muted'))
        $i = New-Info 'TuneRig installiert Treiber nur über Windows Update oder vom Hersteller – nie über Treiber-Updater von Drittanbietern. Vorher wird gesichert (nach deiner Einstellung).'; $i.Margin = New-Thickness 4 0 0 0; [void]$sp.Children.Add($i)
        [void]$d.Children.Add($sp)
        [void]$root.Children.Add((New-HCard $d 16 12))
    } elseif ($u -is [string]) {
        [void]$root.Children.Add((New-Loading 'Suche bei Windows Update … (1–3 Minuten)'))
    } elseif (@($u).Count -eq 0) {
        $d = New-Dock
        [void]$d.Children.Add((Set-Dock (New-Link 'Erneut suchen' { Start-HomeDriverSearch } -Accent) 'Right'))
        [void]$d.Children.Add((New-StateTag 0 'Keine neueren Treiber verfügbar.'))
        [void]$root.Children.Add((New-HCard $d 16 12))
    } else {
        $card = New-HCard $null 0 12; $sp = New-Stack; $first = $true
        foreach ($x in @($u)) {
            if (-not $first) { [void]$sp.Children.Add((New-RowLine)) }; $first = $false
            $row = New-Dock; $row.Margin = New-Thickness 16 10 16 10
            $cb = New-Object Windows.Controls.CheckBox; $cb.IsChecked = [bool]$script:H2.UpdSel[[string]$x.Id]; $cb.VerticalAlignment = 'Center'
            [Windows.Automation.AutomationProperties]::SetName($cb, [string]$x.Title)
            $cb.CommandParameter = [string]$x.Id
            $cb.Add_Click({ $script:H2.UpdSel[[string]$this.CommandParameter] = [bool]$this.IsChecked; Update-DrvBar })
            [void]$row.Children.Add((Set-Dock $cb 'Left'))
            [void]$row.Children.Add((Set-Dock (New-Mono ([string]$x.Date) 13 'ink-muted') 'Right'))
            $tx = New-Stack
            [void]$tx.Children.Add((New-Text ([string]$x.Title) -Role 'body'))
            [void]$tx.Children.Add((New-Text (@($x.Manufacturer, $x.Class | Where-Object { $_ }) -join '  ·  ') -Role 'small' -Color 'ink-muted'))
            [void]$row.Children.Add($tx)
            [void]$sp.Children.Add($row)
        }
        $card.Child = $sp; [void]$root.Children.Add($card)
        Update-DrvBar
    }
    $ft = New-Stack 'Horizontal' 8
    [void]$ft.Children.Add((New-Link 'Alle Geräte ansehen' { Show-Tool 'drivers' } -Accent))
    $dm = New-Link 'Geräte-Manager' { Open-Target 'devmgmt.msc' } -Accent; $dm.Margin = New-Thickness 24 2 0 2; [void]$ft.Children.Add($dm)
    $rc = New-Link 'Neu prüfen' { $script:H2.Drv = $null; Show-Home } -Accent; $rc.Margin = New-Thickness 24 2 0 2; [void]$ft.Children.Add($rc)
    [void]$root.Children.Add($ft)
}
function Update-DrvBar {
    $ids = @($script:H2.UpdSel.Keys | Where-Object { $script:H2.UpdSel[$_] })
    Set-HomeBar "$($ids.Count) Treiber ausgewählt · $(Get-BackupNote)" "$($ids.Count) Treiber installieren" { Invoke-HomeDriverInstall } ($ids.Count -gt 0)
}
function Invoke-HomeDriverInstall {
    $ids = @($script:H2.UpdSel.Keys | Where-Object { $script:H2.UpdSel[$_] })
    if ($ids.Count -eq 0 -or $script:Job) { return }
    $names = @($script:H2.Upd | Where-Object { $ids -contains [string]$_.Id } | ForEach-Object { '-  ' + $_.Title }) -join "`n"
    if (-not (Confirm-Action "Diese Treiber werden über Windows Update installiert:`n`n$names`n`nDer Bildschirm kann kurz flackern. Fortfahren?" 'Treiber-Updates')) { return }
    $script:State.Pending = $ids
    Invoke-WithRestorePoint 'Treiber-Updates' {
        Start-Work -Status 'Installiere Treiber …' -Arguments @(, @($script:State.Pending)) -Script { Install-DriverUpdates $A[0] } -OnDone {
            param($r) $msg = [string](@($r)[-1])
            $script:H2.Upd = $null; $script:H2.UpdSel = @{}; $script:H2.Drv = $null
            Set-Status $msg; Show-Info $msg 'Treiber-Updates'
            if (Test-HomeOn 'drivers') { Show-Home }
        }
    }
}

# ===========================================================================
#  OVERDRIVE: erst Risiko bestätigen, dann Schalter in drei Stufen
# ===========================================================================
function Get-OdItems {
    @($script:H2.Od | Where-Object { $_ } | Sort-Object Level, Title | ForEach-Object {
        $tip = "$($_.Benefit)`nRisiko: $($_.Risk)`nJetzt: $($_.State)" + $(if ($_.Restart) { "`nWirkt nach einem Neustart." } else { '' })
        @{ Id = $_.Id; Title = $_.Title; Tip = $tip; On = [bool]$_.Optimal; CanOff = [bool]$_.CanRevert; CanOn = $true; Impact = [int]$_.Impact; Level = [int]$_.Level
           Tag = $(if ($_.Restart) { 'Neustart' } else { '' }); Src = $_ }
    })
}
function Build-Overdrive($root) {
    $guide = New-HButton 'Übertakten-Anleitung' { Open-WizMode 'overdrive' } -Icon 'flame'
    $guide.ToolTip = 'Schritt für Schritt: CPU, Grafikkarte und Arbeitsspeicher übertakten (XMP/EXPO) – mit Hinweisen zu Temperaturen.'
    [void]$root.Children.Add((New-PageHead 'Overdrive' $guide))
    $sc = New-StateCard 2 $true (New-Thickness 20 16 20 16); $sc.Outer.Margin = New-Thickness 0 0 0 16
    $d = New-Dock
    $ic = New-LineIcon 'warning' 'warning' 28; $ic.Margin = New-Thickness 0 0 16 0; $ic.VerticalAlignment = 'Top'
    [void]$d.Children.Add((Set-Dock $ic 'Left'))
    $tx = New-Stack
    [void]$tx.Children.Add((New-Text 'Auf eigenes Risiko' -Role 'h3'))
    [void]$tx.Children.Add((New-Text 'Mehr Leistung, aber mehr Wärme und Stromverbrauch. Manche Schalter schalten Schutzfunktionen von Windows ab.' -Role 'body' -Color 'ink-muted' -Top 4))
    $cb = New-Object Windows.Controls.CheckBox; $cb.Content = 'Ich kenne die Risiken und will fortfahren.'; $cb.IsChecked = $script:H2.OdAccepted; $cb.Margin = New-Thickness 0 12 0 0
    $cb.Add_Click({ $script:H2.OdAccepted = [bool]$this.IsChecked; Show-Home })
    [void]$tx.Children.Add($cb)
    [void]$d.Children.Add($tx)
    $sc.Inner.Child = $d
    [void]$root.Children.Add($sc.Outer)
    if (-not $script:H2.OdAccepted) { return }
    if ($null -eq $script:H2.Od) {
        [void]$root.Children.Add((New-Loading 'Prüfe Overdrive-Einstellungen …'))
        if (-not $script:Job) {
            Start-Work -Status 'Prüfe Overdrive-Einstellungen …' -Script { @(Get-GamingTweaks 'overdrive' (Test-IsLaptop)) } -OnDone {
                param($r) $script:H2.Od = @($r | Where-Object { $_ }); $script:H2.OdWant = @{}
                try { Show-OverdriveGrid $script:H2.Od } catch {}
                Set-Status "$(@($script:H2.Od).Count) Overdrive-Einstellungen geprüft."
                if (Test-HomeOn 'overdrive') { Show-Home }
            }
        } else { $script:H2.NeedLoad = $true }
        return
    }
    $items = @(Get-OdItems)
    $lv = New-Stack 'Horizontal'; $lv.Margin = New-Thickness 0 0 0 12
    $lt = New-Text 'Stufe auf einmal wählen:' -Role 'small' -Color 'ink-muted'; $lt.VerticalAlignment = 'Center'; $lt.Margin = New-Thickness 0 0 12 0; [void]$lv.Children.Add($lt)
    foreach ($n in 1, 2, 3) {
        $b = New-HButton $script:OdLevelName[$n] { param($k) foreach ($it in @(Get-OdItems)) { if ([int]$it.Level -le $k -and -not $it.On) { $script:H2.OdWant[$it.Id] = $true } elseif ([int]$it.Level -gt $k -and $script:H2.OdWant.ContainsKey($it.Id) -and -not $it.On) { $script:H2.OdWant.Remove($it.Id) } }; Show-Home } $n
        $b.MinHeight = 34; $b.Padding = New-Thickness 12 5 12 6; $b.Margin = New-Thickness 0 0 8 0
        $b.ToolTip = "Schaltet alles bis einschließlich Stufe $n ein. Angewendet wird erst mit »Jetzt anwenden«."
        [void]$lv.Children.Add($b)
    }
    [void]$root.Children.Add($lv)
    foreach ($grp in @($items | Group-Object { $_.Level } | Sort-Object { [int]$_.Name })) {
        $name = $script:OdLevelName[[int]$grp.Name]; if (-not $name) { $name = "Stufe $($grp.Name)" }
        [void]$root.Children.Add((New-Section "Stufe $name"))
        [void]$root.Children.Add((New-ToggleCard @($grp.Group) $script:H2.OdWant { Update-OdBar }))
    }
    Update-OdBar
}
function Update-OdBar {
    $c = Get-WantChanges @(Get-OdItems) $script:H2.OdWant
    $reset = New-HButton 'Zurücksetzen' { $script:H2.OdWant = @{}; Show-Home }; $reset.IsEnabled = $c.Count -gt 0
    Set-HomeBar "$($c.Count) Änderung(en) · $(Get-BackupNote)" 'Jetzt anwenden' { Invoke-OdApply } ($c.Count -gt 0) @($reset)
}
function Invoke-OdApply {
    if (-not $script:H2.OdAccepted) { return }
    $c = Get-WantChanges @(Get-OdItems) $script:H2.OdWant
    if ($c.Count -eq 0 -or $script:Job) { return }
    $lines = @($c.On | ForEach-Object { "+  $($_.Title)`n     Risiko: $($_.Src.Risk)" }) + @($c.Off | ForEach-Object { "–  $($_.Title) (zurück auf deinen früheren Wert)" })
    if (-not (Confirm-Action ("Diese Overdrive-Einstellungen werden geändert:`n`n" + ($lines -join "`n") + "`n`nFortfahren?") 'Overdrive')) { return }
    $script:State.Pending = @{ On = @($c.On | ForEach-Object { $_.Id }); Off = @($c.Off | ForEach-Object { $_.Id }); Restart = [bool](@($c.On + $c.Off | Where-Object { $_.Src.Restart }).Count) }
    Invoke-WithRestorePoint 'TuneRig Overdrive' {
        Start-Work -Status 'Ändere Overdrive-Einstellungen …' -Arguments @(@($script:State.Pending.On), @($script:State.Pending.Off)) -Script {
            $e = @()
            if (@($A[0]).Count) { $e += @(Invoke-AllSettings $A[0]) }
            if (@($A[1]).Count) { $e += @(Invoke-AllSettings $A[1] -Revert) }
            [pscustomobject]@{ Errors = @($e | Where-Object { $_ }); Tweaks = @(Get-GamingTweaks 'overdrive' (Test-IsLaptop)) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            $script:H2.Od = @($r.Tweaks | Where-Object { $_ }); $script:H2.OdWant = @{}
            try { Show-OverdriveGrid $script:H2.Od } catch {}
            $errs = @($r.Errors)
            $msg = if ($errs.Count) { "Erledigt, mit Hinweisen:`n" + ($errs -join "`n") } else { 'Overdrive-Einstellungen übernommen.' }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen wirken erst nach einem Neustart." }
            Set-Status (($msg -split "`n")[0])
            if (Test-HomeOn 'overdrive') { Show-Home }
            if ($errs.Count -or $script:State.Pending.Restart) { Show-Info $msg 'Overdrive' }
        }
    }
}

# ---------------------------------------------------------------------------
#  Hilfe (kurz, passend zur neuen Oberfläche)
# ---------------------------------------------------------------------------
$ui.BtnNavHelp.Add_Click({
    Show-Info ("So benutzt du TuneRig`n`n" +
        "1.  Das Dashboard zeigt deinen Systemzustand und was du verbessern kannst.`n" +
        "2.  Schnell: »PC optimieren« prüft alles, zeigt dir den Plan zum Abhaken und ändert erst, wenn du zustimmst.`n" +
        "3.  Schritt für Schritt: Regulärer Check, Performance Boost oder Overdrive – im Dashboard oder oben in der Leiste. Du entscheidest bei jedem Punkt.`n" +
        "4.  Gezielt: Die Kacheln führen zu Leistung, Speicherplatz, Treiber, Programme und Overdrive. Alle Werkzeuge einzeln: oben »Alle Werkzeuge«.`n`n" +
        "Symbole:  Haken = in Ordnung,  i = Hinweis oder Erklärung,  Dreieck = Verbesserung möglich,  Kreuz = Problem.`n" +
        "Schalter:  an = aktiv. Unten zeigt die Leiste, wie viele Änderungen offen sind.`n`n" +
        "Sicherheit:  Vor Änderungen legt TuneRig je nach Einstellung einen Wiederherstellungspunkt an. Alles verwaltest du unten rechts unter »Sicherungen« oder im Dashboard bei »Letzte Sicherung«.`n`n" +
        "Design:  Oben rechts wechselst du zwischen dunklem und hellem Design.") 'Hilfe'
})
