﻿# ============================================================================
#  TuneRig (portabel) - Hauptprogramm mit grafischer Oberfläche
#  Start: Doppelklick auf "TuneRig starten.bat"
# ============================================================================

param([switch]$DebugMode)

$ErrorActionPreference = 'Continue'
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DebugArg = if ($DebugMode) { ' -DebugMode' } else { '' }
$WinStyle = if ($DebugMode) { '-NoExit' } else { '-WindowStyle Hidden' }

# Jeder unerwartete Fehler beim Start wird angezeigt und protokolliert (sonst bliebe das Fenster einfach aus)
trap {
    try { if ($script:Splash) { $script:Splash.Close() } } catch {}
    $ex = $_.Exception; $detail = $ex.Message
    while ($ex.InnerException) { $ex = $ex.InnerException; $detail += "`n-> " + $ex.Message }
    $msg = "TuneRig konnte nicht gestartet werden:`n`n$detail`n`n$($_.InvocationInfo.PositionMessage)"
    try { $msg | Out-File -FilePath (Join-Path $AppDir 'fehler.log') -Append -Encoding UTF8 } catch {}
    try { Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show($msg, 'TuneRig - Fehler') | Out-Null } catch {}
    exit 1
}

# --- Administratorrechte anfordern -------------------------------------------
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    try {
        Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA $WinStyle -File `"$($MyInvocation.MyCommand.Path)`"$DebugArg"
    } catch {
        Add-Type -AssemblyName PresentationFramework
        [System.Windows.MessageBox]::Show('TuneRig braucht Administratorrechte, um Treiber, Energieoptionen und Programme zu verwalten.', 'TuneRig') | Out-Null
    }
    exit
}

# --- WPF braucht einen STA-Thread ---------------------------------------------
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA $WinStyle -File `"$($MyInvocation.MyCommand.Path)`"$DebugArg"
    exit
}

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Get-ChildItem -LiteralPath $AppDir -Filter *.ps1 | Unblock-File -ErrorAction SilentlyContinue

$CorePath = Join-Path $AppDir 'Core.ps1'
$script:CoreText = [IO.File]::ReadAllText($CorePath, [Text.Encoding]::UTF8)
. $CorePath
if (-not $DebugMode) { [PCO.Native]::HideConsole() }

# --- Corporate Design laden (zentrale Theme-Datei) ----------------------------
. (Join-Path $AppDir 'Theme.ps1')
[TuneRig.Win]::SetAppId('TuneRig.PCOptimierung')
$script:SettingsPath = Join-Path $env:LOCALAPPDATA 'TuneRig\settings.json'
$script:StartSettings = try { Get-Content -LiteralPath $script:SettingsPath -Raw -ErrorAction Stop | ConvertFrom-Json } catch { $null }
Initialize-Theme $(if ($script:StartSettings -and $script:StartSettings.Theme -eq 'light') { 'light' } else { 'dark' })
. (Join-Path $AppDir 'Updater.ps1')
$script:AppVersion = (Get-TuneRigVersionInfo).Version

# ============================================================================
#  Ladesequenz: erscheint sofort; währenddessen wird die Oberfläche aufgebaut
#  und der Systemzustand für die Startseite ermittelt.
# ============================================================================
$splashXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TuneRig" Width="560" Height="340" WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        ResizeMode="NoResize" WindowStartupLocation="CenterScreen" ShowInTaskbar="True" UseLayoutRounding="True"
        TextOptions.TextFormattingMode="Display" FontFamily="{DynamicResource FontSans}">
  <Border Background="{DynamicResource Ground}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="14" Padding="40,28,40,24">
    <DockPanel>
      <DockPanel DockPanel.Dock="Bottom">
        <TextBlock x:Name="SplashVersion" DockPanel.Dock="Right" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}"/>
        <TextBlock x:Name="SplashCopy" Style="{StaticResource Label}" Tag="caps" Text="PC-Optimierung"/>
      </DockPanel>
      <StackPanel VerticalAlignment="Center">
        <Image Source="{DynamicResource LogoImage}" Height="112" HorizontalAlignment="Left" Margin="-10,0,0,0" RenderOptions.BitmapScalingMode="HighQuality"
               AutomationProperties.Name="TuneRig PC-Optimierung"/>
        <StackPanel x:Name="SplashSegments" Orientation="Horizontal" Margin="0,24,0,0"/>
        <StackPanel Orientation="Horizontal" Margin="0,14,0,0">
          <Grid Width="20" Height="20" Margin="0,0,12,0" VerticalAlignment="Center">
            <Ellipse Stroke="{DynamicResource Line}" StrokeThickness="3" StrokeDashArray="1.4 0.9"/>
            <Path Stroke="{DynamicResource Accent}" StrokeThickness="3" StrokeDashArray="1.4 0.9" Data="M10,1.5 A8.5,8.5 0 0 1 18.5,10" RenderTransformOrigin="0.5,0.5">
              <Path.RenderTransform><RotateTransform Angle="0"/></Path.RenderTransform>
              <Path.Triggers>
                <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                  <BeginStoryboard><Storyboard>
                    <DoubleAnimation Storyboard.TargetProperty="(UIElement.RenderTransform).(RotateTransform.Angle)" From="0" To="360" Duration="0:0:1.2" RepeatBehavior="Forever"/>
                  </Storyboard></BeginStoryboard>
                </EventTrigger>
              </Path.Triggers>
            </Path>
          </Grid>
          <TextBlock x:Name="SplashStatus" Style="{StaticResource Small}" VerticalAlignment="Center" Text="Starte TuneRig …"/>
        </StackPanel>
      </StackPanel>
    </DockPanel>
  </Border>
</Window>
'@
$script:Splash = [Windows.Markup.XamlReader]::Parse($splashXaml)
Set-WindowBranding $script:Splash
Set-CapsLabels $script:Splash
$script:Splash.FindName('SplashVersion').Text = "Version $script:AppVersion"
$script:SplashSegs = 24
for ($i = 0; $i -lt $script:SplashSegs; $i++) {
    $b = New-Object Windows.Controls.Border
    $b.Width = 16; $b.Height = 6; $b.Margin = New-Object Windows.Thickness(0, 0, 3, 0); $b.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $b Background 'line'
    [void]$script:Splash.FindName('SplashSegments').Children.Add($b)
}
$script:SplashStart = Get-Date
$script:SplashLevel = 0

function Update-SplashUi {
    try { [Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Background) } catch {}
}
# Segmentierte Fortschrittsanzeige (Motiv aus dem Logo)
function Set-SplashProgress([double]$Fraction, [string]$Text = '') {
    if (-not $script:Splash) { return }
    $n = [math]::Min($script:SplashSegs, [math]::Round($script:SplashSegs * $Fraction))
    $segs = $script:Splash.FindName('SplashSegments').Children
    for ($i = $script:SplashLevel; $i -lt $n; $i++) { Set-ThemeRef $segs[$i] Background 'accent' }
    $script:SplashLevel = [math]::Max($script:SplashLevel, $n)
    if ($Text) { $script:Splash.FindName('SplashStatus').Text = $Text }
    Update-SplashUi
}

# Schnellcheck in einem eigenen Hintergrund-Thread (Ergebnis für die Startseite)
function New-QuickHealthJob {
    $rs = [runspacefactory]::CreateRunspace(); $rs.ApartmentState = 'STA'; $rs.Open()
    $rs.SessionStateProxy.SetVariable('Sync', [hashtable]::Synchronized(@{ Status = '' }))
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript($script:CoreText + "`r`nGet-QuickHealth")
    return @{ PS = $ps; Handle = $ps.BeginInvoke(); Done = $false }
}

$script:Splash.Show()
Set-SplashProgress 0.08 'Lade Oberfläche …'
$script:HealthJob = New-QuickHealthJob

# ============================================================================
#  Oberfläche (XAML)
# ============================================================================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TuneRig" Height="800" Width="1200" MinHeight="600" MinWidth="1120"
        WindowStartupLocation="CenterScreen" UseLayoutRounding="True" TextOptions.TextFormattingMode="Display"
        Background="{DynamicResource Ground}" Foreground="{DynamicResource Ink}" FontFamily="{DynamicResource FontSans}" FontSize="14">
  <DockPanel>
    <!-- ===================== STATUSLEISTE ===================== -->
    <Border x:Name="StatusBar" DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="24,6">
      <DockPanel>
        <Button x:Name="BtnCheckUpdate" DockPanel.Dock="Right" Content="Nach Updates suchen" MinHeight="28" Padding="12,3,12,4" Margin="12,0,0,0" FontSize="12"/>
        <TextBlock x:Name="StatusVersion" DockPanel.Dock="Right" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Margin="16,0,0,0"/>
        <Button x:Name="BtnCancel" DockPanel.Dock="Right" Content="Abbrechen" Visibility="Collapsed" MinHeight="32" Margin="12,0,0,0"/>
        <ProgressBar x:Name="BusyBar" DockPanel.Dock="Right" Width="160" IsIndeterminate="True" Visibility="Collapsed" VerticalAlignment="Center"/>
        <TextBlock x:Name="StatusText" Style="{StaticResource Small}" Text="Bereit." VerticalAlignment="Center" TextTrimming="CharacterEllipsis" TextWrapping="NoWrap"/>
      </DockPanel>
    </Border>

    <!-- ===================== KOPFLEISTE: Symbol + Wortmarke oben links ===================== -->
    <Border x:Name="HeaderBar" DockPanel.Dock="Top" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Height="72" Padding="16,0,24,0">
      <DockPanel>
        <StackPanel x:Name="HeaderNav" DockPanel.Dock="Right" Orientation="Horizontal">
          <Button x:Name="BtnNavHome" Style="{StaticResource TopNav}" Content="STARTSEITE" ToolTip="Zurück zur Auswahl"/>
          <Button x:Name="BtnNavGuided" Style="{StaticResource TopNav}" ToolTip="Prüft und verbessert deinen PC Schritt für Schritt">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavGuidedIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="REGULÄRER CHECK" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavBoost" Style="{StaticResource TopNav}" ToolTip="Mehr Leistung für Spiele – mit sicheren Einstellungen">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavBoostIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="PERFORMANCE BOOST" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavOverdrive" Style="{StaticResource TopNav}" ToolTip="Übertakten und Tuning – auf eigenes Risiko">
            <StackPanel Orientation="Horizontal">
              <ContentControl x:Name="NavOverdriveIcon" Margin="0,0,6,0" VerticalAlignment="Center"/>
              <TextBlock Text="OVERDRIVE" VerticalAlignment="Center"/>
            </StackPanel>
          </Button>
          <Button x:Name="BtnNavExpert" Style="{StaticResource TopNav}" Content="ALLE WERKZEUGE" ToolTip="Alle Funktionen in Reitern"/>
          <Button x:Name="BtnNavHelp" Style="{StaticResource TopNav}" Content="HILFE"/>
          <Button x:Name="BtnTheme" Content="Hell" MinHeight="32" Margin="16,0,0,0" VerticalAlignment="Center" ToolTip="Zwischen dunklem und hellem Design wechseln"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Image x:Name="Logo" Source="{DynamicResource LogoImage}" Height="64" Stretch="Uniform" RenderOptions.BitmapScalingMode="HighQuality"
                 AutomationProperties.Name="TuneRig PC-Optimierung"/>
          <Border Width="1" Height="28" Background="{DynamicResource Line}" Margin="12,0,16,0" Visibility="Collapsed"/>
          <TextBlock x:Name="ModeLabel" Style="{StaticResource Label}" VerticalAlignment="Center" Visibility="Collapsed"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <Grid>
      <!-- ===================== STARTSEITE ===================== -->
      <DockPanel x:Name="WelcomePage" Background="{DynamicResource Ground}">
        <!-- Wechselnde Tipps -->
        <Border x:Name="TipBar" DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="48,12">
          <DockPanel MaxWidth="1120">
            <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
              <Button x:Name="TipAction" Visibility="Collapsed" MinHeight="32" Margin="16,0,16,0"/>
              <TextBlock x:Name="TipCounter" FontFamily="{DynamicResource FontMono}" FontSize="14" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Margin="0,0,12,0"/>
              <Button x:Name="TipPrev" Content="‹" MinWidth="36" MinHeight="32" Padding="0" Margin="0,0,4,0" ToolTip="Vorheriger Tipp"/>
              <Button x:Name="TipNext" Content="›" MinWidth="36" MinHeight="32" Padding="0" Margin="0" ToolTip="Nächster Tipp"/>
            </StackPanel>
            <ContentControl x:Name="TipIcon" DockPanel.Dock="Left" VerticalAlignment="Center" Margin="0,0,12,0"/>
            <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Tipp" VerticalAlignment="Center" Margin="0,0,16,0"/>
            <TextBlock x:Name="TipText" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" VerticalAlignment="Center"/>
          </DockPanel>
        </Border>
        <ScrollViewer VerticalScrollBarVisibility="Auto">
        <StackPanel MaxWidth="1120" Margin="48,32,48,32">
          <TextBlock Style="{StaticResource H1}" Text="Hol mehr aus deinem PC heraus."/>
          <TextBlock Style="{StaticResource Body}" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,24"
                     Text="TuneRig findet, was deinen PC bremst, und behebt es. Nichts ändert sich ohne deine Zustimmung."/>
          <!-- Update-Hinweis (nur sichtbar, wenn eine neuere Version bereitsteht) -->
          <Border x:Name="UpdateCard" Style="{StaticResource Card}" Visibility="Collapsed" Margin="0,0,0,16">
            <DockPanel>
              <ContentControl x:Name="UpdateIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Center"/>
              <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Center">
                <Button x:Name="BtnUpdateNow" Content="Jetzt aktualisieren" Margin="16,0,8,0"/>
                <Button x:Name="BtnUpdateLater" Content="Später" Margin="0"/>
              </StackPanel>
              <StackPanel VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Update verfügbar"/>
                <TextBlock x:Name="UpdateTitle" Style="{StaticResource H3}" FontSize="16" LineHeight="22" Margin="0,4,0,0"/>
                <TextBlock x:Name="UpdateText" Style="{StaticResource Small}"/>
              </StackPanel>
            </DockPanel>
          </Border>
          <!-- Gesamtwertung -->
          <Border x:Name="HealthCard" Style="{StaticResource Card}" Padding="24" Margin="0,0,0,24">
            <Grid>
              <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <ContentControl x:Name="HealthGauge" Width="160" Height="140" VerticalAlignment="Center"/>
              <StackPanel Grid.Column="1" Margin="24,0,24,0" VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Systemzustand"/>
                <StackPanel Orientation="Horizontal" Margin="0,8,0,0">
                  <TextBlock x:Name="HealthScore" Style="{StaticResource Metric}" Text="–"/>
                  <TextBlock x:Name="HealthMax" FontFamily="{DynamicResource FontMono}" FontSize="14" Foreground="{DynamicResource InkMuted}" Text=" / 100" VerticalAlignment="Bottom" Margin="4,0,16,6"/>
                  <TextBlock x:Name="HealthRating" Style="{StaticResource H3}" VerticalAlignment="Center" Text="Wird bewertet …"/>
                </StackPanel>
                <TextBlock x:Name="HealthSummary" Style="{StaticResource Small}" Margin="0,4,0,0" Text="Der Schnellcheck läuft im Hintergrund und dauert nur wenige Sekunden."/>
                <StackPanel x:Name="HealthItems" Margin="0,8,0,0"/>
              </StackPanel>
              <StackPanel Grid.Column="2" VerticalAlignment="Center">
                <Button x:Name="BtnHealthCheck" Style="{StaticResource Primary}" Content="JETZT PRÜFEN" Margin="0,0,0,8" ToolTip="Startet den Regulären Check"/>
                <Button x:Name="BtnHealthRefresh" Content="Neu bewerten" Margin="0" ToolTip="Schnellcheck erneut ausführen"/>
              </StackPanel>
            </Grid>
          </Border>
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="24"/><ColumnDefinition Width="*"/><ColumnDefinition Width="24"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
            <!-- Regulärer Check -->
            <Border Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartGuided" DockPanel.Dock="Bottom" Content="Regulären Check starten" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardGuidedIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource InkMuted}" Tag="caps" Text="Empfohlen für alle" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Regulärer Check" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Prüft und verbessert deinen PC Schritt für Schritt. Oben steht immer, was als Nächstes zu tun ist – meist reicht ein Klick."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainGuided" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="5 Schritte · 5–10 Minuten"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Treiber, Leistung, Aufräumen"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource InkMuted}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Jede Änderung nur nach Rückfrage"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
            <!-- Performance Boost -->
            <Border Grid.Column="2" Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartGaming" DockPanel.Dock="Bottom" Content="Performance Boost starten" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardBoostIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}" Tag="caps" Text="Mehr FPS · weniger Ruckler" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Performance Boost" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Holt deutlich mehr Leistung für Spiele heraus: Bildwiederholrate, Prozessor, Autostart und Ping. Alles mit bewährten, sicheren Einstellungen."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainBoost" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Bildwiederholrate, Maus, Prozessor"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Autostart, Ping und DNS"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Wirkung und Nebenwirkung bei jedem Punkt"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
            <!-- Overdrive: nur auf eigenes Risiko -->
            <Border Grid.Column="4" Style="{StaticResource Card}" Padding="24">
              <DockPanel>
                <Button x:Name="BtnStartOverdrive" DockPanel.Dock="Bottom" Content="Overdrive öffnen" Margin="0,24,0,0" HorizontalAlignment="Left"/>
                <StackPanel>
                  <DockPanel>
                    <ContentControl x:Name="CardOverdriveIcon" DockPanel.Dock="Left" Margin="0,0,8,0" VerticalAlignment="Center"/>
                    <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource Warning}" Tag="caps" Text="Übertakten · auf eigenes Risiko" VerticalAlignment="Center"/>
                  </DockPanel>
                  <TextBlock Style="{StaticResource H3}" Text="Overdrive" Margin="0,12,0,8"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Zum Übertakten: stellt Windows in 3 Stufen kompromisslos auf Leistung und zeigt dir, wie du Prozessor, Grafikkarte und Arbeitsspeicher übertaktest. Dafür mehr Wärme, Stromverbrauch und teils weniger Schutz."/>
                  <DockPanel Margin="0,16,0,0">
                    <TextBlock DockPanel.Dock="Left" Style="{StaticResource Label}" Tag="caps" Text="Leistungsgewinn" Margin="0,0,16,0" VerticalAlignment="Center"/>
                    <ContentControl x:Name="GainOverdrive" VerticalAlignment="Center"/>
                  </DockPanel>
                  <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Übertakten von CPU, GPU und RAM – mit Anleitung"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="3 Stufen, nur nach ausdrücklicher Bestätigung"/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource Warning}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Text="Jederzeit komplett zurücksetzbar"/>
                    </DockPanel>
                  </StackPanel>
                </StackPanel>
              </DockPanel>
            </Border>
          </Grid>
          <!-- Alle Werkzeuge: schmale Leiste -->
          <Border Style="{StaticResource Card}" Padding="24,16" Margin="0,24,0,0">
            <DockPanel>
              <Button x:Name="BtnStartExpert" DockPanel.Dock="Right" Content="Alle Werkzeuge öffnen" VerticalAlignment="Center" Margin="16,0,0,0"/>
              <ContentControl x:Name="CardExpertIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Center"/>
              <StackPanel VerticalAlignment="Center">
                <TextBlock Style="{StaticResource Body}" FontWeight="SemiBold" Text="Alle Werkzeuge – für Erfahrene"/>
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" Margin="0,4,0,0" TextWrapping="Wrap" Text="Alle Funktionen in Reitern, ohne Assistent: Treiber, Energiesparpläne, Grafikkarte pro Spiel, Junk-Dateien auf allen Laufwerken, Deinstallation mit Rückstandssuche."/>
              </StackPanel>
            </DockPanel>
          </Border>
          <Border Style="{StaticResource Card}" Margin="0,24,0,0">
            <DockPanel>
              <ContentControl x:Name="SafetyIcon" DockPanel.Dock="Left" Margin="0,0,16,0" VerticalAlignment="Top"/>
              <StackPanel>
                <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Sicherheit"/>
                <StackPanel Margin="0,8,0,0">
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Vor jeder Änderung legt TuneRig einen Wiederherstellungspunkt an – damit lässt sich alles rückgängig machen."/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Programmreste landen im Papierkorb, Registry-Einträge werden vorher gesichert."/>
                    </DockPanel>
                    <DockPanel Margin="0,6,0,0">
                      <Border DockPanel.Dock="Left" Width="6" Height="6" CornerRadius="1" Background="{DynamicResource AccentText}" Margin="2,7,12,0" VerticalAlignment="Top"/>
                      <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Persönliche Dateien, Passwörter und Browser-Verlauf bleiben unangetastet."/>
                    </DockPanel>
                  </StackPanel>
              </StackPanel>
            </DockPanel>
          </Border>
          <CheckBox x:Name="ChkSkipWelcome" Margin="0,24,0,0" Content="Beim nächsten Start direkt die zuletzt gewählte Ansicht öffnen"/>
        </StackPanel>
        </ScrollViewer>
      </DockPanel>

      <!-- ===================== GEFÜHRTER CHECK ===================== -->
      <Grid x:Name="WizardPage" Visibility="Collapsed" Background="{DynamicResource Ground}">
        <Grid.ColumnDefinitions><ColumnDefinition Width="280"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
        <Border Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,1,0">
          <DockPanel Margin="24,32,16,24">
            <TextBlock DockPanel.Dock="Top" x:Name="WizSideTitle" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}"/>
            <TextBlock DockPanel.Dock="Top" x:Name="WizProgressText" Style="{StaticResource Small}" Margin="0,8,0,8"/>
            <StackPanel DockPanel.Dock="Top" x:Name="WizProgressSegments" Orientation="Horizontal" Margin="0,0,0,24"/>
            <TextBlock x:Name="WizSideLegend" DockPanel.Dock="Bottom" Style="{StaticResource Small}" Margin="0,16,0,0"
                       Text="Erledigte Schritte kannst du jederzeit wieder öffnen."/>
            <StackPanel x:Name="WizSidebar" Margin="-24,0,0,0"/>
          </DockPanel>
        </Border>
        <DockPanel Grid.Column="1">
          <Border DockPanel.Dock="Bottom" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,1,0,0" Padding="48,12">
            <DockPanel x:Name="WizNav">
              <Button x:Name="WizNext" DockPanel.Dock="Right" Content="Weiter" MinWidth="140" Margin="8,0,0,0"/>
              <Button x:Name="WizBack" DockPanel.Dock="Right" Content="Zurück" MinWidth="110" Margin="8,0,0,0"/>
              <Button x:Name="WizRecheck" DockPanel.Dock="Right" Content="Erneut prüfen" Margin="8,0,0,0" ToolTip="Diesen Schritt noch einmal prüfen, z. B. nachdem du etwas geändert hast"/>
              <Button x:Name="WizExit" DockPanel.Dock="Left" Content="Check beenden" Margin="0"/>
              <StackPanel Orientation="Horizontal" VerticalAlignment="Center" Margin="16,0,8,0">
                <ContentControl x:Name="WizNavIcon" Margin="0,0,8,0" VerticalAlignment="Center"/>
                <TextBlock x:Name="WizNavHint" Style="{StaticResource Small}" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" TextWrapping="NoWrap"/>
              </StackPanel>
            </DockPanel>
          </Border>
          <StackPanel DockPanel.Dock="Top" Margin="48,32,48,0" MaxWidth="1000" HorizontalAlignment="Left">
            <TextBlock x:Name="WizStepNo" Style="{StaticResource Label}" Foreground="{DynamicResource AccentText}"/>
            <TextBlock x:Name="WizTitle" Style="{StaticResource H2}" Margin="0,8,0,0"/>
            <TextBlock x:Name="WizSub" Style="{StaticResource Body}" Foreground="{DynamicResource InkMuted}" Margin="0,4,0,0"/>
            <Expander x:Name="WizIntroExp" Header="Worum geht es in diesem Schritt?" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock x:Name="WizIntro" Style="{StaticResource Small}" Foreground="{DynamicResource Ink}"/>
              </Border>
            </Expander>
            <Border x:Name="WizBusy" Style="{StaticResource Card}" Visibility="Collapsed" Margin="0,16,0,0">
              <DockPanel>
                <!-- Segmentierter Fortschrittsring (Motiv aus dem Logo) -->
                <Grid DockPanel.Dock="Left" Width="40" Height="40" Margin="0,0,16,0" VerticalAlignment="Center">
                  <Ellipse Stroke="{DynamicResource Line}" StrokeThickness="4" StrokeDashArray="1.6 0.9"/>
                  <Path Stroke="{DynamicResource Accent}" StrokeThickness="4" StrokeDashArray="1.6 0.9" Data="M20,2 A18,18 0 0 1 38,20" RenderTransformOrigin="0.5,0.5">
                    <Path.RenderTransform><RotateTransform Angle="0"/></Path.RenderTransform>
                    <Path.Triggers>
                      <EventTrigger RoutedEvent="FrameworkElement.Loaded">
                        <BeginStoryboard>
                          <Storyboard>
                            <DoubleAnimation Storyboard.TargetProperty="(UIElement.RenderTransform).(RotateTransform.Angle)" From="0" To="360" Duration="0:0:1.6" RepeatBehavior="Forever"/>
                          </Storyboard>
                        </BeginStoryboard>
                      </EventTrigger>
                    </Path.Triggers>
                  </Path>
                </Grid>
                <StackPanel VerticalAlignment="Center">
                  <TextBlock x:Name="WizBusyText" Style="{StaticResource Body}" FontWeight="Medium"/>
                  <TextBlock x:Name="WizBusyHint" Style="{StaticResource Small}" Margin="0,4,0,0" Text="TuneRig arbeitet. Du musst nichts tun."/>
                </StackPanel>
              </DockPanel>
            </Border>
          </StackPanel>
          <ScrollViewer x:Name="WizScroll" VerticalScrollBarVisibility="Auto" Margin="0,16,0,0">
            <StackPanel x:Name="WizContent" Margin="48,8,48,32" MaxWidth="1000" HorizontalAlignment="Left"/>
          </ScrollViewer>
        </DockPanel>
      </Grid>

      <!-- ===================== ALLE WERKZEUGE ===================== -->
      <Grid x:Name="ExpertPage" Visibility="Collapsed" Background="{DynamicResource Ground}">
    <TabControl x:Name="Tabs" Padding="32,24">

      <!-- ===================== ÜBERSICHT ===================== -->
      <TabItem Header="Übersicht">
        <DockPanel>
          <StackPanel DockPanel.Dock="Top">
            <TextBlock Style="{StaticResource H3}" Text="Systemanalyse"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Hier prüft TuneRig deinen ganzen PC auf einmal: Hardware, Treiber, Grafikkarten und Windows-Einstellungen. Die Analyse liest nur und ändert nichts. Die Statusspalte zeigt OK, Hinweis, Empfehlung oder Problem. In der Spalte »Was tun?« steht, wie du vorgehst. Einfacher geht es mit dem Regulären Check."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,16" Text="Die Analyse ändert nichts. Änderungen machst du in den einzelnen Reitern – vorher legt TuneRig immer einen Wiederherstellungspunkt an."/>
            <WrapPanel>
              <Button x:Name="BtnAnalyze" Style="{StaticResource Primary}" Content="JETZT ANALYSIEREN" ToolTip="Prüft alles auf einmal. Ändert nichts."/>
              <Button x:Name="BtnRestore" Content="Wiederherstellungspunkt anlegen" ToolTip="Speichert den aktuellen Zustand von Windows, damit sich Änderungen rückgängig machen lassen."/>
              <Button x:Name="BtnRestoreManage" Content="Wiederherstellungspunkte verwalten" ToolTip="Alle Wiederherstellungspunkte anzeigen und nicht mehr benötigte löschen"/>
              <Button x:Name="BtnRstrui" Content="Systemwiederherstellung öffnen"/>
            </WrapPanel>
          </StackPanel>
          <Grid Margin="0,16,0,0">
            <Grid.ColumnDefinitions><ColumnDefinition Width="320"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
            <Border Style="{StaticResource Card}" Margin="0,0,16,0">
              <ScrollViewer VerticalScrollBarVisibility="Auto">
                <StackPanel x:Name="SummaryPanel">
                  <TextBlock Style="{StaticResource Label}" Tag="caps" Text="Dein System"/>
                  <TextBlock Style="{StaticResource Small}" Text="Noch nicht analysiert." Margin="0,8,0,0"/>
                </StackPanel>
              </ScrollViewer>
            </Border>
            <DataGrid x:Name="GridFindings" Grid.Column="1" IsReadOnly="True">
              <DataGrid.Columns>
                <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="120" ElementStyle="{StaticResource LevelText}"/>
                <DataGridTextColumn Header="Bereich" Binding="{Binding B}" Width="100" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Ergebnis" Binding="{Binding C}" Width="230" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Details" Binding="{Binding D}" Width="*" ElementStyle="{StaticResource Wrap}"/>
                <DataGridTextColumn Header="Was tun?" Binding="{Binding E}" Width="*" ElementStyle="{StaticResource Wrap}"/>
              </DataGrid.Columns>
            </DataGrid>
          </Grid>
        </DockPanel>
      </TabItem>

      <!-- ===================== TREIBER ===================== -->
      <TabItem Header="Treiber">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="200"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Installierte Treiber"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Treiber sind kleine Programme, mit denen Windows deine Hardware steuert (Grafikkarte, Netzwerk, Sound …). Fehlende oder veraltete Treiber kosten Leistung oder verursachen Fehler. Beim Öffnen des Reiters prüft TuneRig alle Treiber automatisch – Probleme stehen oben. »Nach Updates suchen« fragt Windows Update nach neueren Treibern – installiert wird erst nach deiner Bestätigung. Für Grafikkarten ist die Software des Herstellers meist aktueller."/>
              </Border>
            </Expander>
            <Border Style="{StaticResource Card}" Margin="0,8,0,8">
              <DockPanel>
                <ContentControl x:Name="DriverWarnIcon" DockPanel.Dock="Left" Margin="0,0,12,0" VerticalAlignment="Top"/>
                <StackPanel>
                  <TextBlock Style="{StaticResource Label}" Foreground="{DynamicResource Warning}" Tag="caps" Text="Nur originale Treiber"/>
                  <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Margin="0,4,0,0" Text="Installiere Treiber nur über Windows Update oder direkt beim Hersteller (NVIDIA, AMD, Intel, PC- oder Mainboard-Hersteller). Treiber-Updater und Download-Seiten von Drittanbietern liefern oft falsche, veraltete oder veränderte Treiber – mit Leistungseinbußen, Abstürzen oder Schadsoftware als Folge."/>
                </StackPanel>
              </DockPanel>
            </Border>
            <TextBlock Style="{StaticResource Small}" Margin="0,0,0,12" Text="Problemgeräte stehen oben."/>
            <WrapPanel>
              <Button x:Name="BtnDrivers" Content="Erneut prüfen"/>
              <Button x:Name="BtnDevMgr" Content="Geräte-Manager öffnen"/>
              <TextBlock Style="{StaticResource Small}" Text="Hersteller-Software:" VerticalAlignment="Center" Margin="12,0,8,8"/>
              <Button x:Name="BtnNvidia" Content="NVIDIA App"/>
              <Button x:Name="BtnAmd" Content="AMD Software"/>
              <Button x:Name="BtnIntel" Content="Intel Driver &amp; Support Assistant"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridDrivers" Grid.Row="1" IsReadOnly="True" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="240" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Gerät" Binding="{Binding B}" Width="*"/>
              <DataGridTextColumn Header="Hardware" Binding="{Binding C}" Width="200"/>
              <DataGridTextColumn Header="Anbieter" Binding="{Binding D}" Width="150"/>
              <DataGridTextColumn Header="Version" Binding="{Binding E}" Width="130"/>
              <DataGridTextColumn Header="Datum" Binding="{Binding F}" Width="100"/>
            </DataGrid.Columns>
          </DataGrid>
          <StackPanel Grid.Row="2" Margin="0,24,0,8">
            <TextBlock Style="{StaticResource H3}" Text="Treiber-Updates über Windows Update"/>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnSearchUpdates" Content="Nach Updates suchen" ToolTip="Fragt Windows Update nach neueren Treibern (1–3 Minuten). Installiert noch nichts."/>
              <Button x:Name="BtnInstallUpdates" Style="{StaticResource Primary}" Content="JETZT INSTALLIEREN"/>
              <TextBlock Style="{StaticResource Small}" Text="Für Grafikkarten bietet die Software des Herstellers meist neuere Treiber." VerticalAlignment="Center" Margin="4,0,0,8"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridUpdates" Grid.Row="3">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Update" Binding="{Binding A}" Width="*" IsReadOnly="True"/>
              <DataGridTextColumn Header="Hersteller" Binding="{Binding B}" Width="160" IsReadOnly="True"/>
              <DataGridTextColumn Header="Klasse" Binding="{Binding C}" Width="120" IsReadOnly="True"/>
              <DataGridTextColumn Header="Datum" Binding="{Binding D}" Width="100" IsReadOnly="True"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <!-- ===================== LEISTUNG ===================== -->
      <TabItem Header="Leistung">
        <DockPanel>
          <StackPanel DockPanel.Dock="Top">
            <TextBlock Style="{StaticResource H3}" Text="Leistungsrelevante Windows-Einstellungen"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Windows ist ab Werk auf Stromsparen eingestellt. Hier siehst du, welche Einstellungen Leistung kosten. Angehakte Zeilen stellt »Jetzt optimieren« um – vorher legt TuneRig einen Wiederherstellungspunkt an. Rechts kannst du den Energiesparplan auch direkt wählen."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,12" Text="Angehakt ist alles, was nicht optimal ist. Optionale Einstellungen haben Nebenwirkungen – wähle sie bewusst aus."/>
            <WrapPanel>
              <Button x:Name="BtnTweaks" Content="Erneut prüfen"/>
              <Button x:Name="BtnApplyTweaks" Style="{StaticResource Primary}" Content="JETZT OPTIMIEREN" ToolTip="Ändert alle angehakten Einstellungen. Vorher wird ein Wiederherstellungspunkt angelegt."/>
              <TextBlock Style="{StaticResource Small}" Text="Energiesparplan:" VerticalAlignment="Center" Margin="16,0,8,8"/>
              <ComboBox x:Name="ComboPlans" Width="300" Margin="0,0,8,8" DisplayMemberPath="A"/>
              <Button x:Name="BtnSetPlan" Content="Aktivieren"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridTweaks" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Einstellung" Binding="{Binding A}" Width="250" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Status" Binding="{Binding B}" Width="140" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Aktuell" Binding="{Binding C}" Width="240" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Vorteil" Binding="{Binding D}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
            </DataGrid.Columns>
          </DataGrid>
        </DockPanel>
      </TabItem>

      <!-- ===================== GRAFIKKARTEN ===================== -->
      <TabItem Header="Grafikkarten">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Erkannte Grafikkarten"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Viele PCs und fast alle Gaming-Laptops haben zwei Grafikkarten: eine stromsparende (integriert) und eine leistungsstarke (dediziert). Windows entscheidet pro Programm, welche arbeitet – nicht immer richtig. Stell deine Spiele hier auf »Hohe Leistung«, dann nutzen sie immer die starke Karte."/>
              </Border>
            </Expander>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnGpu" Content="Erneut prüfen"/>
              <Button x:Name="BtnGfxSettings" Content="Windows-Grafikeinstellungen öffnen"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridGpus" Grid.Row="1" IsReadOnly="True" MaxHeight="150" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Grafikkarte" Binding="{Binding A}" Width="*"/>
              <DataGridTextColumn Header="Typ" Binding="{Binding B}" Width="200"/>
              <DataGridTextColumn Header="Speicher" Binding="{Binding C}" Width="100"/>
              <DataGridTextColumn Header="Treiber" Binding="{Binding D}" Width="140"/>
              <DataGridTextColumn Header="vom" Binding="{Binding E}" Width="100"/>
              <DataGridTextColumn Header="Monitor" Binding="{Binding F}" Width="200"/>
            </DataGrid.Columns>
          </DataGrid>
          <DataGrid x:Name="GridGpuFindings" Grid.Row="2" IsReadOnly="True" Margin="0,8,0,0" MaxHeight="140">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="120" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Ergebnis" Binding="{Binding C}" Width="260" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Details" Binding="{Binding D}" Width="*" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Was tun?" Binding="{Binding E}" Width="*" ElementStyle="{StaticResource Wrap}"/>
            </DataGrid.Columns>
          </DataGrid>
          <StackPanel Grid.Row="3" Margin="0,24,0,8">
            <TextBlock Style="{StaticResource H3}" Text="Spiele: Welche Grafikkarte arbeitet?"/>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,12" Text="Gefunden werden Spiele aus Steam, Epic Games und GOG. Mit »Hohe Leistung« startet Windows das Spiel immer auf der dedizierten Grafikkarte. Andere Spiele fügst du über »Programm hinzufügen« hinzu."/>
            <WrapPanel>
              <Button x:Name="BtnGames" Content="Spiele suchen"/>
              <Button x:Name="BtnAddGame" Content="Programm hinzufügen …"/>
              <Button x:Name="BtnHighPerf" Style="{StaticResource Primary}" Content="JETZT UMSTELLEN" ToolTip="Windows startet die angehakten Spiele immer auf der leistungsstarken Grafikkarte."/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridGames" Grid.Row="4">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Spiel" Binding="{Binding A}" Width="240" IsReadOnly="True"/>
              <DataGridTextColumn Header="Quelle" Binding="{Binding B}" Width="100" IsReadOnly="True"/>
              <DataGridTextColumn Header="Grafik" Binding="{Binding C}" Width="170" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Programmdatei" Binding="{Binding D}" Width="*" IsReadOnly="True"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <!-- ===================== BEREINIGUNG ===================== -->
      <TabItem Header="Bereinigung">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Windows-Bereinigung"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Windows und Programme legen ständig Zwischendateien an, die später niemand mehr braucht. Beim Öffnen des Reiters berechnet TuneRig automatisch, wie viel Platz frei werden kann; »Jetzt bereinigen« löscht diese Dateien. Deine persönlichen Dateien sind nie betroffen. Die Junk-Dateien-Suche unten durchsucht alle Laufwerke nach typischem Datenmüll und verschiebt ihn in den Papierkorb."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,12" Text="Entfernt nur Dateien, die Windows und Programme automatisch neu anlegen. Persönliche Dateien, Passwörter und Browser-Verlauf bleiben unangetastet."/>
            <WrapPanel>
              <Button x:Name="BtnCleanScan" Content="Neu berechnen" ToolTip="Berechnet, wie viel Platz frei werden kann. Löscht noch nichts."/>
              <Button x:Name="BtnCleanRun" Style="{StaticResource Primary}" Content="JETZT BEREINIGEN"/>
              <TextBlock x:Name="CleanTotal" Style="{StaticResource Metric}" FontSize="14" LineHeight="20" VerticalAlignment="Center" Margin="8,0,0,8"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridClean" Grid.Row="1" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Kategorie" Binding="{Binding A}" Width="300" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Größe" Binding="{Binding B}" Width="180" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Beschreibung" Binding="{Binding C}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
            </DataGrid.Columns>
          </DataGrid>
          <StackPanel Grid.Row="2" Margin="0,24,0,8">
            <TextBlock Style="{StaticResource H3}" Text="Junk-Dateien auf allen Laufwerken"/>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,12" Text="Sucht typischen Datenmüll (*.tmp, *.chk, *.dmp, *._mp, Thumbs.db …), älter als 7 Tage. System- und Programmordner bleiben außen vor. Gelöschte Dateien landen im Papierkorb."/>
            <WrapPanel>
              <Button x:Name="BtnJunkScan" Content="Junk-Dateien suchen" ToolTip="Durchsucht alle Laufwerke. Kann einige Minuten dauern und lässt sich abbrechen."/>
              <Button x:Name="BtnJunkToggle" Content="Alle / keine"/>
              <Button x:Name="BtnJunkDelete" Content="In den Papierkorb verschieben"/>
              <TextBlock x:Name="JunkTotal" Style="{StaticResource Metric}" FontSize="14" LineHeight="20" VerticalAlignment="Center" Margin="8,0,0,8"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridJunk" Grid.Row="3">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Datei" Binding="{Binding A}" Width="*" IsReadOnly="True"/>
              <DataGridTextColumn Header="Größe" Binding="{Binding B}" Width="110" IsReadOnly="True" SortMemberPath="N1"/>
              <DataGridTextColumn Header="Geändert" Binding="{Binding C}" Width="110" IsReadOnly="True"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <!-- ===================== SPEICHERPLATZ ===================== -->
      <TabItem Header="Speicherplatz">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
          <StackPanel>
            <DockPanel>
              <TextBlock DockPanel.Dock="Right" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" Text="Liest nur – gelöscht wird nur, was du selbst auswählst."/>
              <TextBlock Style="{StaticResource H3}" Text="Was belegt deinen Speicherplatz?"/>
            </DockPanel>
            <WrapPanel x:Name="StorageDrives" Margin="0,12,0,0"/>
            <StackPanel x:Name="StorageProgress" Visibility="Collapsed" Margin="0,4,0,0">
              <ProgressBar x:Name="StorageProgressBar" Height="6" Minimum="0" Maximum="100" IsIndeterminate="False"/>
              <TextBlock x:Name="StorageProgressText" FontFamily="{DynamicResource FontMono}" FontSize="12" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,0" TextTrimming="CharacterEllipsis"/>
            </StackPanel>
          </StackPanel>

          <!-- Vor der ersten Analyse -->
          <Border x:Name="StorageEmpty" Grid.Row="1" Style="{StaticResource Card}" Margin="0,8,0,0" Padding="32">
            <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" MaxWidth="560">
              <ContentControl x:Name="StorageEmptyIcon" HorizontalAlignment="Center"/>
              <TextBlock Style="{StaticResource Body}" FontWeight="SemiBold" HorizontalAlignment="Center" Margin="0,16,0,8" Text="Klick oben auf ein Laufwerk, um es zu analysieren."/>
              <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" TextAlignment="Center" TextWrapping="Wrap" Text="Danach siehst du eine Rangliste deiner größten Spiele, Programme, Ordner und Dateien – mit Größe, zuletzt gespielt und dem passenden Button zum Entfernen. Die Analyse dauert je nach Laufwerk 10 Sekunden bis wenige Minuten und lässt sich abbrechen."/>
            </StackPanel>
          </Border>

          <!-- Ergebnis -->
          <Border x:Name="StorageResult" Grid.Row="1" Style="{StaticResource Card}" Margin="0,8,0,0" Padding="0" Visibility="Collapsed">
            <DockPanel>
              <Border DockPanel.Dock="Top" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Padding="20,12,12,0">
                <DockPanel>
                  <StackPanel DockPanel.Dock="Right" Orientation="Horizontal" VerticalAlignment="Bottom">
                    <Button x:Name="BtnStorageViewBig" Style="{StaticResource TopNav}" Content="WAS DU LÖSCHEN KANNST" Height="40"/>
                    <Button x:Name="BtnStorageViewTree" Style="{StaticResource TopNav}" Content="ORDNER" Height="40"/>
                    <Button x:Name="BtnStorageViewTypes" Style="{StaticResource TopNav}" Content="DATEITYPEN" Height="40"/>
                  </StackPanel>
                  <StackPanel Margin="0,0,16,12">
                    <TextBlock x:Name="StorageHeadline" Style="{StaticResource Metric}" FontSize="18" LineHeight="24"/>
                    <TextBlock x:Name="StorageSubline" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" TextWrapping="Wrap" Margin="0,4,0,0"/>
                  </StackPanel>
                </DockPanel>
              </Border>
              <Grid>
                <!-- Ansicht 1: Rangliste -->
                <ScrollViewer x:Name="StorageViewBig" VerticalScrollBarVisibility="Auto" Padding="12,8,12,12">
                  <StackPanel x:Name="StorageBig"/>
                </ScrollViewer>
                <!-- Ansicht 2: Ordnerbaum -->
                <DockPanel x:Name="StorageViewTree" Visibility="Collapsed" Margin="20,12,12,12">
                  <StackPanel DockPanel.Dock="Top">
                    <DockPanel>
                      <StackPanel DockPanel.Dock="Right" Orientation="Horizontal">
                        <Button x:Name="BtnStorageUp" Content="Eine Ebene höher" MinHeight="32" Padding="12,4,12,5" Margin="8,0,0,0"/>
                        <Button x:Name="BtnStorageOpen" Content="Im Explorer öffnen" MinHeight="32" Padding="12,4,12,5" Margin="8,0,0,0"/>
                      </StackPanel>
                      <WrapPanel x:Name="StorageCrumbs" VerticalAlignment="Center"/>
                    </DockPanel>
                    <TextBlock x:Name="StorageFolderInfo" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" Margin="0,8,0,8"/>
                    <Border Height="1" Background="{DynamicResource Line}"/>
                  </StackPanel>
                  <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="0,4,0,0">
                    <StackPanel x:Name="StorageList"/>
                  </ScrollViewer>
                </DockPanel>
                <!-- Ansicht 3: Dateitypen -->
                <ScrollViewer x:Name="StorageViewTypes" Visibility="Collapsed" VerticalScrollBarVisibility="Auto" Padding="20,12,12,12">
                  <StackPanel x:Name="StorageTypes"/>
                </ScrollViewer>
              </Grid>
            </DockPanel>
          </Border>
        </Grid>
      </TabItem>

      <!-- ===================== DEINSTALLATION ===================== -->
      <TabItem Header="Deinstallation">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="3*"/><RowDefinition Height="Auto"/><RowDefinition Height="2*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Programme ohne Rückstände entfernen"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Normale Deinstallationen lassen oft Ordner und Registry-Einträge zurück. So gehst du vor: 1. Programm in der Liste anklicken. 2. »Jetzt deinstallieren« klicken und dem Fenster des Programms folgen. 3. Unten erscheinen die gefundenen Reste. 4. Liste prüfen und »Reste löschen« klicken. »Erzwungen entfernen« ist nur für Programme gedacht, deren Deinstallation nicht funktioniert."/>
              </Border>
            </Expander>
            <TextBlock Style="{StaticResource Small}" Margin="0,8,0,12" Text="Ablauf: Wiederherstellungspunkt, Deinstallationsprogramm des Herstellers, Suche nach Resten, du wählst aus. Registry-Einträge werden vorher gesichert, Dateien landen im Papierkorb."/>
            <DockPanel>
              <WrapPanel DockPanel.Dock="Right">
                <Button x:Name="BtnPrograms" Content="Liste aktualisieren"/>
                <Button x:Name="BtnOrphanScan" Content="Reste alter Programme suchen" ToolTip="Sucht auf allen Laufwerken nach Resten von Programmen und Spielen, die nicht mehr installiert sind – nur mit Beleg."/>
                <Button x:Name="BtnForce" Content="Erzwungen entfernen" ToolTip="Für Programme, deren Deinstallationsprogramm fehlt oder nicht funktioniert"/>
                <Button x:Name="BtnUninstall" Style="{StaticResource Primary}" Content="JETZT DEINSTALLIEREN" Margin="0,0,0,8" ToolTip="Startet das Deinstallationsprogramm des Herstellers und sucht danach nach Resten."/>
              </WrapPanel>
              <TextBlock Style="{StaticResource Small}" Text="Suchen:" VerticalAlignment="Center" Margin="0,0,8,8"/>
              <TextBox x:Name="TxtSearch" Width="240" Margin="0,0,0,8"/>
              <CheckBox x:Name="ChkStore" Content="Store-Apps anzeigen" VerticalAlignment="Center" Margin="16,0,0,8"/>
              <TextBlock x:Name="ProgramCount" Style="{StaticResource Small}" VerticalAlignment="Center" Margin="16,0,0,8"/>
            </DockPanel>
            <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Padding="16,10" Margin="0,4,0,0">
              <DockPanel>
                <ContentControl x:Name="ProgramSelectedIcon" DockPanel.Dock="Left" Margin="0,0,12,0" VerticalAlignment="Center"/>
                <TextBlock x:Name="ProgramSelected" Style="{StaticResource Small}" Foreground="{DynamicResource InkMuted}" VerticalAlignment="Center" TextTrimming="CharacterEllipsis" Text="Klick ein Programm in der Liste an."/>
              </DockPanel>
            </Border>
          </StackPanel>
          <DataGrid x:Name="GridPrograms" Grid.Row="1" IsReadOnly="True" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTextColumn Header="Programm" Binding="{Binding A}" Width="*"/>
              <DataGridTextColumn Header="Version" Binding="{Binding B}" Width="120"/>
              <DataGridTextColumn Header="Hersteller" Binding="{Binding C}" Width="200"/>
              <DataGridTextColumn Header="Installiert" Binding="{Binding D}" Width="110"/>
              <DataGridTextColumn Header="Größe" Binding="{Binding E}" Width="100" SortMemberPath="N1"/>
              <DataGridTextColumn Header="Typ" Binding="{Binding F}" Width="90"/>
            </DataGrid.Columns>
          </DataGrid>
          <StackPanel Grid.Row="2" Margin="0,24,0,8">
            <TextBlock x:Name="LeftoverHeading" Style="{StaticResource H3}" Text="Gefundene Reste"/>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnLoAll" Content="Alle auswählen"/>
              <Button x:Name="BtnLoNone" Content="Keine auswählen"/>
              <Button x:Name="BtnLoDelete" Content="Ausgewählte Reste löschen"/>
              <Button x:Name="BtnLoOpen" Content="Speicherort öffnen" ToolTip="Öffnet den markierten Eintrag im Explorer bzw. im Registrierungs-Editor (auch per Doppelklick)."/>
              <Button x:Name="BtnLoRescan" Content="Erneut nach Resten suchen" ToolTip="Sucht noch einmal nach Resten des zuletzt deinstallierten Programms – z. B. wenn das Deinstallationsprogramm länger gebraucht hat."/>
              <TextBlock Style="{StaticResource Small}" Text="Angezeigt wird nur, was TuneRig vor der Deinstallation nachweislich dem Programm zuordnen konnte – nie nach ähnlichen Namen. Die Spalte »Beleg« zeigt, woher TuneRig das weiß." VerticalAlignment="Center" TextWrapping="Wrap" Margin="4,0,0,8"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridLeftovers" Grid.Row="3">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Status" Binding="{Binding A}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Typ" Binding="{Binding B}" Width="150" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Pfad" Binding="{Binding C}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Beleg" Binding="{Binding D}" Width="320" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Größe" Binding="{Binding E}" Width="90" IsReadOnly="True" SortMemberPath="N1"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>

      <!-- ===================== GAMING ===================== -->
      <TabItem Header="Gaming">
        <Grid>
          <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="3*"/><RowDefinition Height="Auto"/><RowDefinition Height="2*"/></Grid.RowDefinitions>
          <StackPanel>
            <TextBlock Style="{StaticResource H3}" Text="Gaming-Optimierungen"/>
            <Expander Header="Erklärung für Einsteiger" Margin="0,8,0,0">
              <Border Style="{StaticResource Card}" Background="{DynamicResource SurfaceRaised}" Margin="0,4,0,0">
                <TextBlock Style="{StaticResource Small}" Foreground="{DynamicResource Ink}" Text="Alle Gaming-Optimierungen in einer Liste. »Empfohlen« ist unbedenklich. »Optional« hat eine Nebenwirkung (Spalte rechts), »Experimentell« eine umstrittene Wirkung. Haken setzen und »Jetzt anwenden« klicken. »Zurücksetzen« stellt den Windows-Standard wieder her. Einfacher geht es mit dem Performance Boost auf der Startseite."/>
              </Border>
            </Expander>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnGamingCheck" Content="Erneut prüfen"/>
              <Button x:Name="BtnGamingApply" Style="{StaticResource Primary}" Content="JETZT ANWENDEN"/>
              <Button x:Name="BtnGamingRevert" Content="Ausgewählte zurücksetzen"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridGaming" Grid.Row="1" Margin="0,8,0,0">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Bereich" Binding="{Binding A}" Width="120" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Einstellung" Binding="{Binding B}" Width="220" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Status" Binding="{Binding C}" Width="140" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Aktuell" Binding="{Binding D}" Width="200" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Empfohlen" Binding="{Binding E}" Width="170" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
              <DataGridTextColumn Header="Wirkung / Nebenwirkung" Binding="{Binding F}" Width="*" IsReadOnly="True" ElementStyle="{StaticResource Wrap}"/>
            </DataGrid.Columns>
          </DataGrid>
          <StackPanel Grid.Row="2" Margin="0,24,0,8">
            <TextBlock Style="{StaticResource H3}" Text="Autostart-Programme"/>
            <WrapPanel Margin="0,12,0,0">
              <Button x:Name="BtnStartupCheck" Content="Erneut prüfen"/>
              <Button x:Name="BtnStartupDisable" Content="Ausgewählte abschalten"/>
              <Button x:Name="BtnStartupEnable" Content="Ausgewählte einschalten"/>
            </WrapPanel>
          </StackPanel>
          <DataGrid x:Name="GridStartup" Grid.Row="3">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="" CellTemplate="{StaticResource Check}" Width="44"/>
              <DataGridTextColumn Header="Programm" Binding="{Binding A}" Width="200" IsReadOnly="True"/>
              <DataGridTextColumn Header="Status" Binding="{Binding B}" Width="130" IsReadOnly="True" ElementStyle="{StaticResource LevelText}"/>
              <DataGridTextColumn Header="Empfehlung" Binding="{Binding C}" Width="190" IsReadOnly="True"/>
              <DataGridTextColumn Header="Für" Binding="{Binding D}" Width="140" IsReadOnly="True"/>
              <DataGridTextColumn Header="Befehl" Binding="{Binding E}" Width="*" IsReadOnly="True"/>
            </DataGrid.Columns>
          </DataGrid>
        </Grid>
      </TabItem>
    </TabControl>
      </Grid>
    </Grid>
  </DockPanel>
</Window>
'@

$window = [Windows.Markup.XamlReader]::Parse($xaml)
Set-SplashProgress 0.3 'Lade Oberfläche …'
# Fenster an kleine Bildschirme anpassen (z. B. Laptops mit 1366 x 768)
$wa = [Windows.SystemParameters]::WorkArea
$window.Width = [Math]::Min(1240, $wa.Width * 0.95); $window.Height = [Math]::Min(820, $wa.Height * 0.95)
$window.MinWidth = [Math]::Min(1120, $wa.Width * 0.95); $window.MinHeight = [Math]::Min(600, $wa.Height * 0.95)
$ui = @{}
foreach ($n in [regex]::Matches($xaml, 'x:Name="(\w+)"') | ForEach-Object { $_.Groups[1].Value }) { $ui[$n] = $window.FindName($n) }
Set-WindowBranding $window
Set-CapsLabels $window
$ui.SafetyIcon.Content = New-LineIcon 'shield' 'success' 24
# Startseite: Symbole der drei Checks und Leistungsgewinn als Segmentanzeige
# Jeder Check hat eine eigene Kennfarbe: Regulär neutral, Boost Signal-Orange, Overdrive Warnfarbe (Risiko)
$ui.CardGuidedIcon.Content = New-LineIcon 'check' 'ink' 22
$ui.CardBoostIcon.Content = New-LineIcon 'flame' 'accent' 24
$ui.NavBoostIcon.Content = New-LineIcon 'flame' 'accent' 14
$ui.NavGuidedIcon.Content = New-LineIcon 'check' 'ink' 14
# Buttons der Karten: Text mit Pfeil (führt zum Check)
foreach ($b in @(@($ui.BtnStartGuided, 'Regulären Check starten'), @($ui.BtnStartGaming, 'Performance Boost starten'), @($ui.BtnStartOverdrive, 'Overdrive öffnen'), @($ui.BtnStartExpert, 'Alle Werkzeuge öffnen'))) {
    $sp = New-Object Windows.Controls.StackPanel; $sp.Orientation = 'Horizontal'
    $t = New-Object Windows.Controls.TextBlock; $t.Text = $b[1]; $t.VerticalAlignment = 'Center'; [void]$sp.Children.Add($t)
    $a = New-LineIcon 'arrow' 'ink' 16; $a.Margin = New-Object Windows.Thickness(10, 0, 0, 0); $a.VerticalAlignment = 'Center'; [void]$sp.Children.Add($a)
    $b[0].Content = $sp
    [Windows.Automation.AutomationProperties]::SetName($b[0], $b[1])
}
$ui.NavOverdriveIcon.Content = New-LineIcon 'bolt' 'warning' 14
$ui.CardOverdriveIcon.Content = New-LineIcon 'bolt' 'warning' 22
$ui.CardExpertIcon.Content = New-LineIcon 'grid' 'ink-muted' 24
$ui.GainGuided.Content = New-SegmentMeter 1 3 'ink'
$ui.GainBoost.Content = New-SegmentMeter 2 3 'accent'
$ui.GainOverdrive.Content = New-SegmentMeter 3 3 'warning'
$ui.DriverWarnIcon.Content = New-LineIcon 'warning' 'warning' 24
$ui.BtnTheme.Content = if ($script:ThemeMode -eq 'dark') { 'Hell' } else { 'Dunkel' }
$ui.BtnTheme.Add_Click({
    Set-ThemeMode $(if ($script:ThemeMode -eq 'dark') { 'light' } else { 'dark' })
    Update-TitleBar $window
    $ui.BtnTheme.Content = if ($script:ThemeMode -eq 'dark') { 'Hell' } else { 'Dunkel' }
    Save-AppSettings $(if ($script:State.Page -ne 'welcome') { $script:State.Page } else { (Get-AppSettings).LastMode })
})

# ============================================================================
#  Zustand und Hilfsfunktionen der Oberfläche
# ============================================================================
$script:Sync = [hashtable]::Synchronized(@{ Status = '' })
$script:Job = $null
$script:State = @{ TweakBefore = @{}; IsLaptop = (Test-IsLaptop); LastRestore = $null; Programs = @(); Current = $null; Then = $null; Pending = $null; GpuCount = 0; Page = 'welcome'; LoadId = ''; Previous = '' }

function Set-Status([string]$t) { $script:Sync.Status = $t; $ui.StatusText.Text = $t }
function Show-Info([string]$t, [string]$title = 'TuneRig') { [void][Windows.MessageBox]::Show($window, $t, $title, 'OK', 'Information') }
function Show-Error([string]$t) { [void][Windows.MessageBox]::Show($window, $t, 'Fehler', 'OK', 'Error') }
function Confirm-Action([string]$t, [string]$title = 'Bitte bestätigen') { [Windows.MessageBox]::Show($window, $t, $title, 'YesNo', 'Question') -eq 'Yes' }

function New-Row {
    param($A = '', $B = '', $C = '', $D = '', $E = '', $F = '', [int]$Level = 0, [bool]$Selected = $false, $Tag = $null, [long]$N1 = 0)
    $r = New-Object PCO.Row
    $r.A = [string]$A; $r.B = [string]$B; $r.C = [string]$C; $r.D = [string]$D; $r.E = [string]$E; $r.F = [string]$F
    $r.Level = $Level; $r.IsSelected = $Selected; $r.Tag = $Tag; $r.N1 = $N1
    return $r
}

function Set-Items($grid, $rows) {
    $c = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
    foreach ($r in @($rows)) { if ($null -ne $r) { $c.Add($r) } }
    $grid.ItemsSource = $c
}

function Get-Rows($grid) { if ($grid.ItemsSource) { @($grid.ItemsSource) } else { @() } }

function Get-LevelText([int]$l) { switch ($l) { 0 { 'OK' } 1 { 'Hinweis' } 2 { 'Empfehlung' } default { 'Problem' } } }

function ConvertTo-FindingRows($findings) {
    @($findings) | Where-Object { $_ } | Sort-Object @{ e = { $_.Level }; Descending = $true }, Category |
        ForEach-Object { New-Row -A (Get-LevelText $_.Level) -B $_.Category -C $_.Title -D $_.Detail -E $(if ($_.Do) { $_.Do + $(if ($_.Benefit) { '  →  ' + $_.Benefit } else { '' }) } else { $_.Help }) -Level $_.Level }
}

function Set-Busy([bool]$busy, [bool]$cancellable = $false) {
    $ui.Tabs.IsEnabled = -not $busy
    foreach ($n in 'WizNav', 'WizSidebar', 'WizContent', 'HeaderNav', 'WelcomePage') { $ui[$n].IsEnabled = -not $busy }
    $ui.WizBusy.Visibility = if ($busy -and $script:State.Page -eq 'wizard') { 'Visible' } else { 'Collapsed' }
    $ui.WizBusyText.Text = $script:Sync.Status
    $ui.BusyBar.Visibility = if ($busy) { 'Visible' } else { 'Collapsed' }
    $ui.BtnCancel.Visibility = if ($busy -and $cancellable) { 'Visible' } else { 'Collapsed' }
}

# Führt Kernfunktionen in einem Hintergrund-Thread aus, damit das Fenster bedienbar bleibt.
# Im Skript stehen alle Funktionen aus Core.ps1 und die Argumente als $A[0], $A[1] ... bereit.
function Start-Work {
    param([string]$Status, [scriptblock]$Script, [object[]]$Arguments = @(), [scriptblock]$OnDone, [scriptblock]$OnCancel, [switch]$Cancellable)
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $rs = [runspacefactory]::CreateRunspace()
    $rs.ApartmentState = 'STA'; $rs.ThreadOptions = 'ReuseThread'; $rs.Open()
    $rs.SessionStateProxy.SetVariable('Sync', $script:Sync)
    $rs.SessionStateProxy.SetVariable('A', $Arguments)
    $ps = [powershell]::Create(); $ps.Runspace = $rs
    [void]$ps.AddScript($script:CoreText + "`r`n" + $Script.ToString())
    Set-Status $Status
    $script:Job = @{ PS = $ps; Handle = $ps.BeginInvoke(); OnDone = $OnDone; OnCancel = $OnCancel; Cancelled = $false }
    Set-Busy $true $Cancellable.IsPresent
}

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(250)
$timer.Add_Tick({
    if ($ui.StatusText.Text -ne $script:Sync.Status) { $ui.StatusText.Text = $script:Sync.Status; $ui.WizBusyText.Text = $script:Sync.Status }
    $j = $script:Job
    if (-not $j -or -not $j.Handle.IsCompleted) { return }

    $result = $null; $err = $null
    try { $result = $j.PS.EndInvoke($j.Handle) }
    catch { if (-not $j.Cancelled) { $err = if ($_.Exception.InnerException) { $_.Exception.InnerException.Message } else { $_.Exception.Message } } }
    try { $j.PS.Runspace.Close(); $j.PS.Dispose() } catch {}
    $script:Job = $null
    Set-Busy $false

    if ($j.Cancelled) {
        if ($j.OnCancel) { & $j.OnCancel } else { Set-Status 'Abgebrochen.' }
        return
    }
    if ($err) { Set-Status "Fehler: $err"; Show-Error $err; return }
    if ($j.OnDone) {
        try { & $j.OnDone @($result) }
        catch { Set-Status ('Fehler: ' + $_.Exception.Message); Show-Error ($_.Exception.Message + "`n`n" + $_.ScriptStackTrace) }
    }
})
$timer.Start()

$ui.BtnCancel.Add_Click({
    if ($script:Job) { $script:Job.Cancelled = $true; [TuneRig.DiskScan]::Cancel = $true; [void]$script:Job.PS.BeginStop($null, $null); Set-Status 'Breche ab ...' }
})

# Wiederherstellungspunkt vor Änderungen; scheitert er, wird gefragt, ob trotzdem fortgefahren wird.
function Invoke-WithRestorePoint([string]$Description, [scriptblock]$Then) {
    $script:State.Then = $Then
    if ($script:State.LastRestore -and ((Get-Date) - $script:State.LastRestore).TotalMinutes -lt 30) { & $Then; return }
    Start-Work -Status 'Erstelle Wiederherstellungspunkt ... (kann bis zu einer Minute dauern)' -Arguments @($Description) -Script { New-PCORestorePoint $A[0] } -OnDone {
        param($r)
        $res = @($r)[-1]
        if ($res.Ok) {
            $script:State.LastRestore = Get-Date
            Add-WizLog 'Wiederherstellungspunkt erstellt'
            Add-WizChange 'Windows-Sicherung' 'Wiederherstellungspunkt erstellt' 'Alle Änderungen lassen sich rückgängig machen.' -1
            Set-Status $res.Message
            & $script:State.Then
        } elseif (Confirm-Action ($res.Message + "`n`nTrotzdem ohne Wiederherstellungspunkt fortfahren?") 'Wiederherstellungspunkt') {
            & $script:State.Then
        } else { Set-Status 'Abgebrochen.' }
    }
}

function Open-Target([string]$t) { try { Start-Process $t } catch { Show-Error $_.Exception.Message } }

# ============================================================================
#  Anzeige-Funktionen
# ============================================================================
function Show-Summary($summary) {
    $p = $ui.SummaryPanel; $p.Children.Clear()
    [void]$p.Children.Add((New-Label 'Dein System'))
    foreach ($s in @($summary)) {
        $l = New-Label $s.Label; $l.Margin = New-Object Windows.Thickness(0, 16, 0, 4); [void]$p.Children.Add($l)
        $v = New-Object Windows.Controls.TextBlock; $v.Text = $(if ($s.Value) { [string]$s.Value } else { '-' }); $v.TextWrapping = [Windows.TextWrapping]::Wrap
        Set-TypeRole $v 'small'; Set-ThemeRef $v Foreground 'ink'
        [void]$p.Children.Add($v)
    }
}

function Show-Drivers($drivers) {
    Set-Items $ui.GridDrivers (@($drivers) | ForEach-Object { New-Row -A $_.Status -B $_.Device -C $_.Category -D $_.Provider -E $_.Version -F $_.Date -Level $_.Level })
}

function Show-Gpu($gpu) {
    $script:State.GpuCount = @($gpu.Gpus).Count
    Set-Items $ui.GridGpus (@($gpu.Gpus) | ForEach-Object {
        New-Row -A $_.Name -B $(if ($_.Discrete) { 'Dediziert (leistungsstark)' } else { 'Integriert (stromsparend)' }) -C $(if ($_.Vram -gt 0) { Format-Bytes $_.Vram } else { '-' }) `
                -D $_.Driver -E $_.DriverDate -F $(if ($_.Display) { "Ja ($($_.Resolution))" } else { 'Nein' })
    })
    Set-Items $ui.GridGpuFindings (ConvertTo-FindingRows $gpu.Findings)
}

# Merkt sich beim ersten Prüfen den ursprünglichen Zustand jeder Einstellung (für "vorher / jetzt")
function Register-TweakBefore($tweaks) {
    foreach ($t in @($tweaks)) { if ($t -and -not $script:State.TweakBefore.ContainsKey($t.Id)) { $script:State.TweakBefore[$t.Id] = $t.State } }
}
function Get-TweakBefore($t) {
    $b = $script:State.TweakBefore[$t.Id]
    if ($b -and $b -ne $t.State) { return $b } else { return $null }
}

function Get-TweakRow($t) {
    $lvl = if ($t.Optimal) { 0 } elseif ($t.Optional) { 1 } else { 2 }
    $txt = if ($t.Optimal) { 'Optimal' } elseif ($t.Optional) { 'Optional' } else { 'Nicht optimal' }
    $before = Get-TweakBefore $t
    $state = if ($before) { "Jetzt: $($t.State)   (vorher: $before)" } elseif (-not $t.Optimal -and $t.Target) { "$($t.State)   →  empfohlen: $($t.Target)" } else { $t.State }
    New-Row -A $t.Title -B $txt -C $state -D $(if ($t.Benefit) { $t.Benefit } else { $t.Desc }) -Level $lvl -Selected (-not $t.Optimal -and -not $t.Optional) -Tag $t
}

function Show-Tweaks($tweaks, $plans) {
    Register-TweakBefore $tweaks
    Set-Items $ui.GridTweaks (@($tweaks) | ForEach-Object { Get-TweakRow $_ })
    $planRows = @($plans) | ForEach-Object { New-Row -A $(if ($_.Active) { "$($_.Name) (aktiv)" } else { $_.Name }) -Tag $_.Guid -Selected $_.Active }
    $ui.ComboPlans.ItemsSource = @($planRows)
    $ui.ComboPlans.SelectedItem = @($planRows) | Where-Object { $_.IsSelected } | Select-Object -First 1
}

function Show-Games($games) {
    Set-Items $ui.GridGames (@($games) | ForEach-Object {
        $high = $_.Preference -eq 'Hohe Leistung'
        New-Row -A $_.Name -B $_.Source -C $_.Preference -D $_.Exe -Level $(if ($high) { 0 } else { 2 }) -Selected (-not $high) -Tag $_.Exe
    })
}

# ============================================================================
#  Übersicht
# ============================================================================
$ui.BtnAnalyze.Add_Click({
    Start-Work -Status 'Analysiere System ...' -Script {
        Report 'Lese Hardware-Informationen ...'; $sys = Get-SystemAnalysis
        Report 'Prüfe Treiber ... (dauert etwas)'; $drv = Get-DriverAnalysis
        Report 'Prüfe Grafikkarten ...'; $gpu = Get-GpuAnalysis $sys.IsLaptop
        Report 'Prüfe Energie- und Windows-Einstellungen ...'; $tw = @(Get-Tweaks $sys.IsLaptop)
        Report 'Suche Spiele ...'; $games = @(Find-Games)
        [pscustomobject]@{ Sys = $sys; Drv = $drv; Gpu = $gpu; Tweaks = $tw; Games = $games; Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r)
        $r = @($r)[-1]
        $script:State.IsLaptop = $r.Sys.IsLaptop
        Show-Summary $r.Sys.Summary
        Show-Drivers $r.Drv.Drivers
        Show-Gpu $r.Gpu
        Show-Tweaks $r.Tweaks $r.Plans
        Show-Games $r.Games

        $all = @()
        $all += @($r.Sys.Findings); $all += @($r.Drv.Findings); $all += @($r.Gpu.Findings)
        foreach ($t in @($r.Tweaks | Where-Object { -not $_.Optional })) {
            $all += New-Finding $(if ($t.Optimal) { 0 } else { 2 }) 'Einstellungen' $t.Name $(if ($t.Optimal) { $t.State } else { "Aktuell: $($t.State). $($t.Desc)" })
        }
        $notHigh = @($r.Games | Where-Object { $_.Preference -ne 'Hohe Leistung' }).Count
        if (@($r.Gpu.Gpus | Where-Object { $_.Discrete }).Count -ge 1 -and @($r.Gpu.Gpus).Count -gt 1 -and $notHigh -gt 0) {
            $all += New-Finding 2 'Grafik' "$notHigh Spiel(e) nicht auf 'Hohe Leistung' eingestellt" 'Diese Spiele könnten auf der schwächeren, integrierten Grafik laufen. Im Reiter Grafikkarten mit einem Klick ändern.'
        }
        Set-Items $ui.GridFindings (ConvertTo-FindingRows $all)

        $p = @($all | Where-Object { $_.Level -eq 3 }).Count; $w = @($all | Where-Object { $_.Level -eq 2 }).Count
        if ($p + $w -eq 0) { Set-Status 'Analyse abgeschlossen – dein System ist gut eingestellt.' }
        else { Set-Status "Analyse abgeschlossen: $p Problem(e), $w Empfehlung(en). Details in den einzelnen Reitern." }
    }
})

$ui.BtnRestore.Add_Click({
    Start-Work -Status 'Erstelle Wiederherstellungspunkt ...' -Script { New-PCORestorePoint 'Manuell' } -OnDone {
        param($r) $res = @($r)[-1]
        if ($res.Ok) { $script:State.LastRestore = Get-Date }
        Set-Status $res.Message; Show-Info $res.Message
    }
})
$ui.BtnRstrui.Add_Click({ Open-Target 'rstrui.exe' })
$ui.BtnRestoreManage.Add_Click({ Show-RestorePointManager })

# ============================================================================
#  Treiber
# ============================================================================
$ui.BtnDrivers.Add_Click({
    Start-Work -Status 'Prüfe Treiber ...' -Script { Get-DriverAnalysis } -OnDone {
        param($r) $r = @($r)[-1]
        Show-Drivers $r.Drivers
        $n = @($r.Findings | Where-Object { $_.Level -ge 2 }).Count
        Set-Status $(if ($n -eq 0) { 'Keine Treiberprobleme gefunden.' } else { "$n Treiberproblem(e) gefunden." })
    }
})
$ui.BtnDevMgr.Add_Click({ Open-Target 'devmgmt.msc' })
# Hersteller-Buttons nur für eingebaute Grafikkarten zeigen (alle, falls nichts erkannt wurde)
$gpuNames = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ' '
if ($gpuNames -match 'NVIDIA|AMD|Radeon|Intel') {
    if ($gpuNames -notmatch 'NVIDIA') { $ui.BtnNvidia.Visibility = 'Collapsed' }
    if ($gpuNames -notmatch 'AMD|Radeon') { $ui.BtnAmd.Visibility = 'Collapsed' }
    if ($gpuNames -notmatch 'Intel') { $ui.BtnIntel.Visibility = 'Collapsed' }
}
$ui.BtnNvidia.Add_Click({ Open-Target 'https://www.nvidia.com/de-de/software/nvidia-app/' })
$ui.BtnAmd.Add_Click({ Open-Target 'https://www.amd.com/de/support/download/drivers.html' })
$ui.BtnIntel.Add_Click({ Open-Target 'https://www.intel.de/content/www/de/de/support/detect.html' })

$ui.BtnSearchUpdates.Add_Click({
    Start-Work -Status 'Suche bei Windows Update nach Treibern ... (1-3 Minuten)' -Script { Search-DriverUpdates } -OnDone {
        param($r)
        $list = @($r | Where-Object { $_ })
        Set-Items $ui.GridUpdates ($list | ForEach-Object { New-Row -A $_.Title -B $_.Manufacturer -C $_.Class -D $_.Date -Selected $true -Tag $_.Id })
        Set-Status $(if ($list.Count -eq 0) { 'Windows Update bietet keine neueren Treiber an.' } else { "$($list.Count) Treiber-Update(s) verfügbar." })
    }
})

$ui.BtnInstallUpdates.Add_Click({
    $sel = @(Get-Rows $ui.GridUpdates | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte zuerst nach Updates suchen und welche auswählen.'; return }
    if (-not (Confirm-Action "$($sel.Count) Treiber werden über Windows Update installiert.`n`nVorher wird ein Wiederherstellungspunkt erstellt. Während der Installation kann der Bildschirm kurz flackern.`n`nFortfahren?")) { return }
    $script:State.Pending = @($sel | ForEach-Object { [string]$_.Tag })
    Invoke-WithRestorePoint 'Treiber-Updates' {
        Start-Work -Status 'Installiere Treiber ...' -Arguments @(, $script:State.Pending) -Script { Install-DriverUpdates $A[0] } -OnDone {
            param($r) $msg = [string](@($r)[-1])
            Set-Status $msg; Show-Info $msg 'Treiber-Updates'
            Set-Items $ui.GridUpdates @()
        }
    }
})

# ============================================================================
#  Energie & Einstellungen
# ============================================================================
$script:RefreshTweaks = {
    Start-Work -Status 'Prüfe Einstellungen ...' -Script {
        [pscustomobject]@{ Tweaks = @(Get-Tweaks (Test-IsLaptop)); Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Show-Tweaks $r.Tweaks $r.Plans
        $open = @($r.Tweaks | Where-Object { -not $_.Optimal -and -not $_.Optional }).Count
        Set-Status $(if ($open -eq 0) { 'Alle Einstellungen sind optimal.' } else { "$open Einstellung(en) können verbessert werden." })
    }
}
$ui.BtnTweaks.Add_Click({ & $script:RefreshTweaks })

$ui.BtnApplyTweaks.Add_Click({
    $rows = @(Get-Rows $ui.GridTweaks)
    if ($rows.Count -eq 0) { & $script:RefreshTweaks; return }
    $sel = @($rows | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Es ist keine Einstellung ausgewählt.'; return }
    $list = ($sel | ForEach-Object { '- ' + $_.A }) -join "`n"
    if (-not (Confirm-Action "Folgende Einstellungen werden auf maximale Leistung gestellt:`n`n$list`n`nVorher wird ein Wiederherstellungspunkt erstellt. Fortfahren?")) { return }
    $script:State.Pending = @{ Ids = @($sel | ForEach-Object { $_.Tag.Id }); Restart = [bool]($sel | Where-Object { $_.Tag.Restart }) }
    Invoke-WithRestorePoint 'Leistungseinstellungen' {
        Start-Work -Status 'Wende Einstellungen an ...' -Arguments @(, $script:State.Pending.Ids) -Script {
            $e = @(Invoke-Tweaks $A[0])
            [pscustomobject]@{ Errors = $e; Tweaks = @(Get-Tweaks (Test-IsLaptop)); Plans = @(Get-PowerPlans) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            Show-Tweaks $r.Tweaks $r.Plans
            $errs = @($r.Errors | Where-Object { $_ })
            $msg = if ($errs.Count -eq 0) { 'Alle Einstellungen wurden übernommen.' } else { "Teilweise fehlgeschlagen:`n" + ($errs -join "`n") }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen werden erst nach einem Neustart wirksam." }
            Set-Status $(if ($errs.Count -eq 0) { 'Einstellungen übernommen.' } else { 'Einige Einstellungen konnten nicht geändert werden.' })
            Show-Info $msg
        }
    }
})

$ui.BtnSetPlan.Add_Click({
    $p = $ui.ComboPlans.SelectedItem
    if (-not $p) { & $script:RefreshTweaks; return }
    Start-Work -Status 'Aktiviere Energiesparplan ...' -Arguments @([string]$p.Tag) -Script {
        powercfg.exe /setactive $A[0] | Out-Null
        [pscustomobject]@{ Tweaks = @(Get-Tweaks (Test-IsLaptop)); Plans = @(Get-PowerPlans) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Show-Tweaks $r.Tweaks $r.Plans
        Set-Status ('Aktiver Energiesparplan: ' + (@($r.Plans | Where-Object { $_.Active })[0].Name))
    }
})

# ============================================================================
#  Grafikkarten
# ============================================================================
$ui.BtnGpu.Add_Click({
    Start-Work -Status 'Prüfe Grafikkarten ...' -Script { Get-GpuAnalysis (Test-IsLaptop) } -OnDone {
        param($r) $r = @($r)[-1]; Show-Gpu $r; Set-Status "$(@($r.Gpus).Count) Grafikkarte(n) erkannt."
    }
})
$ui.BtnGfxSettings.Add_Click({ Open-Target 'ms-settings:display-advancedgraphics' })

$ui.BtnGames.Add_Click({
    Start-Work -Status 'Suche installierte Spiele ...' -Script { @(Find-Games) } -OnDone {
        param($r)
        $g = @($r | Where-Object { $_ })
        Show-Games $g
        $msg = "$($g.Count) Spiel(e) gefunden."
        if ($script:State.GpuCount -eq 1) { $msg += ' Hinweis: Es ist nur eine Grafikkarte vorhanden - die Einstellung pro Spiel hat dann keine Wirkung.' }
        Set-Status $msg
    }
})

$ui.BtnAddGame.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = 'Spiel oder Programm auswählen'; $dlg.Filter = 'Programme (*.exe)|*.exe'; $dlg.Multiselect = $true
    if (-not $dlg.ShowDialog($window)) { return }
    $rows = New-Object 'System.Collections.ObjectModel.ObservableCollection[object]'
    foreach ($r in @(Get-Rows $ui.GridGames)) { $rows.Add($r) }
    foreach ($file in $dlg.FileNames) {
        if ($rows | Where-Object { $_.Tag -ieq $file }) { continue }
        $name = (Get-Item -LiteralPath $file).VersionInfo.ProductName
        if (-not $name) { $name = [IO.Path]::GetFileNameWithoutExtension($file) }
        $pref = Get-GpuPreference $file
        $rows.Add((New-Row -A $name -B 'Manuell' -C $pref -D $file -Level $(if ($pref -eq 'Hohe Leistung') { 0 } else { 2 }) -Selected $true -Tag $file))
    }
    $ui.GridGames.ItemsSource = $rows
})

$ui.BtnHighPerf.Add_Click({
    $sel = @(Get-Rows $ui.GridGames | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens ein Spiel auswählen.'; return }
    if (-not (Confirm-Action "$($sel.Count) Programm(e) werden in Windows auf 'Hohe Leistung' (dedizierte Grafikkarte) eingestellt.`n`nDie Änderung kann jederzeit unter Einstellungen > System > Anzeige > Grafik zurückgenommen werden. Fortfahren?")) { return }
    $ok = 0
    foreach ($g in $sel) {
        try {
            Set-GpuHighPerformance $g.Tag
            $g.C = Get-GpuPreference $g.Tag
            $g.Level = 0; $g.IsSelected = $false; $ok++
        } catch { Set-Status "$($g.A): $($_.Exception.Message)" }
    }
    Set-Status "$ok Programm(e) nutzen jetzt die leistungsstarke Grafikkarte. Bereits laufende Spiele bitte neu starten."
})

# ============================================================================
#  Bereinigung
# ============================================================================
Set-Items $ui.GridClean (Get-CleanupDefs | ForEach-Object { New-Row -A $_.Name -B '-' -C $_.Desc -Selected $_.Sel -Tag $_.Id })

function Update-CleanTotal {
    $sum = (@(Get-Rows $ui.GridClean | Where-Object { $_.IsSelected }) | Measure-Object -Property N1 -Sum).Sum
    $ui.CleanTotal.Text = 'Ausgewählt: ' + (Format-Bytes ([double]$sum))
}

function Apply-Measures($measures) {
    foreach ($m in @($measures)) {
        $row = Get-Rows $ui.GridClean | Where-Object { $_.Tag -eq $m.Id } | Select-Object -First 1
        if ($row) {
            $row.N1 = [long]$m.Size
            $row.B = if ($m.Id -eq 'winsxs') { 'erst nach Bereinigung messbar' } else { "{0} ({1} Dateien)" -f (Format-Bytes $m.Size), $m.Count }
        }
    }
    Update-CleanTotal
}

$ui.BtnCleanScan.Add_Click({
    $ids = @(Get-Rows $ui.GridClean | ForEach-Object { $_.Tag })
    Start-Work -Status 'Analysiere Speicherplatz ...' -Arguments @(, $ids) -Script {
        foreach ($id in $A[0]) { Report "Analysiere: $id ..."; Measure-Cleanup $id }
    } -OnDone {
        param($r) Apply-Measures $r; Set-Status 'Analyse abgeschlossen.'
    }
})

$ui.BtnCleanRun.Add_Click({
    $sel = @(Get-Rows $ui.GridClean | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Bitte mindestens eine Kategorie auswählen.'; return }
    if ($sel | Where-Object { $_.Tag -like 'browser-*' }) {
        $running = @(Get-RunningBrowsers)
        if ($running.Count -gt 0 -and -not (Confirm-Action ("Folgende Browser sind geöffnet: {0}.`nIhr Cache lässt sich dann nur teilweise löschen. Schließ die Browser für ein besseres Ergebnis.`n`nTrotzdem fortfahren?" -f ($running -join ', ')))) { return }
    }
    $list = ($sel | ForEach-Object { '- ' + $_.A }) -join "`n"
    if (-not (Confirm-Action "Folgende Bereiche werden endgültig bereinigt:`n`n$list`n`nFortfahren?")) { return }
    $ids = @($sel | ForEach-Object { $_.Tag })
    Start-Work -Status 'Bereinige ...' -Arguments @(, $ids) -Script {
        $freed = 0L
        foreach ($id in $A[0]) { Report "Bereinige: $id ..."; $freed += [long](@(Invoke-Cleanup $id)[-1]) }
        [pscustomobject]@{ Freed = $freed; Measures = @(foreach ($id in $A[0]) { Measure-Cleanup $id }) }
    } -OnDone {
        param($r) $r = @($r)[-1]
        Apply-Measures $r.Measures
        $msg = "Fertig! $(Format-Bytes $r.Freed) freigegeben. Dateien, die gerade verwendet werden, wurden übersprungen."
        Set-Status $msg; Show-Info $msg 'Bereinigung'
    }
})

function Update-JunkTotal {
    $rows = @(Get-Rows $ui.GridJunk)
    $ui.JunkTotal.Text = "{0} Dateien, {1}" -f $rows.Count, (Format-Bytes ([double](($rows | Measure-Object N1 -Sum).Sum)))
}

$ui.BtnJunkScan.Add_Click({
    Start-Work -Cancellable -Status 'Suche Junk-Dateien ...' -Script { Find-JunkFiles } -OnDone {
        param($r)
        Set-Items $ui.GridJunk (@($r | Where-Object { $_ }) | ForEach-Object { New-Row -A $_.Path -B (Format-Bytes $_.Size) -C $_.Modified -N1 $_.Size -Selected $true -Tag $_.Path })
        Update-JunkTotal
        Set-Status "$(@(Get-Rows $ui.GridJunk).Count) Junk-Dateien gefunden."
    }
})

$ui.BtnJunkToggle.Add_Click({
    $rows = @(Get-Rows $ui.GridJunk)
    $target = [bool]($rows | Where-Object { -not $_.IsSelected })
    foreach ($r in $rows) { $r.IsSelected = $target }
})

$ui.BtnJunkDelete.Add_Click({
    $sel = @(Get-Rows $ui.GridJunk | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Keine Dateien ausgewählt.'; return }
    $size = Format-Bytes ([double](($sel | Measure-Object N1 -Sum).Sum))
    if (-not (Confirm-Action "$($sel.Count) Dateien ($size) werden in den Papierkorb verschoben. Fortfahren?")) { return }
    $paths = @($sel | ForEach-Object { [string]$_.Tag })
    Start-Work -Status 'Verschiebe Dateien in den Papierkorb ...' -Arguments @(, $paths) -Script {
        foreach ($p in $A[0]) { if ([PCO.Native]::Recycle($p)) { $p } }
    } -OnDone {
        param($r)
        $done = @($r | Where-Object { $_ })
        $remaining = @(Get-Rows $ui.GridJunk | Where-Object { $done -notcontains $_.Tag })
        $wanted = @(Get-Rows $ui.GridJunk | Where-Object { $_.IsSelected }).Count
        Set-Items $ui.GridJunk $remaining
        Update-JunkTotal
        $msg = "$($done.Count) Dateien in den Papierkorb verschoben."
        if ($done.Count -lt $wanted) { $msg += " $($wanted - $done.Count) waren gesperrt." }
        Set-Status $msg
    }
})

# ============================================================================
#  Deinstallation
# ============================================================================
function Update-ProgramView {
    $q = $ui.TxtSearch.Text.Trim()
    $prev = if ($ui.GridPrograms.SelectedItem) { $ui.GridPrograms.SelectedItem.Tag } else { $null }
    $rows = @($script:State.Programs)
    # IndexOf statt -like: Sonderzeichen wie [ ] * ? im Suchtext sind kein Fehler
    if ($q) { $rows = @($rows | Where-Object { ([string]$_.A).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or ([string]$_.C).IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0 }) }
    Set-Items $ui.GridPrograms $rows
    $ui.ProgramCount.Text = "$($rows.Count) Programme"
    # Auswahl erhalten; bei genau einem Treffer automatisch auswählen
    $sel = $null
    if ($prev) { $sel = @($rows | Where-Object { $_.Tag.Name -eq $prev.Name -and $_.Tag.Version -eq $prev.Version })[0] }
    if (-not $sel -and $rows.Count -eq 1) { $sel = $rows[0] }
    if ($sel) { $ui.GridPrograms.SelectedItem = $sel; $ui.GridPrograms.ScrollIntoView($sel) }
    Update-ProgramSelection
}

function Update-ProgramSelection {
    $row = $ui.GridPrograms.SelectedItem
    $has = [bool]$row
    $ui.BtnUninstall.IsEnabled = $has; $ui.BtnForce.IsEnabled = $has
    if ($has) {
        $p = $row.Tag
        $ui.ProgramSelected.Text = 'Ausgewählt: ' + $p.Name + $(if ($p.Version) { "  ·  $($p.Version)" } else { '' }) + $(if ($p.Publisher) { "  ·  $($p.Publisher)" } else { '' }) + $(if ($p.InstallLocation) { "  ·  $($p.InstallLocation)" } else { '' })
        Set-ThemeRef $ui.ProgramSelected Foreground 'ink'
        $ui.ProgramSelectedIcon.Content = New-LineIcon 'check' 'accent' 18
    } else {
        $ui.ProgramSelected.Text = 'Klick ein Programm in der Liste an.'
        Set-ThemeRef $ui.ProgramSelected Foreground 'ink-muted'
        $ui.ProgramSelectedIcon.Content = New-LineIcon 'info' 'ink-muted' 18
    }
}
$ui.GridPrograms.Add_SelectionChanged({ Update-ProgramSelection })
Update-ProgramSelection

$script:LoadPrograms = {
    Start-Work -Status 'Lade installierte Programme ...' -Arguments @([bool]$ui.ChkStore.IsChecked) -Script { @(Get-InstalledPrograms $A[0]) } -OnDone {
        param($r)
        $script:State.Programs = @($r | Where-Object { $_ } | ForEach-Object {
            New-Row -A $_.Name -B $_.Version -C $_.Publisher -D $_.InstallDate -E $(if ($_.Size -gt 0) { Format-Bytes $_.Size } else { '' }) -F $_.TypeText -N1 $_.Size -Tag $_
        })
        Update-ProgramView
        Set-Status "$(@($script:State.Programs).Count) Programme gefunden."
    }
}
$ui.BtnPrograms.Add_Click({ & $script:LoadPrograms })
$ui.ChkStore.Add_Click({ & $script:LoadPrograms })
$ui.TxtSearch.Add_TextChanged({ Update-ProgramView })

# Zeile der Restetabelle: Zugehörigkeit | Typ | Pfad | Beleg | Größe
function New-LeftoverRow($It) {
    $lvl = switch ($It.Confidence) { 'sicher' { 0 } 'wahrscheinlich' { 1 } default { 2 } }
    $conf = switch ($It.Confidence) { 'sicher' { 'Nachgewiesen' } 'wahrscheinlich' { 'Wahrscheinlich' } default { 'Unsicher' } }
    if ($It.Shared) { $conf += ' · geteilt' }
    $what = "$($It.Type)`n$($It.Reason)" + $(if ($It.Owner) { "`nvon: $($It.Owner)" } else { '' })
    New-Row -A $conf -B $what -C $It.Path -D $It.Proof -E $(if ($It.Size -gt 0) { Format-Bytes $It.Size } else { '' }) -N1 $It.Size -Selected $It.Selected -Level $lvl -Tag $It
}

# Hält vor der Deinstallation fest, was nachweislich zum Programm gehört (danach ist z. B. die Windows-Installer-Liste weg)
function Start-ProgramFootprint([scriptblock]$Then) {
    $script:State.FootprintThen = $Then
    $script:State.Footprint = $null; $script:State.FootprintFor = ''
    if ($script:State.Current.Source -eq 'Store') { & $Then; return }
    $all = @($script:State.Programs | ForEach-Object { $_.Tag })
    Start-Work -Status "Erfasse, was nachweislich zu $($script:State.Current.Name) gehört ... (bis zu zwei Minuten)" -Arguments @($script:State.Current, $all) -Script { Get-ProgramFootprint $A[0] $A[1] } -OnDone {
        param($r)
        $script:State.Footprint = @($r)[-1]; $script:State.FootprintFor = $script:State.Current.Name
        Save-Footprint $script:State.Current $script:State.Footprint    # für spätere Restesuchen
        $cnt = @($script:State.Footprint.Items).Count
        $ui.LeftoverHeading.Text = "Erfasst: $cnt Einträge gehören nachweislich zu $($script:State.Current.Name)"
        Set-Status "$cnt Einträge gehören nachweislich zu $($script:State.Current.Name). Jetzt startet die Deinstallation." 
        & $script:State.FootprintThen
    }
}

# Öffnet den Speicherort eines Rests: Explorer, Registrierungs-Editor, Dienste oder Aufgabenplanung
function Open-LeftoverLocation($It) {
    if (-not $It) { Show-Info 'Markiere zuerst einen Eintrag in der Liste.'; return }
    switch ($It.Type) {
        'Ordner' {
            if (Test-Path -LiteralPath $It.Path) { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $It.Path) }
            else { Show-Info "Der Ordner existiert nicht mehr:`n$($It.Path)" }
        }
        'Datei' {
            if (Test-Path -LiteralPath $It.Path) { Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $It.Path) }
            else { Show-Info "Die Datei existiert nicht mehr:`n$($It.Path)" }
        }
        { $_ -in 'Registry-Schlüssel', 'Registry-Wert' } {
            # Der Registrierungs-Editor öffnet den zuletzt gemerkten Schlüssel – den setzen wir vorher
            $disp = Get-RegDisplayPath $It.Hive $It.View $It.SubKey
            $full = 'Computer\' + ($disp -replace '^HKLM\\', 'HKEY_LOCAL_MACHINE\' -replace '^HKCU\\', 'HKEY_CURRENT_USER\')
            try {
                $k = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Software\Microsoft\Windows\CurrentVersion\Applets\Regedit')
                $k.SetValue('LastKey', $full); $k.Close()
                Start-Process regedit.exe -ArgumentList '-m'
                if ($It.Type -eq 'Registry-Wert') { Set-Status "Im Registrierungs-Editor rechts den Wert »$($It.ValueName)« suchen." }
            } catch { Show-Error $_.Exception.Message }
        }
        'Dienst' { Start-Process services.msc; Set-Status "In der Diensteliste nach »$($It.Service)« suchen." }
        'Aufgabe' { Start-Process taskschd.msc; Set-Status "In der Aufgabenplanung unter »$($It.TaskPath)« nach »$($It.Task)« suchen." }
        'Firewall-Regel' { Start-Process wf.msc; Set-Status "In der Firewall unter eingehenden bzw. ausgehenden Regeln nach »$($It.Path)« suchen." }
    }
}
$ui.BtnLoOpen.Add_Click({ $r = $ui.GridLeftovers.SelectedItem; Open-LeftoverLocation $(if ($r) { $r.Tag } else { $null }) })
$ui.GridLeftovers.Add_MouseDoubleClick({
    param($s, $e)
    $dep = $e.OriginalSource
    try { while ($dep -and -not ($dep -is [Windows.Controls.DataGridRow])) { if ($dep -is [Windows.Controls.CheckBox]) { return }; $dep = [Windows.Media.VisualTreeHelper]::GetParent($dep) } } catch { $dep = $null }
    if ($dep) { Open-LeftoverLocation $dep.Item.Tag }
})

function Start-LeftoverScan([string]$Previous, [switch]$Forced) {
    $script:State.LeftoverMode = 'program'
    $script:State.Previous = $Previous
    $p = $script:State.Current
    if (-not $p) { Show-Info 'Wähl zuerst ein Programm aus und deinstalliere es.'; return }
    $all = @($script:State.Programs | ForEach-Object { $_.Tag })
    $fp = if ($script:State.FootprintFor -eq $p.Name) { $script:State.Footprint } else { $null }
    Start-Work -Status "Suche Reste von $($p.Name) ..." -Arguments @($p, $all, [bool]$Forced, $fp) -Script {
        if (-not $A[2]) { Start-Sleep -Seconds 2 }   # manche Deinstallationsprogramme löschen ihre letzten Dateien kurz nach dem Beenden
        $still = if ($A[2]) { $false } else { Test-ProgramStillInstalled $A[0] }
        [pscustomobject]@{ Still = $still; Items = $(if ($still) { @() } else { @(Find-Leftovers $A[0] $A[1] $A[3]) }) }
    } -OnDone {
        param($r)
        $res = @($r)[-1]
        $name = $script:State.Current.Name
        if ($res.Still) {
            Set-Items $ui.GridLeftovers @()
            $ui.LeftoverHeading.Text = "$name ist noch installiert"
            Set-Status "$($script:State.Previous) $name ist noch installiert."
            Show-Info ("$($script:State.Previous)`n`n$name ist noch installiert. Entweder wurde die Deinstallation abgebrochen, oder sie läuft noch im Hintergrund.`n`n" +
                       "Läuft sie noch: warte, bis sie fertig ist, und klick dann auf »Erneut nach Resten suchen«.`n" +
                       "Lässt sich das Programm gar nicht deinstallieren: »Erzwungen entfernen«.") 'Deinstallation'
            return
        }
        $items = @($res.Items | Where-Object { $_ })
        Set-Items $ui.GridLeftovers ($items | ForEach-Object { New-LeftoverRow $_ })
        $selCount = @($items | Where-Object { $_.Selected }).Count
        $ui.LeftoverHeading.Text = "Nachgewiesene Reste von $name ($($items.Count))"
        if ($items.Count -eq 0) {
            Set-Status "$($script:State.Previous) Keine Reste gefunden – das Programm wurde sauber entfernt."
            Show-Info "$($script:State.Previous)`n`nEs wurden keine Reste gefunden." 'Deinstallation'
            & $script:LoadPrograms
        } else {
            Set-Status "$($script:State.Previous) $($items.Count) Reste gefunden, $selCount davon vorausgewählt. Prüfen und auf »Ausgewählte Reste löschen« klicken."
        }
    }
}

$script:UninstallSelected = {
    $row = $ui.GridPrograms.SelectedItem
    if (-not $row) { Show-Info 'Wähl zuerst ein Programm aus der Liste.'; return }
    $p = $row.Tag
    if (-not (Confirm-Action ("{0} deinstallieren?`n`n1. TuneRig legt einen Wiederherstellungspunkt an.`n2. Das Deinstallationsprogramm des Herstellers startet – folge seinen Anweisungen.`n3. Danach sucht TuneRig nach Resten, die du prüfen und löschen kannst." -f $p.Name) 'Deinstallieren')) { return }
    $script:State.Current = $p
    Set-Items $ui.GridLeftovers @()
    Invoke-WithRestorePoint "Deinstallation $($p.Name)" {
        Start-ProgramFootprint {
            Start-Work -Cancellable -Status "Deinstalliere $($script:State.Current.Name) ... (Abbrechen = nicht länger warten)" -Arguments @($script:State.Current) -Script { Invoke-Uninstaller $A[0] } -OnDone {
                param($r) $msg = [string](@($r)[-1])
                Set-Status $msg
                if ($script:State.Current.Source -eq 'Store') { Show-Info $msg; & $script:LoadPrograms }
                else { Start-LeftoverScan $msg }
            } -OnCancel { Start-LeftoverScan 'Warten auf das Deinstallationsprogramm wurde beendet.' }
        }
    }
}
$ui.BtnUninstall.Add_Click({ & $script:UninstallSelected })
$ui.GridPrograms.Add_MouseDoubleClick({
    param($s, $e)
    $dep = $e.OriginalSource
    try {
        while ($dep -and -not ($dep -is [Windows.Controls.DataGridRow])) { $dep = [Windows.Media.VisualTreeHelper]::GetParent($dep) }
    } catch { $dep = $null }
    if ($dep) { & $script:UninstallSelected }
})

$ui.BtnForce.Add_Click({
    $row = $ui.GridPrograms.SelectedItem
    if (-not $row) { Show-Info 'Wähl zuerst ein Programm aus der Liste.'; return }
    if ($row.Tag.Source -eq 'Store') { & $script:UninstallSelected; return }
    if (-not (Confirm-Action ("{0} erzwungen entfernen?`n`nDas Deinstallationsprogramm wird nicht ausgeführt. Stattdessen werden alle gefundenen Spuren (Ordner, Registry, Verknüpfungen, Dienste) angezeigt und können gelöscht werden.`n`nNutze das nur, wenn die normale Deinstallation nicht funktioniert." -f $row.Tag.Name) 'Erzwungene Deinstallation')) { return }
    $script:State.Current = $row.Tag
    Set-Items $ui.GridLeftovers @()
    Invoke-WithRestorePoint "Erzwungene Deinstallation $($row.Tag.Name)" { Start-ProgramFootprint { Start-LeftoverScan 'Erzwungene Deinstallation.' -Forced } }
})
$ui.BtnLoRescan.Add_Click({ if ($script:State.LeftoverMode -eq 'orphan') { Start-OrphanScan } else { Start-LeftoverScan 'Erneute Suche.' } })

# Reste von Programmen und Spielen, die nicht mehr installiert sind
function Start-OrphanScan {
    $script:State.LeftoverMode = 'orphan'
    $script:State.Current = [pscustomobject]@{ Name = 'Reste nicht mehr installierter Programme'; Source = 'Orphan'; SubKey = '' }
    Set-Items $ui.GridLeftovers @()
    $ui.LeftoverHeading.Text = 'Suche Reste nicht mehr installierter Programme ...'
    Start-Work -Cancellable -Status 'Durchsuche alle Laufwerke nach Resten nicht mehr installierter Programme ... (einige Minuten)' -Script { @(Find-OrphanLeftovers) } -OnDone {
        param($r)
        $items = @($r | Where-Object { $_ })
        Set-Items $ui.GridLeftovers ($items | ForEach-Object { New-LeftoverRow $_ })
        $size = 0L; foreach ($i in $items) { $size += [long]$i.Size }
        $owners = @($items | Where-Object { $_.Owner } | ForEach-Object { $_.Owner } | Sort-Object -Unique)
        $ui.LeftoverHeading.Text = "Nachgewiesene Reste nicht mehr installierter Programme ($($items.Count))"
        if ($items.Count -eq 0) { Set-Status 'Keine Reste nicht mehr installierter Programme gefunden.'; Show-Info 'Es wurden keine nachweisbaren Reste nicht mehr installierter Programme gefunden.' 'Restesuche' }
        else { Set-Status ("{0} Reste gefunden ({1}), davon {2} Programme bzw. Spiele erkennbar. Prüfen und auf »Ausgewählte Reste löschen« klicken." -f $items.Count, (Format-Bytes $size), $owners.Count) }
    } -OnCancel { $ui.LeftoverHeading.Text = 'Gefundene Reste'; Set-Status 'Suche abgebrochen.' }
}
$ui.BtnOrphanScan.Add_Click({
    if (-not (Confirm-Action ("TuneRig durchsucht jetzt alle Laufwerke nach Resten von Programmen und Spielen, die nicht mehr installiert sind.`n`n" +
            "Gefunden wird nur, was sich belegen lässt: Einträge, deren Programm nicht mehr existiert, Spieleordner, die kein Launcher mehr kennt, Reste früherer Deinstallationen mit TuneRig, Datenordner, die nur noch auf entfernte Programme verweisen, und leere Programmordner.`n`n" +
            "Die Suche ändert nichts und dauert einige Minuten. Starten?") 'Reste alter Programme')) { return }
    Start-OrphanScan
})

$ui.BtnLoAll.Add_Click({ foreach ($r in @(Get-Rows $ui.GridLeftovers)) { $r.IsSelected = $true } })
$ui.BtnLoNone.Add_Click({ foreach ($r in @(Get-Rows $ui.GridLeftovers)) { $r.IsSelected = $false } })

$ui.BtnLoDelete.Add_Click({
    $rows = @(Get-Rows $ui.GridLeftovers)
    if (-not $script:State.Current -or $rows.Count -eq 0) { Show-Info 'Es gibt keine Reste zum Löschen.'; return }
    $sel = @($rows | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Wähl die Einträge aus, die gelöscht werden sollen.'; return }
    $warn = ''
    $noProof = @($sel | Where-Object { $_.Tag.Confidence -ne 'sicher' })
    if ($noProof.Count) { $warn += "`n`nAchtung: $($noProof.Count) ausgewählte Einträge sind NICHT nachweislich Teil des Programms (»Wahrscheinlich« oder »Unsicher«). Prüfe sie mit »Speicherort öffnen«, bevor du sie löschst." }
    if ($sel | Where-Object { $_.Tag.Shared }) { $warn += "`n`nAchtung: Du hast Einträge ausgewählt, die auch andere Programme nutzen." }
    if (-not (Confirm-Action ("$($sel.Count) Einträge werden entfernt.`n`n" +
            "–  Registry-Einträge und geplante Aufgaben werden vorher gesichert.`n" +
            "–  Dateien und Ordner landen im Papierkorb. Was nicht hineinpasst, wird direkt gelöscht.`n" +
            "–  Programme, die noch aus diesen Ordnern laufen, werden beendet.`n" +
            "–  Gesperrte Dateien werden beim nächsten Neustart gelöscht.$warn`n`nFortfahren?") 'Reste löschen')) { return }
    $items = @($sel | ForEach-Object { $_.Tag })
    Start-Work -Status 'Entferne Reste ...' -Arguments @($script:State.Current, $items) -Script { Remove-Leftovers $A[0] $A[1] } -OnDone {
        param($r) $res = @($r)[-1]
        # Entfernte Zeilen verschwinden; Gesperrtes und Fehlgeschlagenes bleibt mit Grund stehen
        $byPath = @{}; foreach ($x in @($res.Results)) { $byPath[$x.Item.Type + '|' + $x.Item.Path] = $x }
        $keep = foreach ($row in @(Get-Rows $ui.GridLeftovers)) {
            $x = $byPath[$row.Tag.Type + '|' + $row.Tag.Path]
            if (-not $x) { $row; continue }
            if ($x.Status -in 'ok', 'deleted') { continue }
            $row.IsSelected = $false
            if ($x.Status -eq 'reboot') { $row.A = 'Beim Neustart'; $row.Level = 1 } else { $row.A = 'Fehlgeschlagen'; $row.Level = 3 }
            $row.D = $x.Note
            $row
        }
        Set-Items $ui.GridLeftovers @($keep)
        $ui.LeftoverHeading.Text = "Reste von $($script:State.Current.Name): $(@($keep).Count) übrig"
        if ($res.Reboot) {
            if (Confirm-Action ($res.Message + "`n`nJetzt neu starten, damit die gesperrten Dateien gelöscht werden? (Speichere vorher offene Dateien.)") 'Reste gelöscht') {
                shutdown.exe /r /t 10 /c "TuneRig: Neustart, um gesperrte Reste zu löschen."
            }
        } else { Show-Info $res.Message 'Reste gelöscht' }
        & $script:LoadPrograms
    }
})

# ============================================================================
#  Gaming (Werkzeug-Ansicht)
# ============================================================================
$script:GroupName = @{ display = 'Bild & Steuerung'; system = 'Prozessor & System'; network = 'Internet' }

function Show-GamingGrid($tweaks) {
    Set-Items $ui.GridGaming (@($tweaks) | Sort-Object @{ e = { @{ display = 0; system = 1; network = 2 }[$_.Group] } }, @{ e = { @{ recommended = 0; optional = 1; experimental = 2 }[$_.Mode] } } | ForEach-Object {
        $status = if ($_.Optimal) { 'Aktiv' } elseif ($_.Mode -eq 'recommended') { 'Empfohlen' } elseif ($_.Mode -eq 'optional') { 'Optional' } else { 'Experimentell' }
        $lvl = if ($_.Optimal) { 0 } elseif ($_.Mode -eq 'recommended') { 2 } else { 1 }
        $eff = "Wirkung: $($script:ImpactText[[int]$_.Impact]) - $($_.Benefit)" + $(if ($_.Risk) { "`nNebenwirkung: $($_.Risk)" } else { '' })
        New-Row -A $script:GroupName[$_.Group] -B $_.Title -C $status -D $_.State -E $_.Target -F $eff -Level $lvl -Selected (-not $_.Optimal -and $_.Mode -eq 'recommended') -Tag $_
    })
}

$script:LoadGaming = {
    Start-Work -Status 'Prüfe Gaming-Optimierungen ... (bis zu einer Minute)' -Script { @(Get-GamingTweaks '' (Test-IsLaptop)) } -OnDone {
        param($r)
        $t = @($r | Where-Object { $_ })
        Show-GamingGrid $t
        Set-Status ("{0} Optimierungen geprüft, davon {1} empfohlen und noch offen." -f $t.Count, @($t | Where-Object { $_.Mode -eq 'recommended' -and -not $_.Optimal }).Count)
    }
}
$ui.BtnGamingCheck.Add_Click({ & $script:LoadGaming })

function Invoke-GamingFromGrid([bool]$Revert) {
    $sel = @(Get-Rows $ui.GridGaming | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Hake zuerst die gewünschten Zeilen an.'; return }
    if ($Revert) { $sel = @($sel | Where-Object { $_.Tag.CanRevert }); if ($sel.Count -eq 0) { Show-Info 'Die ausgewählten Einstellungen haben keine Zurücksetzen-Funktion (sie entsprechen bereits dem Windows-Standard bzw. lassen sich über Windows ändern).'; return } }
    $risky = @($sel | Where-Object { -not $Revert -and $_.Tag.Risk })
    $list = ($sel | ForEach-Object { '- ' + $_.B }) -join "`n"
    $warn = if ($risky.Count) { "`n`nNebenwirkungen:`n" + (($risky | ForEach-Object { '- ' + $_.B + ': ' + $_.Tag.Risk }) -join "`n") } else { '' }
    if (-not (Confirm-Action ("{0}`n`n{1}{2}`n`nVorher wird ein Wiederherstellungspunkt erstellt. Fortfahren?" -f $(if ($Revert) { 'Diese Einstellungen werden auf den Windows-Standard zurückgesetzt:' } else { 'Diese Optimierungen werden angewendet:' }), $list, $warn))) { return }
    $script:State.Pending = @{ Ids = @($sel | ForEach-Object { $_.Tag.Id }); Revert = $Revert; Restart = [bool]($sel | Where-Object { $_.Tag.Restart }) }
    Invoke-WithRestorePoint 'Gaming-Optimierungen' {
        Start-Work -Status 'Wende Gaming-Einstellungen an ...' -Arguments @(@($script:State.Pending.Ids), $script:State.Pending.Revert) -Script {
            $e = @(Invoke-GamingTweaks $A[0] -Revert:$A[1])
            [pscustomobject]@{ Errors = $e; Tweaks = @(Get-GamingTweaks '' (Test-IsLaptop)) }
        } -OnDone {
            param($r) $r = @($r)[-1]
            Show-GamingGrid $r.Tweaks
            $errs = @($r.Errors | Where-Object { $_ })
            $msg = if ($errs.Count) { "Teilweise fehlgeschlagen:`n" + ($errs -join "`n") } else { 'Fertig.' }
            if ($script:State.Pending.Restart) { $msg += "`n`nEinige Änderungen wirken erst nach einem Neustart." }
            Set-Status ($msg -replace "`n+", ' '); Show-Info $msg
        }
    }
}
$ui.BtnGamingApply.Add_Click({ Invoke-GamingFromGrid $false })
$ui.BtnGamingRevert.Add_Click({ Invoke-GamingFromGrid $true })

function Show-StartupGrid($items) {
    Set-Items $ui.GridStartup (@($items) | ForEach-Object {
        $status = if ($_.Enabled) { 'Aktiv' } else { 'Abgeschaltet' }
        $rec = switch ($_.Class) { 'off' { 'Abschalten empfohlen' } 'keep' { 'Eingeschaltet lassen' } default { 'Nur bei Bedarf' } }
        New-Row -A $_.Name -B $status -C $rec -D $_.Who -E $_.Command -Level $(if ($_.Enabled -and $_.Class -eq 'off') { 2 } elseif ($_.Enabled) { 0 } else { 1 }) `
                -Selected ($_.Enabled -and $_.Class -eq 'off') -Tag $_
    })
}
$script:LoadStartup = {
    Start-Work -Status 'Lese die Autostart-Programme ...' -Script { @(Get-StartupItems) } -OnDone {
        param($r) $i = @($r | Where-Object { $_ }); Show-StartupGrid $i
        Set-Status ("{0} Autostart-Einträge, davon {1} aktiv." -f $i.Count, @($i | Where-Object { $_.Enabled }).Count)
    }
}
$ui.BtnStartupCheck.Add_Click({ & $script:LoadStartup })

function Set-StartupFromGrid([bool]$Enable) {
    $sel = @(Get-Rows $ui.GridStartup | Where-Object { $_.IsSelected })
    if ($sel.Count -eq 0) { Show-Info 'Hake zuerst die gewünschten Programme an.'; return }
    $keep = @($sel | Where-Object { -not $Enable -and $_.Tag.Class -eq 'keep' })
    $warn = if ($keep.Count) { "`n`nAchtung: Darunter sind Programme für Treiber, Sicherheit oder Geräte:`n" + (($keep | ForEach-Object { '- ' + $_.A }) -join "`n") } else { '' }
    if (-not (Confirm-Action ("{0} Programm(e) werden {1}.{2}`n`nFortfahren?" -f $sel.Count, $(if ($Enable) { 'beim Windows-Start wieder gestartet' } else { 'beim Windows-Start nicht mehr gestartet' }), $warn))) { return }
    Start-Work -Status 'Ändere Autostart ...' -Arguments @(@($sel | ForEach-Object { $_.Tag.Id }), $Enable) -Script {
        foreach ($id in $A[0]) { Set-StartupItemState $id $A[1] }
        @(Get-StartupItems)
    } -OnDone { param($r) Show-StartupGrid @($r | Where-Object { $_ }); Set-Status 'Autostart geändert. Wirkt beim nächsten Windows-Start.' }
}
$ui.BtnStartupDisable.Add_Click({ Set-StartupFromGrid $false })
$ui.BtnStartupEnable.Add_Click({ Set-StartupFromGrid $true })

# ============================================================================
#  Startseite und geführter Check
# ============================================================================
. (Join-Path $AppDir 'Wizard.ps1')
. (Join-Path $AppDir 'Storage.ps1')
Set-SplashProgress 0.5 'Prüfe den Systemzustand …'
$ui.StatusVersion.Text = "TuneRig $script:AppVersion"
$ui.BtnCheckUpdate.Add_Click({ Start-UpdateCheck -Manual })
$ui.BtnUpdateNow.Add_Click({ Start-TuneRigUpdate })
$ui.BtnUpdateLater.Add_Click({ $ui.UpdateCard.Visibility = 'Collapsed' })
$ui.UpdateIcon.Content = New-LineIcon 'download' 'accent-text' 24

# ============================================================================
#  Alle Werkzeuge: Jeder Reiter prüft beim ersten Öffnen automatisch
#  (außer Übersicht - dort startet man die Analyse bewusst selbst).
#  Mehrere Prüfungen eines Reiters laufen nacheinander über eine Warteschlange.
# ============================================================================
function Invoke-ButtonClick($b) { $b.RaiseEvent((New-Object Windows.RoutedEventArgs([Windows.Controls.Button]::ClickEvent))) }
$script:TabLoaders = @{
    1 = @({ Invoke-ButtonClick $ui.BtnDrivers })
    2 = @({ & $script:RefreshTweaks })
    3 = @({ Invoke-ButtonClick $ui.BtnGpu }, { Invoke-ButtonClick $ui.BtnGames })
    4 = @({ Invoke-ButtonClick $ui.BtnCleanScan })
    5 = @({ Update-StorageDrives })
    6 = @({ if (@($script:State.Programs).Count -eq 0) { & $script:LoadPrograms } })
    7 = @({ & $script:LoadGaming }, { & $script:LoadStartup })
}
$script:TabLoaded = @{}
$script:AutoQueue = New-Object System.Collections.Queue
function Request-TabAnalysis {
    if (-not $ui.ExpertPage.IsVisible) { return }
    $i = $ui.Tabs.SelectedIndex
    if ($script:TabLoaded[$i] -or -not $script:TabLoaders.ContainsKey($i)) { return }
    $script:TabLoaded[$i] = $true
    foreach ($l in $script:TabLoaders[$i]) { $script:AutoQueue.Enqueue($l) }
}
$ui.Tabs.Add_SelectionChanged({ param($sender, $e) if ($e.OriginalSource -eq $ui.Tabs) { Request-TabAnalysis } })
$ui.ExpertPage.Add_IsVisibleChanged({ Request-TabAnalysis })
# Startet die nächste Prüfung, sobald nichts anderes läuft
$script:AutoTimer = New-Object Windows.Threading.DispatcherTimer
$script:AutoTimer.Interval = [TimeSpan]::FromMilliseconds(300)
$script:AutoTimer.Add_Tick({ if (-not $script:Job -and $script:AutoQueue.Count -gt 0) { & ($script:AutoQueue.Dequeue()) } })
$script:AutoTimer.Start()

# ============================================================================
#  Start
# ============================================================================
$settings = Get-AppSettings
$ui.ChkSkipWelcome.IsChecked = [bool]$settings.SkipWelcome
$ui.ChkSkipWelcome.Add_Click({ Save-AppSettings $(if ($script:State.Page -ne 'welcome') { $script:State.Page } else { (Get-AppSettings).LastMode }) })
if ($settings.SkipWelcome -and $settings.LastMode -eq 'expert') { Show-Page 'expert' }
elseif ($settings.SkipWelcome -and $settings.LastMode -eq 'wizard') { Show-Page 'wizard'; Show-WizStep 0 }
else { Show-Page 'welcome' }

$window.Add_Closing({ if ($script:Job) { try { $script:Job.PS.Stop() } catch {} } })
Start-BrandFontDownload

# Ladesequenz: warten, bis der Systemzustand feststeht (mindestens 1,5 s, höchstens 20 s)
$frame = New-Object Windows.Threading.DispatcherFrame
$splashTimer = New-Object Windows.Threading.DispatcherTimer
$splashTimer.Interval = [TimeSpan]::FromMilliseconds(120)
$splashTimer.Add_Tick({
    $elapsed = ((Get-Date) - $script:SplashStart).TotalSeconds
    $done = $script:HealthJob.Handle.IsCompleted
    # Fortschritt läuft gleichmäßig weiter, bis das Ergebnis da ist
    if (-not $done) { Set-SplashProgress ([math]::Min(0.9, 0.5 + $elapsed / 30)) }
    if (($done -and $elapsed -ge 1.5) -or $elapsed -ge 20) { $splashTimer.Stop(); $frame.Continue = $false }
})
$splashTimer.Start()
[Windows.Threading.Dispatcher]::PushFrame($frame)
if (-not (Receive-QuickHealth)) { Start-QuickHealth }
Set-SplashProgress 1.0 'Bereit'
Start-Sleep -Milliseconds 250
$window.Add_ContentRendered({ if ($script:Splash) { $script:Splash.Close(); $script:Splash = $null; $window.Activate() | Out-Null }; Start-UpdateCheck })
[void]$window.ShowDialog()
$timer.Stop(); $script:TipTimer.Stop(); $script:AutoTimer.Stop(); if ($script:HealthTimer) { $script:HealthTimer.Stop() }
