﻿# ============================================================================
#  TuneRig - zentrale Theme-Datei (Corporate Design)
#  Alle Farben, Schriften, Abstände, Radien und Steuerelement-Stile kommen von hier.
#  In der Oberfläche werden Farben ausschließlich über Token-Namen angesprochen
#  ({DynamicResource Ink} in XAML, Set-ThemeRef $element Foreground 'ink' im Code).
# ============================================================================

# --- Farb-Tokens -------------------------------------------------------------
$script:ThemeTokens = @{
    dark  = [ordered]@{
        'ground' = '#0E1116'; 'surface' = '#161A21'; 'surface-raised' = '#1A1E25'; 'line' = '#3A414D'
        'ink' = '#EDEFF2'; 'ink-muted' = '#9AA3AF'; 'accent' = '#FF5A1F'; 'accent-text' = '#FF7A45'; 'on-accent' = '#0E1116'
        'success' = '#2EE6A6'; 'warning' = '#FFC531'; 'danger' = '#FF5C7A'
    }
    light = [ordered]@{
        'ground' = '#F3F4F6'; 'surface' = '#FFFFFF'; 'surface-raised' = '#E7EAEE'; 'line' = '#C9CED6'
        'ink' = '#0E1116'; 'ink-muted' = '#4B5563'; 'accent' = '#FF5A1F'; 'accent-text' = '#C2410C'; 'on-accent' = '#0E1116'
        'success' = '#0F7A55'; 'warning' = '#9A5B00'; 'danger' = '#C81E3A'
    }
}
# Token-Name -> Ressourcen-Schlüssel in WPF
$script:TokenKey = @{
    'ground' = 'Ground'; 'surface' = 'Surface'; 'surface-raised' = 'SurfaceRaised'; 'line' = 'Line'
    'ink' = 'Ink'; 'ink-muted' = 'InkMuted'; 'accent' = 'Accent'; 'accent-text' = 'AccentText'; 'on-accent' = 'OnAccent'
    'success' = 'Success'; 'warning' = 'Warning'; 'danger' = 'Danger'
}

# --- Abstände (4-px-Raster) und Radien ---------------------------------------
$script:Space = @{ 1 = 4; 2 = 8; 3 = 12; 4 = 16; 6 = 24; 8 = 32; 12 = 48 }
$script:Radius = @{ sm = 4; md = 8; lg = 14 }

# --- Typografie --------------------------------------------------------------
#   display = Chakra Petch (Überschriften, Buttons, Labels)
#   sans    = IBM Plex Sans (Fließtext)
#   mono    = JetBrains Mono (Messwerte)
$script:TypeScale = @{
    'h1'           = @{ Family = 'display'; Size = 40; Line = 44; Weight = 'Bold' }
    'h2'           = @{ Family = 'display'; Size = 28; Line = 32; Weight = 'SemiBold' }
    'h3'           = @{ Family = 'display'; Size = 20; Line = 26; Weight = 'SemiBold' }
    'title'        = @{ Family = 'display'; Size = 16; Line = 22; Weight = 'SemiBold' }
    'body'         = @{ Family = 'sans'; Size = 16; Line = 24; Weight = 'Normal' }
    'small'        = @{ Family = 'sans'; Size = 14; Line = 20; Weight = 'Normal' }
    'label'        = @{ Family = 'display'; Size = 12; Line = 16; Weight = 'Medium' }
    'metric'       = @{ Family = 'mono'; Size = 32; Line = 36; Weight = 'Medium' }
    'metric-small' = @{ Family = 'mono'; Size = 14; Line = 20; Weight = 'Medium' }
}
$script:FontKey = @{ display = 'FontDisplay'; sans = 'FontSans'; mono = 'FontMono' }

# Schriftdateien (SIL Open Font License) liegen in app\fonts\<ordner>. Fehlen sie, gilt der
# Ersatz aus dem Corporate Design: Segoe UI bzw. Consolas.
$script:FontDir = Join-Path $AppDir 'fonts'
$script:FontSpec = @(
    @{ Key = 'FontDisplay'; Family = 'Chakra Petch'; Fallback = 'Segoe UI'; Folder = 'chakrapetch'; Rx = '^ChakraPetch-(Medium|SemiBold|Bold|BoldItalic)\.ttf$' }
    @{ Key = 'FontSans'; Family = 'IBM Plex Sans'; Fallback = 'Segoe UI'; Folder = 'ibmplexsans'; Rx = '^IBMPlexSans-(Regular|Medium)\.ttf$|^IBMPlexSans\[[^\]]+\]\.ttf$' }
    @{ Key = 'FontMono'; Family = 'JetBrains Mono'; Fallback = 'Consolas'; Folder = 'jetbrainsmono'; Rx = '^JetBrainsMono-Medium\.ttf$|^JetBrainsMono\[wght\]\.ttf$' }
)

# --- Linien-Icons (24-px-Raster, Strich 2 px) --------------------------------
$script:IconPaths = @{
    'ok'      = 'M12,3 A9,9 0 1 1 11.99,3 Z M7.5,12.5 L10.5,15.5 L16.5,9.5'
    'info'    = 'M12,3 A9,9 0 1 1 11.99,3 Z M12,11 L12,16.5 M12,7.6 L12,7.7'
    'warning' = 'M12,3.5 L21.5,20 L2.5,20 Z M12,10 L12,14.5 M12,17.2 L12,17.3'
    'danger'  = 'M12,3 A9,9 0 1 1 11.99,3 Z M9,9 L15,15 M15,9 L9,15'
    'check'   = 'M5,12.5 L10,17.5 L19,7'
    'dot'     = 'M12,9 A3,3 0 1 1 11.99,9 Z'
    'chevron' = 'M9,6 L15,12 L9,18'
    'back'    = 'M15,6 L9,12 L15,18'
    'download'= 'M12,4 L12,15 M7,10.5 L12,15.5 L17,10.5 M5,20 L19,20'
    'refresh' = 'M19,12 A7,7 0 1 1 16.95,7.05 M19,4.5 L19,8.5 L15,8.5'
    'shield'  = 'M12,3 L19.5,6 L19.5,11.5 C19.5,16 16.3,19.4 12,21 C7.7,19.4 4.5,16 4.5,11.5 L4.5,6 Z M8.5,12 L11,14.5 L15.5,10'
    'flame'   = 'M12,2.5 C12.8,6.5 18,9 18,14.5 A6,6 0 0 1 6,14.5 C6,11.5 7.6,9.6 8.8,8.2 C9.2,10.2 10.2,11.4 11.2,12 C11.6,9 10.8,6 12,2.5 Z M12,21 A2.6,2.6 0 0 1 9.4,18.4 C9.4,16.6 11,15.6 12,14 C13,15.6 14.6,16.6 14.6,18.4 A2.6,2.6 0 0 1 12,21'
    'arrow'   = 'M5,12 L19,12 M13,6 L19,12 L13,18'
    'bolt'    = 'M13.5,2.5 L5,13.5 L11.5,13.5 L10.5,21.5 L19,10.5 L12.5,10.5 Z'
    'grid'    = 'M4,4 L10,4 L10,10 L4,10 Z M14,4 L20,4 L20,10 L14,10 Z M4,14 L10,14 L10,20 L4,20 Z M14,14 L20,14 L20,20 L14,20 Z'
}
$script:LevelIconKind = @{ 0 = 'ok'; 1 = 'info'; 2 = 'warning'; 3 = 'danger' }
# Hinweise in accent-text (orange Schrift), Zustände in success / warning / danger - immer mit Icon und Text
$script:LevelToken = @{ 0 = 'success'; 1 = 'accent-text'; 2 = 'warning'; 3 = 'danger' }
$script:LevelWord = @{ 0 = 'In Ordnung'; 1 = 'Hinweis'; 2 = 'Verbesserung möglich'; 3 = 'Problem' }

# ============================================================================
#  Stile der Steuerelemente (verwenden nur Tokens)
# ============================================================================
$script:ThemeXaml = @'
<ResourceDictionary xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
                    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">

  <!-- Fokus: 2 px Ring in accent mit 2 px Abstand -->
  <Style x:Key="FocusRing">
    <Setter Property="Control.Template">
      <Setter.Value>
        <ControlTemplate>
          <Rectangle Margin="-4" RadiusX="10" RadiusY="10" StrokeThickness="2" Stroke="{DynamicResource Accent}" SnapsToDevicePixels="True"/>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Schriftrollen -->
  <Style x:Key="H1" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/><Setter Property="FontSize" Value="40"/><Setter Property="FontWeight" Value="Bold"/>
    <Setter Property="LineHeight" Value="44"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/><Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
  </Style>
  <Style x:Key="H2" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/><Setter Property="FontSize" Value="28"/><Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="LineHeight" Value="32"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/><Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
  </Style>
  <Style x:Key="H3" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/><Setter Property="FontSize" Value="20"/><Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="LineHeight" Value="26"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/><Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
  </Style>
  <Style x:Key="Body" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/><Setter Property="FontSize" Value="16"/>
    <Setter Property="LineHeight" Value="24"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/><Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
  </Style>
  <Style x:Key="Small" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/><Setter Property="FontSize" Value="14"/>
    <Setter Property="LineHeight" Value="20"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/><Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
  </Style>
  <Style x:Key="Label" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/><Setter Property="FontSize" Value="12"/><Setter Property="FontWeight" Value="Medium"/>
    <Setter Property="LineHeight" Value="16"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/>
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
  </Style>
  <Style x:Key="Metric" TargetType="TextBlock">
    <Setter Property="FontFamily" Value="{DynamicResource FontMono}"/><Setter Property="FontSize" Value="32"/><Setter Property="FontWeight" Value="Medium"/>
    <Setter Property="LineHeight" Value="36"/><Setter Property="LineStackingStrategy" Value="BlockLineHeight"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
  </Style>

  <!-- Karte: surface, 1 px line, Innenabstand 16, Radius 8 -->
  <Style x:Key="Card" TargetType="Border">
    <Setter Property="Background" Value="{DynamicResource Surface}"/><Setter Property="BorderBrush" Value="{DynamicResource Line}"/>
    <Setter Property="BorderThickness" Value="1"/><Setter Property="CornerRadius" Value="8"/><Setter Property="Padding" Value="16"/>
  </Style>

  <!-- Sekundär-Button (Standard): transparent, Rahmen line, Text ink -->
  <Style TargetType="Button">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Background" Value="Transparent"/>
    <Setter Property="BorderBrush" Value="{DynamicResource Line}"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="Padding" Value="16,8,16,9"/>
    <Setter Property="MinHeight" Value="40"/>
    <Setter Property="Margin" Value="0,0,8,8"/>
    <Setter Property="Cursor" Value="Hand"/>
    <Setter Property="HorizontalContentAlignment" Value="Center"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="Button">
          <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="8" Padding="{TemplateBinding Padding}" SnapsToDevicePixels="True">
            <ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center" RecognizesAccessKey="False"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="{DynamicResource SurfaceRaised}"/><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource InkMuted}"/></Trigger>
            <Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Background" Value="{DynamicResource Line}"/></Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.45"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Primär-Button: Fläche accent, Text on-accent, Versalien, Höhe 44 -->
  <Style x:Key="Primary" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
    <Setter Property="Background" Value="{DynamicResource Accent}"/>
    <Setter Property="BorderBrush" Value="{DynamicResource Accent}"/>
    <Setter Property="Foreground" Value="{DynamicResource OnAccent}"/>
    <Setter Property="MinHeight" Value="44"/>
    <Setter Property="Padding" Value="20,10,20,11"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="Button">
          <Border x:Name="Bd" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" CornerRadius="8" Padding="{TemplateBinding Padding}" SnapsToDevicePixels="True">
            <ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center" RecognizesAccessKey="False"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="{DynamicResource AccentText}"/><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource AccentText}"/></Trigger>
            <Trigger Property="IsPressed" Value="True"><Setter TargetName="Bd" Property="Opacity" Value="0.85"/></Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter TargetName="Bd" Property="Opacity" Value="0.45"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Navigation in der Kopfleiste: aktiver Bereich mit orangefarbener Linie -->
  <Style x:Key="TopNav" TargetType="Button">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="FontSize" Value="13"/>
    <Setter Property="Cursor" Value="Hand"/>
    <Setter Property="Margin" Value="2,0,0,0"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="Button">
          <Grid Background="Transparent">
            <ContentPresenter Margin="10,0" VerticalAlignment="Center" RecognizesAccessKey="False"/>
            <Border x:Name="Bar" Height="2" VerticalAlignment="Bottom" Background="Transparent"/>
          </Grid>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="{DynamicResource Ink}"/></Trigger>
            <Trigger Property="Tag" Value="active"><Setter Property="Foreground" Value="{DynamicResource Ink}"/><Setter TargetName="Bar" Property="Background" Value="{DynamicResource Accent}"/></Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.45"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Schrittliste in der Seitenleiste (Inhalt wird im Code gebaut) -->
  <Style x:Key="NavItem" TargetType="Button">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="Medium"/>
    <Setter Property="FontSize" Value="15"/>
    <Setter Property="Cursor" Value="Hand"/>
    <Setter Property="HorizontalContentAlignment" Value="Stretch"/>
    <Setter Property="Margin" Value="0,0,0,4"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="Button">
          <Border x:Name="Bd" Background="Transparent" BorderBrush="Transparent" BorderThickness="2,0,0,0" CornerRadius="0,8,8,0" Padding="12,10">
            <ContentPresenter HorizontalAlignment="{TemplateBinding HorizontalContentAlignment}" VerticalAlignment="Center" RecognizesAccessKey="False"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="Background" Value="{DynamicResource SurfaceRaised}"/></Trigger>
            <Trigger Property="Tag" Value="done"><Setter Property="Foreground" Value="{DynamicResource Ink}"/></Trigger>
            <Trigger Property="Tag" Value="current"><Setter Property="Foreground" Value="{DynamicResource Ink}"/><Setter TargetName="Bd" Property="Background" Value="{DynamicResource SurfaceRaised}"/><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource Accent}"/></Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.6"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Kontrollkästchen -->
  <Style TargetType="CheckBox">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="Cursor" Value="Hand"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="CheckBox">
          <Grid Background="Transparent">
            <Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
            <Border x:Name="Box" Width="18" Height="18" CornerRadius="4" BorderThickness="1" Margin="0,1,10,0" VerticalAlignment="Top"
                    BorderBrush="{DynamicResource InkMuted}" Background="{DynamicResource SurfaceRaised}">
              <Path x:Name="Mark" Data="M3.5,8.5 L7,12 L13,5" Stroke="{DynamicResource OnAccent}" StrokeThickness="2"
                    StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round" Visibility="Collapsed"/>
            </Border>
            <ContentPresenter Grid.Column="1" VerticalAlignment="Center" RecognizesAccessKey="False"/>
          </Grid>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Box" Property="BorderBrush" Value="{DynamicResource Accent}"/></Trigger>
            <Trigger Property="IsChecked" Value="True">
              <Setter TargetName="Box" Property="Background" Value="{DynamicResource Accent}"/><Setter TargetName="Box" Property="BorderBrush" Value="{DynamicResource Accent}"/>
              <Setter TargetName="Mark" Property="Visibility" Value="Visible"/>
            </Trigger>
            <Trigger Property="IsChecked" Value="{x:Null}">
              <Setter TargetName="Box" Property="Background" Value="{DynamicResource Accent}"/><Setter TargetName="Box" Property="BorderBrush" Value="{DynamicResource Accent}"/>
              <Setter TargetName="Mark" Property="Data" Value="M4,8.5 L12,8.5"/><Setter TargetName="Mark" Property="Visibility" Value="Visible"/>
            </Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.45"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Aufklappbereich mit Linien-Pfeil -->
  <Style TargetType="Expander">
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="Medium"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="Expander">
          <DockPanel>
            <ToggleButton DockPanel.Dock="Top" Cursor="Hand" FocusVisualStyle="{StaticResource FocusRing}" Foreground="{TemplateBinding Foreground}"
                          Content="{TemplateBinding Header}" IsChecked="{Binding IsExpanded, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}">
              <ToggleButton.Template>
                <ControlTemplate TargetType="ToggleButton">
                  <Border Background="Transparent" Padding="0,6">
                    <StackPanel Orientation="Horizontal">
                      <Path x:Name="Chev" Data="M5,2 L10,7 L5,12" Width="14" Height="14" Margin="0,0,8,0" VerticalAlignment="Center" RenderTransformOrigin="0.5,0.5"
                            Stroke="{DynamicResource InkMuted}" StrokeThickness="2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round">
                        <Path.RenderTransform><RotateTransform Angle="0"/></Path.RenderTransform>
                      </Path>
                      <ContentPresenter VerticalAlignment="Center" RecognizesAccessKey="False"/>
                    </StackPanel>
                  </Border>
                  <ControlTemplate.Triggers>
                    <Trigger Property="IsChecked" Value="True"><Setter TargetName="Chev" Property="RenderTransform"><Setter.Value><RotateTransform Angle="90"/></Setter.Value></Setter></Trigger>
                    <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Chev" Property="Stroke" Value="{DynamicResource Accent}"/></Trigger>
                  </ControlTemplate.Triggers>
                </ControlTemplate>
              </ToggleButton.Template>
            </ToggleButton>
            <ContentPresenter x:Name="Body" Visibility="Collapsed" Margin="22,4,0,0"/>
          </DockPanel>
          <ControlTemplate.Triggers>
            <Trigger Property="IsExpanded" Value="True"><Setter TargetName="Body" Property="Visibility" Value="Visible"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Schmale Bildlaufleisten -->
  <ControlTemplate x:Key="ThumbTpl" TargetType="Thumb">
    <Border x:Name="T" Background="{DynamicResource Line}" CornerRadius="4" Margin="2"/>
    <ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="T" Property="Background" Value="{DynamicResource InkMuted}"/></Trigger></ControlTemplate.Triggers>
  </ControlTemplate>
  <Style TargetType="ScrollBar">
    <Setter Property="Background" Value="Transparent"/>
    <Setter Property="Width" Value="12"/><Setter Property="MinWidth" Value="12"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="ScrollBar">
          <Grid Background="{TemplateBinding Background}">
            <Track x:Name="PART_Track" IsDirectionReversed="True" Orientation="{TemplateBinding Orientation}">
              <Track.Thumb><Thumb Template="{StaticResource ThumbTpl}"/></Track.Thumb>
            </Track>
          </Grid>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
    <Style.Triggers>
      <Trigger Property="Orientation" Value="Horizontal">
        <Setter Property="Width" Value="Auto"/><Setter Property="MinWidth" Value="0"/>
        <Setter Property="Height" Value="12"/><Setter Property="MinHeight" Value="12"/>
        <Setter Property="Template">
          <Setter.Value>
            <ControlTemplate TargetType="ScrollBar">
              <Grid Background="{TemplateBinding Background}">
                <Track x:Name="PART_Track" IsDirectionReversed="False" Orientation="{TemplateBinding Orientation}">
                  <Track.Thumb><Thumb Template="{StaticResource ThumbTpl}"/></Track.Thumb>
                </Track>
              </Grid>
            </ControlTemplate>
          </Setter.Value>
        </Setter>
      </Trigger>
    </Style.Triggers>
  </Style>

  <!-- Eingabefeld -->
  <Style TargetType="TextBox">
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="CaretBrush" Value="{DynamicResource Ink}"/>
    <Setter Property="SelectionBrush" Value="{DynamicResource Accent}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="MinHeight" Value="40"/>
    <Setter Property="Padding" Value="8,0"/>
    <Setter Property="VerticalContentAlignment" Value="Center"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="TextBox">
          <Border x:Name="Bd" Background="{DynamicResource SurfaceRaised}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="8">
            <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsKeyboardFocused" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource Accent}"/></Trigger>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource InkMuted}"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Auswahlliste -->
  <Style TargetType="ComboBoxItem">
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="ComboBoxItem">
          <Border x:Name="Bd" Background="Transparent" Padding="12,8" CornerRadius="4" Margin="4,2">
            <ContentPresenter/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsHighlighted" Value="True"><Setter TargetName="Bd" Property="Background" Value="{DynamicResource SurfaceRaised}"/></Trigger>
            <Trigger Property="IsSelected" Value="True"><Setter Property="Foreground" Value="{DynamicResource AccentText}"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style TargetType="ComboBox">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="MinHeight" Value="40"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="ComboBox">
          <Grid>
            <ToggleButton Focusable="False" ClickMode="Press" Cursor="Hand"
                          IsChecked="{Binding IsDropDownOpen, Mode=TwoWay, RelativeSource={RelativeSource TemplatedParent}}">
              <ToggleButton.Template>
                <ControlTemplate TargetType="ToggleButton">
                  <Border x:Name="Bd" Background="{DynamicResource SurfaceRaised}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="8">
                    <Path HorizontalAlignment="Right" VerticalAlignment="Center" Margin="0,0,14,0" Data="M0,0 L5,5 L10,0"
                          Stroke="{DynamicResource InkMuted}" StrokeThickness="2" StrokeStartLineCap="Round" StrokeEndLineCap="Round" StrokeLineJoin="Round"/>
                  </Border>
                  <ControlTemplate.Triggers>
                    <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource InkMuted}"/></Trigger>
                  </ControlTemplate.Triggers>
                </ControlTemplate>
              </ToggleButton.Template>
            </ToggleButton>
            <ContentPresenter IsHitTestVisible="False" Margin="12,0,36,0" VerticalAlignment="Center" HorizontalAlignment="Left"
                              Content="{TemplateBinding SelectionBoxItem}" ContentTemplate="{TemplateBinding SelectionBoxItemTemplate}"
                              ContentTemplateSelector="{TemplateBinding ItemTemplateSelector}"/>
            <Popup x:Name="PART_Popup" Placement="Bottom" AllowsTransparency="True" Focusable="False" PopupAnimation="None"
                   IsOpen="{Binding IsDropDownOpen, RelativeSource={RelativeSource TemplatedParent}}">
              <Border Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="8" Margin="0,4,0,0"
                      MinWidth="{Binding ActualWidth, RelativeSource={RelativeSource TemplatedParent}}" MaxHeight="{TemplateBinding MaxDropDownHeight}">
                <ScrollViewer Margin="0,4"><ItemsPresenter KeyboardNavigation.DirectionalNavigation="Contained"/></ScrollViewer>
              </Border>
            </Popup>
          </Grid>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Reiter -->
  <Style TargetType="TabControl">
    <Setter Property="Background" Value="Transparent"/>
    <Setter Property="BorderThickness" Value="0"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="TabControl">
          <DockPanel KeyboardNavigation.TabNavigation="Local">
            <Border DockPanel.Dock="Top" Background="{DynamicResource Surface}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,0,1" Padding="20,0">
              <TabPanel IsItemsHost="True" Background="Transparent"/>
            </Border>
            <ContentPresenter ContentSource="SelectedContent" Margin="{TemplateBinding Padding}"/>
          </DockPanel>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style TargetType="TabItem">
    <Setter Property="FocusVisualStyle" Value="{StaticResource FocusRing}"/>
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="FontSize" Value="13"/>
    <Setter Property="Cursor" Value="Hand"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="TabItem">
          <Border x:Name="Bd" Background="Transparent" BorderBrush="Transparent" BorderThickness="0,0,0,2" Padding="12,14,12,12" Margin="0,0,4,-1">
            <ContentPresenter ContentSource="Header" RecognizesAccessKey="False"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="{DynamicResource Ink}"/></Trigger>
            <Trigger Property="IsSelected" Value="True"><Setter Property="Foreground" Value="{DynamicResource Ink}"/><Setter TargetName="Bd" Property="BorderBrush" Value="{DynamicResource Accent}"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Tabellen -->
  <Style TargetType="DataGrid">
    <Setter Property="AutoGenerateColumns" Value="False"/>
    <Setter Property="CanUserAddRows" Value="False"/>
    <Setter Property="CanUserDeleteRows" Value="False"/>
    <Setter Property="HeadersVisibility" Value="Column"/>
    <Setter Property="GridLinesVisibility" Value="Horizontal"/>
    <Setter Property="HorizontalGridLinesBrush" Value="{DynamicResource Line}"/>
    <Setter Property="VerticalGridLinesBrush" Value="{DynamicResource Line}"/>
    <Setter Property="BorderBrush" Value="{DynamicResource Line}"/>
    <Setter Property="BorderThickness" Value="1"/>
    <Setter Property="Background" Value="{DynamicResource Surface}"/>
    <Setter Property="RowBackground" Value="{DynamicResource Surface}"/>
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="SelectionMode" Value="Single"/>
    <Setter Property="RowHeaderWidth" Value="0"/>
  </Style>
  <Style TargetType="DataGridColumnHeader">
    <Setter Property="Foreground" Value="{DynamicResource InkMuted}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="Medium"/>
    <Setter Property="FontSize" Value="12"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="DataGridColumnHeader">
          <Grid>
            <Border Background="{DynamicResource SurfaceRaised}" BorderBrush="{DynamicResource Line}" BorderThickness="0,0,1,1" Padding="10,10">
              <ContentPresenter VerticalAlignment="Center" RecognizesAccessKey="False"/>
            </Border>
            <Thumb x:Name="PART_RightHeaderGripper" HorizontalAlignment="Right" Width="6" Cursor="SizeWE">
              <Thumb.Template><ControlTemplate TargetType="Thumb"><Border Background="Transparent"/></ControlTemplate></Thumb.Template>
            </Thumb>
          </Grid>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>
  <Style TargetType="DataGridRow">
    <Style.Triggers>
      <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="{DynamicResource SurfaceRaised}"/></Trigger>
      <Trigger Property="IsSelected" Value="True"><Setter Property="Background" Value="{DynamicResource SurfaceRaised}"/></Trigger>
    </Style.Triggers>
  </Style>
  <Style TargetType="DataGridCell">
    <Setter Property="FocusVisualStyle" Value="{x:Null}"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="DataGridCell">
          <Border Background="Transparent" Padding="10,8"><ContentPresenter VerticalAlignment="Center"/></Border>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
    <Style.Triggers>
      <Trigger Property="IsSelected" Value="True"><Setter Property="Foreground" Value="{DynamicResource Ink}"/></Trigger>
    </Style.Triggers>
  </Style>
  <Style x:Key="Wrap" TargetType="TextBlock">
    <Setter Property="TextWrapping" Value="Wrap"/>
    <Setter Property="VerticalAlignment" Value="Center"/>
  </Style>
  <!-- Statusspalte: Zustandsfarbe immer zusammen mit Text -->
  <Style x:Key="LevelText" TargetType="TextBlock" BasedOn="{StaticResource Wrap}">
    <Setter Property="FontFamily" Value="{DynamicResource FontDisplay}"/>
    <Setter Property="FontWeight" Value="SemiBold"/>
    <Setter Property="Foreground" Value="{DynamicResource Success}"/>
    <Style.Triggers>
      <DataTrigger Binding="{Binding Level}" Value="1"><Setter Property="Foreground" Value="{DynamicResource AccentText}"/></DataTrigger>
      <DataTrigger Binding="{Binding Level}" Value="2"><Setter Property="Foreground" Value="{DynamicResource Warning}"/></DataTrigger>
      <DataTrigger Binding="{Binding Level}" Value="3"><Setter Property="Foreground" Value="{DynamicResource Danger}"/></DataTrigger>
    </Style.Triggers>
  </Style>
  <DataTemplate x:Key="Check">
    <CheckBox IsChecked="{Binding IsSelected, Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}" HorizontalAlignment="Center" VerticalAlignment="Center"/>
  </DataTemplate>

  <!-- Kurzinfo -->
  <Style TargetType="ToolTip">
    <Setter Property="Foreground" Value="{DynamicResource Ink}"/>
    <Setter Property="FontFamily" Value="{DynamicResource FontSans}"/>
    <Setter Property="FontSize" Value="14"/>
    <Setter Property="Template">
      <Setter.Value>
        <ControlTemplate TargetType="ToolTip">
          <Border Background="{DynamicResource SurfaceRaised}" BorderBrush="{DynamicResource Line}" BorderThickness="1" CornerRadius="8" Padding="12,8" MaxWidth="420">
            <ContentPresenter><ContentPresenter.Resources><Style TargetType="TextBlock"><Setter Property="TextWrapping" Value="Wrap"/></Style></ContentPresenter.Resources></ContentPresenter>
          </Border>
        </ControlTemplate>
      </Setter.Value>
    </Setter>
  </Style>

  <!-- Fortschrittsbalken -->
  <Style TargetType="ProgressBar">
    <Setter Property="Foreground" Value="{DynamicResource Accent}"/>
    <Setter Property="Background" Value="{DynamicResource SurfaceRaised}"/>
    <Setter Property="BorderThickness" Value="0"/>
    <Setter Property="Height" Value="4"/>
  </Style>
</ResourceDictionary>
'@

# ============================================================================
#  Funktionen
# ============================================================================
$script:ThemeMode = 'dark'

function Initialize-Theme([string]$Mode = 'dark') {
    if (-not [Windows.Application]::Current) {
        $script:App = New-Object Windows.Application
        $script:App.ShutdownMode = [Windows.ShutdownMode]::OnExplicitShutdown
    }
    $res = [Windows.Application]::Current.Resources
    $res.MergedDictionaries.Clear()
    $res.MergedDictionaries.Add([Windows.Markup.XamlReader]::Parse($script:ThemeXaml))
    Set-BrandFonts
    Set-ThemeMode $Mode
}

# Legt eine Ressource ab. Wichtig: immer das echte .NET-Objekt speichern - die Index-Schreibweise
# $dict[$key] = $wert würde in PowerShell die PSObject-Hülle ablegen, die WPF nicht versteht.
function Set-AppResource([string]$Key, $Value) {
    $res = [Windows.Application]::Current.Resources
    if ($res.Contains($Key)) { $res.Remove($Key) }
    $res.Add($Key, $Value.PSObject.BaseObject)
}

# Setzt alle Farb-Tokens und das passende Logo (wirkt sofort auf die ganze Oberfläche)
function Set-ThemeMode([string]$Mode) {
    if (-not $script:ThemeTokens.ContainsKey($Mode)) { $Mode = 'dark' }
    $script:ThemeMode = $Mode
    $res = [Windows.Application]::Current.Resources
    foreach ($t in $script:ThemeTokens[$Mode].GetEnumerator()) {
        $b = New-Object Windows.Media.SolidColorBrush([Windows.Media.ColorConverter]::ConvertFromString($t.Value))
        $b.Freeze()
        Set-AppResource $script:TokenKey[$t.Key] $b
    }
    $logo = Join-Path $AppDir $(if ($Mode -eq 'light') { 'assets\tunerig-logo-hell.png' } else { 'assets\tunerig-logo-dunkel.png' })
    if (Test-Path -LiteralPath $logo) {
        $img = New-Object Windows.Media.Imaging.BitmapImage
        $img.BeginInit(); $img.CacheOption = 'OnLoad'; $img.UriSource = New-Object Uri($logo); $img.EndInit(); $img.Freeze()
        Set-AppResource 'LogoImage' $img
    }
}

function Get-ThemeColor([string]$Token) { $script:ThemeTokens[$script:ThemeMode][$Token] }
function Get-ThemeBrush([string]$Token) { [Windows.Application]::Current.Resources[$script:TokenKey[$Token]] }

# Bindet eine Eigenschaft (Foreground, Background, BorderBrush, Stroke, Fill ...) an ein Token.
# Die Bindung bleibt lebendig: Beim Umschalten Hell/Dunkel ändert sich die Farbe automatisch.
function Set-ThemeRef($Element, [string]$Property, [string]$Token) {
    if (-not $Element -or -not $Token) { return }
    $key = $script:TokenKey[$Token]
    if (-not $key) { throw "Unbekanntes Farb-Token: $Token" }
    $f = $Element.GetType().GetField("${Property}Property", [Reflection.BindingFlags]'Public, Static, FlattenHierarchy')
    $Element.SetResourceReference($f.GetValue($null), $key)
}

# Wendet eine Schriftrolle (h1, h2, h3, title, body, small, label, metric, metric-small) an
function Set-TypeRole($Element, [string]$Role) {
    $r = $script:TypeScale[$Role]
    if (-not $r) { return }
    $f = $Element.GetType().GetField('FontFamilyProperty', [Reflection.BindingFlags]'Public, Static, FlattenHierarchy')
    $Element.SetResourceReference($f.GetValue($null), $script:FontKey[$r.Family])
    $Element.FontSize = $r.Size
    $Element.FontWeight = [Windows.FontWeights]::($r.Weight)
    if ($Element -is [Windows.Controls.TextBlock]) {
        $Element.LineHeight = $r.Line
        $Element.LineStackingStrategy = 'BlockLineHeight'
    }
}

# Label-Stil: Versalien mit erhöhter Laufweite (schmales Leerzeichen zwischen den Zeichen, ca. 0,2 em)
function Format-Caps([string]$Text) {
    if (-not $Text) { return '' }
    $thin = [string][char]0x2009
    (($Text.ToUpper().ToCharArray() | ForEach-Object { [string]$_ }) -join $thin) -replace "$thin $thin", '  '
}

# Wandelt alle mit Tag="caps" markierten Beschriftungen (TextBlock, TabItem, Spaltenköpfe) in den Label-Stil um
function Set-CapsLabels($Root) {
    $queue = New-Object System.Collections.Queue
    $queue.Enqueue($Root)
    while ($queue.Count -gt 0) {
        $o = $queue.Dequeue()
        if ($o -is [Windows.Controls.TextBlock] -and $o.Tag -eq 'caps') { [Windows.Automation.AutomationProperties]::SetName($o, $o.Text); $o.Text = Format-Caps $o.Text }
        elseif ($o -is [Windows.Controls.TabItem] -and $o.Header -is [string]) { $o.Header = Format-Caps $o.Header.Trim() }
        elseif ($o -is [Windows.Controls.DataGrid]) { foreach ($c in $o.Columns) { if ($c.Header -is [string] -and $c.Header) { $c.Header = Format-Caps $c.Header } } }
        if ($o -is [Windows.DependencyObject]) {
            foreach ($child in [Windows.LogicalTreeHelper]::GetChildren($o)) { if ($child -is [Windows.DependencyObject]) { $queue.Enqueue($child) } }
        }
    }
}

function New-Label([string]$Text, [string]$Token = 'ink-muted') {
    $t = New-Object Windows.Controls.TextBlock
    $t.Text = Format-Caps $Text
    [Windows.Automation.AutomationProperties]::SetName($t, $Text)
    Set-TypeRole $t 'label'
    Set-ThemeRef $t Foreground $Token
    return $t
}

# Linien-Icon im 24-px-Raster
function New-LineIcon([string]$Kind, [string]$Token = 'ink', [double]$Size = 20) {
    $p = New-Object Windows.Shapes.Path
    $p.Data = [Windows.Media.Geometry]::Parse($script:IconPaths[$Kind])
    $p.StrokeThickness = 2
    $p.StrokeStartLineCap = 'Round'; $p.StrokeEndLineCap = 'Round'; $p.StrokeLineJoin = 'Round'
    Set-ThemeRef $p Stroke $Token
    $c = New-Object Windows.Controls.Canvas
    $c.Width = 24; $c.Height = 24
    [void]$c.Children.Add($p)
    $v = New-Object Windows.Controls.Viewbox
    $v.Width = $Size; $v.Height = $Size
    $v.Child = $c
    return $v
}

# Sechseckiges Status-Abzeichen (Motiv aus dem Logo, sparsam eingesetzt)
function New-HexBadge([int]$Level, [double]$Size = 44) {
    $g = New-Object Windows.Controls.Grid
    $g.Width = $Size; $g.Height = $Size
    $hex = New-Object Windows.Shapes.Path
    $hex.Data = [Windows.Media.Geometry]::Parse('M22,2.5 L39,12.25 L39,31.75 L22,41.5 L5,31.75 L5,12.25 Z')
    $hex.StrokeThickness = 2; $hex.StrokeLineJoin = 'Round'; $hex.Stretch = 'Uniform'
    Set-ThemeRef $hex Stroke $script:LevelToken[$Level]
    [void]$g.Children.Add($hex)
    $glyph = @{ 0 = 'check'; 1 = 'info'; 2 = 'warning'; 3 = 'danger' }[$Level]
    $i = New-LineIcon $glyph $script:LevelToken[$Level] ($Size * 0.45)
    $i.HorizontalAlignment = 'Center'; $i.VerticalAlignment = 'Center'
    [void]$g.Children.Add($i)
    return $g
}

# Karte mit farbiger Statuskante links (Hinweis, Verbesserung, Problem)
function New-StateCard([int]$Level, [bool]$Stripe, [Windows.Thickness]$Padding) {
    $outer = New-Object Windows.Controls.Border
    $outer.Style = [Windows.Application]::Current.Resources['Card']
    $outer.Padding = New-Object Windows.Thickness(0)
    $dock = New-Object Windows.Controls.DockPanel
    if ($Stripe) {
        $st = New-Object Windows.Controls.Border
        $st.Width = 4; $st.CornerRadius = New-Object Windows.CornerRadius(7, 0, 0, 7)
        Set-ThemeRef $st Background $script:LevelToken[$Level]
        [Windows.Controls.DockPanel]::SetDock($st, 'Left'); [void]$dock.Children.Add($st)
    }
    $inner = New-Object Windows.Controls.Border
    $inner.Padding = $Padding
    [void]$dock.Children.Add($inner)
    $outer.Child = $dock
    return @{ Outer = $outer; Inner = $inner }
}

# Segmentierte Anzeige (z. B. Wirkung 1-3): aktive Segmente in accent, inaktive in line
function New-SegmentMeter([int]$Value, [int]$Max = 3, [string]$Token = 'accent') {
    $sp = New-Object Windows.Controls.StackPanel
    $sp.Orientation = 'Horizontal'; $sp.VerticalAlignment = 'Center'
    for ($i = 1; $i -le $Max; $i++) {
        $b = New-Object Windows.Controls.Border
        $b.Width = 12; $b.Height = 6; $b.CornerRadius = New-Object Windows.CornerRadius(1); $b.Margin = New-Object Windows.Thickness(0, 0, 3, 0)
        Set-ThemeRef $b Background $(if ($i -le $Value) { $Token } else { 'line' })
        [void]$sp.Children.Add($b)
    }
    return $sp
}

# --- Schriften ---------------------------------------------------------------
function Get-BrandFontFamily($Spec) {
    $dir = Join-Path $script:FontDir $Spec.Folder
    $files = @(Get-ChildItem -LiteralPath $dir -Filter *.ttf -ErrorAction SilentlyContinue)
    if ($files.Count -gt 0) {
        try { return New-Object Windows.Media.FontFamily((New-Object Uri($dir.TrimEnd('\') + '\')), "./#$($Spec.Family), $($Spec.Fallback)") } catch {}
    }
    return New-Object Windows.Media.FontFamily($Spec.Fallback)
}

function Set-BrandFonts {
    $res = [Windows.Application]::Current.Resources
    foreach ($s in $script:FontSpec) { Set-AppResource $s.Key (Get-BrandFontFamily $s) }
}

function Test-BrandFontsComplete {
    foreach ($s in $script:FontSpec) { if (-not (Get-ChildItem -LiteralPath (Join-Path $script:FontDir $s.Folder) -Filter *.ttf -ErrorAction SilentlyContinue)) { return $false } }
    return $true
}

# Lädt fehlende Schriften einmalig im Hintergrund aus dem offiziellen Google-Fonts-Archiv
# (github.com/google/fonts, SIL Open Font License). Ohne Internet bleibt der Ersatz aktiv.
function Start-BrandFontDownload {
    if (Test-BrandFontsComplete) { return }
    $ps = [powershell]::Create()
    [void]$ps.AddScript({
        param($FontDir, $Specs)
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $ok = 0
        foreach ($s in $Specs) {
            $dir = Join-Path $FontDir $s.Folder
            if (Get-ChildItem -LiteralPath $dir -Filter *.ttf -ErrorAction SilentlyContinue) { continue }
            try {
                $list = Invoke-RestMethod -UseBasicParsing -Uri "https://api.github.com/repos/google/fonts/contents/ofl/$($s.Folder)" -Headers @{ 'User-Agent' = 'TuneRig' } -TimeoutSec 20
                $want = @($list | Where-Object { $_.name -match $s.Rx -or $_.name -eq 'OFL.txt' })
                if (-not ($want | Where-Object { $_.name -like '*.ttf' })) { continue }
                $tmp = "$dir.download"
                New-Item -ItemType Directory -Force -Path $tmp | Out-Null
                foreach ($f in $want) { Invoke-WebRequest -UseBasicParsing -Uri $f.download_url -OutFile (Join-Path $tmp $f.name) -TimeoutSec 60 }
                if (Test-Path -LiteralPath $dir) { Remove-Item -LiteralPath $dir -Recurse -Force }
                Rename-Item -LiteralPath $tmp -NewName (Split-Path $dir -Leaf)
                $ok++
            } catch {}
        }
        $ok
    }).AddArgument($script:FontDir).AddArgument($script:FontSpec)
    $script:FontJob = @{ PS = $ps; Handle = $ps.BeginInvoke() }
    $script:FontTimer = New-Object Windows.Threading.DispatcherTimer
    $script:FontTimer.Interval = [TimeSpan]::FromSeconds(1)
    $script:FontTimer.Add_Tick({
        if (-not $script:FontJob.Handle.IsCompleted) { return }
        $script:FontTimer.Stop()
        try { $n = @($script:FontJob.PS.EndInvoke($script:FontJob.Handle))[-1]; $script:FontJob.PS.Dispose() } catch { $n = 0 }
        if ($n -gt 0) { Set-BrandFonts }
    })
    $script:FontTimer.Start()
}

# --- Fenster: Icon, dunkle Titelleiste, eigene Taskleisten-Gruppe -------------
if (-not ('TuneRig.Win' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace TuneRig {
    public static class Win {
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] static extern int SetCurrentProcessExplicitAppUserModelID(string id);
        public static void DarkTitleBar(IntPtr hwnd, bool dark) {
            int v = dark ? 1 : 0;
            try { if (DwmSetWindowAttribute(hwnd, 20, ref v, 4) != 0) DwmSetWindowAttribute(hwnd, 19, ref v, 4); } catch { }
        }
        public static void SetAppId(string id) { try { SetCurrentProcessExplicitAppUserModelID(id); } catch { } }
    }
}
'@
}

function Set-WindowBranding($Window) {
    $ico = Join-Path $AppDir 'assets\tunerig.ico'
    if (Test-Path -LiteralPath $ico) { try { $Window.Icon = [Windows.Media.Imaging.BitmapFrame]::Create((New-Object Uri($ico))) } catch {} }
    $Window.Add_SourceInitialized({
        param($s, $e)
        try { [TuneRig.Win]::DarkTitleBar((New-Object Windows.Interop.WindowInteropHelper($s)).Handle, $script:ThemeMode -eq 'dark') } catch {}
    })
}

function Update-TitleBar($Window) {
    try { [TuneRig.Win]::DarkTitleBar((New-Object Windows.Interop.WindowInteropHelper($Window)).Handle, $script:ThemeMode -eq 'dark') } catch {}
}
