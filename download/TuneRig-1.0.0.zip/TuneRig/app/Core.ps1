﻿# ============================================================================
#  TuneRig (portabel) - Kernfunktionen
#  Diese Datei enthält die gesamte Logik ohne Oberfläche. Sie wird sowohl im
#  Hauptfenster als auch in den Hintergrund-Threads geladen.
# ============================================================================

$ErrorActionPreference = 'Continue'

# ---------------------------------------------------------------------------
#  Native Hilfsfunktionen (Papierkorb, Energiemodus, Konsolenfenster)
# ---------------------------------------------------------------------------
if (-not ('PCO.Native' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace PCO
{
    /// Universelle Tabellenzeile mit Änderungsbenachrichtigung (für Checkboxen in DataGrids)
    public class Row : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void N(string n) { var h = PropertyChanged; if (h != null) h(this, new PropertyChangedEventArgs(n)); }

        private bool _sel; private int _lvl;
        private string _a, _b, _c, _d, _e, _f;
        public bool IsSelected { get { return _sel; } set { _sel = value; N("IsSelected"); } }
        public int Level { get { return _lvl; } set { _lvl = value; N("Level"); } }
        public string A { get { return _a; } set { _a = value; N("A"); } }
        public string B { get { return _b; } set { _b = value; N("B"); } }
        public string C { get { return _c; } set { _c = value; N("C"); } }
        public string D { get { return _d; } set { _d = value; N("D"); } }
        public string E { get { return _e; } set { _e = value; N("E"); } }
        public string F { get { return _f; } set { _f = value; N("F"); } }
        public long N1 { get; set; }
        public object Tag { get; set; }
    }

    public static class Native
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        private struct SHFILEOPSTRUCT
        {
            public IntPtr hwnd; public uint wFunc; public string pFrom; public string pTo;
            public ushort fFlags; public bool fAnyOperationsAborted; public IntPtr hNameMappings; public string lpszProgressTitle;
        }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHFileOperation(ref SHFILEOPSTRUCT op);

        /// Verschiebt Datei oder Ordner in den Papierkorb
        public static bool Recycle(string path)
        {
            if (!System.IO.File.Exists(path) && !System.IO.Directory.Exists(path)) return true;
            var op = new SHFILEOPSTRUCT();
            op.wFunc = 3; // FO_DELETE
            op.pFrom = path + "\0\0";
            op.fFlags = 0x0040 | 0x0010 | 0x0004 | 0x0400; // ALLOWUNDO | NOCONFIRMATION | SILENT | NOERRORUI
            int r = SHFileOperation(ref op);
            return r == 0 && !op.fAnyOperationsAborted && !System.IO.File.Exists(path) && !System.IO.Directory.Exists(path);
        }

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool MoveFileEx(string existing, string newName, int flags);
        public static bool DeleteOnReboot(string path) { return MoveFileEx(path, null, 4); }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        private struct SHQUERYRBINFO { public int cbSize; public long i64Size; public long i64NumItems; }
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHQueryRecycleBin(string root, ref SHQUERYRBINFO info);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] private static extern int SHEmptyRecycleBin(IntPtr hwnd, string root, uint flags);

        public static long[] QueryRecycleBin()
        {
            var i = new SHQUERYRBINFO(); i.cbSize = Marshal.SizeOf(typeof(SHQUERYRBINFO));
            if (SHQueryRecycleBin(null, ref i) != 0) return new long[] { 0, 0 };
            return new long[] { i.i64Size, i.i64NumItems };
        }
        public static void EmptyRecycleBin() { SHEmptyRecycleBin(IntPtr.Zero, null, 0x7); }

        [DllImport("powrprof.dll")] private static extern uint PowerGetEffectiveOverlayScheme(out Guid g);
        [DllImport("powrprof.dll")] private static extern uint PowerSetActiveOverlayScheme(Guid g);
        public static string GetOverlay()
        {
            try { Guid g; return PowerGetEffectiveOverlayScheme(out g) == 0 ? g.ToString() : ""; } catch { return ""; }
        }
        public static bool SetOverlay(string guid)
        {
            try { return PowerSetActiveOverlayScheme(new Guid(guid)) == 0; } catch { return false; }
        }

        [DllImport("srclient.dll")] private static extern int SRRemoveRestorePoint(int sequenceNumber);
        /// Löscht einen Wiederherstellungspunkt anhand seiner Nummer (0 = Erfolg)
        public static int RemoveRestorePoint(int sequenceNumber) { try { return SRRemoveRestorePoint(sequenceNumber); } catch { return -1; } }


        // ---- Bildschirme: Bildwiederholrate erkennen und einstellen ----
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DISPLAY_DEVICE
        {
            public int cb;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceString;
            public int StateFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceID;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)] public string DeviceKey;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct DEVMODE
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmDeviceName;
            public short dmSpecVersion; public short dmDriverVersion; public short dmSize; public short dmDriverExtra;
            public int dmFields;
            public int dmPositionX; public int dmPositionY; public int dmDisplayOrientation; public int dmDisplayFixedOutput;
            public short dmColor; public short dmDuplex; public short dmYResolution; public short dmTTOption; public short dmCollate;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string dmFormName;
            public short dmLogPixels;
            public int dmBitsPerPel; public int dmPelsWidth; public int dmPelsHeight; public int dmDisplayFlags; public int dmDisplayFrequency;
            public int dmICMMethod; public int dmICMIntent; public int dmMediaType; public int dmDitherType;
            public int dmReserved1; public int dmReserved2; public int dmPanningWidth; public int dmPanningHeight;
        }

        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool EnumDisplayDevices(string lpDevice, uint iDevNum, ref DISPLAY_DEVICE lpDisplayDevice, uint dwFlags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool EnumDisplaySettings(string deviceName, int modeNum, ref DEVMODE devMode);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int ChangeDisplaySettingsEx(string lpszDeviceName, ref DEVMODE lpDevMode, IntPtr hwnd, uint dwflags, IntPtr lParam);

        private static DEVMODE NewDevMode() { var d = new DEVMODE(); d.dmSize = (short)Marshal.SizeOf(typeof(DEVMODE)); return d; }

        /// Pro aktivem Bildschirm: "Gerät|Monitor|Breite|Höhe|Hz|MaxHz|Grafikkarte"
        public static string[] GetDisplays()
        {
            var list = new System.Collections.Generic.List<string>();
            for (uint i = 0; i < 16; i++)
            {
                var dd = new DISPLAY_DEVICE(); dd.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                if (!EnumDisplayDevices(null, i, ref dd, 0)) break;
                if ((dd.StateFlags & 1) == 0) continue; // nicht mit dem Desktop verbunden
                var cur = NewDevMode();
                if (!EnumDisplaySettings(dd.DeviceName, -1, ref cur)) continue;
                int max = cur.dmDisplayFrequency;
                var m = NewDevMode();
                for (int k = 0; EnumDisplaySettings(dd.DeviceName, k, ref m); k++)
                {
                    if (m.dmPelsWidth == cur.dmPelsWidth && m.dmPelsHeight == cur.dmPelsHeight &&
                        m.dmBitsPerPel == cur.dmBitsPerPel && m.dmDisplayFrequency > max && m.dmDisplayFrequency < 1000)
                        max = m.dmDisplayFrequency;
                    m = NewDevMode();
                }
                string mon = "";
                var md = new DISPLAY_DEVICE(); md.cb = Marshal.SizeOf(typeof(DISPLAY_DEVICE));
                if (EnumDisplayDevices(dd.DeviceName, 0, ref md, 0)) mon = md.DeviceString;
                list.Add(dd.DeviceName + "|" + mon + "|" + cur.dmPelsWidth + "|" + cur.dmPelsHeight + "|" +
                         cur.dmDisplayFrequency + "|" + max + "|" + dd.DeviceString);
            }
            return list.ToArray();
        }

        /// Stellt die Bildwiederholrate bei gleicher Auflösung um (0 = Erfolg)
        public static int SetRefreshRate(string deviceName, int hz)
        {
            var dm = NewDevMode();
            if (!EnumDisplaySettings(deviceName, -1, ref dm)) return -99;
            dm.dmDisplayFrequency = hz;
            dm.dmFields = 0x400000; // DM_DISPLAYFREQUENCY
            int r = ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 2, IntPtr.Zero); // CDS_TEST
            if (r != 0) return r;
            return ChangeDisplaySettingsEx(deviceName, ref dm, IntPtr.Zero, 1, IntPtr.Zero); // CDS_UPDATEREGISTRY
        }

        // ---- Mausbeschleunigung sofort übernehmen ----
        [DllImport("user32.dll", SetLastError = true)] private static extern bool SystemParametersInfo(uint action, uint param, int[] vparam, uint winIni);
        public static bool SetMouseAcceleration(bool on)
        {
            int[] v = on ? new int[] { 6, 10, 1 } : new int[] { 0, 0, 0 };
            return SystemParametersInfo(0x0004, 0, v, 3); // SPI_SETMOUSE, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
        }

        [DllImport("kernel32.dll")] private static extern IntPtr GetConsoleWindow();
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr h, int cmd);
        public static void HideConsole() { var h = GetConsoleWindow(); if (h != IntPtr.Zero) ShowWindow(h, 0); }
    }
}
'@
}

# ---------------------------------------------------------------------------
#  Allgemeine Helfer
# ---------------------------------------------------------------------------
function Report([string]$Text) { if ($Sync) { $Sync.Status = $Text } }

# Einfache Erklärungen ("Was kann ich tun?") und passende Aktionen für jedes Prüfergebnis.
# Aktionsziele: open:<Programm/URI>  goto:<Schritt>  web:<URL>  search:<Suchbegriff>  wu (Windows Update)  vendor (Grafik-Hersteller)  recheck
$script:FindingHelp = @(
    @{ P = '^Veraltete Windows-Version'; D = 'Windows Update öffnen und alle Updates installieren.'; B = 'Mehr Sicherheit, neue Funktionen und Leistungsverbesserungen.'; H = 'Öffne Windows Update und installiere alle angebotenen Updates. Ein großes Funktionsupdate (z. B. auf Windows 11) wird dort ebenfalls angeboten. Sichere vorher deine wichtigen Daten.'
       A = @(@{ L = 'Windows Update öffnen'; T = 'open:ms-settings:windowsupdate' }) }
    @{ P = '^Wenig Arbeitsspeicher'; D = 'Weniger Programme gleichzeitig öffnen. Dauerhaft hilft nur mehr RAM (16 GB).'; B = 'Der PC bleibt auch mit vielen offenen Programmen flüssig.'; H = 'Der Arbeitsspeicher (RAM) ist das Kurzzeitgedächtnis des PCs. Ist er voll, wird alles langsam. Sofort hilft: weniger Programme und Browser-Tabs gleichzeitig öffnen. Dauerhaft hilft: RAM aufrüsten. Welcher passt, steht im Handbuch deines PCs oder Mainboards.'
       A = @(@{ L = 'Task-Manager öffnen (zeigt die RAM-Auslastung)'; T = 'open:taskmgr.exe' }) }
    @{ P = '^Nur ein RAM-Modul'; D = 'Ein zweites, baugleiches RAM-Modul einbauen lassen.'; B = 'Bis zu doppelte Speichergeschwindigkeit – spürbar mehr FPS in Spielen.'; H = 'Ein zweites, baugleiches Modul einsetzen (gleiche Größe und Geschwindigkeit). Das ist eine Hardware-Änderung; ein PC-Fachhändler hilft gerne. Nicht dringend – der PC funktioniert auch so.'; A = @() }
    @{ P = '^Arbeitsspeicher läuft evtl'; D = 'Im BIOS das Speicherprofil XMP bzw. EXPO einschalten (nur für Erfahrene).'; B = 'Der Arbeitsspeicher läuft mit seiner vollen Geschwindigkeit.'; H = 'Im BIOS/UEFI (Einstellungsmenü beim Einschalten des PCs) kann das Speicherprofil XMP bzw. EXPO aktiviert werden. Wenn du unsicher bist, lass es einfach so – das ist nur eine Optimierung.'; A = @() }
    @{ P = '^BIOS/UEFI ist älter'; D = 'Nur bei Problemen: neuestes BIOS von der Herstellerseite installieren.'; B = 'Mehr Stabilität und Sicherheit.'; H = 'Such auf der Support-Seite des Mainboard- bzw. PC-Herstellers nach dem neuesten BIOS und befolge die Anleitung genau. Läuft dein PC stabil, ist das nicht dringend.'; A = @() }
    @{ P = '^Laufwerk meldet Probleme'; D = 'Sofort wichtige Dateien sichern und das Laufwerk tauschen lassen.'; B = 'Schutz vor Datenverlust.'; H = 'Sichere jetzt deine wichtigen Dateien (Fotos, Dokumente) auf einen USB-Stick, eine externe Festplatte oder in die Cloud. Lass das Laufwerk danach austauschen.'; A = @() }
    @{ P = 'Festplatte \(HDD\)'; D = 'Eine SSD einbauen lassen (z. B. beim PC-Fachhändler).'; B = 'Start und Programme werden um ein Vielfaches schneller.'; H = 'Eine SSD einbauen und Windows darauf umziehen. SSDs mit 500 GB sind heute günstig. Ein PC-Fachhändler übernimmt Einbau und Umzug auf Wunsch.'; A = @() }
    @{ P = '^Systemlaufwerk fast voll'; D = 'Im Schritt Aufräumen Platz schaffen und nicht genutzte Programme entfernen.'; B = 'Windows bleibt schnell und kann Updates installieren.'; H = 'Im Schritt Aufräumen löschst du unnötige Dateien mit einem Klick. Entferne außerdem Programme, die du nicht mehr nutzt, und verschiebe große Videos auf eine externe Festplatte.'
       A = @(@{ L = 'Zum Aufräumen'; T = 'goto:cleanup' }, @{ L = 'Programme deinstallieren'; T = 'goto:uninstall' }) }
    @{ P = '^(Fehlender Treiber|Geräteproblem)'; D = 'Bei Windows Update nach Treibern suchen.'; B = 'Das Gerät funktioniert wieder vollständig.'; H = 'Meist hilft eine Suche bei Windows Update. Findet Windows nichts, gibt es den Treiber auf der Webseite des Geräte- oder PC-Herstellers. Im Geräte-Manager ist das Gerät mit einem gelben Warnzeichen markiert.'
       A = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) }
    @{ P = '^(Kein Grafiktreiber|Grafiktreiber veraltet|Grafikkarte ohne Treiber)'; D = 'Das Treiber-Programm des Grafikkarten-Herstellers installieren.'; B = 'Volle Grafikleistung, richtige Auflösung, flüssige Spiele.'; H = 'Lade das kostenlose Treiber-Programm des Grafikkarten-Herstellers herunter. Es erkennt deine Grafikkarte automatisch, installiert den passenden Treiber und meldet künftige Updates von selbst.'
       A = @(@{ L = 'Treiber-Seite des Herstellers öffnen'; T = 'vendor' }) }
    @{ P = '^Nur integrierte Grafik'; D = 'Nichts nötig. In Spielen niedrigere Grafikdetails wählen.'; B = ''; H = 'Für einfache Spiele und Videos reicht das. In Spielen hilft es, niedrigere Grafikdetails und eine geringere Auflösung einzustellen. Für aktuelle 3D-Spiele wäre eine dedizierte Grafikkarte nötig.'; A = @() }
    @{ P = '^Monitor ist vermutlich am Mainboard'; D = 'Monitorkabel hinten am PC in die Grafikkarte stecken (die unteren Anschlüsse).'; B = 'Spiele nutzen die volle Grafikkarte - oft ein Vielfaches an FPS.'; H = 'PC herunterfahren, das Monitorkabel hinten abziehen und in einen Anschluss der Grafikkarte stecken. Das sind die waagerecht angeordneten Anschlüsse weiter unten am Gehäuse. PC wieder starten und hier auf Erneut prüfen klicken.'
       A = @(@{ L = 'Erneut prüfen'; T = 'recheck' }) }
    @{ P = '^(Hybrid-Grafik|Mehrere Grafikkarten)'; D = 'Spiele auf Hohe Leistung stellen.'; B = 'Spiele laufen auf der starken Grafikkarte.'; H = 'Stell deine Spiele auf Hohe Leistung. Im geführten Check geht das im Schritt Leistung mit einem Klick, unter Alle Werkzeuge im Reiter Grafikkarten.'; A = @() }
)

function New-Finding([int]$Level, [string]$Category, [string]$Title, [string]$Detail, [string]$Help = '', $Actions = $null, [string]$Do = '', [string]$Benefit = '') {
    foreach ($h in $script:FindingHelp) {
        if ($Title -match $h.P) {
            if (-not $Help) { $Help = $h.H }
            if ($null -eq $Actions) { $Actions = $h.A }
            if (-not $Do) { $Do = $h.D }
            if (-not $Benefit) { $Benefit = $h.B }
            break
        }
    }
    if ($null -eq $Actions) { $Actions = @() }
    [pscustomobject]@{ Level = $Level; Category = $Category; Title = $Title; Detail = $Detail; Help = $Help; Actions = @($Actions); Do = $Do; Benefit = $Benefit }
}

function Format-Bytes([double]$Bytes) {
    $u = 'B', 'KB', 'MB', 'GB', 'TB'; $i = 0
    while ($Bytes -ge 1024 -and $i -lt 4) { $Bytes /= 1024; $i++ }
    '{0:0.##} {1}' -f $Bytes, $u[$i]
}

function Get-RegValue([string]$Hive, [string]$Path, [string]$Name, $Default = $null) {
    try {
        $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
        $k = $root.OpenSubKey($Path)
        if (-not $k) { return $Default }
        $v = $k.GetValue($Name, $Default); $k.Close(); return $v
    } catch { return $Default }
}

function Set-RegDword([string]$Hive, [string]$Path, [string]$Name, [int]$Value) {
    $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
    $k = $root.CreateSubKey($Path)
    $k.SetValue($Name, $Value, [Microsoft.Win32.RegistryValueKind]::DWord); $k.Close()
}

function Set-RegString([string]$Hive, [string]$Path, [string]$Name, [string]$Value) {
    $root = if ($Hive -eq 'HKLM') { [Microsoft.Win32.Registry]::LocalMachine } else { [Microsoft.Win32.Registry]::CurrentUser }
    $k = $root.CreateSubKey($Path)
    $k.SetValue($Name, $Value, [Microsoft.Win32.RegistryValueKind]::String); $k.Close()
}

function Test-IsLaptop {
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
    $bat = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
    return (($cs -and $cs.PCSystemType -eq 2) -or $bat.Count -gt 0)
}

# ---------------------------------------------------------------------------
#  Wiederherstellungspunkt
# ---------------------------------------------------------------------------
function New-PCORestorePoint([string]$Description) {
    try {
        # Windows erlaubt sonst nur einen Punkt pro 24 Stunden
        Set-RegDword 'HKLM' 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore' 'SystemRestorePointCreationFrequency' 0
        try { Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue } catch {}
        Checkpoint-Computer -Description ("TuneRig: " + $Description) -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        return [pscustomobject]@{ Ok = $true; Message = 'Wiederherstellungspunkt wurde erstellt.' }
    } catch {
        return [pscustomobject]@{ Ok = $false; Message = 'Wiederherstellungspunkt konnte nicht erstellt werden: ' + $_.Exception.Message }
    }
}

function Get-PCORestorePoints {
    $types = @{ 0 = 'Programm installiert'; 1 = 'Programm deinstalliert'; 6 = 'Wiederherstellung'; 7 = 'Prüfpunkt'; 10 = 'Treiber installiert'; 12 = 'Einstellungen geändert'; 13 = 'Abgebrochen' }
    $list = @()
    foreach ($rp in @(Get-ComputerRestorePoint -ErrorAction SilentlyContinue)) {
        $date = $null
        try { $date = [Management.ManagementDateTimeConverter]::ToDateTime($rp.CreationTime) } catch {}
        $t = [int]$rp.RestorePointType
        $list += [pscustomobject]@{
            Sequence = [int]$rp.SequenceNumber; Description = [string]$rp.Description; Date = $date
            DateText = $(if ($date) { $date.ToString('dd.MM.yyyy  HH:mm') } else { '-' })
            Type = $(if ($types.ContainsKey($t)) { $types[$t] } else { "Typ $t" })
            ByUs = ([string]$rp.Description) -match '^(TuneRig|PC Optimizer)'
        }
    }
    $list | Sort-Object Sequence -Descending
}

function Remove-PCORestorePoints([int[]]$Sequences) {
    $ok = 0; $fail = 0
    foreach ($n in $Sequences) { if ([PCO.Native]::RemoveRestorePoint($n) -eq 0) { $ok++ } else { $fail++ } }
    [pscustomobject]@{ Ok = $ok; Failed = $fail }
}

# ---------------------------------------------------------------------------
#  System & Hardware
# ---------------------------------------------------------------------------
function Get-SystemAnalysis {
    $f = New-Object System.Collections.ArrayList
    $sum = New-Object System.Collections.ArrayList
    function S($l, $v) { [void]$sum.Add([pscustomobject]@{ Label = $l; Value = $v }) }

    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $cs = Get-CimInstance Win32_ComputerSystem
    $mem = @(Get-CimInstance Win32_PhysicalMemory)
    $board = Get-CimInstance Win32_BaseBoard
    $bios = Get-CimInstance Win32_BIOS
    $gpus = @(Get-CimInstance Win32_VideoController)
    $isLaptop = Test-IsLaptop

    S 'Betriebssystem' ("{0} ({1}), Build {2}" -f $os.Caption, $os.OSArchitecture, $os.BuildNumber)
    S 'Gerätetyp' $(if ($isLaptop) { 'Laptop' } else { 'Desktop-PC' })
    S 'Prozessor' ("{0} - {1} Kerne / {2} Threads" -f $cpu.Name.Trim(), $cpu.NumberOfCores, $cpu.NumberOfLogicalProcessors)

    $ramTotal = [long]$cs.TotalPhysicalMemory
    $speed = ($mem | Measure-Object -Property ConfiguredClockSpeed -Maximum).Maximum
    S 'Arbeitsspeicher' ("{0} in {1} Modul(en){2}" -f (Format-Bytes $ramTotal), $mem.Count, $(if ($speed) { ", $speed MT/s" } else { '' }))
    S 'Grafik' (($gpus | ForEach-Object { $_.Name }) -join "`n")
    S 'Mainboard' ("{0} {1}" -f $board.Manufacturer, $board.Product)
    S 'BIOS/UEFI' ("{0} vom {1:dd.MM.yyyy}" -f $bios.SMBIOSBIOSVersion, $bios.ReleaseDate)

    if ([int]$os.BuildNumber -lt 19045) {
        [void]$f.Add((New-Finding 2 'System' 'Veraltete Windows-Version' "Build $($os.BuildNumber) erhält keine Updates mehr. Ein Upgrade auf eine aktuelle Windows-Version wird empfohlen."))
    }
    if ($ramTotal -gt 0 -and $ramTotal -lt 8GB) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Wenig Arbeitsspeicher' 'Weniger als 8 GB RAM. Für Spiele und moderne Anwendungen sind 16 GB empfehlenswert.'))
    }
    if ($mem.Count -eq 1 -and $ramTotal -ge 8GB) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Nur ein RAM-Modul (Single-Channel)' 'Mit zwei gleichen Modulen (Dual-Channel) steigt die Speicherbandbreite deutlich. Das bringt vor allem bei integrierter Grafik und in Spielen mehr Leistung.'))
    }
    if (-not $isLaptop -and @(2133, 2400, 4800) -contains [int]$speed) {
        [void]$f.Add((New-Finding 1 'Hardware' 'Arbeitsspeicher läuft evtl. nur mit Basistakt' "Der RAM läuft mit $speed MT/s (Standardtakt). Falls die Module schneller spezifiziert sind, kann im BIOS das Profil XMP (Intel) bzw. EXPO/DOCP (AMD) aktiviert werden. Das sollten nur erfahrene Nutzer tun."))
    }
    if ($bios.ReleaseDate -and $bios.ReleaseDate -lt (Get-Date).AddYears(-3)) {
        [void]$f.Add((New-Finding 1 'Treiber' 'BIOS/UEFI ist älter als 3 Jahre' ("Das BIOS stammt vom {0:dd.MM.yyyy}. Updates gibt es auf der Support-Seite von {1}. Achtung: Ein BIOS-Update darf nicht unterbrochen werden." -f $bios.ReleaseDate, $board.Manufacturer) '' @(@{ L = 'Support-Seite suchen'; T = ('search:' + $board.Manufacturer + ' ' + $board.Product + ' BIOS Download') })))
    }

    # Laufwerke
    $disks = @(Get-CimInstance -Namespace 'root\Microsoft\Windows\Storage' -ClassName MSFT_PhysicalDisk -ErrorAction SilentlyContinue)
    $diskText = @()
    foreach ($d in $disks) {
        $type = switch ([int]$d.MediaType) { 3 { 'HDD' } 4 { 'SSD' } default { 'Laufwerk' } }
        if ([int]$d.BusType -eq 17) { $type = 'NVMe-SSD' }
        $diskText += "{0} - {1}, {2}" -f $d.FriendlyName, $type, (Format-Bytes $d.Size)
        if (@(1, 2) -contains [int]$d.HealthStatus) {
            [void]$f.Add((New-Finding 3 'Hardware' 'Laufwerk meldet Probleme' "$($d.FriendlyName) meldet einen Warnstatus. Sichere deine wichtigen Daten so bald wie möglich."))
        }
    }
    S 'Laufwerke' ($diskText -join "`n")
    if ($diskText.Count -gt 0 -and -not ($diskText | Where-Object { $_ -notmatch 'HDD' })) {
        [void]$f.Add((New-Finding 2 'Hardware' 'Windows läuft auf einer Festplatte (HDD)' 'Eine SSD ist der größte einzelne Leistungsgewinn für ältere PCs: Start, Programme und Ladezeiten werden um ein Vielfaches schneller.'))
    }

    # Freier Speicher
    $sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'"
    if ($sys -and $sys.Size -gt 0) {
        $pct = [double]$sys.FreeSpace / $sys.Size * 100
        if ($pct -lt 10) {
            [void]$f.Add((New-Finding 2 'System' 'Systemlaufwerk fast voll' ("Auf {0} sind nur noch {1} ({2:0} %) frei. Unter 10 % wird Windows langsamer. Nutze die Bereinigung oder deinstalliere nicht benötigte Programme." -f $env:SystemDrive, (Format-Bytes $sys.FreeSpace), $pct)))
        } else {
            [void]$f.Add((New-Finding 0 'System' 'Genügend freier Speicher' ("{0} frei auf {1}" -f (Format-Bytes $sys.FreeSpace), $env:SystemDrive)))
        }
    }

    [pscustomobject]@{ Summary = $sum.ToArray(); Findings = $f.ToArray(); IsLaptop = $isLaptop }
}

# ---------------------------------------------------------------------------
#  Treiber
# ---------------------------------------------------------------------------
$script:DeviceErrors = @{
    1 = 'Gerät ist nicht richtig konfiguriert'; 3 = 'Treiber ist beschädigt'; 10 = 'Gerät kann nicht gestartet werden'
    12 = 'Nicht genügend freie Ressourcen'; 14 = 'Neustart erforderlich'; 18 = 'Treiber muss neu installiert werden'
    19 = 'Registrierungsfehler'; 21 = 'Gerät wird entfernt'; 22 = 'Gerät ist deaktiviert'
    24 = 'Gerät nicht vorhanden oder funktioniert nicht'; 28 = 'Kein Treiber installiert'; 29 = 'In der Firmware deaktiviert'
    31 = 'Treiber konnte nicht geladen werden'; 32 = 'Treiberdienst ist deaktiviert'; 37 = 'Treiber konnte nicht initialisiert werden'
    39 = 'Treiber fehlt oder ist beschädigt'; 43 = 'Gerät hat Probleme gemeldet'; 48 = 'Treiber wurde blockiert'; 52 = 'Treibersignatur ungültig'
}

# Hardware-Kategorien für die Treiberübersicht (Reihenfolge = Anzeige)
$script:DriverCategories = [ordered]@{
    DISPLAY     = 'Grafikkarte'
    MEDIA       = 'Sound / Audio'
    NET         = 'Netzwerk und WLAN'
    BLUETOOTH   = 'Bluetooth'
    SCSIADAPTER = 'Speicher-Controller (SSD / Festplatte)'
    HDC         = 'Speicher-Controller (SSD / Festplatte)'
    DISKDRIVE   = 'Laufwerke'
    SYSTEM      = 'Chipsatz und Mainboard'
    USB         = 'USB-Anschlüsse'
    CAMERA      = 'Kamera'
    IMAGE       = 'Kamera'
    BIOMETRIC   = 'Anmeldung (Fingerabdruck / Gesicht)'
    KEYBOARD    = 'Tastatur'
    MOUSE       = 'Maus und Touchpad'
    SENSOR      = 'Sensoren'
    SMARTCARDREADER = 'Kartenleser'
    SDHOST      = 'Kartenleser'
}

# Virtuelle bzw. reine Software-Geräte, die keinen eigenen Hardware-Treiber brauchen
$script:VirtualDeviceRx = 'WAN Miniport|Virtual|Virtuell|VPN|Hyper-V|Kernel Debug|Teredo|ISATAP|6to4|Wi-Fi Direct|TAP-|Loopback|RAS Async|Microsoft ISATAP|Remote NDIS|Bluetooth Device \(Personal|Bluetooth-Gerät \(PAN|Enumerator|RFCOMM|Root Hub|Stammhub|Generic USB Hub|Generischer USB-Hub|USB-Verbundgerät|USB Composite|Composite Device'

function Get-DriverAnalysis {
    $devices = New-Object System.Collections.ArrayList   # Übersicht aller Hardware-Komponenten
    $todo = New-Object System.Collections.ArrayList      # was der Nutzer tun muss
    $f = New-Object System.Collections.ArrayList         # Ergebnisse für die Übersicht / Expertenansicht

    Report 'Lese alle Geräte und ihre Treiber ... (dauert etwa 20 bis 60 Sekunden)'
    $drvById = @{}
    foreach ($d in @(Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue)) {
        if ($d.DeviceID) { $drvById[[string]$d.DeviceID] = $d }
    }

    foreach ($e in @(Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue)) {
        $id = [string]$e.DeviceID
        $cls = ([string]$e.PNPClass).ToUpper()
        $code = [int]$e.ConfigManagerErrorCode
        $name = if ($e.Name) { [string]$e.Name } else { 'Unbekanntes Gerät' }
        if ($code -eq 45) { continue }                                   # nicht angeschlossen
        $isHardware = $id -match '^(PCI|USB|HDAUDIO|INTELAUDIO|ACPI|SCSI|NVME|SD|HID)\\'
        $known = $script:DriverCategories.Contains($cls)

        # Geräte mit Problem immer aufnehmen; sonst nur echte Hardware der bekannten Kategorien
        if ($code -eq 0) {
            if (-not $known -or -not $isHardware) { continue }
            if ($name -match $script:VirtualDeviceRx) { continue }
            if ($cls -eq 'SYSTEM' -and $id -notmatch '^PCI\\') { continue }      # nur Chipsatz-Bauteile
            if ($cls -eq 'USB' -and $name -notmatch 'Controller|xHCI|eXtensible') { continue }
            if ($id -match '^HID\\' -and @('KEYBOARD', 'MOUSE') -notcontains $cls) { continue }
        }

        $cat = if ($known) { $script:DriverCategories[$cls] } else { 'Sonstige Geräte' }
        $drv = $drvById[$id]
        $ver = if ($drv) { [string]$drv.DriverVersion } else { '' }
        $prov = if ($drv) { [string]$drv.DriverProviderName } else { '' }
        $date = if ($drv -and $drv.DriverDate) { $drv.DriverDate } else { $null }
        $dateText = if ($date) { $date.ToString('dd.MM.yyyy') } else { '' }
        $lvl = 0; $status = ''

        if ($code -eq 28 -or $code -eq 1 -or $code -eq 18 -or $code -eq 39) {
            $lvl = 3; $status = 'Treiber fehlt'
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = "Treiber für $name installieren"; Kind = 'wu'; Device = $name; DeviceId = $id; Benefit = 'Das Gerät funktioniert wieder vollständig.'
                Detail = ("Für dieses Gerät fehlt der Treiber (Fehlercode $code). Es funktioniert deshalb nicht oder nur eingeschränkt." +
                          $(if ($name -match 'SM-?Bus|PCI-Gerät|PCI Device|PCI-Datenerfassung|PCI Simple|Coprocessor|Koprozessor|Unbekannt|Unknown') { ' Solche Geräte gehören meist zum Chipsatz: Dann hilft der Chipsatztreiber von AMD bzw. Intel oder von der Support-Seite deines Mainboard- bzw. PC-Herstellers.' } else { '' }))
                Actions = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) })
        } elseif ($code -eq 22) {
            $lvl = 1; $status = 'Gerät ist deaktiviert'
        } elseif ($code -ne 0) {
            $txt = if ($script:DeviceErrors.ContainsKey($code)) { $script:DeviceErrors[$code] } else { 'Unbekannter Fehler' }
            $lvl = 3; $status = "Fehler: $txt"
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = "Problem mit $name beheben"; Kind = 'wu'; Device = $name; DeviceId = $id; Benefit = 'Das Gerät funktioniert wieder zuverlässig.'
                Detail = "Das Gerät meldet: $txt (Code $code). Meist hilft es, den Treiber über Windows Update neu zu installieren und den PC neu zu starten."
                Actions = @(@{ L = 'Bei Windows Update nach Treibern suchen'; T = 'wu' }, @{ L = 'Geräte-Manager öffnen'; T = 'open:devmgmt.msc' }) })
        } elseif ($cls -eq 'DISPLAY' -and $name -match 'Basic Display|Basisanzeige|Standard-VGA') {
            $lvl = 3; $status = 'Nur Windows-Standardtreiber - Grafiktreiber fehlt'
            [void]$todo.Add([pscustomobject]@{ Level = 3; Title = 'Grafiktreiber installieren'; Kind = 'vendor'; Device = $name; DeviceId = $id; Benefit = 'Volle Grafikleistung, richtige Auflösung, flüssige Spiele.'
                Detail = 'Die Grafikkarte läuft nur mit dem Microsoft-Standardtreiber. Spiele und Videos laufen so extrem langsam, oft ist nicht einmal die richtige Auflösung möglich.'
                Actions = @(@{ L = 'Treiber-Seite des Herstellers öffnen'; T = 'vendor' }) })
        } else {
            $status = 'Treiber installiert'
            $inbox = $prov -eq 'Microsoft' -or ($date -and $date.Year -le 2006)
            if ($inbox -and @('MEDIA', 'NET', 'BLUETOOTH') -contains $cls) {
                $lvl = 1; $status = 'Windows-Standardtreiber (funktioniert)'
            } elseif ($date -and -not $inbox -and ((Get-Date) - $date).TotalDays -gt 365 * 5) {
                $lvl = 1; $status = 'Treiber installiert (älter als 5 Jahre)'
            }
        }
        [void]$devices.Add([pscustomobject]@{ Category = $cat; Device = $name; Status = $status; Level = $lvl; Provider = $prov; Version = $ver; Date = $dateText; Class = $cls })
    }

    Report 'Prüfe, ob die Software der Grafikkarte installiert ist ...'
    $software = @(Get-GpuSoftwareCheck)
    foreach ($sw in $software) {
        [void]$devices.Add([pscustomobject]@{ Category = 'Grafikkarte'; Device = "Software: $($sw.Product)"; Status = $sw.Status; Level = $sw.Level; Provider = $sw.Vendor; Version = ''; Date = ''; Class = 'SOFTWARE' })
        if ($sw.Level -ge 2) {
            [void]$todo.Add([pscustomobject]@{ Level = $sw.Level; Title = "$($sw.Product) installieren"; Kind = 'software'; Device = $sw.Device; DeviceId = ''; Detail = $sw.Finding.Detail; Actions = $sw.Finding.Actions
                Benefit = 'Grafiktreiber bleiben automatisch aktuell; Einstellungen wie G-Sync/FreeSync und Spielprofile werden verfügbar.' })
        }
    }

    # Ergebnisse für Übersicht und Expertenansicht: ein Eintrag je Aufgabe, sonst eine Erfolgsmeldung
    foreach ($t in $todo) {
        [void]$f.Add((New-Finding $t.Level 'Treiber' $t.Title $t.Detail 'Nutze die Buttons bzw. den Reiter Treiber. Installiere Treiber nur aus offiziellen Quellen (Windows Update oder Hersteller).' $t.Actions ([string](@($t.Actions)[0].L)) ([string]$t.Benefit)))
    }
    if ($todo.Count -eq 0) {
        $okSw = @($software | Where-Object { $_.Level -eq 0 } | ForEach-Object { $_.Product })
        $extra = if ($okSw.Count) { ' Die Software der Grafikkarte ist ebenfalls installiert (' + ($okSw -join ', ') + ').' } else { '' }
        [void]$f.Add((New-Finding 0 'Treiber' 'Kein Handlungsbedarf bei den Treibern' ("Alle $(@($devices | Where-Object { $_.Class -ne 'SOFTWARE' }).Count) geprüften Hardware-Komponenten haben einen funktionierenden Treiber.$extra") '' @()))
    }

    # Gleichnamige Einträge zusammenfassen (z. B. mehrere 'HID-Tastatur'-Einträge einer Gaming-Tastatur)
    $grouped = foreach ($g in ($devices | Group-Object Category, Device, Status)) {
        $first = $g.Group[0]
        if ($g.Count -gt 1) { $first | Add-Member -NotePropertyName Device -NotePropertyValue ("{0}  ({1}x)" -f $first.Device, $g.Count) -Force }
        $first
    }
    $devices = @($grouped)
    $order = @{}; $n = 0; foreach ($v in $script:DriverCategories.Values) { if (-not $order.ContainsKey($v)) { $order[$v] = $n++ } }; $order['Sonstige Geräte'] = 99
    $sorted = @($devices | Sort-Object @{ e = { $order[$_.Category] } }, @{ e = { $_.Class -eq 'SOFTWARE' } }, Device)
    [pscustomobject]@{ Drivers = $sorted; Todo = $todo.ToArray(); Software = $software; Findings = $f.ToArray() }
}

# Herstellersoftware, die zu einer Grafikkarte gehört
$script:GpuSoftware = @(
    @{ Vendor = 'NVIDIA'; Ven = 'VEN_10DE'; Product = 'NVIDIA App'
       Names = '^NVIDIA App|GeForce Experience|NVIDIA Control Panel|NVIDIA Systemsteuerung'; Appx = 'NVIDIACorp\.NVIDIAControlPanel'
       Actions = @(@{ L = 'NVIDIA App herunterladen (offizielle Seite)'; T = 'web:https://www.nvidia.com/de-de/software/nvidia-app/' },
                   @{ L = 'NVIDIA Systemsteuerung (Microsoft Store)'; T = 'web:https://apps.microsoft.com/detail/9nf8h0h7wmlt' }) }
    @{ Vendor = 'AMD'; Ven = 'VEN_1002'; Product = 'AMD Software: Adrenalin Edition'
       Names = 'AMD Software|Radeon Software|AMD Radeon Settings|Adrenalin'; Appx = 'AMDRadeonSoftware'
       Actions = @(@{ L = 'AMD Software herunterladen (offizielle Seite)'; T = 'web:https://www.amd.com/de/support/download/drivers.html' }) }
    @{ Vendor = 'Intel'; Ven = 'VEN_8086'; Product = 'Intel Graphics Software bzw. Intel Graphics Command Center'
       Names = 'Intel.*(Graphics Command Center|Arc Control|Graphics Software)'; Appx = 'IntelGraphicsExperience|IntelArcSoftware|IntelGraphicsSoftware'
       Actions = @(@{ L = 'Intel Driver & Support Assistant (offizielle Seite)'; T = 'web:https://www.intel.de/content/www/de/de/support/detect.html' },
                   @{ L = 'Intel Graphics Command Center (Microsoft Store)'; T = 'web:https://apps.microsoft.com/detail/9plfnlnt3g5g' }) }
)

function Get-InstalledDisplayNames {
    $names = New-Object System.Collections.ArrayList
    foreach ($src in @(@('HKLM', '64'), @('HKLM', '32'), @('HKCU', 'Default'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]; $root = $bk.OpenSubKey($script:UninstallPath)
            if ($root) {
                foreach ($sub in $root.GetSubKeyNames()) {
                    $k = $root.OpenSubKey($sub)
                    if ($k) { $n = $k.GetValue('DisplayName'); if ($n) { [void]$names.Add([string]$n) }; $k.Close() }
                }
                $root.Close()
            }
            $bk.Close()
        } catch {}
    }
    return $names.ToArray()
}

# Prüft für jede Grafikkarte, ob die zugehörige Software des Herstellers installiert ist
function Get-GpuSoftwareCheck {
    $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object {
        ([string]$_.PNPDeviceID).ToUpper().StartsWith('PCI\') -and $_.Name -notmatch 'Basic Display|Basisanzeige|Standard-VGA' })
    if ($gpus.Count -eq 0) { return }
    $installed = @(Get-InstalledDisplayNames)
    $appx = @(Get-AppxPackage -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
    $done = @{}
    foreach ($g in $gpus) {
        $def = $script:GpuSoftware | Where-Object { ([string]$g.PNPDeviceID).ToUpper().Contains($_.Ven) } | Select-Object -First 1
        if (-not $def -or $done.ContainsKey($def.Vendor)) { continue }
        $done[$def.Vendor] = $true
        $hit = @($installed | Where-Object { $_ -match $def.Names }) + @($appx | Where-Object { $_ -match $def.Appx })
        if ($hit.Count -gt 0) {
            $what = ($hit | Select-Object -Unique | Select-Object -First 2) -join ', '
            [pscustomobject]@{ Vendor = $def.Vendor; Product = $def.Product; Device = $g.Name; Level = 0; Status = "Installiert: $what"
                Finding = (New-Finding 0 'Treiber' "Grafik-Software installiert ($($def.Vendor))" "$what - passend zu $($g.Name)." '' @()) }
        } else {
            $dedicated = $def.Vendor -ne 'Intel' -or $g.Name -match 'Arc(\(TM\))?\s+[AB]\d{3}'
            $lvl = if ($dedicated) { 3 } else { 2 }
            $detail = "Für deine Grafikkarte $($g.Name) ist die Software des Herstellers ($($def.Product)) zwingend erforderlich, sie ist aber nicht installiert. " +
                      'Ohne sie fehlen wichtige Einstellungen (z. B. Bildwiederholrate, G-Sync/FreeSync, Spielprofile), und neue Grafiktreiber werden nicht automatisch angeboten.'
            $help = 'Lade die Software ausschließlich über die Buttons bzw. die offizielle Seite des Herstellers herunter. Bei AMD und NVIDIA ist der passende Treiber im Installationspaket bereits enthalten. Starte den PC nach der Installation neu.'
            [pscustomobject]@{ Vendor = $def.Vendor; Product = $def.Product; Device = $g.Name; Level = $lvl; Status = 'Nicht installiert - erforderlich'
                Finding = (New-Finding $lvl 'Treiber' "Grafik-Software fehlt: $($def.Product)" $detail $help $def.Actions) }
        }
    }
}

function New-UpdateSearcher {
    $s = New-Object -ComObject Microsoft.Update.Session
    $s.ClientApplicationID = 'TuneRig'
    $q = $s.CreateUpdateSearcher()
    $q.Online = $true
    $q.ServerSelection = 2   # direkt bei Microsoft (auch wenn WSUS konfiguriert ist)
    return @($s, $q)
}

function Search-DriverUpdates {
    Report 'Suche bei Windows Update nach Treibern ... (1-3 Minuten)'
    $s, $q = New-UpdateSearcher
    $r = $q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
    $list = @()
    for ($i = 0; $i -lt $r.Updates.Count; $i++) {
        $u = $r.Updates.Item($i)
        $date = try { ([datetime]$u.DriverVerDate).ToString('dd.MM.yyyy') } catch { '-' }
        $list += [pscustomobject]@{ Id = $u.Identity.UpdateID; Title = $u.Title; Manufacturer = $u.DriverManufacturer; Class = $u.DriverClass; Date = $date }
    }
    return $list
}

function Install-DriverUpdates([string[]]$Ids) {
    Report 'Bereite Installation vor ...'
    $s, $q = New-UpdateSearcher
    $r = $q.Search("IsInstalled=0 and Type='Driver' and IsHidden=0")
    $coll = New-Object -ComObject Microsoft.Update.UpdateColl
    for ($i = 0; $i -lt $r.Updates.Count; $i++) {
        $u = $r.Updates.Item($i)
        if ($Ids -contains $u.Identity.UpdateID) {
            if (-not $u.EulaAccepted) { $u.AcceptEula() }
            [void]$coll.Add($u)
        }
    }
    if ($coll.Count -eq 0) { return 'Die ausgewählten Updates werden nicht mehr angeboten.' }

    Report "Lade $($coll.Count) Treiber herunter ..."
    $dl = $s.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()

    Report 'Installiere Treiber ... (das kann einige Minuten dauern)'
    $inst = $s.CreateUpdateInstaller(); $inst.Updates = $coll
    $res = $inst.Install()
    $ok = 0
    for ($i = 0; $i -lt $coll.Count; $i++) { if (@(2, 3) -contains [int]$res.GetUpdateResult($i).ResultCode) { $ok++ } }
    $msg = "$ok von $($coll.Count) Treibern installiert."
    if ($res.RebootRequired) { $msg += ' Starte den PC neu.' }
    return $msg
}

# ---------------------------------------------------------------------------
#  Energiesparpläne
# ---------------------------------------------------------------------------
$script:PlanGuid = @{
    Balanced = '381b4222-f694-41f0-9685-ff5bb260df2e'
    High     = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
    Ultimate = 'e9a42b02-d5df-448d-aa00-03f14749eb61'
}
$script:Overlay = @{
    Best     = 'ded574b5-45a0-4f42-8737-46345c09c238'
    Better   = '3af9b8d9-7c97-431d-ad78-34a8bfea439f'
    Balanced = '00000000-0000-0000-0000-000000000000'
    Battery  = '961cc777-2547-4f9d-8174-7d86181b8a7a'
}
$script:GuidRx = '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})'

function Get-PowerPlans {
    $plans = @()
    foreach ($line in @(powercfg.exe /list)) {
        if ($line -match ($script:GuidRx + '\s+\((.+?)\)(\s*\*)?')) {
            $plans += [pscustomobject]@{ Guid = $Matches[1].ToLower(); Name = $Matches[2].Trim(); Active = [bool]$Matches[3] }
        }
    }
    return $plans
}

function Get-ActivePlan { Get-PowerPlans | Where-Object { $_.Active } | Select-Object -First 1 }

function Get-OverlayName {
    $g = [PCO.Native]::GetOverlay()
    if ($g -eq $script:Overlay.Best) { return 'Beste Leistung' }
    if ($g -eq $script:Overlay.Better) { return 'Bessere Leistung' }
    if ($g -eq $script:Overlay.Battery) { return 'Bessere Akkuleistung' }
    if ($g -eq $script:Overlay.Balanced) { return 'Ausbalanciert' }
    return 'unbekannt'

}

function Test-HighPerfPlan($p) {
    if (-not $p) { return $false }
    return ($p.Guid -eq $script:PlanGuid.High -or $p.Guid -eq $script:PlanGuid.Ultimate -or
            $p.Name -match 'Höchstleistung|Ultimat|High performance|Ultimate' -or
            ($p.Name -match 'Performance' -and $p.Name -notmatch 'Balanced'))
}

function Set-MaxPerformance {
    $plans = @(Get-PowerPlans)
    $ult = $plans | Where-Object { $_.Guid -eq $script:PlanGuid.Ultimate -or $_.Name -match 'Ultimat' } | Select-Object -First 1
    if (-not $ult) {
        $dup = (powercfg.exe -duplicatescheme $script:PlanGuid.Ultimate) -join ' '
        if ($dup -match $script:GuidRx) { $ult = [pscustomobject]@{ Guid = $Matches[1] } }
    }
    if ($ult) {
        powercfg.exe /setactive $ult.Guid | Out-Null
        if ((Get-ActivePlan).Guid -eq $ult.Guid.ToLower()) {
            [void][PCO.Native]::SetOverlay($script:Overlay.Best)
            return 'Energiesparplan Ultimative Leistung ist jetzt aktiv.'
        }
    }
    $high = $plans | Where-Object { $_.Guid -eq $script:PlanGuid.High } | Select-Object -First 1
    if (-not $high) {
        $dup = (powercfg.exe -duplicatescheme $script:PlanGuid.High) -join ' '
        if ($dup -match $script:GuidRx) { $high = [pscustomobject]@{ Guid = $Matches[1] } }
    }
    if ($high) {
        powercfg.exe /setactive $high.Guid | Out-Null
        if ((Get-ActivePlan).Guid -eq $high.Guid.ToLower()) {
            [void][PCO.Native]::SetOverlay($script:Overlay.Best)
            return 'Energiesparplan Höchstleistung ist jetzt aktiv.'
        }
    }
    # Modern-Standby-Geräte haben nur "Ausbalanciert" - dort den Energiemodus nutzen
    if ([PCO.Native]::SetOverlay($script:Overlay.Best)) {
        return 'Dieses Gerät unterstützt nur den Plan Ausbalanciert. Der Energiemodus wurde auf Beste Leistung gestellt.'
    }
    throw 'Der Energiesparplan konnte nicht geändert werden.'
}

# Wert einer Energieplan-Einstellung (Netzbetrieb) - sprachunabhängig:
# die letzten beiden 0x-Zeilen der Ausgabe sind "aktueller Wert Netz" und "aktueller Wert Akku"
function Get-PowerValue([string]$Sub, [string]$Setting) {
    $hex = @(powercfg.exe /query SCHEME_CURRENT $Sub $Setting | Where-Object { $_ -match ':\s*0x[0-9a-fA-F]+\s*$' })
    if ($hex.Count -lt 2) { return -1 }
    if ($hex[$hex.Count - 2] -match '0x([0-9a-fA-F]+)') { return [Convert]::ToInt32($Matches[1], 16) }
    return -1
}

function Set-PowerValue([string]$Sub, [string]$Setting, [int]$Value) {
    powercfg.exe /setacvalueindex SCHEME_CURRENT $Sub $Setting $Value | Out-Null
    powercfg.exe /setdcvalueindex SCHEME_CURRENT $Sub $Setting $Value | Out-Null
    powercfg.exe /setactive SCHEME_CURRENT | Out-Null
}

# ---------------------------------------------------------------------------
#  Windows-Einstellungen (Tweaks)
# ---------------------------------------------------------------------------
$script:PcieSub = '501a4d13-42af-4429-9fd1-a8218c268e20'; $script:PcieAspm = 'ee12f906-d277-404b-b6da-e5fa1a576df5'
$script:UsbSub = '2a737441-1930-4402-8d77-b2bebba308a3'; $script:UsbSusp = '48e6b7a6-50f5-4782-a5d4-53bb8f07e226'
$script:DxKey = 'Software\Microsoft\DirectX\UserGpuPreferences'

function Get-DxGlobal { [string](Get-RegValue 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' '') }

function Set-DxGlobalValue([string]$Key, [string]$Value) {
    $parts = [ordered]@{}
    foreach ($p in ((Get-DxGlobal) -split ';')) { if ($p -match '^(.+?)=(.*)$') { $parts[$Matches[1]] = $Matches[2] } }
    $parts[$Key] = $Value
    Set-RegString 'HKCU' $script:DxKey 'DirectXUserGlobalSettings' ((($parts.Keys | ForEach-Object { "$_=$($parts[$_])" }) -join ';') + ';')
}

function Get-TweakDefs([bool]$IsLaptop) {
    $akku = if ($IsLaptop) { ' Hinweis Laptop: Der Akku hält damit spürbar kürzer.' } else { '' }
    @(
        @{ Id = 'power'; Target = 'Höchstleistung (Energiemodus: Beste Leistung)'; Title = 'Energiesparplan'; Problem = 'Der Prozessor drosselt sich, um Strom zu sparen.'; Benefit = 'Prozessor arbeitet mit voller Kraft - Programme und Spiele reagieren schneller.'; Fix = 'Auf Höchstleistung stellen'; Name = 'Energiesparplan: Maximale Leistung'; Optional = $false; Restart = $false
           Desc = 'Aktiviert Ultimative Leistung bzw. Höchstleistung und stellt den Energiemodus auf Beste Leistung. Der Prozessor taktet nicht mehr herunter.' + $akku
           Read = { $p = Get-ActivePlan; "Energiesparplan: $($p.Name)  ·  Energiemodus: $(Get-OverlayName)" }
           Check = {
               $p = Get-ActivePlan
               if (Test-HighPerfPlan $p) { return $true }
               return ($p.Guid -eq $script:PlanGuid.Balanced -and [PCO.Native]::GetOverlay() -eq $script:Overlay.Best -and @(Get-PowerPlans).Count -eq 1)
           }
           Apply = { Set-MaxPerformance } }

        @{ Id = 'gamemode'; Target = 'Spielmodus einschalten'; Title = 'Spielmodus'; Problem = 'Windows bevorzugt laufende Spiele nicht.'; Benefit = 'Spiele bekommen Vorrang, Updates stören nicht beim Spielen.'; Fix = 'Einschalten'; Name = 'Spielmodus'; Optional = $false; Restart = $false
           Desc = 'Windows priorisiert laufende Spiele und unterdrückt Updates und Hintergrundaufgaben während des Spielens.'
           Read = { if ((Get-RegValue 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1) -eq 1) { 'Spielmodus ist eingeschaltet' } else { 'Spielmodus ist ausgeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1) -eq 1 }
           Apply = { Set-RegDword 'HKCU' 'Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1; Set-RegDword 'HKCU' 'Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 } }

        @{ Id = 'hags'; Target = 'GPU-Planung einschalten'; Title = 'GPU-Planung (Grafikkarte)'; Problem = 'Windows verwaltet den Speicher der Grafikkarte selbst.'; Benefit = 'Etwas weniger Verzögerung in Spielen; nötig für DLSS Frame Generation.'; Fix = 'Einschalten'; Name = 'Hardwarebeschleunigte GPU-Planung (HAGS)'; Optional = $false; Restart = $true
           Desc = 'Die Grafikkarte verwaltet ihren Speicher selbst. Senkt die Latenz und ist Voraussetzung für DLSS Frame Generation. Benötigt einen Neustart.'
           Read = { switch (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0) { 2 { 'GPU-Planung ist eingeschaltet' } 1 { 'GPU-Planung ist ausgeschaltet' } default { 'Nicht festgelegt (der Treiber entscheidet)' } } }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 0) -eq 2 }
           Apply = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2 } }

        @{ Id = 'windowed'; Target = 'Optimierung einschalten'; Title = 'Spiele im Fenstermodus'; Problem = 'Spiele im Fenster nutzen eine ältere, langsamere Darstellung.'; Benefit = 'Weniger Verzögerung im Fenster- und randlosen Modus.'; Fix = 'Einschalten'; Name = 'Optimierungen für Spiele im Fenstermodus'; Optional = $false; Restart = $false
           Desc = 'Spiele im Fenster- oder randlosen Modus nutzen die moderne Darstellungsart: geringere Latenz, Auto-HDR und VRR möglich.'
           Read = { if ((Get-DxGlobal) -match 'SwapEffectUpgradeEnable=1;') { 'Optimierung ist eingeschaltet' } else { 'Optimierung ist ausgeschaltet (Windows-Standard)' } }
           Check = { (Get-DxGlobal) -match 'SwapEffectUpgradeEnable=1;' }
           Apply = { Set-DxGlobalValue 'SwapEffectUpgradeEnable' '1' } }

        @{ Id = 'gamedvr'; Target = 'Hintergrundaufnahme ausschalten'; Title = 'Xbox-Hintergrundaufnahme'; Problem = 'Windows nimmt beim Spielen ständig im Hintergrund auf.'; Benefit = 'Mehr Leistung in Spielen, weniger Last auf der Festplatte.'; Fix = 'Ausschalten'; Name = 'Hintergrundaufnahme der Xbox Game Bar'; Optional = $false; Restart = $false
           Desc = 'Die automatische Hintergrundaufnahme kostet dauerhaft Leistung. Wird deaktiviert; manuelle Aufnahmen bleiben möglich.'
           Read = { if ((Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0) -eq 1) { 'Hintergrundaufnahme ist eingeschaltet (kostet Leistung)' } else { 'Hintergrundaufnahme ist ausgeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0) -eq 0 }
           Apply = { Set-RegDword 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\GameDVR' 'HistoricalCaptureEnabled' 0 } }

        @{ Id = 'pcie'; Target = 'Stromsparen ausschalten (volle Leistung)'; Title = 'Stromsparen von Grafikkarte und SSD'; Problem = 'Grafikkarte und SSD schalten zeitweise in einen Sparzustand.'; Benefit = 'Weniger Mikroruckler, schnellere Reaktion.'; Fix = 'Stromsparen ausschalten'; Name = 'PCI-Express-Energiesparmodus'; Optional = $false; Restart = $false
           Desc = 'Verhindert, dass Grafikkarte und NVMe-SSD im aktiven Energiesparplan in Stromsparzustände wechseln (vermeidet Mikroruckler).'
           Read = { switch (Get-PowerValue $script:PcieSub $script:PcieAspm) { 0 { 'Energiesparen ist ausgeschaltet (volle Leistung)' } 1 { 'Mittlere Energieeinsparung ist eingeschaltet' } 2 { 'Maximale Energieeinsparung ist eingeschaltet' } default { 'unbekannt' } } }
           Check = { (Get-PowerValue $script:PcieSub $script:PcieAspm) -eq 0 }
           Apply = { Set-PowerValue $script:PcieSub $script:PcieAspm 0 } }

        @{ Id = 'usb'; Target = 'USB-Energiesparen ausschalten'; Title = 'Stromsparen bei USB-Geräten'; Problem = 'USB-Geräte (z. B. Maus, Headset usw.) werden zeitweise abgeschaltet.'; Benefit = 'Keine Aussetzer oder Verbindungsabbrüche bei USB-Geräten.'; Fix = 'Stromsparen ausschalten'; Name = 'USB: Selektives Energiesparen'; Optional = $false; Restart = $false
           Desc = 'Verhindert, dass USB-Geräte (z. B. Maus, Headset usw.) zum Stromsparen abgeschaltet werden. Vermeidet Aussetzer und Verbindungsabbrüche.'
           Read = { switch (Get-PowerValue $script:UsbSub $script:UsbSusp) { 0 { 'USB-Energiesparen ist ausgeschaltet' } -1 { 'unbekannt' } default { 'USB-Energiesparen ist eingeschaltet' } } }
           Check = { (Get-PowerValue $script:UsbSub $script:UsbSusp) -eq 0 }
           Apply = { Set-PowerValue $script:UsbSub $script:UsbSusp 0 } }

        @{ Id = 'visual'; Target = 'Für optimale Leistung'; Title = 'Windows-Animationen'; Problem = 'Animationen und Schatten kosten etwas Leistung.'; Benefit = 'Etwas schnellere Bedienung auf schwachen PCs - sieht dafür schlichter aus.'; Fix = 'Auf Leistung stellen'; Name = 'Visuelle Effekte auf Leistung optimieren'; Optional = $true; Restart = $false
           Desc = 'Optional: Schaltet Animationen und Schatten von Windows ab. Bringt auf schwachen PCs etwas, sieht aber schlichter aus.'
           Read = { switch (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) { 2 { 'Eingestellt auf: Für optimale Leistung' } 1 { 'Eingestellt auf: Für optimale Darstellung' } 3 { 'Eingestellt auf: Benutzerdefiniert' } default { 'Eingestellt auf: Automatisch (Windows-Standard)' } } }
           Check = { (Get-RegValue 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 0) -eq 2 }
           Apply = { Set-RegDword 'HKCU' 'Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 2 } }
    )
}

function Get-Tweaks([bool]$IsLaptop) {
    foreach ($t in Get-TweakDefs $IsLaptop) {
        $state = try { [string](& $t.Read) } catch { 'Fehler: ' + $_.Exception.Message }
        $ok = try { [bool](& $t.Check) } catch { $false }
        [pscustomobject]@{ Id = $t.Id; Name = $t.Name; Title = $t.Title; Problem = $t.Problem; Benefit = $t.Benefit; Fix = $t.Fix; Target = $t.Target
                           Desc = $t.Desc; State = $state; Optimal = $ok; Optional = $t.Optional; Restart = $t.Restart }
    }
}

function Invoke-Tweaks([string[]]$Ids) {
    $errors = @()
    foreach ($t in Get-TweakDefs $false) {
        if ($Ids -notcontains $t.Id) { continue }
        Report "Setze: $($t.Name) ..."
        try { [void](& $t.Apply) } catch { $errors += "$($t.Name): $($_.Exception.Message)" }
    }
    return $errors
}

# ---------------------------------------------------------------------------
#  Grafikkarten
# ---------------------------------------------------------------------------
function Get-VramMap {
    $map = @{}
    $cls = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    foreach ($k in @(Get-ChildItem $cls -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' })) {
        try {
            $p = Get-ItemProperty $k.PSPath -ErrorAction Stop
            $desc = $p.DriverDesc
            if (-not $desc) { continue }
            $v = $p.'HardwareInformation.qwMemorySize'
            if ($null -eq $v) { $v = $p.'HardwareInformation.MemorySize' }
            $size = 0
            if ($v -is [byte[]]) { $size = if ($v.Length -ge 8) { [BitConverter]::ToInt64($v, 0) } else { [BitConverter]::ToUInt32($v, 0) } }
            elseif ($v -is [int]) { $size = [long][BitConverter]::ToUInt32([BitConverter]::GetBytes($v), 0) }
            elseif ($null -ne $v) { $size = [long]$v }
            if ($size -gt 0 -and (-not $map.ContainsKey($desc) -or $map[$desc] -lt $size)) { $map[$desc] = $size }
        } catch {}
    }
    return $map
}

function Get-GpuAnalysis([bool]$IsLaptop) {
    $gpus = @(); $f = New-Object System.Collections.ArrayList
    $vram = Get-VramMap
    foreach ($v in @(Get-CimInstance Win32_VideoController)) {
        $pnp = [string]$v.PNPDeviceID
        if (-not $pnp.ToUpper().StartsWith('PCI\')) { continue }   # virtuelle Adapter überspringen
        $vendor = if ($pnp -match 'VEN_10DE') { 'NVIDIA' } elseif ($pnp -match 'VEN_1002') { 'AMD' } elseif ($pnp -match 'VEN_8086') { 'Intel' } else { 'Unbekannt' }
        $mem = if ($vram.ContainsKey($v.Name)) { $vram[$v.Name] } else { [long]$v.AdapterRAM }
        $basic = $v.Name -match 'Basic Display|Basisanzeige|Standard-VGA'
        $discrete = ($vendor -eq 'NVIDIA') -or ($v.Name -match 'Arc(\(TM\))?\s+[AB]\d{3}') -or
                    ($vendor -eq 'AMD' -and $v.Name -match '\bRX\s?\d{3,4}|Radeon\s?Pro') -or
                    ($vendor -ne 'Intel' -and $mem -ge 2GB)
        $w = [int]$v.CurrentHorizontalResolution
        $gpus += [pscustomobject]@{
            Name = $v.Name; Vendor = $vendor; Discrete = [bool]$discrete; Vram = $mem
            Driver = $v.DriverVersion; DriverDate = $(if ($v.DriverDate) { $v.DriverDate.ToString('dd.MM.yyyy') } else { '-' })
            Display = ($w -gt 0); Resolution = $(if ($w -gt 0) { "{0}x{1} @ {2} Hz" -f $w, $v.CurrentVerticalResolution, $v.CurrentRefreshRate } else { '' })
            HasDriver = -not $basic
        }
    }

    $ded = @($gpus | Where-Object { $_.Discrete }); $int = @($gpus | Where-Object { -not $_.Discrete })
    foreach ($g in @($gpus | Where-Object { -not $_.HasDriver })) {
        [void]$f.Add((New-Finding 3 'Grafik' 'Grafikkarte ohne Treiber' "$($g.Name) läuft mit dem Windows-Standardtreiber. Installiere den Treiber des Herstellers."))
    }
    if ($gpus.Count -eq 0) {
        [void]$f.Add((New-Finding 2 'Grafik' 'Keine Grafikkarte erkannt' 'Die Grafikkarten konnten nicht ausgelesen werden.'))
    } elseif ($ded.Count -eq 0) {
        [void]$f.Add((New-Finding 1 'Grafik' 'Nur integrierte Grafik vorhanden' 'Es wurde keine dedizierte Grafikkarte gefunden. Für anspruchsvolle Spiele ist die Leistung begrenzt.'))
    } elseif ($gpus.Count -eq 1) {
        [void]$f.Add((New-Finding 0 'Grafik' 'Eine dedizierte Grafikkarte' "$($ded[0].Name) wird für alle Anwendungen genutzt."))
    } elseif (-not $IsLaptop -and ($int | Where-Object { $_.Display }) -and -not ($ded | Where-Object { $_.Display })) {
        [void]$f.Add((New-Finding 3 'Grafik' 'Monitor ist vermutlich am Mainboard angeschlossen' ("Das Bild wird über die integrierte Grafik ({0}) ausgegeben, nicht über {1}. Steck das Monitorkabel hinten am PC in die Anschlüsse der Grafikkarte (meist weiter unten, waagerecht angeordnet) – nicht in die Anschlüsse neben USB/LAN. Das ist einer der häufigsten Gründe für schlechte Spieleleistung." -f $int[0].Name, $ded[0].Name)))
    } else {
        $t = if ($IsLaptop) { 'Hybrid-Grafik (Laptop)' } else { 'Mehrere Grafikkarten' }
        [void]$f.Add((New-Finding 1 'Grafik' $t ("Leistungsstark: {0}; stromsparend: {1}. Windows entscheidet pro Programm, welche Karte genutzt wird. Stell deine Spiele auf Hohe Leistung (geführter Check: Schritt Leistung)." -f (($ded | ForEach-Object Name) -join ', '), (($int | ForEach-Object Name) -join ', '))))
    }
    [pscustomobject]@{ Gpus = $gpus; Findings = $f.ToArray() }
}

$script:JunkExe = '^(unins|uninstall|setup|install|vcredist|vc_redist|dxsetup|dxwebsetup|crash|report|ue4prereq|easyanticheat|eac|be(service)?_|battleye|launcherpatcher|redist|dotnet|oalinst|physx|touchup|cleanup|activation|update)'

function Find-MainExe([string]$Folder) {
    if (-not $Folder -or -not (Test-Path -LiteralPath $Folder)) { return $null }
    $exe = Get-ChildItem -LiteralPath $Folder -Filter *.exe -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notmatch $script:JunkExe -and $_.FullName -notmatch '\\(_|redist|support|directx|vcredist)[^\\]*\\' } |
        Sort-Object Length -Descending | Select-Object -First 1
    if ($exe) { return $exe.FullName } else { return $null }
}

function Get-GpuPreference([string]$Exe) {
    $data = [string](Get-RegValue 'HKCU' $script:DxKey $Exe '')
    if ($data -match 'GpuPreference=(\d)') {
        switch ($Matches[1]) { '2' { return 'Hohe Leistung' } '1' { return 'Energiesparen' } }
    }
    return 'Windows entscheidet'
}

function Set-GpuHighPerformance([string]$Exe) {
    $existing = [string](Get-RegValue 'HKCU' $script:DxKey $Exe '')
    $parts = @('GpuPreference=2') + @(($existing -split ';') | Where-Object { $_ -and $_ -notmatch '^GpuPreference=' })
    Set-RegString 'HKCU' $script:DxKey $Exe (($parts -join ';') + ';')
}

function Find-Games {
    $games = @()
    # Steam
    $steam = Get-RegValue 'HKCU' 'Software\Valve\Steam' 'SteamPath' $null
    if ($steam) {
        $steam = $steam -replace '/', '\'
        $libs = @($steam)
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"(.+?)"')) { $libs += $m.Groups[1].Value -replace '\\\\', '\' }
        }
        foreach ($lib in ($libs | Select-Object -Unique)) {
            $apps = Join-Path $lib 'steamapps'
            foreach ($acf in @(Get-ChildItem -LiteralPath $apps -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue)) {
                $txt = Get-Content -LiteralPath $acf.FullName -Raw -ErrorAction SilentlyContinue
                if ($txt -notmatch '"name"\s+"(.+?)"') { continue }; $name = $Matches[1]
                if ($txt -notmatch '"installdir"\s+"(.+?)"') { continue }; $dir = $Matches[1]
                if ($name -match 'Redistributable|^Steamworks|^Proton|SteamVR') { continue }
                Report "Suche Spiele: $name"
                $exe = Find-MainExe (Join-Path $apps "common\$dir")
                if ($exe) { $games += [pscustomobject]@{ Name = $name; Source = 'Steam'; Exe = $exe } }
            }
        }
    }
    # Epic Games
    $epic = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    foreach ($item in @(Get-ChildItem -LiteralPath $epic -Filter *.item -ErrorAction SilentlyContinue)) {
        try {
            $j = Get-Content -LiteralPath $item.FullName -Raw | ConvertFrom-Json
            $exe = Join-Path $j.InstallLocation $j.LaunchExecutable
            if (-not (Test-Path -LiteralPath $exe)) { $exe = Find-MainExe $j.InstallLocation }
            if ($exe) { $games += [pscustomobject]@{ Name = $j.DisplayName; Source = 'Epic Games'; Exe = $exe } }
        } catch {}
    }
    # GOG
    foreach ($k in @(Get-ChildItem 'HKLM:\SOFTWARE\WOW6432Node\GOG.com\Games' -ErrorAction SilentlyContinue)) {
        $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
        if ($p.exe -and (Test-Path -LiteralPath $p.exe)) { $games += [pscustomobject]@{ Name = $p.gameName; Source = 'GOG'; Exe = $p.exe } }
    }

    $games | Sort-Object Exe -Unique | Sort-Object Name | ForEach-Object {
        $_ | Add-Member -NotePropertyName Preference -NotePropertyValue (Get-GpuPreference $_.Exe) -PassThru
    }
}

# ---------------------------------------------------------------------------
#  Bereinigung
# ---------------------------------------------------------------------------
function Get-OldFiles([string]$Dir, [string]$Filter = '*', [double]$MinAgeHours = 0, [switch]$NoRecurse) {
    if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return }
    $cut = (Get-Date).AddHours(-$MinAgeHours)
    Get-ChildItem -LiteralPath $Dir -Filter $Filter -File -Force -Recurse:(-not $NoRecurse) -ErrorAction SilentlyContinue |
        Where-Object { $MinAgeHours -le 0 -or $_.LastWriteTime -lt $cut }
}

function Get-ChromiumCache([string]$UserData) {
    if (-not (Test-Path -LiteralPath $UserData)) { return }
    foreach ($p in @(Get-ChildItem -LiteralPath $UserData -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' })) {
        Get-OldFiles (Join-Path $p.FullName 'Cache'); Get-OldFiles (Join-Path $p.FullName 'Code Cache'); Get-OldFiles (Join-Path $p.FullName 'GPUCache')
    }
}

# Nur anzeigen, was diesen PC betrifft: Browser-Caches nur für installierte Browser,
# Shader-Caches nur für den Hersteller der eingebauten Grafikkarte
function Test-CleanupRelevant([string]$Id) {
    $local = $env:LOCALAPPDATA
    if ($null -eq $script:GpuNamesCache) {
        $script:GpuNamesCache = (@(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ' ')
    }
    $r = switch ($Id) {
        'browser-chrome'  { Test-Path -LiteralPath "$local\Google\Chrome\User Data" }
        'browser-edge'    { Test-Path -LiteralPath "$local\Microsoft\Edge\User Data" }
        'browser-brave'   { Test-Path -LiteralPath "$local\BraveSoftware\Brave-Browser\User Data" }
        'browser-firefox' { Test-Path -LiteralPath "$local\Mozilla\Firefox\Profiles" }
        'shader-nvidia'   { $script:GpuNamesCache -match 'NVIDIA' }
        'shader-amd'      { $script:GpuNamesCache -match 'AMD|Radeon' }
        default           { $true }
    }
    return [bool]$r
}

function Get-CleanupDefs { @(Get-AllCleanupDefs | Where-Object { Test-CleanupRelevant $_.Id }) }

function Get-AllCleanupDefs {
    @(
        [pscustomobject]@{ Id = 'usertemp'; Sel = $true;  Name = 'Temporäre Dateien (Benutzer)'; Desc = 'Reste von Installationen und Programmen im Benutzer-Temp-Ordner (älter als 24 Std.).' }
        [pscustomobject]@{ Id = 'wintemp';  Sel = $true;  Name = 'Temporäre Dateien (Windows)'; Desc = 'Inhalt von C:\Windows\Temp (älter als 24 Std.).' }
        [pscustomobject]@{ Id = 'wudl';     Sel = $true;  Name = 'Windows-Update-Downloads'; Desc = 'Bereits installierte Update-Pakete. Der Update-Dienst wird dafür kurz angehalten.' }
        [pscustomobject]@{ Id = 'do';       Sel = $true;  Name = 'Übermittlungsoptimierung'; Desc = 'Zwischenspeicher, mit dem Windows Updates an andere PCs verteilt.' }
        [pscustomobject]@{ Id = 'wer';      Sel = $true;  Name = 'Fehlerberichte und Speicherabbilder'; Desc = 'Windows-Fehlerberichte, Minidumps und Absturzabbilder von Programmen.' }
        [pscustomobject]@{ Id = 'thumbs';   Sel = $true;  Name = 'Miniaturansichten-Cache'; Desc = 'Vorschaubilder des Explorers. Werden bei Bedarf automatisch neu erstellt.' }
        [pscustomobject]@{ Id = 'logs';     Sel = $true;  Name = 'Alte Windows-Protokolle'; Desc = 'Log-Dateien in C:\Windows\Logs, die älter als 14 Tage sind.' }
        [pscustomobject]@{ Id = 'browser-chrome';  Group = 'browser'; Sel = $true; Short = 'Google Chrome'; Name = 'Browser-Cache: Google Chrome'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Chrome.' }
        [pscustomobject]@{ Id = 'browser-edge';    Group = 'browser'; Sel = $true; Short = 'Microsoft Edge'; Name = 'Browser-Cache: Microsoft Edge'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Edge.' }
        [pscustomobject]@{ Id = 'browser-brave';   Group = 'browser'; Sel = $true; Short = 'Brave'; Name = 'Browser-Cache: Brave'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Brave.' }
        [pscustomobject]@{ Id = 'browser-firefox'; Group = 'browser'; Sel = $true; Short = 'Mozilla Firefox'; Name = 'Browser-Cache: Mozilla Firefox'; Desc = 'Zwischengespeicherte Webseiten-Dateien von Firefox.' }
        [pscustomobject]@{ Id = 'recycle';  Sel = $false; Name = 'Papierkorb'; Desc = 'Leert den Papierkorb aller Laufwerke.' }
        [pscustomobject]@{ Id = 'shader-dx';     Group = 'shader'; Sel = $false; Short = 'DirectX (Windows)'; Name = 'Shader-Cache: DirectX (Windows)'; Desc = 'Vorbereitete Grafikdaten von DirectX-Spielen.' }
        [pscustomobject]@{ Id = 'shader-nvidia'; Group = 'shader'; Sel = $false; Short = 'NVIDIA'; Name = 'Shader-Cache: NVIDIA'; Desc = 'Vorbereitete Grafikdaten des NVIDIA-Treibers.' }
        [pscustomobject]@{ Id = 'shader-amd';    Group = 'shader'; Sel = $false; Short = 'AMD'; Name = 'Shader-Cache: AMD'; Desc = 'Vorbereitete Grafikdaten des AMD-Treibers.' }
        [pscustomobject]@{ Id = 'winsxs';   Sel = $false; Name = 'Komponentenspeicher (WinSxS) bereinigen'; Desc = 'Optional: entfernt alte Versionen von Windows-Komponenten mit DISM. Dauert 5-20 Minuten.' }
    )
}

# Beschreibung der Cache-Gruppen (im geführten Check als aufklappbare Gruppe mit Unterpunkten)
$script:CleanupGroups = @{
    browser = @{ Name = 'Browser-Cache'; Desc = 'Nur zwischengespeicherte Webseiten-Dateien. Passwörter, Verlauf und Cookies bleiben erhalten. Am besten die Browser vorher schließen.' }
    shader  = @{ Name = 'Shader-Cache (Spiele)'; Desc = 'Spiele speichern hier vorbereitete Grafikdaten, damit sie flüssiger laufen. Löschen nur bei Problemen: wenn ein Spiel nach einem Spiel- oder Treiber-Update bzw. nach Abstürzen dauerhaft ruckelt oder Grafikfehler zeigt. Danach ruckeln Spiele beim ersten Start kurz, bis der Cache neu aufgebaut ist.' }
}

function Get-CleanupFiles([string]$Id) {
    $local = $env:LOCALAPPDATA; $win = $env:windir
    switch ($Id) {
        'usertemp' { Get-OldFiles $env:TEMP -MinAgeHours 24 }
        'wintemp'  { Get-OldFiles "$win\Temp" -MinAgeHours 24 }
        'wudl'     { Get-OldFiles "$win\SoftwareDistribution\Download" }
        'do'       { Get-OldFiles "$win\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache" }
        'wer'      {
            Get-OldFiles "$env:ProgramData\Microsoft\Windows\WER\ReportArchive"
            Get-OldFiles "$env:ProgramData\Microsoft\Windows\WER\ReportQueue"
            Get-OldFiles "$local\Microsoft\Windows\WER"
            Get-OldFiles "$local\CrashDumps"
            Get-OldFiles "$win\Minidump"
            if (Test-Path -LiteralPath "$win\MEMORY.DMP") { Get-Item -LiteralPath "$win\MEMORY.DMP" -Force }
        }
        'thumbs'   { Get-OldFiles "$local\Microsoft\Windows\Explorer" 'thumbcache_*.db' -NoRecurse; Get-OldFiles "$local\Microsoft\Windows\Explorer" 'iconcache_*.db' -NoRecurse }
        'logs'     { Get-OldFiles "$win\Logs" '*.log' (24 * 14); Get-OldFiles "$win\Logs" '*.etl' (24 * 14); Get-OldFiles "$win\Logs\CBS" '*.cab' (24 * 14) }
        'browser-chrome'  { Get-ChromiumCache "$local\Google\Chrome\User Data" }
        'browser-edge'    { Get-ChromiumCache "$local\Microsoft\Edge\User Data" }
        'browser-brave'   { Get-ChromiumCache "$local\BraveSoftware\Brave-Browser\User Data" }
        'browser-firefox' { foreach ($p in @(Get-ChildItem "$local\Mozilla\Firefox\Profiles" -Directory -ErrorAction SilentlyContinue)) { Get-OldFiles (Join-Path $p.FullName 'cache2') } }
        'shader-dx'       { Get-OldFiles "$local\D3DSCache" }
        'shader-nvidia'   { Get-OldFiles "$local\NVIDIA\DXCache"; Get-OldFiles "$local\NVIDIA\GLCache"; Get-OldFiles "$local\NVIDIA Corporation\NV_Cache" }
        'shader-amd'      { Get-OldFiles "$local\AMD\DxCache"; Get-OldFiles "$local\AMD\DxcCache"; Get-OldFiles "$local\AMD\VkCache" }
    }
}

function Measure-Cleanup([string]$Id) {
    if ($Id -eq 'recycle') { $r = [PCO.Native]::QueryRecycleBin(); return [pscustomobject]@{ Id = $Id; Size = $r[0]; Count = $r[1] } }
    if ($Id -eq 'winsxs') { return [pscustomobject]@{ Id = $Id; Size = 0; Count = 0 } }
    $m = Get-CleanupFiles $Id | Measure-Object -Property Length -Sum
    [pscustomobject]@{ Id = $Id; Size = [long]$m.Sum; Count = [int]$m.Count }
}

function Remove-EmptyDirs([string]$Root) {
    if (-not (Test-Path -LiteralPath $Root)) { return }
    Get-ChildItem -LiteralPath $Root -Directory -Recurse -Force -ErrorAction SilentlyContinue |
        Sort-Object { $_.FullName.Length } -Descending |
        ForEach-Object { try { if (-not (Get-ChildItem -LiteralPath $_.FullName -Force -ErrorAction Stop)) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop } } catch {} }
}

function Invoke-Cleanup([string]$Id) {
    $win = $env:windir
    switch ($Id) {
        'recycle' { $r = [PCO.Native]::QueryRecycleBin(); [PCO.Native]::EmptyRecycleBin(); return [long]$r[0] }
        'winsxs' {
            $before = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace
            dism.exe /Online /Cleanup-Image /StartComponentCleanup | Out-Null
            $after = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace
            return [Math]::Max(0, [long]$after - [long]$before)
        }
        'do' {
            $before = (Measure-Cleanup 'do').Size
            try { Delete-DeliveryOptimizationCache -Force -ErrorAction SilentlyContinue | Out-Null } catch {}
            return [Math]::Max(0, $before - (Measure-Cleanup 'do').Size)
        }
    }
    if ($Id -eq 'wudl') { Stop-Service wuauserv, bits -Force -ErrorAction SilentlyContinue }
    $freed = 0L
    try {
        foreach ($file in @(Get-CleanupFiles $Id)) {
            try {
                $len = $file.Length
                if ($file.IsReadOnly) { $file.IsReadOnly = $false }
                $file.Delete()
                $freed += $len
            } catch {}   # Datei in Benutzung - überspringen
        }
        switch ($Id) {
            'usertemp' { Remove-EmptyDirs $env:TEMP }
            'wintemp'  { Remove-EmptyDirs "$win\Temp" }
            'wudl'     { Remove-EmptyDirs "$win\SoftwareDistribution\Download" }
        }
    } finally {
        if ($Id -eq 'wudl') { Start-Service bits, wuauserv -ErrorAction SilentlyContinue }
    }
    return $freed
}

function Get-RunningBrowsers {
    $map = @{ chrome = 'Google Chrome'; msedge = 'Microsoft Edge'; brave = 'Brave'; firefox = 'Mozilla Firefox' }
    foreach ($k in $map.Keys) { if (Get-Process -Name $k -ErrorAction SilentlyContinue) { $map[$k] } }
}

# Junk-Dateien auf allen Laufwerken
function Find-JunkFiles {
    $junkRx = New-Object regex '(\.(tmp|temp|_mp|~mp|gid|chk|dmp|\$\$\$|---)$)|(^thumbs\.db$)', 'IgnoreCase'
    $cut = (Get-Date).AddDays(-7)
    $excludeFull = @($env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData) | Where-Object { $_ }
    $excludeNames = '$Recycle.Bin', 'System Volume Information', 'Recovery', '$WinREAgent', 'Windows.old', 'WindowsApps', 'steamapps', 'Epic Games', 'node_modules', '.git'
    $result = New-Object System.Collections.ArrayList

    foreach ($drive in @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')) {
        $stack = New-Object System.Collections.Stack
        $stack.Push($drive.DeviceID + '\')
        while ($stack.Count -gt 0) {
            $dir = $stack.Pop()
            Report "Durchsuche $dir"
            try { $files = [IO.Directory]::GetFiles($dir) } catch { $files = @() }
            foreach ($fp in $files) {
                if (-not $junkRx.IsMatch([IO.Path]::GetFileName($fp))) { continue }
                try {
                    $fi = New-Object IO.FileInfo $fp
                    if ($fi.LastWriteTime -gt $cut) { continue }
                    [void]$result.Add([pscustomobject]@{ Path = $fi.FullName; Size = $fi.Length; Modified = $fi.LastWriteTime.ToString('dd.MM.yyyy') })
                } catch {}
            }
            try { $subs = [IO.Directory]::GetDirectories($dir) } catch { continue }
            foreach ($s in $subs) {
                try {
                    $di = New-Object IO.DirectoryInfo $s
                    if ($di.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
                    if ($excludeNames -contains $di.Name) { continue }
                    if ($excludeFull | Where-Object { $_ -ieq $s }) { continue }
                    $stack.Push($s)
                } catch {}
            }
        }
    }
    $result | Sort-Object Path -Unique | Sort-Object Size -Descending
}

# ---------------------------------------------------------------------------
#  Deinstallation mit Rückstandssuche
# ---------------------------------------------------------------------------
$script:UninstallPath = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
$script:BackupRoot = Join-Path $env:LOCALAPPDATA 'TuneRig\Backups'

function Open-BaseKey([string]$Hive, [string]$View) {
    $h = if ($Hive -eq 'HKLM') { [Microsoft.Win32.RegistryHive]::LocalMachine } else { [Microsoft.Win32.RegistryHive]::CurrentUser }
    $v = switch ($View) { '32' { [Microsoft.Win32.RegistryView]::Registry32 } '64' { [Microsoft.Win32.RegistryView]::Registry64 } default { [Microsoft.Win32.RegistryView]::Default } }
    [Microsoft.Win32.RegistryKey]::OpenBaseKey($h, $v)
}

function Get-InstalledPrograms([bool]$IncludeStore) {
    $list = New-Object System.Collections.ArrayList
    foreach ($src in @(@('HKLM', '64'), @('HKLM', '32'), @('HKCU', 'Default'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]
            $root = $bk.OpenSubKey($script:UninstallPath)
            if (-not $root) { continue }
            foreach ($sub in $root.GetSubKeyNames()) {
                try {
                    $k = $root.OpenSubKey($sub); if (-not $k) { continue }
                    $name = [string]$k.GetValue('DisplayName')
                    if (-not $name.Trim()) { continue }
                    if ($k.GetValue('SystemComponent') -eq 1) { continue }
                    if ($k.GetValue('ParentKeyName')) { continue }
                    if ([string]$k.GetValue('ReleaseType') -match 'Update|Hotfix') { continue }
                    $un = [string]$k.GetValue('UninstallString')
                    $isGuid = $sub -match '^\{[0-9A-Fa-f\-]{36}\}$'
                    $isMsi = ($k.GetValue('WindowsInstaller') -eq 1) -and $isGuid
                    if (-not $un -and -not $isMsi) { continue }
                    $date = $null; $ds = [string]$k.GetValue('InstallDate')
                    if ($ds -match '^\d{8}$') { try { $date = [datetime]::ParseExact($ds, 'yyyyMMdd', $null) } catch {} }
                    $size = 0L; $es = $k.GetValue('EstimatedSize'); if ($es -is [int]) { $size = [long]$es * 1024 }
                    [void]$list.Add([pscustomobject]@{
                        Name = $name.Trim(); Version = [string]$k.GetValue('DisplayVersion'); Publisher = ([string]$k.GetValue('Publisher')).Trim()
                        InstallDate = $(if ($date) { $date.ToString('dd.MM.yyyy') } else { '' }); Size = $size
                        InstallLocation = ([string]$k.GetValue('InstallLocation')).Trim().Trim('"').TrimEnd('\')
                        UninstallString = $un; IsMsi = $isMsi; ProductCode = $(if ($isGuid) { $sub } else { '' })
                        Hive = $src[0]; View = $src[1]; SubKey = "$($script:UninstallPath)\$sub"; KeyName = $sub
                        Source = 'Win32'; PackageFullName = ''
                        TypeText = $(if ($src[1] -eq '32') { '32-Bit' } elseif ($src[0] -eq 'HKCU') { 'Benutzer' } else { '64-Bit' })
                    })
                    $k.Close()
                } catch {}
            }
            $root.Close(); $bk.Close()
        } catch {}
    }
    if ($IncludeStore) {
        foreach ($a in @(Get-AppxPackage -PackageTypeFilter Main -ErrorAction SilentlyContinue | Where-Object { -not $_.IsFramework -and -not $_.NonRemovable -and $_.SignatureKind -eq 'Store' })) {
            $friendly = if ($a.Name -match '\.') { $a.Name.Substring($a.Name.LastIndexOf('.') + 1) } else { $a.Name }
            [void]$list.Add([pscustomobject]@{
                Name = "$friendly (Store)"; Version = $a.Version.ToString(); Publisher = $a.Name.Split('.')[0]; InstallDate = ''; Size = 0L
                InstallLocation = $a.InstallLocation; UninstallString = ''; IsMsi = $false; ProductCode = ''; Hive = ''; View = ''; SubKey = ''; KeyName = ''
                Source = 'Store'; PackageFullName = $a.PackageFullName; TypeText = 'Store-App'
            })
        }
    }
    $list | Sort-Object @{ e = { $_.Name.ToLower() + '|' + $_.Version } } -Unique | Sort-Object Name
}

function Get-UninstallCommand($P) {
    if ($P.IsMsi -and $P.ProductCode) { return @('msiexec.exe', "/x $($P.ProductCode)") }
    $cmd = [Environment]::ExpandEnvironmentVariables([string]$P.UninstallString).Trim()
    if (-not $cmd) { return @('', '') }
    if ($cmd -match 'msiexec(\.exe)?\s+/[ix]\s*(\{[0-9A-Fa-f\-]+\})') { return @('msiexec.exe', "/x $($Matches[2])") }
    if ($cmd.StartsWith('"')) {
        $end = $cmd.IndexOf('"', 1)
        if ($end -gt 0) { return @($cmd.Substring(1, $end - 1), $cmd.Substring($end + 1).Trim()) }
    }
    $i = $cmd.ToLower().IndexOf('.exe')
    if ($i -gt 0) { return @($cmd.Substring(0, $i + 4), $cmd.Substring($i + 4).Trim()) }
    $sp = $cmd.IndexOf(' ')
    if ($sp -gt 0) { return @($cmd.Substring(0, $sp), $cmd.Substring($sp + 1)) }
    return @($cmd, '')
}

# Startet den Uninstaller und wartet, bis er UND alle nachgestarteten Kopien (z. B. NSIS "Au_.exe") beendet sind
function Invoke-Uninstaller($P) {
    if ($P.Source -eq 'Store') {
        Report 'Entferne Store-App ...'
        try { Remove-AppxPackage -Package $P.PackageFullName -ErrorAction Stop; return 'Store-App wurde entfernt.' }
        catch { return 'Fehler: ' + $_.Exception.Message }
    }
    $exe, $arg = Get-UninstallCommand $P
    if (-not $exe) { return 'Kein Deinstallationsprogramm gefunden – nutze »Erzwungen entfernen«.' }
    if ($exe -ne 'msiexec.exe' -and [IO.Path]::IsPathRooted($exe) -and -not (Test-Path -LiteralPath $exe)) {
        return 'Das Deinstallationsprogramm existiert nicht mehr – nutze »Erzwungen entfernen«.'
    }
    Report 'Deinstallationsprogramm läuft … Folge den Anweisungen im Fenster des Programms.'
    $start = Get-Date
    $proc = if ($arg) { Start-Process -FilePath $exe -ArgumentList $arg -PassThru } else { Start-Process -FilePath $exe -PassThru }
    $null = $proc.Handle   # nötig, damit der Exit-Code später lesbar ist

    $tracked = New-Object 'System.Collections.Generic.HashSet[int]'
    [void]$tracked.Add($proc.Id)
    $quiet = 0
    while ($true) {
        $procs = @(Get-CimInstance Win32_Process -Property ProcessId, ParentProcessId, Name, CreationDate -ErrorAction SilentlyContinue)
        $alive = @{}
        foreach ($x in $procs) {
            $alive[[int]$x.ProcessId] = $true
            if ($x.CreationDate -ge $start.AddSeconds(-1)) {
                if ($tracked.Contains([int]$x.ParentProcessId) -or $x.Name -match '^(au_|un_a|un_|unins|uninst|_iu14d2n|_un|uninstall)') { [void]$tracked.Add([int]$x.ProcessId) }
            }
        }
        $any = $false; foreach ($id in $tracked) { if ($alive.ContainsKey($id)) { $any = $true; break } }
        if ($any) { $quiet = 0 } elseif (++$quiet -ge 6) { break }
        Start-Sleep -Milliseconds 500
    }
    return "Deinstallationsprogramm beendet (Code $($proc.ExitCode))."
}

$script:GenericNames = @(
    'microsoft', 'windows', 'commonfiles', 'common', 'intel', 'nvidia', 'nvidiacorporation', 'amd', 'google', 'mozilla', 'programs', 'program',
    'temp', 'packages', 'default', 'drivers', 'system', 'system32', 'update', 'updater', 'app', 'apps', 'application', 'applications',
    'software', 'tools', 'games', 'steam', 'data', 'cache', 'config', 'settings', 'user', 'users', 'public', 'shared', 'runtime', 'framework',
    'uninstall', 'installer', 'setup', 'launcher', 'client', 'service', 'services', 'helper', 'classes', 'policies', 'wow6432node', 'clients',
    'registeredapplications', 'microsoftcorporation', 'inc', 'corporation', 'gmbh', 'ltd', 'llc', 'desktop', 'documents', 'downloads',
    'startmenu', 'startup', 'local', 'roaming', 'locallow', 'appdata', 'programdata', 'programfiles', 'net', 'dotnet', 'java', 'python',
    'vulkan', 'directx', 'realtek', 'logitech', 'adobe', 'apple', 'oracle', 'valve', 'epicgames'
)

function ConvertTo-Token([string]$s) { ($s.ToLower() -replace '[^a-z0-9äöüß]', '') }

function Get-CleanName([string]$n) {
    $n = $n -replace '\((x64|x86|64[\s-]?bit|32[\s-]?bit|amd64)\)', ''
    $n = $n -replace '\b(x64|x86|64[\s-]?bit|32[\s-]?bit)\b', ''
    $n = $n -replace '\s+v?\d+([.,]\d+)+.*$', ''
    $n = $n -replace '\s*[-–]\s*(de|en|deutsch|english|de-de|en-us)\s*$', ''
    $n = $n -replace '\s*\(.*?\)\s*$', ''
    return $n.Trim(' ', '-', '_')
}

function Test-ProtectedPath([string]$Path) {
    $p = $Path.TrimEnd('\')
    if ($p.Length -le 3) { return $true }
    $prot = @(
        $env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramW6432, $env:CommonProgramFiles, ${env:CommonProgramFiles(x86)},
        $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA, $env:USERPROFILE, (Split-Path $env:USERPROFILE -Parent),
        "$env:LOCALAPPDATA\Programs", "$env:USERPROFILE\AppData\LocalLow",
        [Environment]::GetFolderPath('MyDocuments'), [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('CommonDesktopDirectory'),
        [Environment]::GetFolderPath('StartMenu'), [Environment]::GetFolderPath('CommonStartMenu'), [Environment]::GetFolderPath('Programs'),
        [Environment]::GetFolderPath('CommonPrograms'), [Environment]::GetFolderPath('Startup'), [Environment]::GetFolderPath('CommonStartup')
    ) | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') }
    if ($prot | Where-Object { $_ -ieq $p }) { return $true }
    return $p.StartsWith($env:windir + '\', [StringComparison]::OrdinalIgnoreCase)
}

function Get-DirSize([string]$Dir) {
    [long](Get-ChildItem -LiteralPath $Dir -File -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
}

function New-Leftover([string]$Type, [string]$Path, [string]$Reason, [hashtable]$Extra = @{}) {
    $o = [ordered]@{ Type = $Type; Path = $Path; Reason = $Reason; Size = 0L; Selected = $true; Shared = $false; Hive = ''; View = ''; SubKey = ''; ValueName = ''; Service = '' }
    foreach ($k in $Extra.Keys) { $o[$k] = $Extra[$k] }
    if ($Type -eq 'Ordner') { $o.Size = Get-DirSize $Path; $o.Selected = -not (Test-ProtectedPath $Path) }
    elseif ($Type -eq 'Datei') { try { $o.Size = (Get-Item -LiteralPath $Path -Force).Length } catch {} }
    [pscustomobject]$o
}

function Get-RegDisplayPath([string]$Hive, [string]$View, [string]$Sub) {
    if ($Hive -eq 'HKLM' -and $View -eq '32') { $Sub = $Sub -replace '^SOFTWARE\\', 'SOFTWARE\WOW6432Node\' }
    "$Hive\$Sub"
}

function New-RegLeftover([string]$Hive, [string]$View, [string]$Sub, [string]$Reason) {
    New-Leftover 'Registry-Schlüssel' (Get-RegDisplayPath $Hive $View $Sub) $Reason @{ Hive = $Hive; View = $View; SubKey = $Sub }
}

function Find-Leftovers($P, $AllPrograms) {
    $found = New-Object System.Collections.ArrayList
    $tokens = New-Object 'System.Collections.Generic.HashSet[string]'
    foreach ($t in @($P.Name, (Get-CleanName $P.Name), $(if ($P.InstallLocation) { Split-Path $P.InstallLocation -Leaf } else { '' }),
                     $(if ($P.KeyName -and $P.KeyName -notmatch '^\{') { $P.KeyName -replace '_is1$', '' } else { '' }))) {
        $n = ConvertTo-Token $t
        if ($n.Length -ge 4 -and $script:GenericNames -notcontains $n) { [void]$tokens.Add($n) }
    }
    $pub = ConvertTo-Token ($P.Publisher -replace '[,.]?\s*(inc|gmbh|ltd|llc|corp|corporation|co|ag|s\.?a|limited|software|technologies|entertainment)\.?$', '')
    $pubOk = $pub.Length -ge 3 -and $script:GenericNames -notcontains $pub
    $match = { param($s) $tokens.Contains((ConvertTo-Token $s)) }

    # 1) Deinstallationseintrag
    if ($P.SubKey) {
        $bk = Open-BaseKey $P.Hive $P.View; $k = $bk.OpenSubKey($P.SubKey)
        if ($k) { $k.Close(); [void]$found.Add((New-RegLeftover $P.Hive $P.View $P.SubKey 'Deinstallationseintrag in der Systemsteuerung')) }
        $bk.Close()
    }

    # 2) Registry: Software-Zweige
    Report 'Durchsuche Registry ...'
    foreach ($src in @(@('HKCU', 'Default', 'Software'), @('HKLM', '64', 'SOFTWARE'), @('HKLM', '32', 'SOFTWARE'))) {
        try {
            $bk = Open-BaseKey $src[0] $src[1]; $sw = $bk.OpenSubKey($src[2])
            foreach ($top in $sw.GetSubKeyNames()) {
                $tn = ConvertTo-Token $top
                if ($script:GenericNames -contains $tn) { continue }
                if (& $match $top) {
                    [void]$found.Add((New-RegLeftover $src[0] $src[1] "$($src[2])\$top" 'Programmeinstellungen'))
                } elseif ($pubOk -and $tn -eq $pub) {
                    $pk = $sw.OpenSubKey($top); if (-not $pk) { continue }
                    $subs = $pk.GetSubKeyNames(); $hit = @($subs | Where-Object { & $match $_ })
                    if ($hit.Count -gt 0) {
                        if ($hit.Count -eq $subs.Count -and $pk.ValueCount -eq 0) {
                            [void]$found.Add((New-RegLeftover $src[0] $src[1] "$($src[2])\$top" 'Herstellerschlüssel (enthält nur dieses Programm)'))
                        } else {
                            foreach ($h in $hit) { [void]$found.Add((New-RegLeftover $src[0] $src[1] "$($src[2])\$top\$h" 'Programmeinstellungen')) }
                        }
                    }
                    $pk.Close()
                }
            }
            $sw.Close(); $bk.Close()
        } catch {}
    }

    # 3) Autostart und App Paths
    $loc = [string]$P.InstallLocation
    $locOk = $loc.Length -gt 8 -and -not (Test-ProtectedPath $loc)
    foreach ($src in @(@('HKCU', 'Default'), @('HKLM', '64'), @('HKLM', '32'))) {
        $run = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
        try {
            $bk = Open-BaseKey $src[0] $src[1]; $rk = $bk.OpenSubKey($run)
            if ($rk) {
                foreach ($v in $rk.GetValueNames()) {
                    $data = [string]$rk.GetValue($v)
                    if ((& $match $v) -or ($locOk -and $data.IndexOf($loc, [StringComparison]::OrdinalIgnoreCase) -ge 0)) {
                        [void]$found.Add((New-Leftover 'Registry-Wert' ("{0} -> {1}" -f (Get-RegDisplayPath $src[0] $src[1] $run), $v) 'Autostart-Eintrag' @{ Hive = $src[0]; View = $src[1]; SubKey = $run; ValueName = $v }))
                    }
                }
                $rk.Close()
            }
            if ($locOk) {
                $ap = 'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths'
                $apk = $bk.OpenSubKey($ap)
                if ($apk) {
                    foreach ($e in $apk.GetSubKeyNames()) {
                        $ek = $apk.OpenSubKey($e)
                        $target = if ($ek) { ([string]$ek.GetValue('')).Trim('"') } else { '' }
                        if ($target.StartsWith($loc, [StringComparison]::OrdinalIgnoreCase)) { [void]$found.Add((New-RegLeftover $src[0] $src[1] "$ap\$e" 'Programmpfad-Registrierung')) }
                    }
                    $apk.Close()
                }
            }
            $bk.Close()
        } catch {}
    }

    # 4) Dateisystem
    Report 'Durchsuche Ordner ...'
    if ($locOk -and (Test-Path -LiteralPath $loc)) { [void]$found.Add((New-Leftover 'Ordner' $loc 'Installationsordner')) }
    $roots = @(
        $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:ProgramData, $env:APPDATA, $env:LOCALAPPDATA,
        "$env:LOCALAPPDATA\Programs", "$env:USERPROFILE\AppData\LocalLow",
        ([Environment]::GetFolderPath('CommonStartMenu') + '\Programs'), ([Environment]::GetFolderPath('StartMenu') + '\Programs')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    foreach ($root in $roots) {
        foreach ($d in @(Get-ChildItem -LiteralPath $root -Directory -Force -ErrorAction SilentlyContinue)) {
            $dn = ConvertTo-Token $d.Name
            if ($script:GenericNames -contains $dn) { continue }
            if (& $match $d.Name) {
                [void]$found.Add((New-Leftover 'Ordner' $d.FullName 'Programmdaten'))
            } elseif ($pubOk -and $dn -eq $pub) {
                $entries = @(Get-ChildItem -LiteralPath $d.FullName -Force -ErrorAction SilentlyContinue)
                $hit = @($entries | Where-Object { $_.PSIsContainer -and (& $match $_.Name) })
                if ($hit.Count -gt 0) {
                    if ($hit.Count -eq $entries.Count) { [void]$found.Add((New-Leftover 'Ordner' $d.FullName 'Herstellerordner (enthält nur dieses Programm)')) }
                    else { foreach ($h in $hit) { [void]$found.Add((New-Leftover 'Ordner' $h.FullName 'Programmdaten')) } }
                }
            }
        }
        if ($root -like '*\Programs') {
            foreach ($l in @(Get-ChildItem -LiteralPath $root -Filter *.lnk -File -ErrorAction SilentlyContinue)) {
                if (& $match $l.BaseName) { [void]$found.Add((New-Leftover 'Datei' $l.FullName 'Startmenü-Verknüpfung')) }
            }
        }
    }
    foreach ($desk in @([Environment]::GetFolderPath('DesktopDirectory'), [Environment]::GetFolderPath('CommonDesktopDirectory'))) {
        foreach ($l in @(Get-ChildItem -LiteralPath $desk -Filter *.lnk -File -ErrorAction SilentlyContinue)) {
            if (& $match $l.BaseName) { [void]$found.Add((New-Leftover 'Datei' $l.FullName 'Desktop-Verknüpfung')) }
        }
    }

    # 5) Dienste
    if ($locOk) {
        Report 'Prüfe Dienste ...'
        foreach ($s in @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue)) {
            if ([string]$s.PathName -and $s.PathName.IndexOf($loc, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                [void]$found.Add((New-Leftover 'Dienst' ("{0} ({1})" -f $s.DisplayName, $s.Name) 'Dienst des Programms' @{ Service = $s.Name }))
            }
        }
    }

    # Sicherheitsnetz: Ordner, die ein anderes installiertes Programm nutzt, nicht vorauswählen
    $others = @($AllPrograms | Where-Object { $_.Name -ne $P.Name -and $_.Source -eq 'Win32' -and ([string]$_.InstallLocation).Length -gt 3 })
    foreach ($f in @($found | Where-Object { $_.Type -eq 'Ordner' })) {
        $dir = $f.Path.TrimEnd('\') + '\'
        $user = $others | Where-Object { ($_.InstallLocation.TrimEnd('\') + '\').StartsWith($dir, [StringComparison]::OrdinalIgnoreCase) } | Select-Object -First 1
        if ($user) { $f.Selected = $false; $f.Shared = $true; $f.Reason += " – wird auch von $($user.Name) genutzt" }
    }

    # Doppelte und verschachtelte Einträge entfernen
    $unique = @($found | Sort-Object { $_.Type + '|' + $_.Path.ToLower() } -Unique)
    $selFolders = @($unique | Where-Object { $_.Type -eq 'Ordner' -and $_.Selected } | ForEach-Object { $_.Path.TrimEnd('\') + '\' })
    $keys = @($unique | Where-Object { $_.Type -eq 'Registry-Schlüssel' } | ForEach-Object { $_.Path + '\' })
    $unique | Where-Object {
        $x = $_
        switch ($x.Type) {
            { $_ -in 'Ordner', 'Datei' } { -not ($selFolders | Where-Object { $x.Path.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) -and ($x.Path.TrimEnd('\') + '\') -ne $_ }); break }
            'Registry-Schlüssel' { -not ($keys | Where-Object { $x.Path.StartsWith($_, [StringComparison]::OrdinalIgnoreCase) }); break }
            default { $true }
        }
    } | Sort-Object Type, Path
}

# Sichert einen Registry-Schlüssel als .reg-Datei (per Doppelklick wiederherstellbar)
function Export-RegKey([string]$Hive, [string]$View, [string]$Sub, [string]$File) {
    $a = @('export', "$Hive\$Sub", $File, '/y')
    if ($View -eq '32') { $a += '/reg:32' } elseif ($View -eq '64') { $a += '/reg:64' }
    & reg.exe @a 2>&1 | Out-Null
}

function Remove-Leftovers($P, $Items) {
    $safe = $P.Name -replace '[^\w\-]+', '_'
    $backup = Join-Path $script:BackupRoot ("{0:yyyy-MM-dd_HH-mm-ss}_{1}" -f (Get-Date), $safe)
    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    $ok = 0; $reboot = 0; $failed = 0; $n = 0; $errors = @()

    foreach ($it in $Items) {
        $n++; Report "Entferne $n/$($Items.Count): $($it.Path)"
        try {
            switch ($it.Type) {
                'Registry-Schlüssel' {
                    Export-RegKey $it.Hive $it.View $it.SubKey (Join-Path $backup ("reg_{0:000}.reg" -f $n))
                    $bk = Open-BaseKey $it.Hive $it.View; $bk.DeleteSubKeyTree($it.SubKey, $false); $bk.Close(); $ok++
                }
                'Registry-Wert' {
                    Export-RegKey $it.Hive $it.View $it.SubKey (Join-Path $backup ("reg_{0:000}.reg" -f $n))
                    $bk = Open-BaseKey $it.Hive $it.View; $k = $bk.OpenSubKey($it.SubKey, $true)
                    if ($k) { $k.DeleteValue($it.ValueName, $false); $k.Close() }; $bk.Close(); $ok++
                }
                { $_ -in 'Ordner', 'Datei' } {
                    if (Test-ProtectedPath $it.Path) { $failed++; $errors += "Geschützt: $($it.Path)"; break }
                    if ([PCO.Native]::Recycle($it.Path)) { $ok++; break }
                    # gesperrt: Dateien beim nächsten Neustart löschen
                    $sched = 0
                    if (Test-Path -LiteralPath $it.Path -PathType Container) {
                        foreach ($f in @(Get-ChildItem -LiteralPath $it.Path -File -Recurse -Force -ErrorAction SilentlyContinue)) {
                            try { $f.Delete() } catch { if ([PCO.Native]::DeleteOnReboot($f.FullName)) { $sched++ } }
                        }
                        foreach ($d in @(Get-ChildItem -LiteralPath $it.Path -Directory -Recurse -Force -ErrorAction SilentlyContinue | Sort-Object { $_.FullName.Length } -Descending) + @(Get-Item -LiteralPath $it.Path -Force)) {
                            try { $d.Delete() } catch { if ([PCO.Native]::DeleteOnReboot($d.FullName)) { $sched++ } }
                        }
                    } elseif ([PCO.Native]::DeleteOnReboot($it.Path)) { $sched++ }
                    if ($sched -gt 0) { $reboot++ } else { $ok++ }
                }
                'Dienst' {
                    sc.exe stop $it.Service 2>&1 | Out-Null
                    $out = sc.exe delete $it.Service 2>&1
                    if ($LASTEXITCODE -eq 0) { $ok++ } else { $failed++; $errors += "$($it.Path): $out" }
                }
            }
        } catch { $failed++; $errors += "$($it.Path): $($_.Exception.Message)" }
    }
    $msg = "$ok Einträge entfernt."
    if ($reboot -gt 0) { $msg += " $reboot gesperrte Elemente werden beim nächsten Neustart gelöscht." }
    if ($failed -gt 0) { $msg += " $failed fehlgeschlagen:`n" + (($errors | Select-Object -First 10) -join "`n") }
    $msg += "`n`nRegistry-Sicherung: $backup`nGelöschte Dateien liegen im Papierkorb."
    return $msg
}

# ===========================================================================
#  GAMING-MODUS
#  Jede Optimierung hat: Wirkung (Impact 0-3), Modus (recommended / optional /
#  experimental), ggf. Nebenwirkung (Risk) und - wo möglich - Rückgängig (Revert).
#  Bewusst NICHT enthalten sind Tweaks ohne belegte Wirkung oder mit Schaden
#  (siehe $script:GamingMyths).
# ===========================================================================
$script:MmKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'
$script:MmGames = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
$script:DoKey = 'S-1-5-20\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Settings'
$script:ProcSub = '54533251-82be-4824-96c1-47b60b740d00'
$script:CoreParking = '0cc5b647-c1df-4637-891a-dec35c318583'
$script:WlanSub = '19cbb8fa-5279-450e-9fac-8a3d5fedd0c1'
$script:WlanPower = '12bbebe6-58d6-4636-95bb-3217ef867c1a'
$script:EeeKeywords = '*EEE', 'EEE', 'AdvancedEEE', 'EnableGreenEthernet'

$script:GamingMyths = @(
    @{ T = 'Windows Defender abschalten'; W = 'Kaum Leistungsgewinn, aber der PC ist ungeschützt. Besser: Spieleordner bei Bedarf als Ausnahme eintragen.' }
    @{ T = '20 % reservierte Bandbreite (QoS) freigeben'; W = 'Ein Mythos: Windows reserviert keine Bandbreite, solange kein Programm sie anfordert.' }
    @{ T = 'TCP-Autotuning abschalten'; W = 'Macht Downloads langsamer und senkt den Ping nicht. Das Programm stellt es im Gegenteil auf »Normal« zurück.' }
    @{ T = 'NetworkThrottlingIndex ändern'; W = 'Betrifft die Multimedia-Wiedergabe, nicht den Ping in Spielen.' }
    @{ T = 'Arbeitsspeicher-»Booster« / RAM-Cleaner'; W = 'Leeren den Speicher nur scheinbar - Windows muss die Daten danach neu laden, das verursacht eher Ruckler.' }
    @{ T = 'Auslagerungsdatei abschalten'; W = 'Kann Spiele zum Absturz bringen, wenn der Arbeitsspeicher knapp wird.' }
    @{ T = 'HPET / Zeitgeber per bcdedit verändern'; W = 'Wirkung je nach PC unterschiedlich, kann Ruckler sogar verstärken.' }
    @{ T = 'Windows Update dauerhaft abschalten'; W = 'Sicherheitsrisiko und keine Leistung im Spiel - der Spielmodus verhindert Updates beim Spielen ohnehin.' }
)

# ---------------------------------------------------------------------------
#  Bildschirme
# ---------------------------------------------------------------------------
function Get-DisplayInfo {
    $i = 0
    foreach ($l in @([PCO.Native]::GetDisplays())) {
        $i++
        $p = $l -split '\|'
        [pscustomobject]@{ No = $i; Device = $p[0]; Monitor = $p[1]; Width = [int]$p[2]; Height = [int]$p[3]; Hz = [int]$p[4]; MaxHz = [int]$p[5]; Gpu = $p[6] }
    }
}

# ---------------------------------------------------------------------------
#  Netzwerk
# ---------------------------------------------------------------------------
function Get-ActiveAdapters {
    @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
}

function Test-WifiAdapter($a) {
    ([string]$a.PhysicalMediaType -match '802\.11|Wireless') -or ([string]$a.InterfaceDescription -match 'Wi-?Fi|Wireless|WLAN|802\.11')
}

function Get-EeeProperties {
    $list = @()
    foreach ($a in @(Get-ActiveAdapters | Where-Object { -not (Test-WifiAdapter $_) })) {
        foreach ($k in $script:EeeKeywords) {
            $p = Get-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword $k -ErrorAction SilentlyContinue
            if ($p) { $list += $p }
        }
    }
    return $list
}

function Get-TcpInterfaceKeys {
    $root = 'SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
    $k = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($root)
    if (-not $k) { return @() }
    $res = @()
    foreach ($n in $k.GetSubKeyNames()) {
        $s = $k.OpenSubKey($n)
        if (-not $s) { continue }
        $ip = [string](@($s.GetValue('DhcpIPAddress')) + @($s.GetValue('IPAddress')) | Where-Object { $_ -and $_ -ne '0.0.0.0' } | Select-Object -First 1)
        if ($ip) { $res += "$root\$n" }
        $s.Close()
    }
    $k.Close()
    return $res
}

function Measure-Ping([string]$Target, [int]$Count = 10) {
    $p = New-Object System.Net.NetworkInformation.Ping
    $times = @(); $lost = 0
    for ($i = 0; $i -lt $Count; $i++) {
        try { $r = $p.Send($Target, 1000); if ($r.Status -eq 'Success') { $times += [int]$r.RoundtripTime } else { $lost++ } } catch { $lost++ }
        Start-Sleep -Milliseconds 120
    }
    if ($times.Count -eq 0) { return [pscustomobject]@{ Target = $Target; Avg = -1; Jitter = -1; Max = -1; Loss = 100 } }
    $avg = ($times | Measure-Object -Average).Average
    $jit = 0.0
    for ($i = 1; $i -lt $times.Count; $i++) { $jit += [math]::Abs($times[$i] - $times[$i - 1]) }
    if ($times.Count -gt 1) { $jit = $jit / ($times.Count - 1) }
    [pscustomobject]@{ Target = $Target; Avg = [math]::Round($avg, 1); Jitter = [math]::Round($jit, 1)
        Max = ($times | Measure-Object -Maximum).Maximum; Loss = [math]::Round($lost * 100 / $Count) }
}

function Measure-Dns([string]$Server) {
    $names = 'www.google.com', 'www.wikipedia.org', 'www.microsoft.com', 'www.amazon.de', 'store.steampowered.com'
    $t = @()
    foreach ($n in $names) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        try { $null = Resolve-DnsName -Name $n -Server $Server -DnsOnly -NoHostsFile -QuickTimeout -ErrorAction Stop; $t += $sw.Elapsed.TotalMilliseconds }
        catch { $t += 2000 }
    }
    $s = @($t | Sort-Object)
    return [math]::Round($s[[int][math]::Floor($s.Count / 2)], 0)
}

$script:PublicDns = @(
    @{ Name = 'Cloudflare'; P = '1.1.1.1'; S = '1.0.0.1' }
    @{ Name = 'Google'; P = '8.8.8.8'; S = '8.8.4.4' }
    @{ Name = 'Quad9'; P = '9.9.9.9'; S = '149.112.112.112' }
)

function Get-NetworkStatus {
    $cfg = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } | Select-Object -First 1
    if (-not $cfg) { return [pscustomobject]@{ Connected = $false; Time = (Get-Date) } }
    $ad = $cfg.NetAdapter
    $gw = [string](@($cfg.IPv4DefaultGateway)[0].NextHop)
    Report 'Messe den Ping zum Router und ins Internet ...'
    $pGw = Measure-Ping $gw 10
    $pNet = Measure-Ping '1.1.1.1' 15
    Report 'Teste die Geschwindigkeit der DNS-Server ...'
    $cur = @((Get-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses)
    $curDns = [string]($cur | Select-Object -First 1)
    $dns = @()
    if ($curDns) { $dns += [pscustomobject]@{ Name = 'Aktuell'; P = $curDns; S = ''; Ms = (Measure-Dns $curDns) } }
    foreach ($d in $script:PublicDns) { if ($d.P -ne $curDns) { $dns += [pscustomobject]@{ Name = $d.Name; P = $d.P; S = $d.S; Ms = (Measure-Dns $d.P) } } }
    $public = $script:PublicDns | Where-Object { $_.P -eq $curDns } | Select-Object -First 1
    [pscustomobject]@{
        Connected = $true; Adapter = $ad.Name; Desc = $ad.InterfaceDescription; IfIndex = $ad.ifIndex; Wifi = (Test-WifiAdapter $ad)
        Speed = [string]$ad.LinkSpeed; Gateway = $gw; PingGw = $pGw; PingNet = $pNet; CurrentDns = $curDns
        CurrentDnsName = $(if ($public) { $public.Name } elseif ($curDns -eq $gw) { 'Router' } else { $curDns }); Dns = $dns; Time = (Get-Date)
    }
}

function Set-GamingDns([int]$IfIndex, [string]$Primary, [string]$Secondary) {
    Set-DnsClientServerAddress -InterfaceIndex $IfIndex -ServerAddresses @($Primary, $Secondary) -ErrorAction Stop
    Clear-DnsClientCache -ErrorAction SilentlyContinue
}

function Reset-GamingDns([int]$IfIndex) {
    Set-DnsClientServerAddress -InterfaceIndex $IfIndex -ResetServerAddresses -ErrorAction Stop
    Clear-DnsClientCache -ErrorAction SilentlyContinue
}

# ---------------------------------------------------------------------------
#  Autostart
# ---------------------------------------------------------------------------
$script:StartupKeepRx = 'SecurityHealth|Windows Security|Defender|RtkAud|Realtek|Waves|Dolby|Nahimic|NVIDIA|nvcpl|NvBackend|Radeon|AMD|igfx|Intel|Synaptics|ELAN|Logitech|LGHUB|Razer|Corsair|iCUE|SteelSeries|OneDrive|Dropbox|Bitdefender|Kaspersky|Avast|AVG|ESET|Norton|McAfee|Avira|Malwarebytes|Sophos|G DATA|Wacom|Bluetooth|Touchpad|Audio|Keyboard|Tastatur|VPN'
$script:StartupOffRx = 'Steam|Epic|Discord|Spotify|Teams|Skype|EADesktop|EA Desktop|Origin|Ubisoft|uplay|Battle\.net|GOG|Galaxy|Adobe|CCXProcess|Creative Cloud|EdgeAutoLaunch|iTunes|Opera|Zoom|WhatsApp|Telegram|Slack|CCleaner|jusched|Java Update|Overwolf|Medal|Cortana|Wallpaper Engine|uTorrent|qBittorrent|BitTorrent|Messenger|Amazon Music|Deezer'

function Get-StartupApproved([string]$Hive, [string]$Sub, [string]$Name) {
    try {
        $bk = Open-BaseKey $Hive $(if ($Hive -eq 'HKLM') { '64' } else { 'Default' })
        $k = $bk.OpenSubKey("Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\$Sub")
        if (-not $k) { return $true }
        $v = $k.GetValue($Name)
        $k.Close(); $bk.Close()
        if ($v -is [byte[]] -and $v.Length -gt 0) { return (($v[0] % 2) -eq 0) }
    } catch {}
    return $true
}

function Set-StartupItemState([string]$Id, [bool]$Enable) {
    $hive, $sub, $name = $Id -split '\|', 3
    $bk = Open-BaseKey $hive $(if ($hive -eq 'HKLM') { '64' } else { 'Default' })
    $k = $bk.CreateSubKey("Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\$sub")
    $bytes = New-Object byte[] 12
    $bytes[0] = if ($Enable) { 2 } else { 3 }
    $k.SetValue($name, $bytes, [Microsoft.Win32.RegistryValueKind]::Binary)
    $k.Close(); $bk.Close()
}

function Get-StartupItems {
    $items = @()
    $sources = @(
        @{ Hive = 'HKCU'; View = 'Default'; Sub = 'Run'; Who = 'Nur dieser Benutzer' }
        @{ Hive = 'HKLM'; View = '64'; Sub = 'Run'; Who = 'Alle Benutzer' }
        @{ Hive = 'HKLM'; View = '32'; Sub = 'Run32'; Who = 'Alle Benutzer' }
    )
    foreach ($src in $sources) {
        try {
            $bk = Open-BaseKey $src.Hive $src.View
            $k = $bk.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run')
            if ($k) {
                foreach ($n in $k.GetValueNames()) {
                    if (-not $n) { continue }
                    $items += [pscustomobject]@{ Id = "$($src.Hive)|$($src.Sub)|$n"; Name = $n; Command = [string]$k.GetValue($n); Who = $src.Who
                        Enabled = (Get-StartupApproved $src.Hive $src.Sub $n) }
                }
                $k.Close()
            }
            $bk.Close()
        } catch {}
    }
    foreach ($f in @(@{ Dir = [Environment]::GetFolderPath('Startup'); Hive = 'HKCU'; Who = 'Nur dieser Benutzer' }, @{ Dir = [Environment]::GetFolderPath('CommonStartup'); Hive = 'HKLM'; Who = 'Alle Benutzer' })) {
        foreach ($file in @(Get-ChildItem -LiteralPath $f.Dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne 'desktop.ini' })) {
            $items += [pscustomobject]@{ Id = "$($f.Hive)|StartupFolder|$($file.Name)"; Name = $file.BaseName; Command = $file.FullName; Who = $f.Who
                Enabled = (Get-StartupApproved $f.Hive 'StartupFolder' $file.Name) }
        }
    }
    foreach ($i in $items) {
        $text = "$($i.Name) $($i.Command)"
        $class = if ($text -match $script:StartupKeepRx) { 'keep' } elseif ($text -match $script:StartupOffRx) { 'off' } else { 'neutral' }
        $i | Add-Member -NotePropertyName Class -NotePropertyValue $class
    }
    $items | Sort-Object @{ e = { @{ off = 0; neutral = 1; keep = 2 }[$_.Class] } }, Name
}

# ---------------------------------------------------------------------------
#  Gaming-Optimierungen
# ---------------------------------------------------------------------------
function Get-GamingTweakDefs([bool]$IsLaptop) {
    $akku = if ($IsLaptop) { 'Laptop: Der Akku hält etwas kürzer.' } else { '' }
    @(
        # ======================= Bild & Steuerung =======================
        @{ Id = 'refresh'; Group = 'display'; Mode = 'recommended'; Impact = 3; Restart = $false
           Title = 'Bildwiederholrate des Monitors'; Target = 'Höchste mögliche Bildwiederholrate'; Fix = 'Auf Maximum stellen'; Risk = ''
           Benefit = 'Deutlich flüssigeres Bild und weniger Verzögerung - der Monitor zeigt alle Bilder, die die Grafikkarte liefert.'
           Desc = 'Windows stellt Monitore oft auf 60 Hz, obwohl sie 144 Hz oder mehr können. Beim Umstellen wird der Bildschirm kurz schwarz. Erscheint die höhere Rate gar nicht, liegt es meist am Kabel (DisplayPort verwenden) oder am Anschluss (Grafikkarte statt Mainboard).'
           Applicable = { @(Get-DisplayInfo).Count -gt 0 }
           Read = { (@(Get-DisplayInfo) | ForEach-Object { "Bildschirm $($_.No): $($_.Hz) Hz" + $(if ($_.MaxHz -gt $_.Hz) { " (möglich: $($_.MaxHz) Hz)" } else { ' (Maximum)' }) }) -join '  ·  ' }
           Check = { -not (@(Get-DisplayInfo) | Where-Object { $_.MaxHz -gt $_.Hz }) }
           Apply = {
               foreach ($d in @(Get-DisplayInfo | Where-Object { $_.MaxHz -gt $_.Hz })) {
                   $r = [PCO.Native]::SetRefreshRate($d.Device, $d.MaxHz)
                   if ($r -ne 0) { throw "Bildschirm $($d.No) ließ sich nicht auf $($d.MaxHz) Hz stellen (Code $r). Prüf Kabel und Anschluss." }
               }
           } }
        @{ Id = 'vrr'; Group = 'display'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Variable Bildwiederholrate für Fensterspiele'; Target = 'Einschalten'; Fix = 'Einschalten'; Risk = ''
           Benefit = 'G-Sync/FreeSync funktioniert auch bei Spielen im Fenster- oder randlosen Modus - weniger Zerreißen und Ruckeln.'
           Desc = 'Wirkt nur mit einem Monitor, der G-Sync, FreeSync oder »Adaptive Sync« unterstützt. Sonst schadet die Einstellung nicht.'
           Read = { if ((Get-DxGlobal) -match 'VRROptimizeEnable=1;') { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { (Get-DxGlobal) -match 'VRROptimizeEnable=1;' }
           Apply = { Set-DxGlobalValue 'VRROptimizeEnable' '1' }
           Revert = { Set-DxGlobalValue 'VRROptimizeEnable' '0' } }
        @{ Id = 'mouse'; Group = 'display'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Mausbeschleunigung'; Target = 'Ausschalten'; Fix = 'Ausschalten'; Risk = ''
           Benefit = 'Präziseres Zielen: Die gleiche Handbewegung bewegt den Mauszeiger immer gleich weit.'
           Desc = 'Windows beschleunigt den Mauszeiger bei schnellen Bewegungen (»Zeigerbeschleunigung verbessern«). Für Spiele ist das hinderlich. Die Mausempfindlichkeit selbst bleibt unverändert.'
           Read = { if ((Get-RegValue 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1') -eq '0') { 'Mausbeschleunigung ist ausgeschaltet' } else { 'Mausbeschleunigung ist eingeschaltet' } }
           Check = { (Get-RegValue 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1') -eq '0' }
           Apply = {
               Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '0'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold1' '0'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold2' '0'
               [void][PCO.Native]::SetMouseAcceleration($false)
           }
           Revert = {
               Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseSpeed' '1'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold1' '6'; Set-RegString 'HKCU' 'Control Panel\Mouse' 'MouseThreshold2' '10'
               [void][PCO.Native]::SetMouseAcceleration($true)
           } }

        # ======================= Prozessor & System =======================
        @{ Id = 'coreparking'; Group = 'system'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Prozessorkerne schlafen legen (Core Parking)'; Target = 'Alle Kerne bleiben aktiv'; Fix = 'Alle Kerne aktiv halten'; Risk = $akku
           Benefit = 'Weniger Mikroruckler, weil keine Prozessorkerne erst »aufwachen« müssen.'
           Desc = 'Windows legt ungenutzte Kerne schlafen, um Strom zu sparen. Wird plötzlich Leistung gebraucht, dauert das Aufwecken einen Moment.'
           Read = { $v = Get-PowerValue $script:ProcSub $script:CoreParking; if ($v -lt 0) { 'unbekannt' } else { "Mindestens $v % der Kerne bleiben aktiv" } }
           Check = { $v = Get-PowerValue $script:ProcSub $script:CoreParking; ($v -eq 100) -or ($v -lt 0) }
           Apply = { Set-PowerValue $script:ProcSub $script:CoreParking 100 } }
        @{ Id = 'powerthrottling'; Group = 'system'; Mode = 'optional'; Impact = 0; Restart = $true
           Title = 'Drosselung von Hintergrundprogrammen'; Target = 'Ausschalten - nur beim Streamen oder Aufnehmen'; Fix = 'Drosselung ausschalten'
           Risk = 'Hintergrundprogramme verbrauchen mehr Strom' + $(if ($IsLaptop) { ' - kürzere Akkulaufzeit' } else { '' }) + '. Dem Spiel selbst bringt das nichts.'
           Benefit = 'Nur sinnvoll, wenn du nebenbei streamst oder aufnimmst (z. B. OBS) und die Aufnahme ruckelt. Das Spiel selbst wird nie gedrosselt.'
           Desc = 'Windows bremst nur Programme, die im Hintergrund laufen (»Power Throttling«). Das Spiel im Vordergrund ist davon nie betroffen und bekommt immer volle Leistung. Mit dem Energiesparplan Höchstleistung (Schritt Leistung) drosselt Windows ohnehin kaum noch. Deshalb hier: eingeschaltet lassen.'
           Read = { if ((Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0) -eq 1) { 'Drosselung ist ausgeschaltet' } else { 'Drosselung ist eingeschaltet (Windows-Standard)' } }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0) -eq 1 }
           Apply = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1 }
           Revert = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 0 } }
        @{ Id = 'trim'; Group = 'system'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'SSD-Pflege (TRIM)'; Target = 'Einschalten'; Fix = 'TRIM einschalten'; Risk = ''
           Benefit = 'Die SSD bleibt dauerhaft schnell - Spiele laden nicht mit der Zeit langsamer.'
           Desc = 'TRIM teilt der SSD mit, welche Bereiche frei sind. Ist es ausgeschaltet (oft durch alte Tuning-Programme), wird die SSD mit der Zeit langsamer.'
           Applicable = { @(Get-CimInstance -Namespace 'root\Microsoft\Windows\Storage' -ClassName MSFT_PhysicalDisk -ErrorAction SilentlyContinue | Where-Object { [int]$_.MediaType -eq 4 }).Count -gt 0 }
           Read = { if ((fsutil.exe behavior query DisableDeleteNotify | Out-String) -match 'NTFS[^\r\n]*=\s*1') { 'TRIM ist ausgeschaltet' } else { 'TRIM ist eingeschaltet' } }
           Check = { -not ((fsutil.exe behavior query DisableDeleteNotify | Out-String) -match 'NTFS[^\r\n]*=\s*1') }
           Apply = { fsutil.exe behavior set DisableDeleteNotify 0 | Out-Null } }
        @{ Id = 'hvci'; Group = 'system'; Mode = 'optional'; Impact = 2; Restart = $true
           Title = 'Speicher-Integrität (Kernisolierung)'; Target = 'Beim Spielen ausschalten'; Fix = 'Ausschalten'
           Risk = 'Weniger Schutz vor Schadsoftware, die Treiber angreift. Microsoft empfiehlt, sie nach dem Spielen wieder einzuschalten.'
           Benefit = 'Laut Microsoft in manchen Spielen spürbar mehr FPS, weil Windows Treiber nicht mehr zusätzlich überwacht.'
           Desc = 'Eine Sicherheitsfunktion von Windows 11. Microsoft nennt das Abschalten selbst als Möglichkeit für mehr Spieleleistung - mit dem Hinweis, dass der PC dann angreifbarer ist. Hier jederzeit wieder einschaltbar (Button »Zurücksetzen«).'
           Read = {
               $cfg = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' $null
               $run = @((Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning) -contains 2
               if ($cfg -eq 0 -and $run) { 'Ausgeschaltet - wirkt nach dem Neustart' } elseif ($cfg -eq 1 -and -not $run) { 'Eingeschaltet - wirkt nach dem Neustart' } elseif ($run -or $cfg -eq 1) { 'Eingeschaltet' } else { 'Ausgeschaltet' }
           }
           Check = {
               $cfg = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' $null
               if ($cfg -eq 0) { return $true }
               if ($cfg -eq 1) { return $false }
               -not (@((Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard -ErrorAction SilentlyContinue).SecurityServicesRunning) -contains 2)
           }
           Apply = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' 0 }
           Revert = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' 'Enabled' 1 } }
        @{ Id = 'vmp'; Group = 'system'; Mode = 'optional'; Impact = 1; Restart = $true
           Title = 'Plattform für virtuelle Computer'; Target = 'Ausschalten (wenn nicht benötigt)'; Fix = 'Ausschalten'
           Risk = 'WSL 2, Android-Apps, Hyper-V und manche Emulatoren funktionieren danach nicht mehr.'
           Benefit = 'Laut Microsoft in manchen Spielen etwas mehr Leistung, weil die Virtualisierungsschicht wegfällt.'
           Desc = 'Wird für virtuelle Maschinen und Linux unter Windows benötigt. Wer das nicht nutzt, kann sie abschalten. Hier jederzeit wieder einschaltbar.'
           Applicable = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; [bool]$f }
           Read = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; if ([string]$f.State -match '^Enabled') { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { $f = Get-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -ErrorAction SilentlyContinue; [string]$f.State -notmatch '^Enabled' }
           Apply = { Disable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart -ErrorAction Stop | Out-Null }
           Revert = { Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart -ErrorAction Stop | Out-Null } }
        @{ Id = 'bgapps'; Group = 'system'; Mode = 'optional'; Impact = 1; Restart = $false
           Title = 'Store-Apps im Hintergrund'; Target = 'Nicht im Hintergrund ausführen'; Fix = 'Ausschalten'
           Risk = 'Store-Apps wie Mail, Kalender oder Wetter aktualisieren sich erst beim Öffnen und zeigen evtl. keine Benachrichtigungen.'
           Benefit = 'Weniger Programme im Hintergrund - etwas mehr Leistung und Arbeitsspeicher für Spiele.'
           Desc = 'Gilt nur für Apps aus dem Microsoft Store, nicht für normale Programme wie Discord oder Steam.'
           Read = { if ((Get-RegValue 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 0) -eq 2) { 'Store-Apps laufen nicht im Hintergrund' } else { 'Store-Apps dürfen im Hintergrund laufen' } }
           Check = { (Get-RegValue 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 0) -eq 2 }
           Apply = { Set-RegDword 'HKLM' 'SOFTWARE\Policies\Microsoft\Windows\AppPrivacy' 'LetAppsRunInBackground' 2 }
           Revert = { try { $k = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Policies\Microsoft\Windows\AppPrivacy', $true); if ($k) { $k.DeleteValue('LetAppsRunInBackground', $false); $k.Close() } } catch {} } }
        @{ Id = 'mmcss'; Group = 'system'; Mode = 'experimental'; Impact = 1; Restart = $true
           Title = 'Vorrang für Spiele im Multimedia-Planer'; Target = 'Spiele bevorzugen'; Fix = 'Anwenden'
           Risk = 'Die Wirkung ist umstritten und je nach PC kaum messbar.'
           Benefit = 'Windows reserviert weniger Rechenzeit für Hintergrundaufgaben und gibt Spielen höhere Priorität.'
           Desc = 'Setzt SystemResponsiveness auf 10 % und für die Aufgabe »Games« höhere Prozessor- und Grafikpriorität. Beliebter Gaming-Tweak, unabhängige Messungen zeigen aber meist nur kleine Unterschiede.'
           Read = { "Für Hintergrund reserviert: $(Get-RegValue 'HKLM' $script:MmKey 'SystemResponsiveness' 20) %  ·  Spiele-Priorität: $(Get-RegValue 'HKLM' $script:MmGames 'Priority' 2)" }
           Check = { (Get-RegValue 'HKLM' $script:MmKey 'SystemResponsiveness' 20) -le 10 -and (Get-RegValue 'HKLM' $script:MmGames 'Priority' 2) -ge 6 }
           Apply = {
               Set-RegDword 'HKLM' $script:MmKey 'SystemResponsiveness' 10
               Set-RegDword 'HKLM' $script:MmGames 'GPU Priority' 8; Set-RegDword 'HKLM' $script:MmGames 'Priority' 6
               Set-RegString 'HKLM' $script:MmGames 'Scheduling Category' 'High'; Set-RegString 'HKLM' $script:MmGames 'SFIO Priority' 'High'
           }
           Revert = {
               Set-RegDword 'HKLM' $script:MmKey 'SystemResponsiveness' 20
               Set-RegDword 'HKLM' $script:MmGames 'GPU Priority' 8; Set-RegDword 'HKLM' $script:MmGames 'Priority' 2
               Set-RegString 'HKLM' $script:MmGames 'Scheduling Category' 'Medium'; Set-RegString 'HKLM' $script:MmGames 'SFIO Priority' 'Normal'
           } }
        @{ Id = 'priosep'; Group = 'system'; Mode = 'experimental'; Impact = 1; Restart = $false
           Title = 'Prozessor-Zeitverteilung (Vordergrund-Vorrang)'; Target = 'Vordergrund stärker bevorzugen'; Fix = 'Anwenden'
           Risk = 'Wirkung umstritten. Hintergrundaufgaben (Downloads, Aufnahmen) können langsamer laufen.'
           Benefit = 'Das Programm im Vordergrund - also das Spiel - bekommt kürzere Reaktionszeiten.'
           Desc = 'Setzt Win32PrioritySeparation auf 0x26 (kurze, variable Zeitscheiben mit hohem Vordergrund-Vorrang). In Gaming-Foren beliebt, messbare Vorteile sind nicht belegt.'
           Read = { $v = Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2; 'Wert: 0x{0:X2}{1}' -f [int]$v, $(if ([int]$v -eq 2) { ' (Windows-Standard)' } else { '' }) }
           Check = { (Get-RegValue 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2) -eq 0x26 }
           Apply = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 0x26 }
           Revert = { Set-RegDword 'HKLM' 'SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 2 } }

        # ======================= Internet & Ping =======================
        @{ Id = 'autotuning'; Group = 'network'; Mode = 'recommended'; Impact = 2; Restart = $false
           Title = 'TCP-Autotuning (Empfangsfenster)'; Target = 'Normal (Windows-Standard)'; Fix = 'Reparieren'; Risk = ''
           Benefit = 'Downloads (z. B. Spiele-Updates) nutzen wieder die volle Geschwindigkeit deiner Leitung.'
           Desc = 'Viele »Internet-Tuning«-Programme schalten diese Funktion ab. Das senkt den Ping nicht, macht aber Downloads langsamer.'
           Read = { $s = Get-NetTCPSetting -SettingName Internet -ErrorAction SilentlyContinue; if ($s) { "Stufe: $($s.AutoTuningLevelLocal)" } else { 'unbekannt' } }
           Check = { $s = Get-NetTCPSetting -SettingName Internet -ErrorAction SilentlyContinue; (-not $s) -or ([string]$s.AutoTuningLevelLocal -eq 'Normal') }
           Apply = { netsh.exe int tcp set global autotuninglevel=normal | Out-Null } }
        @{ Id = 'deliveryopt'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Windows-Updates an andere PCs im Internet senden'; Target = 'Nur im eigenen Heimnetz teilen'; Fix = 'Ausschalten'; Risk = ''
           Benefit = 'Deine Upload-Bandbreite bleibt für Spiele, Voice-Chat und Streaming frei.'
           Desc = 'Windows verteilt heruntergeladene Updates standardmäßig teils an fremde PCs im Internet (Übermittlungsoptimierung). Das kostet Upload. Danach teilt Windows nur noch mit PCs im eigenen Netzwerk.'
           Read = { $v = try { [Microsoft.Win32.Registry]::Users.OpenSubKey($script:DoKey).GetValue('DownloadMode') } catch { $null }
                    switch ($v) { 0 { 'Teilen ausgeschaltet' } 1 { 'Nur im Heimnetz' } 3 { 'Teilen mit PCs im Internet' } default { 'Windows-Standard (Teilen mit PCs im Internet möglich)' } } }
           Check = { $v = try { [Microsoft.Win32.Registry]::Users.OpenSubKey($script:DoKey).GetValue('DownloadMode') } catch { $null }; $v -eq 0 -or $v -eq 1 }
           Apply = { $k = [Microsoft.Win32.Registry]::Users.CreateSubKey($script:DoKey); $k.SetValue('DownloadMode', 1, [Microsoft.Win32.RegistryValueKind]::DWord); $k.Close() }
           Revert = { $k = [Microsoft.Win32.Registry]::Users.CreateSubKey($script:DoKey); $k.SetValue('DownloadMode', 3, [Microsoft.Win32.RegistryValueKind]::DWord); $k.Close() } }
        @{ Id = 'wlanpower'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Energiesparen des WLAN-Adapters'; Target = 'Höchstleistung'; Fix = 'Energiesparen ausschalten'; Risk = $akku
           Benefit = 'Weniger Ping-Spitzen und Aussetzer, weil der WLAN-Adapter nicht zwischendurch in den Sparmodus wechselt.'
           Desc = 'Gilt für den aktiven Energiesparplan, im Netz- und im Akkubetrieb.'
           Applicable = { @(Get-ActiveAdapters | Where-Object { Test-WifiAdapter $_ }).Count -gt 0 }
           Read = { switch (Get-PowerValue $script:WlanSub $script:WlanPower) { 0 { 'Höchstleistung' } 1 { 'Niedriger Energiesparmodus' } 2 { 'Mittlerer Energiesparmodus' } 3 { 'Maximaler Energiesparmodus' } default { 'unbekannt' } } }
           Check = { (Get-PowerValue $script:WlanSub $script:WlanPower) -le 0 }
           Apply = { Set-PowerValue $script:WlanSub $script:WlanPower 0 } }
        @{ Id = 'nicpower'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Netzwerkadapter zum Stromsparen abschalten'; Target = 'Nicht abschalten'; Fix = 'Ausschalten'; Risk = 'Die Verbindung ist beim Umstellen wenige Sekunden unterbrochen.'
           Benefit = 'Keine Verbindungsabbrüche, weil Windows den Netzwerkadapter nicht mehr zum Stromsparen abschaltet.'
           Desc = 'Entspricht im Geräte-Manager dem Häkchen »Computer kann das Gerät ausschalten, um Energie zu sparen«.'
           Applicable = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue } | Where-Object { [string]$_.AllowComputerToTurnOffDevice -ne 'Unsupported' }).Count -gt 0 }
           Read = { $on = @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue } | Where-Object { [string]$_.AllowComputerToTurnOffDevice -eq 'Enabled' }); if ($on.Count) { "Windows darf $($on.Count) Adapter abschalten" } else { 'Windows schaltet die Adapter nicht ab' } }
           Check = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue } | Where-Object { [string]$_.AllowComputerToTurnOffDevice -eq 'Enabled' }).Count -eq 0 }
           Apply = { foreach ($a in @(Get-ActiveAdapters)) { $pm = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue; if ([string]$pm.AllowComputerToTurnOffDevice -eq 'Enabled') { Set-NetAdapterPowerManagement -Name $a.Name -AllowComputerToTurnOffDevice Disabled -ErrorAction Stop } } }
           Revert = { foreach ($a in @(Get-ActiveAdapters)) { $pm = Get-NetAdapterPowerManagement -Name $a.Name -ErrorAction SilentlyContinue; if ([string]$pm.AllowComputerToTurnOffDevice -eq 'Disabled') { Set-NetAdapterPowerManagement -Name $a.Name -AllowComputerToTurnOffDevice Enabled -ErrorAction SilentlyContinue } } } }
        @{ Id = 'eee'; Group = 'network'; Mode = 'recommended'; Impact = 1; Restart = $false
           Title = 'Energiesparendes Ethernet (Green Ethernet)'; Target = 'Ausschalten'; Fix = 'Ausschalten'; Risk = 'Die Verbindung ist beim Umstellen wenige Sekunden unterbrochen.'
           Benefit = 'Gleichmäßigerer Ping über das Netzwerkkabel, weil die Verbindung nicht in Pausen heruntergefahren wird.'
           Desc = 'Der Netzwerkanschluss spart in Datenpausen Strom. Beim Spielen kann das kleine Verzögerungen verursachen.'
           Applicable = { @(Get-EeeProperties).Count -gt 0 }
           Read = { $on = @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' }); if ($on.Count) { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' }).Count -eq 0 }
           Apply = { foreach ($p in @(Get-EeeProperties | Where-Object { [string]$_.RegistryValue -ne '0' })) { Set-NetAdapterAdvancedProperty -Name $p.Name -RegistryKeyword $p.RegistryKeyword -RegistryValue 0 -ErrorAction Stop } }
           Revert = { foreach ($p in @(Get-EeeProperties)) { Set-NetAdapterAdvancedProperty -Name $p.Name -RegistryKeyword $p.RegistryKeyword -RegistryValue 1 -ErrorAction SilentlyContinue } } }
        @{ Id = 'intmod'; Group = 'network'; Mode = 'experimental'; Impact = 1; Restart = $false
           Title = 'Interrupt-Moderation des Netzwerkadapters'; Target = 'Ausschalten'; Fix = 'Ausschalten'
           Risk = 'Etwas höhere Prozessorlast bei viel Datenverkehr. Verbindung beim Umstellen kurz unterbrochen. Nur bei schnellen Prozessoren sinnvoll.'
           Benefit = 'Netzwerkpakete werden sofort statt gesammelt verarbeitet - minimal geringere Verzögerung.'
           Desc = 'Der Adapter sammelt eingehende Pakete und meldet sie gebündelt. Das schont den Prozessor, kostet aber Bruchteile von Millisekunden.'
           Applicable = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue }).Count -gt 0 }
           Read = { $on = @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue } | Where-Object { [string]$_.RegistryValue -ne '0' }); if ($on.Count) { 'Eingeschaltet' } else { 'Ausgeschaltet' } }
           Check = { @(Get-ActiveAdapters | ForEach-Object { Get-NetAdapterAdvancedProperty -Name $_.Name -RegistryKeyword '*InterruptModeration' -ErrorAction SilentlyContinue } | Where-Object { [string]$_.RegistryValue -ne '0' }).Count -eq 0 }
           Apply = { foreach ($a in @(Get-ActiveAdapters)) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*InterruptModeration' -RegistryValue 0 -ErrorAction SilentlyContinue } }
           Revert = { foreach ($a in @(Get-ActiveAdapters)) { Set-NetAdapterAdvancedProperty -Name $a.Name -RegistryKeyword '*InterruptModeration' -RegistryValue 1 -ErrorAction SilentlyContinue } } }
        @{ Id = 'nagle'; Group = 'network'; Mode = 'experimental'; Impact = 1; Restart = $true
           Title = 'Nagle-Algorithmus (TCP-Verzögerung)'; Target = 'Ausschalten'; Fix = 'Ausschalten'
           Risk = 'Hilft nur bei älteren Online-Spielen, die TCP nutzen (z. B. manche MMOs). Die meisten Shooter nutzen UDP - dort ändert sich nichts.'
           Benefit = 'Kleine Datenpakete werden sofort gesendet statt kurz gesammelt.'
           Desc = 'Setzt TcpAckFrequency=1 und TCPNoDelay=1 für die aktiven Netzwerkverbindungen. Wird nach einem Neustart wirksam.'
           Applicable = { @(Get-TcpInterfaceKeys).Count -gt 0 }
           Read = { $keys = @(Get-TcpInterfaceKeys); $off = @($keys | Where-Object { (Get-RegValue 'HKLM' $_ 'TcpAckFrequency' 0) -eq 1 -and (Get-RegValue 'HKLM' $_ 'TCPNoDelay' 0) -eq 1 }); if ($off.Count -eq $keys.Count) { 'Ausgeschaltet' } else { 'Eingeschaltet (Windows-Standard)' } }
           Check = { $keys = @(Get-TcpInterfaceKeys); @($keys | Where-Object { (Get-RegValue 'HKLM' $_ 'TcpAckFrequency' 0) -eq 1 -and (Get-RegValue 'HKLM' $_ 'TCPNoDelay' 0) -eq 1 }).Count -eq $keys.Count }
           Apply = { foreach ($k in @(Get-TcpInterfaceKeys)) { Set-RegDword 'HKLM' $k 'TcpAckFrequency' 1; Set-RegDword 'HKLM' $k 'TCPNoDelay' 1 } }
           Revert = { foreach ($k in @(Get-TcpInterfaceKeys)) { try { $r = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($k, $true); $r.DeleteValue('TcpAckFrequency', $false); $r.DeleteValue('TCPNoDelay', $false); $r.Close() } catch {} } } }
    )
}

function Get-GamingTweaks([string]$Group = '', [bool]$IsLaptop = $false) {
    foreach ($t in Get-GamingTweakDefs $IsLaptop) {
        if ($Group -and $t.Group -ne $Group) { continue }
        if ($t.Applicable) { $ok = try { [bool](& $t.Applicable) } catch { $false }; if (-not $ok) { continue } }
        Report "Prüfe: $($t.Title) ..."
        $state = try { [string](& $t.Read) } catch { 'Fehler: ' + $_.Exception.Message }
        $opt = try { [bool](& $t.Check) } catch { $false }
        [pscustomobject]@{
            Id = $t.Id; Group = $t.Group; Title = $t.Title; Target = $t.Target; Fix = $t.Fix; Benefit = $t.Benefit; Desc = $t.Desc
            Risk = $t.Risk; Mode = $t.Mode; Impact = $t.Impact; Restart = $t.Restart; CanRevert = [bool]$t.Revert
            State = $state; Optimal = $opt; Optional = ($t.Mode -ne 'recommended')
        }
    }
}

function Invoke-GamingTweaks([string[]]$Ids, [switch]$Revert) {
    $errors = @()
    foreach ($t in Get-GamingTweakDefs (Test-IsLaptop)) {
        if ($Ids -notcontains $t.Id) { continue }
        $sb = if ($Revert) { $t.Revert } else { $t.Apply }
        if (-not $sb) { continue }
        Report "$(if ($Revert) { 'Setze zurück' } else { 'Optimiere' }): $($t.Title) ..."
        try { [void](& $sb) } catch { $errors += "$($t.Title): $($_.Exception.Message)" }
    }
    return $errors
}

# ============================================================================
#  Schnellcheck für die Gesamtwertung auf der Startseite (liest nur, dauert wenige Sekunden)
#  Jeder Befund kostet Punkte; 100 = alles in Ordnung.
# ============================================================================
function Get-QuickHealth {
    $items = New-Object System.Collections.ArrayList
    function Add-Q([int]$Level, [string]$Title, [int]$Penalty, [string]$Step) {
        [void]$items.Add([pscustomobject]@{ Level = $Level; Title = $Title; Penalty = $Penalty; Step = $Step })
    }

    # Speicherplatz auf dem Systemlaufwerk
    try {
        $sys = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'" -ErrorAction Stop
        $pct = 100.0 * $sys.FreeSpace / [math]::Max(1, $sys.Size)
        if ($pct -lt 10) { Add-Q 3 ("Systemlaufwerk fast voll – nur {0:0} % frei" -f $pct) 25 'cleanup' }
        elseif ($pct -lt 20) { Add-Q 2 ("Wenig Platz auf dem Systemlaufwerk – {0:0} % frei" -f $pct) 10 'cleanup' }
    } catch {}

    # Laufwerke mit Warnstatus
    try {
        $bad = @(Get-PhysicalDisk -ErrorAction Stop | Where-Object { [string]$_.HealthStatus -match '^(Warning|Unhealthy|1|2)$' })
        foreach ($d in $bad) { Add-Q 3 "Laufwerk meldet Probleme: $($d.FriendlyName)" 30 'system' }
    } catch {}

    # Geräte mit Treiberproblemen (22 = vom Nutzer deaktiviert, 45 = nicht angeschlossen)
    try {
        $err = @(Get-CimInstance Win32_PnPEntity -Filter 'ConfigManagerErrorCode <> 0' -ErrorAction Stop |
                 Where-Object { $_.ConfigManagerErrorCode -notin 22, 45 -and [string]$_.PNPDeviceID -notmatch '^(SWD|ROOT|HTREE)\\' })
        if ($err.Count -gt 0) { Add-Q 3 $(if ($err.Count -eq 1) { "1 Gerät ohne funktionierenden Treiber" } else { "$($err.Count) Geräte ohne funktionierenden Treiber" }) ([math]::Min(30, 12 * $err.Count)) 'drivers' }
    } catch {}

    # Software des Grafikkarten-Herstellers
    try { foreach ($s in @(Get-GpuSoftwareCheck | Where-Object { $_.Level -ge 2 })) { Add-Q 2 "$($s.Product) fehlt" 15 'drivers' } } catch {}

    # Leistungseinstellungen
    try {
        $open = @(Get-Tweaks (Test-IsLaptop) | Where-Object { -not $_.Optimal -and -not $_.Optional })
        if ($open.Count -gt 0) { Add-Q 2 $(if ($open.Count -eq 1) { "1 Einstellung bremst deinen PC" } else { "$($open.Count) Einstellungen bremsen deinen PC" }) ([math]::Min(20, 5 * $open.Count)) 'settings' }
    } catch {}

    # Datenmüll
    try {
        $junk = 0L
        foreach ($id in 'usertemp', 'wintemp', 'wudl') { $junk += [long](@(Measure-Cleanup $id)[-1]).Size }
        if ($junk -ge 5GB) { Add-Q 2 ("{0} Datenmüll" -f (Format-Bytes $junk)) 10 'cleanup' }
        elseif ($junk -ge 1GB) { Add-Q 1 ("{0} Datenmüll" -f (Format-Bytes $junk)) 5 'cleanup' }
    } catch {}

    # Lange nicht neu gestartet
    try {
        $boot = (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime
        $days = [int]((Get-Date) - $boot).TotalDays
        if ($days -ge 14) { Add-Q 1 "Seit $days Tagen nicht neu gestartet" 5 '' }
    } catch {}

    # Wiederherstellungspunkt der letzten 30 Tage
    try {
        $last = @(Get-PCORestorePoints | Where-Object { $_.Date } | Sort-Object Date -Descending | Select-Object -First 1)
        if ($last.Count -eq 0 -or ((Get-Date) - $last[0].Date).TotalDays -gt 30) { Add-Q 1 'Kein aktueller Wiederherstellungspunkt' 5 'safety' }
    } catch {}

    $score = [math]::Max(0, 100 - (($items | Measure-Object Penalty -Sum).Sum))
    $rating = if ($score -ge 90) { @{ Text = 'Sehr gut'; Level = 0 } } elseif ($score -ge 75) { @{ Text = 'Gut'; Level = 0 } } elseif ($score -ge 50) { @{ Text = 'Verbesserungswürdig'; Level = 2 } } else { @{ Text = 'Kritisch'; Level = 3 } }
    [pscustomobject]@{ Score = [int]$score; Rating = $rating.Text; Level = $rating.Level; Items = @($items | Sort-Object @{ e = { $_.Penalty }; Descending = $true }); Time = Get-Date }
}
