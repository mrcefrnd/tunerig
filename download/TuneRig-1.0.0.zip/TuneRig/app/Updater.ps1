﻿# ============================================================================
#  TuneRig - Version und Updater
#  Prinzip (bewusst einfach):
#    app\version.json enthält die installierte Version und die Adresse einer
#    Update-Beschreibung (latest.json), z. B. als Datei in einem GitHub-Release:
#      { "Version": "1.1.0", "Url": "https://…/TuneRig-1.1.0.zip", "Sha256": "…", "Notes": "…" }
#    Ist dort eine neuere Version eingetragen, lädt TuneRig das ZIP, prüft die
#    SHA-256-Prüfsumme, ersetzt die Programmdateien und startet neu.
#    Einstellungen (%LOCALAPPDATA%\TuneRig) und geladene Schriften bleiben erhalten.
# ============================================================================
$script:VersionFile = Join-Path $AppDir 'version.json'
$script:InstallRoot = Split-Path -Parent $AppDir
$script:UninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TuneRig'

function Get-TuneRigVersionInfo {
    try { $v = Get-Content -LiteralPath $script:VersionFile -Raw -ErrorAction Stop | ConvertFrom-Json; if ($v.Version) { return $v } } catch {}
    return [pscustomobject]@{ Version = '1.0.0'; UpdateUrl = '' }
}

function Test-NewerVersion([string]$Candidate, [string]$Current) {
    try { return ([version]$Candidate) -gt ([version]$Current) } catch { return $false }
}

# Update-Prüfung in einem eigenen Hintergrund-Thread (blockiert nichts)
function New-UpdateCheckJob([string]$Url) {
    $ps = [powershell]::Create()
    [void]$ps.AddScript({
        param($Url)
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        try {
            $m = Invoke-RestMethod -UseBasicParsing -Uri $Url -TimeoutSec 15 -Headers @{ 'User-Agent' = 'TuneRig-Updater' }
            if ($m -is [string]) { $m = $m | ConvertFrom-Json }
            [pscustomobject]@{ Ok = $true; Manifest = $m; Error = '' }
        } catch { [pscustomobject]@{ Ok = $false; Manifest = $null; Error = $_.Exception.Message } }
    }).AddArgument($Url)
    return @{ PS = $ps; Handle = $ps.BeginInvoke(); Done = $false }
}

# Wird nach dem Update in einem eigenen Prozess ausgeführt: wartet, bis TuneRig beendet ist,
# kopiert die neuen Dateien und startet TuneRig neu.
$script:ApplyUpdateScript = @'
param([int]$ProcessId, [string]$Source, [string]$Target, [string]$Version)
$log = Join-Path (Split-Path -Parent $Source) 'update.log'
try { Wait-Process -Id $ProcessId -Timeout 60 -ErrorAction SilentlyContinue } catch {}
Start-Sleep -Milliseconds 800
try {
    & robocopy.exe $Source $Target /E /R:3 /W:1 /NFL /NDL /NJH /NJS /NP /XF fehler.log | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "Kopieren fehlgeschlagen (robocopy $LASTEXITCODE)" }
    Get-ChildItem -LiteralPath $Target -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TuneRig'
    if (Test-Path $key) { Set-ItemProperty -Path $key -Name DisplayVersion -Value $Version }
    "Update auf $Version erfolgreich: $(Get-Date)" | Out-File -LiteralPath $log -Encoding UTF8
} catch {
    "Update fehlgeschlagen: $($_.Exception.Message)" | Out-File -LiteralPath $log -Encoding UTF8
    Add-Type -AssemblyName PresentationFramework
    [void][Windows.MessageBox]::Show("Das Update konnte nicht abgeschlossen werden:`n`n$($_.Exception.Message)`n`nTuneRig startet in der bisherigen Version.", 'TuneRig-Update')
}
$exe = Join-Path $Target 'app\TuneRig.exe'
if (Test-Path -LiteralPath $exe) { Start-Process -FilePath $exe }
else { Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$Target\app\TuneRig.ps1`"" }
'@

# ---------------------------------------------------------------------------
#  Oberfläche (braucht $ui und $window - wird erst nach dem Laden aufgerufen)
# ---------------------------------------------------------------------------
function Start-UpdateCheck([switch]$Manual) {
    $info = Get-TuneRigVersionInfo
    if (-not $info.UpdateUrl) {
        if ($Manual) { Show-Info "Du nutzt TuneRig $($info.Version).`n`nFür diese Version ist keine Update-Adresse hinterlegt. Neue Versionen installierst du mit dem Setup – deine Einstellungen bleiben dabei erhalten." 'Nach Updates suchen' }
        return
    }
    if ($script:UpdateJob -and -not $script:UpdateJob.Done) { return }
    $script:UpdateManual = [bool]$Manual
    if ($Manual) { $ui.BtnCheckUpdate.IsEnabled = $false; Set-Status 'Suche nach Updates …' }
    $script:UpdateJob = New-UpdateCheckJob $info.UpdateUrl
    if (-not $script:UpdateTimer) {
        $script:UpdateTimer = New-Object Windows.Threading.DispatcherTimer
        $script:UpdateTimer.Interval = [TimeSpan]::FromMilliseconds(500)
        $script:UpdateTimer.Add_Tick({
            $j = $script:UpdateJob
            if (-not $j -or $j.Done -or -not $j.Handle.IsCompleted) { return }
            $script:UpdateTimer.Stop(); $j.Done = $true
            $r = $null
            try { $r = @($j.PS.EndInvoke($j.Handle))[-1]; $j.PS.Dispose() } catch {}
            $ui.BtnCheckUpdate.IsEnabled = $true
            Show-UpdateResult $r
        })
    }
    $script:UpdateTimer.Start()
}

function Show-UpdateResult($r) {
    $cur = (Get-TuneRigVersionInfo).Version
    if (-not $r -or -not $r.Ok) {
        if ($script:UpdateManual) { Show-Info ("Die Update-Prüfung hat nicht geklappt.`n`n" + $(if ($r) { $r.Error } else { 'Unbekannter Fehler' }) + "`n`nPrüf die Internetverbindung und versuch es später noch einmal.") 'Nach Updates suchen' }
        return
    }
    $m = $r.Manifest
    if ($m -and $m.Version -and $m.Url -and (Test-NewerVersion ([string]$m.Version) $cur)) {
        $script:UpdateManifest = $m
        $ui.UpdateTitle.Text = "TuneRig $($m.Version) ist da"
        $ui.UpdateText.Text = $(if ($m.Notes) { [string]$m.Notes } else { "Du nutzt Version $cur. Das Update dauert unter einer Minute; deine Einstellungen bleiben erhalten." })
        $ui.UpdateCard.Visibility = 'Visible'
        Set-Status "Update verfügbar: TuneRig $($m.Version)"
        if ($script:UpdateManual) { Show-Page 'welcome' }
    } else {
        $ui.UpdateCard.Visibility = 'Collapsed'
        if ($script:UpdateManual) { Set-Status "TuneRig ist aktuell (Version $cur)."; Show-Info "Du nutzt die neueste Version ($cur)." 'Nach Updates suchen' }
    }
}

function Start-TuneRigUpdate {
    $m = $script:UpdateManifest
    if (-not $m) { return }
    if ($script:Job) { Show-Info 'Warte, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    if (-not ([string]$m.Url).StartsWith('https://')) { Show-Error 'Die Update-Adresse ist nicht sicher (kein https). Das Update wird nicht geladen.'; return }
    if (-not (Confirm-Action ("TuneRig wird auf Version {0} aktualisiert.`n`nTuneRig lädt das Update, prüft es, schließt sich kurz und startet danach neu. Deine Einstellungen bleiben erhalten.`n`nJetzt aktualisieren?" -f $m.Version) 'Update')) { return }
    Start-Work -Status "Lade TuneRig $($m.Version) …" -Arguments @([string]$m.Url, [string]$m.Sha256) -Script {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $dir = Join-Path $env:TEMP ('TuneRig-Update-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
        $zip = Join-Path $dir 'update.zip'
        Report 'Lade das Update herunter …'
        Invoke-WebRequest -UseBasicParsing -Uri $A[0] -OutFile $zip -TimeoutSec 300 -Headers @{ 'User-Agent' = 'TuneRig-Updater' }
        Report 'Prüfe die Prüfsumme …'
        if (-not $A[1]) { throw 'Im Update fehlt die Prüfsumme (Sha256). Aus Sicherheitsgründen wird es nicht installiert.' }
        $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash
        if ($hash -ne ([string]$A[1]).Trim().ToUpper()) { throw 'Die Prüfsumme stimmt nicht. Die Datei ist beschädigt oder verändert und wird nicht installiert.' }
        Report 'Entpacke …'
        $new = Join-Path $dir 'neu'
        Expand-Archive -LiteralPath $zip -DestinationPath $new -Force
        $main = Get-ChildItem -LiteralPath $new -Recurse -Filter 'TuneRig.ps1' | Where-Object { $_.Directory.Name -eq 'app' } | Select-Object -First 1
        if (-not $main) { throw 'Im Update fehlt app\TuneRig.ps1.' }
        [pscustomobject]@{ Source = $main.Directory.Parent.FullName; Dir = $dir }
    } -OnDone {
        param($r) $r = @($r)[-1]
        $apply = Join-Path $r.Dir 'Apply-Update.ps1'
        Set-Content -LiteralPath $apply -Value $script:ApplyUpdateScript -Encoding UTF8
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"{0}`" -ProcessId {1} -Source `"{2}`" -Target `"{3}`" -Version `"{4}`"" -f $apply, $PID, $r.Source, $script:InstallRoot, $script:UpdateManifest.Version)
        Set-Status 'Update wird installiert – TuneRig startet gleich neu.'
        $window.Close()
    }
}
