' TuneRig ohne Konsolenfenster starten (wird von den Verknuepfungen genutzt)
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
CreateObject("WScript.Shell").Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File """ & dir & "\TuneRig.ps1""", 0, False
