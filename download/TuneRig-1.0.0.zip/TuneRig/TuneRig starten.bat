@echo off
REM TuneRig (portabel) starten - fragt nach Administratorrechten
cd /d "%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%~dp0app\TuneRig.ps1"
