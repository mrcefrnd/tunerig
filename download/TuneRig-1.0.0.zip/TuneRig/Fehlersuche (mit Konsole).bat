@echo off
REM Startet TuneRig mit sichtbarer Konsole, damit Fehlermeldungen lesbar sind
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -NoExit -File "%~dp0app\TuneRig.ps1" -DebugMode
