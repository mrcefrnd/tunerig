﻿# ============================================================================
#  TuneRig - Deinstallation
#  Wird über »Einstellungen > Apps« bzw. »Programme und Features« aufgerufen.
#  Entfernt Programmdateien, Verknüpfungen und den Eintrag in der App-Liste.
#  Optional auch Einstellungen und Registry-Sicherungen (%LOCALAPPDATA%\TuneRig).
#  Von TuneRig geänderte Windows-Einstellungen bleiben, wie sie sind; zurück geht
#  es über die Wiederherstellungspunkte.
# ============================================================================
param([switch]$Quiet)

$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName PresentationFramework
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TuneRig'
$title = 'TuneRig deinstallieren'

function Ask([string]$Text, [string]$Icon = 'Question') { [Windows.MessageBox]::Show($Text, $title, 'YesNo', $Icon, 'No') -eq 'Yes' }

# Sicherheitsprüfung: nur einen echten TuneRig-Ordner entfernen
$valid = (Test-Path -LiteralPath (Join-Path $root 'app\TuneRig.ps1')) -and $root.Length -gt 10 -and
         $root -notin @($env:USERPROFILE, $env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)}, $env:windir)
if (-not $valid) {
    if (-not $Quiet) { [void][Windows.MessageBox]::Show("In diesem Ordner ist keine TuneRig-Installation:`n$root", $title, 'OK', 'Warning') }
    exit 1
}

# Läuft TuneRig noch?
$running = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
             Where-Object { $_.CommandLine -like "*$root\app\TuneRig.ps1*" -and $_.ProcessId -ne $PID })
if ($running.Count -gt 0) {
    if ($Quiet -or (Ask "TuneRig ist noch geöffnet. Soll TuneRig jetzt beendet werden?" 'Warning')) { $running | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } }
    else { exit 1 }
}

$removeData = $false
if (-not $Quiet) {
    if (-not (Ask "TuneRig vollständig von diesem PC entfernen?`n`nDeine mit TuneRig vorgenommenen Windows-Einstellungen bleiben erhalten. Zurück geht es jederzeit über die Systemwiederherstellung.")) { exit 0 }
    $removeData = Ask "Auch deine TuneRig-Einstellungen und die Registry-Sicherungen der Deinstallationen löschen?`n`n(Ordner: %LOCALAPPDATA%\TuneRig)`n`nNein = behalten, falls du TuneRig später wieder installierst."
}

# Verknüpfungen
$links = @(
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'TuneRig.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'TuneRig.lnk')
)
foreach ($l in $links) { if (Test-Path -LiteralPath $l) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue } }

# Eintrag in der App-Liste
if (Test-Path $key) { Remove-Item -Path $key -Recurse -Force -ErrorAction SilentlyContinue }

if ($removeData) { Remove-Item -LiteralPath (Join-Path $env:LOCALAPPDATA 'TuneRig') -Recurse -Force -ErrorAction SilentlyContinue }

# Programmordner: wird kurz nach dem Ende dieses Skripts gelöscht (das Skript liegt selbst darin)
Start-Process cmd.exe -WindowStyle Hidden -ArgumentList "/c timeout /t 3 /nobreak >nul & rmdir /s /q `"$root`""

if (-not $Quiet) { [void][Windows.MessageBox]::Show('TuneRig wurde entfernt.', $title, 'OK', 'Information') }
