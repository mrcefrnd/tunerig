﻿# ============================================================================
#  TuneRig - Speicherplatz-Analyse (Alle Werkzeuge > Speicherplatz)
#  Zeigt, was ein Laufwerk belegt: nach Ordnern (zum Hineinklicken), typischen
#  Platzfressern, Dateitypen und den größten Dateien. Liest nur, löscht nichts.
#  Der eigentliche Durchlauf ist [TuneRig.DiskScan] in Core.ps1.
# ============================================================================
$script:Storage = @{ Drives = @(); Result = $null; Node = $null; Drive = ''; Used = 0L }

# Dateitypen -> Kategorie
$script:StorageCategories = [ordered]@{
    'Videos'                   = 'mp4 mkv avi mov wmv webm m4v flv mpg mpeg ts m2ts mts vob 3gp'
    'Bilder'                   = 'jpg jpeg png gif bmp tif tiff heic heif webp raw cr2 cr3 nef arw dng orf psd xcf svg ico'
    'Musik und Audio'          = 'mp3 flac wav aac ogg m4a wma opus aiff alac'
    'Dokumente'                = 'pdf doc docx xls xlsx xlsm ppt pptx odt ods odp txt rtf csv md epub one pst ost'
    'Archive und Abbilder'     = 'zip rar 7z tar gz tgz bz2 xz zst iso img vhd vhdx vmdk vdi qcow2 cab wim esd'
    'Spieldaten'               = 'pak vpk bsa ba2 ucas utoc forge sga big arc bnk wem bik assets resource resources bundle gcf ncf rpf wad pck acb awb'
    'Programme und Bibliotheken' = 'exe dll sys msi msix msixbundle appx appxbundle ocx drv mui cpl winmd node pyd jar'
    'Zwischenspeicher und Protokolle' = 'tmp temp log etl dmp mdmp bak old cache db-wal blob ldb'
}
$script:StorageExtCat = @{}
foreach ($k in $script:StorageCategories.Keys) { foreach ($e in $script:StorageCategories[$k].Split(' ')) { $script:StorageExtCat[$e] = $k } }

function Format-Count([long]$n) { $n.ToString('N0', [Globalization.CultureInfo]::GetCultureInfo('de-DE')) }
function Format-Share([double]$p) { if ($p -le 0) { '0 %' } elseif ($p -lt 0.01) { '< 1 %' } else { '{0:0} %' -f ($p * 100) } }

# ---------------------------------------------------------------------------
#  Bausteine
# ---------------------------------------------------------------------------
# Balken (Anteil 0..1) in einer Farbe
function New-StorageBar([double]$Share, [string]$Token = 'accent', [double]$Height = 4) {
    $g = New-Object Windows.Controls.Grid
    $g.Height = $Height
    $s = [Math]::Max(0.0, [Math]::Min(1.0, $Share))
    $c0 = New-Object Windows.Controls.ColumnDefinition; $c0.Width = New-Object Windows.GridLength(($s * 1000), [Windows.GridUnitType]::Star)
    $c1 = New-Object Windows.Controls.ColumnDefinition; $c1.Width = New-Object Windows.GridLength(((1 - $s) * 1000), [Windows.GridUnitType]::Star)
    $g.ColumnDefinitions.Add($c0); $g.ColumnDefinitions.Add($c1)
    $bg = New-Object Windows.Controls.Border; $bg.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $bg Background 'line'; [Windows.Controls.Grid]::SetColumnSpan($bg, 2); [void]$g.Children.Add($bg)
    $fg = New-Object Windows.Controls.Border; $fg.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $fg Background $Token; [void]$g.Children.Add($fg)
    return $g
}

# Klickbare Zeile mit Hover-Fläche (für Ordner, Dateien, Platzfresser)
function Set-StorageClick($Border, [scriptblock]$Do, $Data, [string]$Tip) {
    $Border.Cursor = [Windows.Input.Cursors]::Hand
    $Border.Focusable = $true
    $Border.ToolTip = $Tip
    $Border.Tag = @{ Do = $Do; Data = $Data }
    $Border.Add_MouseEnter({ Set-ThemeRef $this Background 'surface-raised' })
    $Border.Add_MouseLeave({ $this.Background = [Windows.Media.Brushes]::Transparent })
    $Border.Add_MouseLeftButtonUp({ $t = $this.Tag; try { & $t.Do $t.Data } catch { Show-Error $_.Exception.Message } })
    $Border.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Return' -or $e.Key -eq 'Space') { $t = $this.Tag; & $t.Do $t.Data; $e.Handled = $true } })
}

# Zeile: Symbol | Name (+ Zusatz) und Balken | Größe | Anteil
function New-StorageRow {
    param([string]$Name, [long]$Size, [double]$Share, [string]$Meta = '', [string]$Icon = 'folder', [scriptblock]$Do = $null, $Data = $null, [string]$Tip = '', [string]$BarToken = 'accent')
    $b = New-Object Windows.Controls.Border
    $b.Padding = New-Thickness 8 8 8 8
    $b.CornerRadius = New-Object Windows.CornerRadius(4)
    $b.Background = [Windows.Media.Brushes]::Transparent
    $g = New-Object Windows.Controls.Grid
    foreach ($w in 28, -1, 96, 56) {
        $c = New-Object Windows.Controls.ColumnDefinition
        $c.Width = if ($w -lt 0) { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { New-Object Windows.GridLength($w) }
        $g.ColumnDefinitions.Add($c)
    }
    $ic = New-LineIcon $Icon 'ink-muted' 18; $ic.VerticalAlignment = 'Top'; $ic.Margin = New-Thickness 0 1 0 0
    [void]$g.Children.Add($ic)

    $sp = New-Object Windows.Controls.StackPanel; $sp.Margin = New-Thickness 0 0 12 0
    $t = New-Object Windows.Controls.TextBlock; $t.TextTrimming = 'CharacterEllipsis'
    Set-TypeRole $t 'body'
    $r1 = New-Object Windows.Documents.Run($Name); Set-ThemeRef $r1 Foreground 'ink'; [void]$t.Inlines.Add($r1)
    if ($Meta) { $r2 = New-Object Windows.Documents.Run("   $Meta"); Set-ThemeRef $r2 Foreground 'ink-muted'; $r2.FontSize = 12; [void]$t.Inlines.Add($r2) }
    [void]$sp.Children.Add($t)
    $bar = New-StorageBar $Share $BarToken; $bar.Margin = New-Thickness 0 6 0 0
    [void]$sp.Children.Add($bar)
    [Windows.Controls.Grid]::SetColumn($sp, 1); [void]$g.Children.Add($sp)

    $sz = New-Object Windows.Controls.TextBlock; $sz.Text = Format-Bytes $Size; $sz.HorizontalAlignment = 'Right'
    Set-TypeRole $sz 'metric-small'; Set-ThemeRef $sz Foreground 'ink'
    [Windows.Controls.Grid]::SetColumn($sz, 2); [void]$g.Children.Add($sz)
    $pc = New-Object Windows.Controls.TextBlock; $pc.Text = Format-Share $Share; $pc.HorizontalAlignment = 'Right'
    Set-TypeRole $pc 'small'; Set-ThemeRef $pc Foreground 'ink-muted'
    [Windows.Controls.Grid]::SetColumn($pc, 3); [void]$g.Children.Add($pc)

    $b.Child = $g
    if ($Do) { Set-StorageClick $b $Do $Data $Tip }
    return $b
}

function Add-StorageHeading($Panel, [string]$Text, [string]$Sub = '') {
    $l = New-Label $Text; $l.Margin = New-Thickness 0 0 0 4
    [void]$Panel.Children.Add($l)
    if ($Sub) { [void]$Panel.Children.Add((New-Text $Sub -Role 'small' -Color 'ink-muted')) }
    $sp = New-Object Windows.Controls.Border; $sp.Height = 8; [void]$Panel.Children.Add($sp)
}

function Open-StoragePath([string]$Path, [switch]$Select) {
    try {
        if ($Select) { Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $Path) }
        else { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $Path) }
    } catch { Show-Error $_.Exception.Message }
}

# ---------------------------------------------------------------------------
#  Laufwerke
# ---------------------------------------------------------------------------
function Update-StorageDrives {
    $script:Storage.Drives = @(Get-StorageDrives)
    $ui.StorageDrives.Children.Clear()
    if ($script:Storage.Drives.Count -eq 0) { [void]$ui.StorageDrives.Children.Add((New-Text 'Keine Laufwerke gefunden.' -Role 'small' -Color 'ink-muted')); return }
    foreach ($d in $script:Storage.Drives) {
        $used = $d.Size - $d.Free
        $share = $used / [Math]::Max(1L, $d.Size)
        $card = New-Object Windows.Controls.Border
        $card.Style = Get-ThemeStyle 'Card'
        $card.Width = 300; $card.Padding = New-Thickness 16 16 16 16; $card.Margin = New-Thickness 0 0 16 16
        if ($script:Storage.Drive -eq $d.Drive -and $script:Storage.Result) { Set-ThemeRef $card BorderBrush 'accent' }
        $sp = New-Object Windows.Controls.StackPanel
        $head = New-Object Windows.Controls.DockPanel
        $ic = New-LineIcon 'drive' 'ink' 20; $ic.Margin = New-Thickness 0 0 10 0; [Windows.Controls.DockPanel]::SetDock($ic, 'Left'); [void]$head.Children.Add($ic)
        $name = $d.Drive + $(if ($d.Label) { "  $($d.Label)" } else { '' }) + $(if ($d.System) { '  ·  Windows' } elseif ($d.Removable) { '  ·  Wechseldatenträger' } else { '' })
        $tt = New-Text $name -Role 'title'; $tt.TextTrimming = 'CharacterEllipsis'; $tt.VerticalAlignment = 'Center'
        [void]$head.Children.Add($tt)
        [void]$sp.Children.Add($head)
        # Füllstand: Zustandsfarbe nur mit Text
        $lvl = if ($share -ge 0.9) { 3 } elseif ($share -ge 0.8) { 2 } else { -1 }
        $bar = New-StorageBar $share $(if ($lvl -eq 3) { 'danger' } elseif ($lvl -eq 2) { 'warning' } else { 'accent' }) 6
        $bar.Margin = New-Thickness 0 12 0 8
        [void]$sp.Children.Add($bar)
        $m = New-Text ("{0} von {1} belegt" -f (Format-Bytes $used), (Format-Bytes $d.Size)) -Role 'metric-small'
        [void]$sp.Children.Add($m)
        $freeTxt = "{0} frei" -f (Format-Bytes $d.Free)
        if ($lvl -ge 2) { [void]$sp.Children.Add((New-ColoredLine ($freeTxt + $(if ($lvl -eq 3) { ' – fast voll' } else { ' – wird knapp' })) $lvl 0)) }
        else { [void]$sp.Children.Add((New-Text $freeTxt -Role 'small' -Color 'ink-muted')) }
        $btn = New-ActionButton 'Analysieren' { param($drv) Start-StorageScan $drv } $d.Drive
        $btn.Margin = New-Thickness 0 12 0 0; $btn.HorizontalAlignment = 'Left'
        [void]$sp.Children.Add($btn)
        $card.Child = $sp
        [void]$ui.StorageDrives.Children.Add($card)
    }
}

# ---------------------------------------------------------------------------
#  Analyse starten (Fortschritt live aus [TuneRig.DiskScan])
# ---------------------------------------------------------------------------
$script:StorageTimer = New-Object Windows.Threading.DispatcherTimer
$script:StorageTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$script:StorageTimer.Add_Tick({
    $f = [TuneRig.DiskScan]::ScannedFiles; $b = [TuneRig.DiskScan]::ScannedBytes
    $pct = [Math]::Min(99, 100.0 * $b / [Math]::Max(1L, $script:Storage.Used))
    $ui.StorageProgressBar.Value = $pct
    $ui.StorageProgressText.Text = '{0} Dateien  ·  {1}  ·  {2}' -f (Format-Count $f), (Format-Bytes $b), [TuneRig.DiskScan]::Current
    $script:Sync.Status = 'Analysiere {0} … {1:0} %' -f $script:Storage.Drive, $pct
})

function Stop-StorageProgress {
    $script:StorageTimer.Stop()
    $ui.StorageProgress.Visibility = 'Collapsed'
}

function Start-StorageScan([string]$Drive) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $d = @($script:Storage.Drives | Where-Object { $_.Drive -eq $Drive })[0]
    $script:Storage.Drive = $Drive
    $script:Storage.Used = if ($d) { $d.Size - $d.Free } else { 1L }
    $ui.StorageProgressBar.Value = 0; $ui.StorageProgressText.Text = ''
    $ui.StorageProgress.Visibility = 'Visible'
    $script:StorageTimer.Start()
    Start-Work -Cancellable -Status "Analysiere $Drive …" -Arguments @($Drive) -Script { Invoke-StorageScan $A[0] } -OnDone {
        param($r)
        Stop-StorageProgress
        Show-StorageResult (@($r)[-1])
    } -OnCancel { Stop-StorageProgress; Set-Status 'Analyse abgebrochen.' }
}

# ---------------------------------------------------------------------------
#  Ergebnis
# ---------------------------------------------------------------------------
function Show-StorageResult($r) {
    if (-not $r -or -not $r.Scan) { Set-Status 'Die Analyse hat kein Ergebnis geliefert.'; return }
    $script:Storage.Result = $r
    $ui.StorageResult.Visibility = 'Visible'
    Update-StorageDrives
    Show-StorageFolder $r.Scan.Root
    Show-StorageSummary $r
    Show-StorageHogs $r
    Show-StorageTypes $r
    Show-StorageFiles $r
    Set-Status ('Analyse von {0} fertig: {1} in {2} Dateien ({3:0} Sekunden). Klick auf einen Ordner, um hineinzuschauen.' -f $r.Drive, (Format-Bytes $r.Scan.Root.Size), (Format-Count $r.Scan.Files), $r.Scan.Seconds)
}

function Show-StorageFolder($Node) {
    if (-not $Node) { return }
    $script:Storage.Node = $Node
    $r = $script:Storage.Result
    # Pfad als klickbare Brotkrumen
    $ui.StorageCrumbs.Children.Clear()
    $chain = New-Object System.Collections.ArrayList
    $n = $Node; while ($n) { [void]$chain.Insert(0, $n); $n = $n.Parent }
    for ($i = 0; $i -lt $chain.Count; $i++) {
        $c = $chain[$i]
        $label = if ($i -eq 0) { $c.Name.TrimEnd('\') } else { $c.Name }
        if ($i -gt 0) { $sep = New-LineIcon 'chevron' 'ink-muted' 14; $sep.Margin = New-Thickness 2 0 2 0; $sep.VerticalAlignment = 'Center'; [void]$ui.StorageCrumbs.Children.Add($sep) }
        if ($i -eq $chain.Count - 1) {
            $t = New-Text $label -Role 'title'; $t.VerticalAlignment = 'Center'; $t.Margin = New-Thickness 4 0 4 0
            [void]$ui.StorageCrumbs.Children.Add($t)
        } else {
            $btn = New-ActionButton $label { param($x) Show-StorageFolder $x } $c
            $btn.MinHeight = 28; $btn.Padding = New-Thickness 8 2 8 3; $btn.Margin = New-Thickness 0 0 0 0
            [void]$ui.StorageCrumbs.Children.Add($btn)
        }
    }
    $used = [Math]::Max(1L, $r.Size - $r.Free)
    $ui.StorageFolderInfo.Text = '{0}  ·  {1} Dateien  ·  {2} Unterordner  ·  {3} des belegten Speichers' -f (Format-Bytes $Node.Size), (Format-Count $Node.Files), (Format-Count $Node.Children.Count), (Format-Share ($Node.Size / $used))
    $ui.BtnStorageUp.IsEnabled = [bool]$Node.Parent

    $list = $ui.StorageList
    $list.Children.Clear()
    $total = [double][Math]::Max(1L, $Node.Size)
    $kids = @($Node.Children | Sort-Object Size -Descending)
    $show = [Math]::Min(100, $kids.Count)
    for ($i = 0; $i -lt $show; $i++) {
        $k = $kids[$i]
        $meta = if ($k.Denied) { 'kein Zugriff' } elseif ($k.Files -gt 0) { '{0} Dateien' -f (Format-Count $k.Files) } else { 'leer' }
        $do = if ($k.Children.Count -gt 0 -or $k.OwnFiles -gt 0) { { param($x) Show-StorageFolder $x } } else { $null }
        [void]$list.Children.Add((New-StorageRow -Name $k.Name -Size $k.Size -Share ($k.Size / $total) -Meta $meta -Icon 'folder' -Do $do -Data $k -Tip 'Ordner öffnen'))
    }
    if ($kids.Count -gt $show) {
        $rest = 0L; for ($i = $show; $i -lt $kids.Count; $i++) { $rest += $kids[$i].Size }
        [void]$list.Children.Add((New-StorageRow -Name ('{0} weitere Ordner' -f ($kids.Count - $show)) -Size $rest -Share ($rest / $total) -Icon 'folder' -BarToken 'ink-muted'))
    }
    if ($Node.OwnFiles -gt 0) {
        [void]$list.Children.Add((New-StorageRow -Name 'Dateien direkt in diesem Ordner' -Size $Node.OwnSize -Share ($Node.OwnSize / $total) -Meta ('{0} Dateien' -f (Format-Count $Node.OwnFiles)) -Icon 'file' -BarToken 'ink-muted' `
            -Do { param($x) Open-StoragePath $x } -Data $Node.Path -Tip 'Im Explorer öffnen'))
    }
    if ($Node.Denied) { [void]$list.Children.Add((New-ColoredLine 'Kein Zugriff: Windows schützt diesen Ordner. Sein Inhalt ist im Posten »Geschützt / nicht lesbar« enthalten.' 1 8)) }
    elseif ($list.Children.Count -eq 0) { [void]$list.Children.Add((New-Text 'Dieser Ordner ist leer.' -Role 'small' -Color 'ink-muted' -Top 8)) }
}

function Show-StorageSummary($r) {
    $p = $ui.StorageSummary; $p.Children.Clear()
    $used = [long]($r.Size - $r.Free)
    Add-StorageHeading $p "Laufwerk $($r.Drive)"
    $m = New-Text ('{0} von {1} belegt' -f (Format-Bytes $used), (Format-Bytes $r.Size)) -Role 'metric'
    [void]$p.Children.Add($m)
    $bar = New-StorageBar ($used / [Math]::Max(1L, $r.Size)) 'accent' 6; $bar.Margin = New-Thickness 0 8 0 12
    [void]$p.Children.Add($bar)
    $s = $r.Scan
    $unread = [Math]::Max(0L, $used - $s.Root.Size)
    [void]$p.Children.Add((New-LabeledLine 'Ausgewertet:' ('{0} in {1} Dateien und {2} Ordnern ({3:0} s)' -f (Format-Bytes $s.Root.Size), (Format-Count $s.Files), (Format-Count $s.Dirs), $s.Seconds)))
    if ($unread -gt 256MB) { [void]$p.Children.Add((New-LabeledLine 'Geschützt / nicht lesbar:' ((Format-Bytes $unread) + $(if ($r.Shadow -gt 0) { "  (davon Wiederherstellungspunkte: $(Format-Bytes $r.Shadow))" } else { '' })))) }
    if ($s.CloudBytes -gt 0) { [void]$p.Children.Add((New-LabeledLine 'Nur in der Cloud:' ('{0} in {1} Dateien – belegt hier keinen Platz' -f (Format-Bytes $s.CloudBytes), (Format-Count $s.CloudFiles)))) }
    if ($s.DeniedDirs -gt 0) { [void]$p.Children.Add((New-LabeledLine 'Kein Zugriff:' ('{0} Ordner (Systemschutz)' -f (Format-Count $s.DeniedDirs)))) }
}

# Bekannte Platzfresser: Windows, Programme, Spiele, Benutzerordner, Papierkorb, geschützte Bereiche
function Get-StorageHogs($r) {
    $root = $r.Scan.Root
    $used = [double][Math]::Max(1L, $r.Size - $r.Free)
    $out = New-Object System.Collections.ArrayList
    function Add-H([string]$Title, [long]$Size, [string]$Note, $Node = $null, [string]$Action = '', [string]$ActionLabel = '') {
        if ($Size -lt 100MB) { return }
        [void]$out.Add([pscustomobject]@{ Title = $Title; Size = $Size; Note = $Note; Node = $Node; Action = $Action; ActionLabel = $ActionLabel })
    }
    $win = $root.Find('Windows')
    if ($r.System -and $win) {
        Add-H 'Windows' $win.Size 'Das Betriebssystem selbst. Der Ordner WinSxS wirkt hier größer, als er ist, weil Windows viele Dateien doppelt verlinkt.' $win 'cleanup' 'Bereinigen'
    }
    foreach ($pf in 'Program Files', 'Program Files (x86)') {
        $n = $root.Find($pf); if ($n) { Add-H "Programme ($pf)" $n.Size 'Installierte Programme und Spiele. Entfernen über die Deinstallation.' $n 'uninstall' 'Deinstallation öffnen' }
    }
    $pd = $root.Find('ProgramData'); if ($pd) { Add-H 'ProgramData' $pd.Size 'Gemeinsame Daten von Programmen, z. B. Updates, Treiberpakete und Spiele-Launcher.' $pd }
    foreach ($f in @($r.Scan.Largest | Where-Object { $_.Path -match '^[A-Za-z]:\\(pagefile|hiberfil|swapfile)\.sys$' })) {
        switch -Regex ($f.Path) {
            'pagefile' { Add-H 'Auslagerungsdatei (pagefile.sys)' $f.Size 'Erweitert den Arbeitsspeicher. Windows verwaltet die Größe selbst – nicht löschen.' }
            'hiberfil' { Add-H 'Ruhezustandsdatei (hiberfil.sys)' $f.Size 'Für Ruhezustand und Schnellstart. Wird frei, wenn du den Ruhezustand abschaltest (Befehl: powercfg /h off).' }
            'swapfile' { Add-H 'Auslagerung für Apps (swapfile.sys)' $f.Size 'Von Windows verwaltet – nicht löschen.' }
        }
    }
    $rb = $root.Find('$Recycle.Bin'); if ($rb) { Add-H 'Papierkorb' $rb.Size 'Gelöschte Dateien, die noch Platz belegen.' $rb 'cleanup' 'Bereinigen' }

    # Benutzerordner
    $users = $root.Find('Users')
    if ($users) {
        $real = @($users.Children | Where-Object { $_.Name -notin 'Public', 'Default', 'Default User', 'All Users', 'defaultuser0', 'Öffentlich' -and $_.Size -gt 0 })
        foreach ($u in $real) {
            $suffix = if ($real.Count -gt 1) { " ($($u.Name))" } else { '' }
            foreach ($x in @(
                    @{ P = 'Downloads'; T = 'Downloads'; N = 'Oft alte Installationsdateien und Archive – lohnt sich durchzusehen.' }
                    @{ P = 'Desktop'; T = 'Desktop'; N = 'Dateien auf dem Desktop.' }
                    @{ P = 'Videos'; T = 'Videos'; N = 'Eigene Videos und Aufnahmen.' }
                    @{ P = 'Pictures'; T = 'Bilder'; N = 'Eigene Fotos und Bilder.' }
                    @{ P = 'Documents'; T = 'Dokumente'; N = 'Eigene Dateien – enthält oft auch Spielstände und Mods.' }
                    @{ P = 'Music'; T = 'Musik'; N = 'Eigene Musik.' })) {
                $n = $u.Find($x.P); if ($n) { Add-H ($x.T + $suffix) $n.Size $x.N $n }
            }
            $ad = $u.Find('AppData')
            if ($ad) {
                $tmp = $null; $loc = $ad.Find('Local'); if ($loc) { $tmp = $loc.Find('Temp') }
                $tmpSize = if ($tmp) { $tmp.Size } else { 0 }
                Add-H ('Programmdaten (AppData)' + $suffix) ($ad.Size - $tmpSize) 'Einstellungen und Zwischenspeicher von Programmen, z. B. Browser, Discord oder Launcher.' $ad
                if ($tmp) { Add-H ('Temporäre Dateien' + $suffix) $tmp.Size 'Lassen sich gefahrlos löschen.' $tmp 'cleanup' 'Bereinigen' }
            }
        }
    }

    # Spielebibliotheken (bis 4 Ebenen tief, Windows-Ordner ausgenommen)
    $games = New-Object System.Collections.ArrayList
    $rx = '^(SteamLibrary|steamapps|Epic Games|XboxGames|Riot Games|GOG Games|GOG Galaxy|Battle\.net|EA Games|Ubisoft Game Launcher|Rockstar Games|Origin Games)$'
    $stack = New-Object System.Collections.Stack
    foreach ($c in $root.Children) { if ($c.Name -ne 'Windows') { $stack.Push(@($c, 1)) } }
    while ($stack.Count -gt 0) {
        $e = $stack.Pop(); $n = $e[0]; $depth = $e[1]
        if ($n.Name -match $rx) { [void]$games.Add($n); continue }
        if ($depth -lt 4) { foreach ($c in $n.Children) { $stack.Push(@($c, $depth + 1)) } }
    }
    foreach ($g in $games) {
        $label = if ($g.Name -eq 'steamapps' -and $g.Parent) { "Steam ($($g.Parent.Path))" } else { "$($g.Name) ($($g.Parent.Path))" }
        Add-H "Spiele: $label" $g.Size 'Installierte Spiele. Deinstallieren am besten über den jeweiligen Launcher.' $g
    }

    # Was Windows nicht auflisten lässt
    $unread = [long]($r.Size - $r.Free) - $root.Size
    if ($unread -gt 512MB) {
        $note = 'Bereiche, die Windows schützt: Wiederherstellungspunkte, Systemdateien und Ordner ohne Zugriff.'
        if ($r.Shadow -gt 0) { $note += " Davon Wiederherstellungspunkte: $(Format-Bytes $r.Shadow)." }
        Add-H 'Geschützt / nicht lesbar' $unread $note $null $(if ($r.Shadow -gt 0) { 'restore' } else { '' }) 'Punkte verwalten'
    }
    return @($out | Sort-Object Size -Descending)
}

function Show-StorageHogs($r) {
    $p = $ui.StorageHogs; $p.Children.Clear()
    Add-StorageHeading $p 'Die größten Platzfresser' 'Klick auf einen Eintrag zeigt ihn links im Ordnerbaum.'
    $used = [double][Math]::Max(1L, $r.Size - $r.Free)
    $hogs = @(Get-StorageHogs $r | Select-Object -First 14)
    if ($hogs.Count -eq 0) { [void]$p.Children.Add((New-Text 'Keine großen Posten gefunden.' -Role 'small' -Color 'ink-muted')); return }
    foreach ($h in $hogs) {
        $b = New-Object Windows.Controls.Border
        $b.Padding = New-Thickness 8 8 8 8; $b.CornerRadius = New-Object Windows.CornerRadius(4); $b.Background = [Windows.Media.Brushes]::Transparent
        $sp = New-Object Windows.Controls.StackPanel
        $top = New-Object Windows.Controls.DockPanel
        $sz = New-Text (Format-Bytes $h.Size) -Role 'metric-small'; [Windows.Controls.DockPanel]::SetDock($sz, 'Right'); $sz.Margin = New-Thickness 12 0 0 0
        [void]$top.Children.Add($sz)
        $tt = New-Text $h.Title -Role 'title'; $tt.TextTrimming = 'CharacterEllipsis'; [void]$top.Children.Add($tt)
        [void]$sp.Children.Add($top)
        $bar = New-StorageBar ($h.Size / $used) 'accent'; $bar.Margin = New-Thickness 0 6 0 6; [void]$sp.Children.Add($bar)
        [void]$sp.Children.Add((New-Text $h.Note -Role 'small' -Color 'ink-muted'))
        if ($h.Action) {
            $act = New-ActionButton $h.ActionLabel {
                param($a)
                switch ($a) {
                    'cleanup' { $ui.Tabs.SelectedIndex = 4 }
                    'uninstall' { $ui.Tabs.SelectedIndex = 6 }
                    'restore' { Show-RestorePointManager }
                }
            } $h.Action
            $act.MinHeight = 32; $act.Padding = New-Thickness 12 4 12 5; $act.HorizontalAlignment = 'Left'
            [void]$sp.Children.Add($act)
        }
        $b.Child = $sp
        if ($h.Node) { Set-StorageClick $b { param($n) Show-StorageFolder $n } $h.Node 'Im Ordnerbaum anzeigen' }
        [void]$p.Children.Add($b)
    }
}

function Show-StorageTypes($r) {
    $p = $ui.StorageTypes; $p.Children.Clear()
    Add-StorageHeading $p 'Nach Dateityp'
    $total = [double][Math]::Max(1L, $r.Scan.Root.Size)
    $cat = @{}; $cnt = @{}
    foreach ($e in $r.Scan.Extensions) {
        $k = $script:StorageExtCat[$e.Ext]; if (-not $k) { $k = 'Sonstiges' }
        $cat[$k] = [long]$cat[$k] + $e.Size; $cnt[$k] = [long]$cnt[$k] + $e.Count
    }
    foreach ($k in @($cat.Keys | Sort-Object { $cat[$_] } -Descending)) {
        if ($cat[$k] -le 0) { continue }
        [void]$p.Children.Add((New-StorageRow -Name $k -Size $cat[$k] -Share ($cat[$k] / $total) -Meta ('{0} Dateien' -f (Format-Count $cnt[$k])) -Icon 'file'))
    }
    $sp = New-Object Windows.Controls.StackPanel
    foreach ($e in @($r.Scan.Extensions | Select-Object -First 15)) {
        $name = if ($e.Ext) { '.' + $e.Ext } else { '(ohne Endung)' }
        [void]$sp.Children.Add((New-StorageRow -Name $name -Size $e.Size -Share ($e.Size / $total) -Meta ('{0} Dateien' -f (Format-Count $e.Count)) -Icon 'file' -BarToken 'ink-muted'))
    }
    $x = New-ExpanderBox 'Häufigste Dateiendungen' $sp
    $x.Margin = New-Thickness 0 8 0 0
    [void]$p.Children.Add($x)
}

function Show-StorageFiles($r) {
    $p = $ui.StorageFiles; $p.Children.Clear()
    Add-StorageHeading $p 'Die größten Dateien' 'Klick öffnet den Ordner im Explorer und markiert die Datei.'
    $total = [double][Math]::Max(1L, $r.Size - $r.Free)
    $files = @($r.Scan.Largest | Select-Object -First 30)
    foreach ($f in $files) {
        $name = [IO.Path]::GetFileName($f.Path); $dir = [IO.Path]::GetDirectoryName($f.Path)
        $meta = if ($f.Modified -and $f.Modified.Year -gt 1980) { $f.Modified.ToString('dd.MM.yyyy') } else { '' }
        $row = New-StorageRow -Name $name -Size $f.Size -Share ($f.Size / $total) -Meta $meta -Icon 'file' -Do { param($x) Open-StoragePath $x -Select } -Data $f.Path -Tip $f.Path
        # Ordner unter dem Namen
        $sp = $row.Child.Children[1]
        $d = New-Text $dir -Role 'small' -Color 'ink-muted'; $d.TextTrimming = 'CharacterEllipsis'; $d.FontSize = 12; $d.Margin = New-Thickness 0 4 0 0
        [void]$sp.Children.Add($d)
        [void]$p.Children.Add($row)
    }
    if ($files.Count -eq 0) { [void]$p.Children.Add((New-Text 'Keine Dateien gefunden.' -Role 'small' -Color 'ink-muted')) }
}

# ---------------------------------------------------------------------------
#  Ereignisse
# ---------------------------------------------------------------------------
$ui.BtnStorageUp.Add_Click({ if ($script:Storage.Node -and $script:Storage.Node.Parent) { Show-StorageFolder $script:Storage.Node.Parent } })
$ui.BtnStorageOpen.Add_Click({ if ($script:Storage.Node) { Open-StoragePath $script:Storage.Node.Path } })
