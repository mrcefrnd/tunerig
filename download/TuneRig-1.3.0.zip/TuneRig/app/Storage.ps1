﻿﻿# ============================================================================
#  TuneRig - Speicherplatz-Analyse (Alle Werkzeuge > Speicherplatz)
#  Zeigt, was ein Laufwerk belegt - vor allem als Rangliste »Was du löschen kannst«:
#  Spiele (mit Namen und »zuletzt gespielt«), Programme, große Ordner und Dateien,
#  jeweils mit dem passenden Weg zum Entfernen. Dazu Ordnerbaum und Dateitypen.
#  Der eigentliche Durchlauf ist [TuneRig.DiskScan] in Core.ps1 (liest nur).
# ============================================================================
$script:Storage = @{ Drives = @(); Result = $null; Node = $null; Drive = ''; Used = 0L; View = 'big'; Filter = 'all'; Entries = @(); SysEntries = @() }

# Dateitypen -> Kategorie
$script:StorageCategories = [ordered]@{
    'Videos'                          = 'mp4 mkv avi mov wmv webm m4v flv mpg mpeg ts m2ts mts vob 3gp'
    'Bilder'                          = 'jpg jpeg png gif bmp tif tiff heic heif webp raw cr2 cr3 nef arw dng orf psd xcf svg ico'
    'Musik und Audio'                 = 'mp3 flac wav aac ogg m4a wma opus aiff alac'
    'Dokumente'                       = 'pdf doc docx xls xlsx xlsm ppt pptx odt ods odp txt rtf csv md epub one pst ost'
    'Archive und Abbilder'            = 'zip rar 7z tar gz tgz bz2 xz zst iso img vhd vhdx vmdk vdi qcow2 cab wim esd'
    'Spieldaten'                      = 'pak vpk bsa ba2 ucas utoc forge sga big arc bnk wem bik assets resource resources bundle gcf ncf rpf wad pck acb awb'
    'Programme und Bibliotheken'      = 'exe dll sys msi msix msixbundle appx appxbundle ocx drv mui cpl winmd node pyd jar'
    'Zwischenspeicher und Protokolle' = 'tmp temp log etl dmp mdmp bak old cache db-wal blob ldb'
}
$script:StorageExtCat = @{}
foreach ($k in $script:StorageCategories.Keys) { foreach ($e in $script:StorageCategories[$k].Split(' ')) { $script:StorageExtCat[$e] = $k } }

# Ordner der obersten Ebene, die zu Windows bzw. Programmen gehören (nie als »löschbar« vorschlagen)
$script:StorageSystemRoots = @('Windows', 'Program Files', 'Program Files (x86)', 'ProgramData', '$Recycle.Bin', 'System Volume Information', 'Recovery',
    '$WinREAgent', 'PerfLogs', 'Config.Msi', 'MSOCache', '$SysReset', '$Windows.~BT', '$Windows.~WS', 'Boot', 'EFI', 'OneDriveTemp', 'Intel', 'AMD', 'NVIDIA', 'Drivers')
# Bekannte Benutzerordner: werden nie als Ganzes vorgeschlagen, sondern ihr Inhalt
$script:StorageContainers = @('Downloads', 'Desktop', 'Documents', 'Pictures', 'Videos', 'Music', 'Saved Games', 'Favorites', 'Contacts', 'Links', 'Searches', '3D Objects', 'OneDrive', 'Dokumente', 'Bilder', 'Musik')
# Ordner, deren Unterordner jeweils ein Spiel sind
$script:StorageGameLibs = '^(Epic Games|XboxGames|Riot Games|GOG Games|GOG Galaxy Games|EA Games|Origin Games|Ubisoft Games|Games|Spiele)$'
$script:StorageGamePublishers = 'Riot|Blizzard|Electronic Arts|Ubisoft|CD PROJEKT|Rockstar|Valve|Epic Games|GOG|Activision|2K|Bethesda|Mojang|Wargaming|Bungie|Bandai|Square Enix|SEGA|Capcom|Paradox|Krafton|miHoYo|HoYoverse|Cognosphere|Gaijin|Grinding Gear|Digital Extremes|Hi-Rez|Warhorse|Larian|Respawn|Embark|Facepunch|Kinguin|NetEase'

function Format-Count([long]$n) { $n.ToString('N0', [Globalization.CultureInfo]::GetCultureInfo('de-DE')) }
function Format-Share([double]$p) { if ($p -le 0) { '0 %' } elseif ($p -lt 0.01) { '< 1 %' } else { '{0:0} %' -f ($p * 100) } }
function Format-Ago($Date) {
    if (-not $Date) { return '' }
    $days = ((Get-Date) - [datetime]$Date).TotalDays
    if ($days -lt 1) { 'heute' } elseif ($days -lt 2) { 'gestern' } elseif ($days -lt 31) { 'vor {0:0} Tagen' -f $days }
    elseif ($days -lt 365) { $m = [Math]::Max(1, [Math]::Round($days / 30.4)); if ($m -eq 1) { 'vor 1 Monat' } else { "vor $m Monaten" } }
    else { $y = [Math]::Round($days / 365, 1); if ($y -lt 1.5) { 'vor über 1 Jahr' } else { 'vor {0:0} Jahren' -f [Math]::Floor($y) } }
}

# ---------------------------------------------------------------------------
#  Bausteine
# ---------------------------------------------------------------------------
function New-StorageBar([double]$Share, [string]$Token = 'accent', [double]$Height = 4) {
    $g = New-Object Windows.Controls.Grid
    $g.Height = $Height
    $s = [Math]::Max(0.0, [Math]::Min(1.0, $Share))
    $c0 = New-Object Windows.Controls.ColumnDefinition; $c0.Width = New-Object Windows.GridLength(($s * 1000), [Windows.GridUnitType]::Star)
    $c1 = New-Object Windows.Controls.ColumnDefinition; $c1.Width = New-Object Windows.GridLength(((1 - $s) * 1000), [Windows.GridUnitType]::Star)
    $g.ColumnDefinitions.Add($c0); $g.ColumnDefinitions.Add($c1)
    $bg = New-Object Windows.Controls.Border; $bg.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $bg Background 'line'; [Windows.Controls.Grid]::SetColumnSpan($bg, 2); [void]$g.Children.Add($bg)
    $fg = New-Object Windows.Controls.Border; $fg.CornerRadius = New-Object Windows.CornerRadius(1)
    Set-ThemeRef $fg Background $Token; [void]$g.Children.Add($fg)
    return $g
}

function Set-StorageClick($Border, [scriptblock]$Do, $Data, [string]$Tip) {
    $Border.Cursor = [Windows.Input.Cursors]::Hand
    $Border.Focusable = $true
    $Border.ToolTip = $Tip
    $Border.Tag = @{ Do = $Do; Data = $Data }
    $Border.Add_MouseEnter({ Set-ThemeRef $this Background 'surface-raised' })
    $Border.Add_MouseLeave({ $this.Background = [Windows.Media.Brushes]::Transparent })
    $Border.Add_MouseLeftButtonUp({ $t = $this.Tag; try { & $t.Do $t.Data } catch { Show-Error $_.Exception.Message } })
    $Border.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Return' -or $e.Key -eq 'Space') { $t = $this.Tag; & $t.Do $t.Data; $e.Handled = $true } })
}

function New-SmallButton([string]$Label, [scriptblock]$Do, $Data = $null) {
    $b = New-ActionButton $Label $Do $Data
    $b.MinHeight = 32; $b.Padding = New-Thickness 12 4 12 5; $b.Margin = New-Thickness 0 0 0 6
    $b.HorizontalAlignment = 'Stretch'
    return $b
}

# Zeile für Ordnerbaum und Dateitypen: Symbol | Name (+ Zusatz) und Balken | Größe | Anteil
function New-StorageRow {
    param([string]$Name, [long]$Size, [double]$Share, [string]$Meta = '', [string]$Icon = 'folder', [scriptblock]$Do = $null, $Data = $null, [string]$Tip = '', [string]$BarToken = 'accent')
    $b = New-Object Windows.Controls.Border
    $b.Padding = New-Thickness 8 8 8 8
    $b.CornerRadius = New-Object Windows.CornerRadius(4)
    $b.Background = [Windows.Media.Brushes]::Transparent
    $g = New-Object Windows.Controls.Grid
    foreach ($w in 28, -1, 96, 56) {
        $c = New-Object Windows.Controls.ColumnDefinition
        $c.Width = if ($w -lt 0) { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { New-Object Windows.GridLength($w) }
        $g.ColumnDefinitions.Add($c)
    }
    $ic = New-LineIcon $Icon 'ink-muted' 18; $ic.VerticalAlignment = 'Top'; $ic.Margin = New-Thickness 0 1 0 0
    [void]$g.Children.Add($ic)
    $sp = New-Object Windows.Controls.StackPanel; $sp.Margin = New-Thickness 0 0 12 0
    $t = New-Object Windows.Controls.TextBlock; $t.TextTrimming = 'CharacterEllipsis'
    Set-TypeRole $t 'body'
    $r1 = New-Object Windows.Documents.Run($Name); Set-ThemeRef $r1 Foreground 'ink'; [void]$t.Inlines.Add($r1)
    if ($Meta) { $r2 = New-Object Windows.Documents.Run("   $Meta"); Set-ThemeRef $r2 Foreground 'ink-muted'; $r2.FontSize = 12; [void]$t.Inlines.Add($r2) }
    [void]$sp.Children.Add($t)
    $bar = New-StorageBar $Share $BarToken; $bar.Margin = New-Thickness 0 6 0 0
    [void]$sp.Children.Add($bar)
    [Windows.Controls.Grid]::SetColumn($sp, 1); [void]$g.Children.Add($sp)
    $sz = New-Object Windows.Controls.TextBlock; $sz.Text = Format-Bytes $Size; $sz.HorizontalAlignment = 'Right'
    Set-TypeRole $sz 'metric-small'; Set-ThemeRef $sz Foreground 'ink'
    [Windows.Controls.Grid]::SetColumn($sz, 2); [void]$g.Children.Add($sz)
    $pc = New-Object Windows.Controls.TextBlock; $pc.Text = Format-Share $Share; $pc.HorizontalAlignment = 'Right'
    Set-TypeRole $pc 'small'; Set-ThemeRef $pc Foreground 'ink-muted'
    [Windows.Controls.Grid]::SetColumn($pc, 3); [void]$g.Children.Add($pc)
    $b.Child = $g
    if ($Do) { Set-StorageClick $b $Do $Data $Tip }
    return $b
}

function Open-StoragePath([string]$Path, [switch]$Select) {
    try {
        if ($Select) { Start-Process explorer.exe -ArgumentList ('/select,"{0}"' -f $Path) }
        else { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $Path) }
    } catch { Show-Error $_.Exception.Message }
}

function Find-StorageNode([string]$Path) {
    $r = $script:Storage.Result; if (-not $r) { return $null }
    $n = $r.Scan.Root
    $rel = $Path.Substring([Math]::Min($Path.Length, 3)).Trim('\')
    if (-not $rel) { return $n }
    foreach ($part in $rel.Split('\')) { $n = $n.Find($part); if (-not $n) { return $null } }
    return $n
}

# ---------------------------------------------------------------------------
#  Laufwerke (kompakt: ganze Kachel ist klickbar)
# ---------------------------------------------------------------------------
function Update-StorageDrives {
    $script:Storage.Drives = @(Get-StorageDrives)
    $ui.StorageDrives.Children.Clear()
    if ($script:Storage.Drives.Count -eq 0) { [void]$ui.StorageDrives.Children.Add((New-Text 'Keine Laufwerke gefunden.' -Role 'small' -Color 'ink-muted')); return }
    foreach ($d in $script:Storage.Drives) {
        $used = $d.Size - $d.Free
        $share = $used / [Math]::Max(1L, $d.Size)
        $card = New-Object Windows.Controls.Border
        $card.Width = 264; $card.Padding = New-Thickness 14 12 14 12; $card.Margin = New-Thickness 0 0 12 12
        $card.CornerRadius = New-Object Windows.CornerRadius(8); $card.BorderThickness = New-Thickness 1 1 1 1
        Set-ThemeRef $card BorderBrush $(if ($script:Storage.Drive -eq $d.Drive -and $script:Storage.Result) { 'accent' } else { 'line' })
        $card.Background = [Windows.Media.Brushes]::Transparent
        $sp = New-Object Windows.Controls.StackPanel
        $head = New-Object Windows.Controls.DockPanel
        $go = New-Object Windows.Controls.StackPanel; $go.Orientation = 'Horizontal'; [Windows.Controls.DockPanel]::SetDock($go, 'Right')
        $gt = New-Text $(if ($script:Storage.Drive -eq $d.Drive -and $script:Storage.Result) { 'Neu analysieren' } else { 'Analysieren' }) -Role 'small' -Color 'accent-text'
        [void]$go.Children.Add($gt)
        $ga = New-LineIcon 'arrow' 'accent-text' 14; $ga.Margin = New-Thickness 6 0 0 0; $ga.VerticalAlignment = 'Center'; [void]$go.Children.Add($ga)
        [void]$head.Children.Add($go)
        $ic = New-LineIcon 'drive' 'ink' 18; $ic.Margin = New-Thickness 0 0 8 0; [Windows.Controls.DockPanel]::SetDock($ic, 'Left'); [void]$head.Children.Add($ic)
        $name = $d.Drive + $(if ($d.Label) { "  $($d.Label)" } elseif ($d.System) { '  Windows' } elseif ($d.Removable) { '  Wechseldatenträger' } else { '' })
        $tt = New-Text $name -Role 'title'; $tt.TextTrimming = 'CharacterEllipsis'; $tt.VerticalAlignment = 'Center'
        [void]$head.Children.Add($tt)
        [void]$sp.Children.Add($head)
        $lvl = if ($share -ge 0.9) { 3 } elseif ($share -ge 0.8) { 2 } else { -1 }
        $bar = New-StorageBar $share $(if ($lvl -eq 3) { 'danger' } elseif ($lvl -eq 2) { 'warning' } else { 'accent' }) 4
        $bar.Margin = New-Thickness 0 10 0 6
        [void]$sp.Children.Add($bar)
        $info = '{0} von {1}  ·  {2} frei' -f (Format-Bytes $used), (Format-Bytes $d.Size), (Format-Bytes $d.Free)
        if ($lvl -ge 2) { $l = New-ColoredLine ($info + $(if ($lvl -eq 3) { ' – fast voll' } else { ' – wird knapp' })) $lvl 0; $l.Margin = New-Thickness 0 0 0 0; [void]$sp.Children.Add($l) }
        else { [void]$sp.Children.Add((New-Text $info -Role 'small' -Color 'ink-muted')) }
        $card.Child = $sp
        Set-StorageClick $card { param($drv) Start-StorageScan $drv } $d.Drive "Laufwerk $($d.Drive) analysieren"
        [Windows.Automation.AutomationProperties]::SetName($card, "Laufwerk $($d.Drive) analysieren")
        [void]$ui.StorageDrives.Children.Add($card)
    }
}

# ---------------------------------------------------------------------------
#  Analyse starten (Fortschritt live aus [TuneRig.DiskScan])
# ---------------------------------------------------------------------------
$script:StorageTimer = New-Object Windows.Threading.DispatcherTimer
$script:StorageTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$script:StorageTimer.Add_Tick({
    $f = [TuneRig.DiskScan]::ScannedFiles; $b = [TuneRig.DiskScan]::ScannedBytes
    $pct = [Math]::Min(99.0, 100.0 * $b / [Math]::Max(1L, $script:Storage.Used))
    $ui.StorageProgressBar.Value = $pct
    $ui.StorageProgressText.Text = '{0} Dateien  ·  {1}  ·  {2}' -f (Format-Count $f), (Format-Bytes $b), [TuneRig.DiskScan]::Current
    $script:Sync.Status = 'Analysiere {0} … {1:0} %' -f $script:Storage.Drive, $pct
})

function Stop-StorageProgress { $script:StorageTimer.Stop(); $ui.StorageProgress.Visibility = 'Collapsed' }

function Start-StorageScan([string]$Drive) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $d = @($script:Storage.Drives | Where-Object { $_.Drive -eq $Drive })[0]
    $script:Storage.Drive = $Drive
    $script:Storage.Used = if ($d) { [long]($d.Size - $d.Free) } else { 1L }
    $ui.StorageProgressBar.Value = 0; $ui.StorageProgressText.Text = ''
    $ui.StorageProgress.Visibility = 'Visible'
    $script:StorageTimer.Start()
    Start-Work -Cancellable -Status "Analysiere $Drive …" -Arguments @($Drive) -Script { Invoke-StorageScan $A[0] } -OnDone {
        param($r)
        Stop-StorageProgress
        Show-StorageResult (@($r)[-1])
    } -OnCancel { Stop-StorageProgress; Set-Status 'Analyse abgebrochen.' }
}

# ---------------------------------------------------------------------------
#  Rangliste: Spiele, Programme, Ordner und Dateien, die am meisten Platz belegen
# ---------------------------------------------------------------------------
function Get-StorageExtHint([string]$Path) {
    $ext = [IO.Path]::GetExtension($Path).TrimStart('.').ToLowerInvariant()
    switch -Regex ($ext) {
        '^(iso|img)$' { 'Abbild einer CD/DVD oder eines Installationsmediums – nach der Installation meist nicht mehr nötig.' }
        '^(exe|msi|msix)$' { 'Installationsdatei – nach der Installation meist nicht mehr nötig.' }
        '^(zip|rar|7z|tar|gz|xz|zst)$' { 'Archiv – prüfe, ob du den Inhalt schon entpackt hast.' }
        '^(vhd|vhdx|vmdk|vdi|qcow2)$' { 'Virtuelle Festplatte – gehört vermutlich zu einer virtuellen Maschine oder WSL.' }
        '^(dmp|mdmp)$' { 'Absturzabbild – kann gelöscht werden.' }
        '^(mp4|mkv|avi|mov|wmv|webm|m4v|ts|m2ts)$' { 'Video – z. B. eine Aufnahme oder ein Film.' }
        '^(bak|old|tmp)$' { 'Sicherungs- oder Zwischendatei – meist überflüssig.' }
        default { '' }
    }
}

function Get-StorageEntries($r) {
    $min = 500MB
    $root = $r.Scan.Root
    $entries = New-Object System.Collections.ArrayList
    $sys = New-Object System.Collections.ArrayList

    # Spiele/Programme mit bekanntem Installationsordner (Steam und Epic haben Vorrang vor der Programmliste)
    $apps = @{}
    foreach ($a in @($r.Apps)) {
        if (-not $a.Path) { continue }
        $k = ([string]$a.Path).ToLowerInvariant().TrimEnd('\')
        if (-not $apps.ContainsKey($k) -or $apps[$k].Kind -eq 'program') { $apps[$k] = $a }
    }

    function Add-E([string]$Kind, [string]$Title, [long]$Size, $Node, [string]$Path, [string]$Hint = '', $App = $null, [bool]$Recycle = $false, $Modified = $null) {
        [void]$entries.Add([pscustomobject]@{ Kind = $Kind; Title = $Title; Size = $Size; Node = $Node; Path = $Path; Hint = $Hint; App = $App
                                              Recycle = $Recycle; Modified = $Modified; Files = (New-Object System.Collections.ArrayList); Library = '' })
    }
    function Test-GameApp($a, [string]$Path) {
        ($a.Kind -in 'steam', 'epic') -or ([string]$a.Publisher -match $script:StorageGamePublishers) -or ($Path -match '\\(steamapps|Epic Games|XboxGames|Riot Games|GOG Games|EA Games|Origin Games)\\')
    }

    function Visit($n, [bool]$IsSys, [int]$Depth, [bool]$Container) {
        if ($n.Size -lt $min) { return }
        $path = $n.Path
        $key = $path.ToLowerInvariant()
        # 1) bekanntes Spiel oder Programm
        if ($apps.ContainsKey($key)) {
            $a = $apps[$key]
            $kind = if (Test-GameApp $a $path) { 'game' } else { 'program' }
            Add-E $kind $(if ($a.Name) { $a.Name } else { $n.Name }) $n.Size $n $path '' $a
            return
        }
        # 2) Unterordner einer Spielebibliothek (auch Steam-Spiele ohne Manifest)
        $p = $n.Parent
        if ($p -and ($p.Name -match $script:StorageGameLibs -or ($p.Name -eq 'common' -and $p.Parent -and $p.Parent.Name -eq 'steamapps'))) {
            $lib = if ($p.Name -eq 'common') { 'steam-orphan' } elseif ($p.Name -eq 'XboxGames') { 'xbox' } else { 'lib' }
            Add-E 'game' $n.Name $n.Size $n $path '' ([pscustomobject]@{ Kind = $lib; Name = $n.Name; Id = ''; LastPlayed = $null; Uninstall = $n.Name })
            return
        }
        if ($n.Name -eq 'workshop' -and $p -and $p.Name -eq 'steamapps') {
            Add-E 'folder' 'Steam Workshop-Inhalte' $n.Size $n $path 'Mods und Karten aus dem Steam Workshop. Abonnements in Steam beenden, dann werden sie entfernt.'
            return
        }
        # 3) Windows- und Programmbereiche: nur nach Spielen/Programmen suchen
        if ($IsSys) {
            if ($Depth -lt 6) { foreach ($c in $n.Children) { Visit $c $true ($Depth + 1) $false } }
            return
        }
        # 4) Benutzerordner und Laufwerk: immer hineinschauen
        if ($Container) {
            foreach ($c in $n.Children) {
                $cSys = $false; $cCont = $false
                if ($n.Parent -eq $null) { $cSys = $c.Name -in $script:StorageSystemRoots; $cCont = $c.Name -eq 'Users' }
                elseif ($n.Name -eq 'Users' -and $n.Parent.Parent -eq $null) { $cCont = $true; $cSys = $c.Name -in 'Public', 'Default', 'Default User', 'All Users', 'defaultuser0' }
                elseif ($n.Parent.Name -eq 'Users' -and $n.Parent.Parent.Parent -eq $null) { $cSys = $c.Name -eq 'AppData'; $cCont = ($c.Name -in $script:StorageContainers) -or ($c.Name -like 'OneDrive*') }
                Visit $c $cSys ($Depth + 1) $cCont
            }
            if ($n.Parent) { [void]$leftover.Add($n) }
            return
        }
        # 5) Spielebibliotheken: immer hineinschauen, damit jedes Spiel einzeln erscheint
        if ($n.Name -match $script:StorageGameLibs -or $n.Name -in 'SteamLibrary', 'steamapps', 'common') {
            foreach ($c in $n.Children) { Visit $c $false ($Depth + 1) $false }
            return
        }
        # 6) Ein Unterordner überwiegt: dort weitersuchen, sonst ist dieser Ordner ein »Brocken«
        $big = $null; foreach ($c in $n.Children) { if (-not $big -or $c.Size -gt $big.Size) { $big = $c } }
        if ($big -and $big.Size -ge 0.6 * $n.Size) {
            foreach ($c in $n.Children) { Visit $c $false ($Depth + 1) $false }
            [void]$leftover.Add($n)
            return
        }
        Add-E 'folder' $n.Name $n.Size $n $path '' $null ($Depth -ge 2)
    }

    $leftover = New-Object System.Collections.ArrayList
    if ($r.System) {
        $wo = $root.Find('Windows.old')
        if ($wo -and $wo.Size -ge $min) { Add-E 'special' 'Windows.old – alte Windows-Version' $wo.Size $wo $wo.Path 'Bleibt nach einem großen Windows-Update zurück. Entfernen mit der Datenträgerbereinigung (»Vorherige Windows-Installationen«).' }
    }
    foreach ($c in $root.Children) {
        if ($c.Name -eq 'Windows.old') { continue }
        $isSys = $c.Name -in $script:StorageSystemRoots
        Visit $c $isSys 1 ($c.Name -eq 'Users')
    }

    # Große Dateien: einem Ordner-Brocken zuordnen oder einzeln aufführen
    $sysRx = '^[A-Za-z]:\\(Windows|Program Files|Program Files \(x86\)|ProgramData|\$Recycle\.Bin|System Volume Information|Recovery)\\|\\AppData\\|^[A-Za-z]:\\(pagefile|hiberfil|swapfile)\.sys$'
    $listed = @{}
    foreach ($f in @($r.Scan.Largest | Where-Object { $_.Size -ge $min })) {
        if ($f.Path -match $sysRx) { continue }
        $owner = $null
        foreach ($e in $entries) { if ($e.Path -and $f.Path.StartsWith($e.Path + '\', [StringComparison]::OrdinalIgnoreCase)) { $owner = $e; break } }
        if ($owner) { if ($owner.Kind -eq 'folder') { [void]$owner.Files.Add($f) }; continue }
        Add-E 'file' ([IO.Path]::GetFileName($f.Path)) $f.Size $null $f.Path (Get-StorageExtHint $f.Path) $null $true $f.Modified
        $dir = [IO.Path]::GetDirectoryName($f.Path).ToLowerInvariant()
        $listed[$dir] = [long]$listed[$dir] + $f.Size
    }
    # Reste: viele kleinere Dateien direkt in einem Ordner (z. B. Downloads)
    foreach ($n in $leftover) {
        $rest = $n.OwnSize - [long]$listed[$n.Path.ToLowerInvariant()]
        if ($rest -ge $min) { Add-E 'files' "Weitere Dateien in »$($n.Name)«" $rest $n $n.Path ('{0} Dateien direkt in diesem Ordner – im Explorer nach Größe sortieren und aussortieren.' -f (Format-Count $n.OwnFiles)) }
    }

    # Hinweise je Eintrag
    foreach ($e in $entries) {
        if ($e.Kind -eq 'game') {
            $a = $e.App
            $e.Library = switch ($a.Kind) { 'steam' { 'Steam' } 'steam-orphan' { 'Steam' } 'epic' { 'Epic Games' } 'xbox' { 'Xbox' } default { '' } }
            $parts = @()
            if ($a.LastPlayed) { $parts += 'Zuletzt gespielt: ' + (Format-Ago $a.LastPlayed) + ' (' + ([datetime]$a.LastPlayed).ToString('dd.MM.yyyy') + ')' }
            $parts += switch ($a.Kind) {
                'steam' { 'Deinstallieren über Steam. Spielstände in der Steam Cloud bleiben erhalten.' }
                'steam-orphan' { 'Steam kennt dieses Spiel nicht mehr – vermutlich ein Rest. Ordner prüfen und löschen.' }
                'epic' { 'Deinstallieren im Epic Games Launcher: Bibliothek > Spiel > ... > Deinstallieren.' }
                'xbox' { 'Deinstallieren über die Xbox-App oder Windows-Einstellungen > Apps.' }
                'program' { 'Deinstallieren mit TuneRig – inklusive Restesuche.' }
                default { 'Deinstallieren über den Launcher des Spiels oder die Deinstallation in TuneRig.' }
            }
            $e.Hint = $parts -join '  ·  '
            if ($a.Kind -eq 'steam-orphan') { $e.Recycle = $true }
        } elseif ($e.Kind -eq 'program') {
            $e.Hint = 'Programm – deinstallieren mit TuneRig, inklusive Restesuche.' + $(if ($e.App.Publisher) { "  ·  Hersteller: $($e.App.Publisher)" } else { '' })
        } elseif ($e.Kind -eq 'folder' -and -not $e.Hint) {
            $e.Hint = if ($e.Files.Count) { 'Enthält große Dateien (siehe unten). Inhalt prüfen, bevor du löschst.' } else { 'Inhalt prüfen, bevor du löschst – »Öffnen« zeigt ihn im Explorer.' }
        } elseif ($e.Kind -eq 'file' -and $e.Modified -and ([datetime]$e.Modified).Year -gt 1980) {
            $e.Hint = (@($e.Hint, ('Zuletzt geändert: ' + ([datetime]$e.Modified).ToString('dd.MM.yyyy'))) | Where-Object { $_ }) -join '  ·  '
        }
    }
    return @($entries | Sort-Object Size -Descending)
}

# Zur Einordnung: Windows, Auslagerung, Programmdaten, Papierkorb, geschützte Bereiche
function Get-StorageSysEntries($r) {
    $root = $r.Scan.Root
    $out = New-Object System.Collections.ArrayList
    function Add-S([string]$Title, [long]$Size, [string]$Note, $Node = $null, [string]$Action = '', [string]$ActionLabel = '') {
        if ($Size -lt 100MB) { return }
        [void]$out.Add([pscustomobject]@{ Title = $Title; Size = $Size; Note = $Note; Node = $Node; Action = $Action; ActionLabel = $ActionLabel })
    }
    $win = $root.Find('Windows')
    if ($r.System -and $win) { Add-S 'Windows' $win.Size 'Das Betriebssystem. WinSxS wirkt größer, als es ist, weil Windows viele Dateien doppelt verlinkt.' $win 'cleanup' 'Bereinigen' }
    $pd = $root.Find('ProgramData'); if ($pd) { Add-S 'ProgramData' $pd.Size 'Gemeinsame Daten von Programmen, Treiberpakete und Launcher-Downloads.' $pd }
    foreach ($f in @($r.Scan.Largest | Where-Object { $_.Path -match '^[A-Za-z]:\\(pagefile|hiberfil|swapfile)\.sys$' })) {
        switch -Regex ($f.Path) {
            'pagefile' { Add-S 'Auslagerungsdatei (pagefile.sys)' $f.Size 'Erweitert den Arbeitsspeicher. Windows verwaltet die Größe selbst – nicht löschen.' }
            'hiberfil' { Add-S 'Ruhezustandsdatei (hiberfil.sys)' $f.Size 'Für Ruhezustand und Schnellstart. Wird frei, wenn du den Ruhezustand abschaltest (Befehl: powercfg /h off).' }
            'swapfile' { Add-S 'Auslagerung für Apps (swapfile.sys)' $f.Size 'Von Windows verwaltet – nicht löschen.' }
        }
    }
    $rb = $root.Find('$Recycle.Bin'); if ($rb) { Add-S 'Papierkorb' $rb.Size 'Gelöschte Dateien belegen weiter Platz, bis der Papierkorb geleert ist.' $rb 'cleanup' 'Papierkorb leeren' }
    $users = $root.Find('Users')
    if ($users) {
        foreach ($u in @($users.Children)) {
            $ad = $u.Find('AppData'); if (-not $ad) { continue }
            $tmp = $null; $loc = $ad.Find('Local'); if ($loc) { $tmp = $loc.Find('Temp') }
            $ts = if ($tmp) { $tmp.Size } else { 0L }
            Add-S "Programmdaten von $($u.Name) (AppData)" ($ad.Size - $ts) 'Einstellungen und Zwischenspeicher von Programmen. Nicht von Hand löschen – über das Programm oder die Bereinigung.' $ad
            if ($tmp) { Add-S "Temporäre Dateien von $($u.Name)" $tmp.Size 'Lassen sich gefahrlos löschen.' $tmp 'cleanup' 'Bereinigen' }
        }
    }
    $unread = [long]($r.Size - $r.Free) - $root.Size
    if ($unread -gt 512MB) {
        $note = 'Bereiche, die Windows schützt: Wiederherstellungspunkte, Systemdateien und Ordner ohne Zugriff.'
        if ($r.Shadow -gt 0) { $note += " Davon Wiederherstellungspunkte: $(Format-Bytes $r.Shadow)." }
        Add-S 'Geschützt / nicht lesbar' $unread $note $null $(if ($r.Shadow -gt 0) { 'restore' } else { '' }) 'Punkte verwalten'
    }
    return @($out | Sort-Object Size -Descending)
}

# ---------------------------------------------------------------------------
#  Aktionen
# ---------------------------------------------------------------------------
function Open-StorageUninstall([string]$Name) {
    Show-Page 'expert'
    $ui.Tabs.SelectedIndex = 6
    $ui.TxtSearch.Text = $Name
    Set-Status "Wähle »$Name« in der Liste und klick auf »Jetzt deinstallieren«. TuneRig sucht danach nach Resten."
}

function Invoke-StorageGameUninstall($e) {
    $a = $e.App
    switch ($a.Kind) {
        'steam' { if ($a.Id) { Start-Process "steam://uninstall/$($a.Id)"; Set-Status "Steam fragt jetzt, ob »$($e.Title)« deinstalliert werden soll. Danach hier »Neu analysieren«." } }
        'epic' { try { Start-Process 'com.epicgames.launcher://store/library' } catch {}; Set-Status "Im Epic Games Launcher: Bibliothek > »$($e.Title)« > ... > Deinstallieren." }
        'xbox' { Start-Process 'ms-settings:appsfeatures'; Set-Status "In den Einstellungen nach »$($e.Title)« suchen und deinstallieren." }
        default { Open-StorageUninstall $a.Uninstall }
    }
}

# In den Papierkorb (Windows zeigt bei sehr großen Ordnern selbst eine Rückfrage an)
function Remove-StorageItem($e) {
    if ($script:Job) { Set-Status 'Bitte warten, bis der aktuelle Vorgang abgeschlossen ist.'; return }
    $isDir = $e.Kind -in 'folder', 'game'
    $what = if ($isDir) { 'den Ordner' } else { 'die Datei' }
    $q = "Soll TuneRig $what in den Papierkorb verschieben?`n`n$($e.Path)`n$(Format-Bytes $e.Size)`n`nDer Platz wird erst frei, wenn du den Papierkorb leerst. Bis dahin kannst du alles wiederherstellen."
    if (-not (Confirm-Action $q 'In den Papierkorb')) { return }
    $script:State.StorageRemove = $e
    Start-Work -Status "Verschiebe »$($e.Title)« in den Papierkorb …" -Arguments @($e.Path, $isDir) -Script {
        Add-Type -AssemblyName Microsoft.VisualBasic
        if ($A[1]) { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($A[0], 'AllDialogs', 'SendToRecycleBin', 'DoNothing') }
        else { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($A[0], 'AllDialogs', 'SendToRecycleBin', 'DoNothing') }
        [pscustomobject]@{ Gone = -not (Test-Path -LiteralPath $A[0]) }
    } -OnDone {
        param($res)
        $e = $script:State.StorageRemove
        if (-not (@($res)[-1]).Gone) { Set-Status 'Nicht verschoben (abgebrochen oder kein Zugriff).'; return }
        # Größen im Baum nachführen
        $size = $e.Size
        if ($e.Node -and $e.Kind -ne 'files') {
            $p = $e.Node.Parent; [void]$p.Children.Remove($e.Node)
            $files = $e.Node.Files
            while ($p) { $p.Size -= $size; $p.Files -= $files; $p = $p.Parent }
        } else {
            $p = Find-StorageNode ([IO.Path]::GetDirectoryName($e.Path))
            if ($p) { $p.OwnSize -= $size; $p.OwnFiles--; while ($p) { $p.Size -= $size; $p.Files--; $p = $p.Parent } }
            $lf = @($script:Storage.Result.Scan.Largest | Where-Object { $_.Path -eq $e.Path })
            foreach ($x in $lf) { [void]$script:Storage.Result.Scan.Largest.Remove($x) }
        }
        $script:Storage.Result.Scan.Root.Size = [Math]::Max(0L, $script:Storage.Result.Scan.Root.Size)
        $script:Storage.Entries = @(Get-StorageEntries $script:Storage.Result)
        Show-StorageBig
        if ($script:Storage.Node) { Show-StorageFolder $script:Storage.Node }
        Set-Status "»$($e.Title)« liegt jetzt im Papierkorb. Leere den Papierkorb (Reiter Bereinigung), um $(Format-Bytes $size) freizugeben."
    } -OnCancel { Set-Status 'Abgebrochen.' }
}

# ---------------------------------------------------------------------------
#  Ergebnis anzeigen
# ---------------------------------------------------------------------------
function Set-StorageView([string]$View) {
    $script:Storage.View = $View
    $ui.StorageViewBig.Visibility = if ($View -eq 'big') { 'Visible' } else { 'Collapsed' }
    $ui.StorageViewTree.Visibility = if ($View -eq 'tree') { 'Visible' } else { 'Collapsed' }
    $ui.StorageViewTypes.Visibility = if ($View -eq 'types') { 'Visible' } else { 'Collapsed' }
    $ui.BtnStorageViewBig.Tag = if ($View -eq 'big') { 'active' } else { $null }
    $ui.BtnStorageViewTree.Tag = if ($View -eq 'tree') { 'active' } else { $null }
    $ui.BtnStorageViewTypes.Tag = if ($View -eq 'types') { 'active' } else { $null }
}

function Show-StorageResult($r) {
    if (-not $r -or -not $r.Scan) { Set-Status 'Die Analyse hat kein Ergebnis geliefert.'; return }
    $script:Storage.Result = $r
    $ui.StorageEmpty.Visibility = 'Collapsed'
    $ui.StorageResult.Visibility = 'Visible'
    Update-StorageDrives
    $s = $r.Scan
    $used = [long]($r.Size - $r.Free)
    $ui.StorageHeadline.Text = '{0}   {1} von {2} belegt  ·  {3} frei' -f $r.Drive, (Format-Bytes $used), (Format-Bytes $r.Size), (Format-Bytes $r.Free)
    $sub = @(('Ausgewertet: {0} in {1} Dateien ({2:0} s)' -f (Format-Bytes $s.Root.Size), (Format-Count $s.Files), $s.Seconds))
    $unread = [Math]::Max(0L, $used - $s.Root.Size)
    if ($unread -gt 256MB) { $sub += 'Geschützt / nicht lesbar: ' + (Format-Bytes $unread) }
    if ($s.CloudBytes -gt 0) { $sub += 'Nur in der Cloud (belegt keinen Platz): ' + (Format-Bytes $s.CloudBytes) }
    $ui.StorageSubline.Text = $sub -join '   ·   '
    $script:Storage.Entries = @(Get-StorageEntries $r)
    $script:Storage.SysEntries = @(Get-StorageSysEntries $r)
    $script:Storage.Filter = 'all'
    Show-StorageBig
    Show-StorageFolder $s.Root
    Show-StorageTypes $r
    Set-StorageView 'big'
    $games = @($script:Storage.Entries | Where-Object { $_.Kind -eq 'game' })
    Set-Status ('Analyse von {0} fertig: {1} Einträge über 500 MB, davon {2} Spiele.' -f $r.Drive, $script:Storage.Entries.Count, $games.Count)
}

function New-StorageBigRow($e, [int]$Rank, [double]$Total) {
    $b = New-Object Windows.Controls.Border
    $b.Padding = New-Thickness 8 14 8 14
    Set-ThemeRef $b BorderBrush 'line'; $b.BorderThickness = New-Thickness 0 0 0 1
    $g = New-Object Windows.Controls.Grid
    foreach ($w in 40, 32, -1, 104, 196) {
        $c = New-Object Windows.Controls.ColumnDefinition
        $c.Width = if ($w -lt 0) { New-Object Windows.GridLength(1, [Windows.GridUnitType]::Star) } else { New-Object Windows.GridLength($w) }
        $g.ColumnDefinitions.Add($c)
    }
    $rk = New-Text ([string]$Rank) -Role 'metric-small' -Color 'ink-muted'; $rk.VerticalAlignment = 'Top'
    [void]$g.Children.Add($rk)
    $iconKind = switch ($e.Kind) { 'game' { 'game' } 'program' { 'grid' } 'file' { 'file' } 'files' { 'file' } default { 'folder' } }
    $ic = New-LineIcon $iconKind $(if ($e.Kind -eq 'game') { 'accent-text' } else { 'ink-muted' }) 20; $ic.VerticalAlignment = 'Top'
    [Windows.Controls.Grid]::SetColumn($ic, 1); [void]$g.Children.Add($ic)

    $sp = New-Object Windows.Controls.StackPanel; $sp.Margin = New-Thickness 4 0 16 0
    $head = New-Object Windows.Controls.WrapPanel
    $tt = New-Text $e.Title -Role 'title'; $tt.TextTrimming = 'CharacterEllipsis'; $tt.Margin = New-Thickness 0 0 10 0
    [void]$head.Children.Add($tt)
    $badge = switch ($e.Kind) { 'game' { 'Spiel' + $(if ($e.Library) { " · $($e.Library)" } else { '' }) } 'program' { 'Programm' } 'file' { 'Datei' } 'files' { 'Dateien' } 'special' { 'Windows' } default { 'Ordner' } }
    $bl = New-Label $badge $(if ($e.Kind -eq 'game') { 'accent-text' } else { 'ink-muted' }); $bl.VerticalAlignment = 'Center'
    [void]$head.Children.Add($bl)
    [void]$sp.Children.Add($head)
    $pt = New-Text $e.Path -Role 'small' -Color 'ink-muted'; $pt.TextTrimming = 'CharacterEllipsis'; $pt.FontSize = 12; $pt.Margin = New-Thickness 0 2 0 0
    [void]$sp.Children.Add($pt)
    $bar = New-StorageBar ($e.Size / $Total) $(if ($e.Kind -eq 'game') { 'accent' } else { 'ink-muted' }); $bar.Margin = New-Thickness 0 8 0 8
    [void]$sp.Children.Add($bar)
    if ($e.Hint) { [void]$sp.Children.Add((New-Text $e.Hint -Role 'small')) }
    if ($e.Files.Count) {
        $fp = New-Object Windows.Controls.StackPanel
        foreach ($f in @($e.Files | Sort-Object Size -Descending | Select-Object -First 8)) {
            $fr = New-StorageRow -Name ([IO.Path]::GetFileName($f.Path)) -Size $f.Size -Share ($f.Size / [Math]::Max(1L, $e.Size)) -Meta $(if ($f.Modified -and $f.Modified.Year -gt 1980) { $f.Modified.ToString('dd.MM.yyyy') } else { '' }) `
                -Icon 'file' -Do { param($x) Open-StoragePath $x -Select } -Data $f.Path -Tip 'Im Explorer zeigen' -BarToken 'ink-muted'
            [void]$fp.Children.Add($fr)
        }
        $x = New-ExpanderBox ("Große Dateien darin ($($e.Files.Count))") $fp
        $x.Margin = New-Thickness 0 8 0 0
        [void]$sp.Children.Add($x)
    }
    [Windows.Controls.Grid]::SetColumn($sp, 2); [void]$g.Children.Add($sp)

    $sz = New-Object Windows.Controls.StackPanel; $sz.HorizontalAlignment = 'Right'; $sz.Margin = New-Thickness 0 0 16 0
    $st = New-Text (Format-Bytes $e.Size) -Role 'metric-small'; $st.HorizontalAlignment = 'Right'; [void]$sz.Children.Add($st)
    $sh = New-Text (Format-Share ($e.Size / $Total)) -Role 'small' -Color 'ink-muted'; $sh.HorizontalAlignment = 'Right'; [void]$sz.Children.Add($sh)
    [Windows.Controls.Grid]::SetColumn($sz, 3); [void]$g.Children.Add($sz)

    $act = New-Object Windows.Controls.StackPanel
    switch ($e.Kind) {
        'game' {
            if ($e.App.Kind -eq 'steam-orphan') { [void]$act.Children.Add((New-SmallButton 'In den Papierkorb' { param($x) Remove-StorageItem $x } $e)) }
            else { [void]$act.Children.Add((New-SmallButton 'Deinstallieren' { param($x) Invoke-StorageGameUninstall $x } $e)) }
            [void]$act.Children.Add((New-SmallButton 'Ordner öffnen' { param($x) Open-StoragePath $x } $e.Path))
        }
        'program' {
            [void]$act.Children.Add((New-SmallButton 'Deinstallieren' { param($x) Open-StorageUninstall $x } $e.App.Uninstall))
            [void]$act.Children.Add((New-SmallButton 'Ordner öffnen' { param($x) Open-StoragePath $x } $e.Path))
        }
        'special' {
            [void]$act.Children.Add((New-SmallButton 'Datenträgerbereinigung' { try { Start-Process cleanmgr.exe -ArgumentList "/d $($script:Storage.Drive)" } catch { Show-Error $_.Exception.Message } }))
        }
        'file' {
            [void]$act.Children.Add((New-SmallButton 'Im Explorer zeigen' { param($x) Open-StoragePath $x -Select } $e.Path))
            if ($e.Recycle) { [void]$act.Children.Add((New-SmallButton 'In den Papierkorb' { param($x) Remove-StorageItem $x } $e)) }
        }
        default {
            [void]$act.Children.Add((New-SmallButton 'Öffnen' { param($x) Open-StoragePath $x } $e.Path))
            if ($e.Node) { [void]$act.Children.Add((New-SmallButton 'Im Ordnerbaum zeigen' { param($n) Set-StorageView 'tree'; Show-StorageFolder $n } $e.Node)) }
            if ($e.Recycle -and $e.Kind -eq 'folder') { [void]$act.Children.Add((New-SmallButton 'In den Papierkorb' { param($x) Remove-StorageItem $x } $e)) }
        }
    }
    [Windows.Controls.Grid]::SetColumn($act, 4); [void]$g.Children.Add($act)
    $b.Child = $g
    return $b
}

function Show-StorageBig {
    $p = $ui.StorageBig; $p.Children.Clear()
    $r = $script:Storage.Result
    $total = [double][Math]::Max(1L, $r.Size - $r.Free)
    $all = @($script:Storage.Entries)

    # Filter (Alle / Spiele / Programme / Ordner und Dateien)
    $bar = New-Object Windows.Controls.StackPanel; $bar.Margin = New-Thickness 8 0 8 4
    $fp = New-Object Windows.Controls.WrapPanel
    $counts = @{
        all = $all.Count; game = @($all | Where-Object { $_.Kind -eq 'game' }).Count; program = @($all | Where-Object { $_.Kind -eq 'program' }).Count
        data = @($all | Where-Object { $_.Kind -in 'folder', 'file', 'files', 'special' }).Count
    }
    foreach ($f in @(@('all', 'Alle'), @('game', 'Spiele'), @('program', 'Programme'), @('data', 'Ordner & Dateien'))) {
        $b = New-Object Windows.Controls.Button
        $b.Style = Get-ThemeStyle 'TopNav'; $b.Height = 32
        $b.Content = Format-Caps ("{0} ({1})" -f $f[1], $counts[$f[0]])
        $b.Tag = if ($script:Storage.Filter -eq $f[0]) { 'active' } else { $null }
        $b.CommandParameter = $f[0]
        $b.Add_Click({ $script:Storage.Filter = [string]$this.CommandParameter; Show-StorageBig })
        [void]$fp.Children.Add($b)
    }
    [void]$bar.Children.Add($fp)
    $fp.Margin = New-Thickness -10 0 0 4
    [void]$p.Children.Add($bar)

    $list = switch ($script:Storage.Filter) {
        'game' { @($all | Where-Object { $_.Kind -eq 'game' }) }
        'program' { @($all | Where-Object { $_.Kind -eq 'program' }) }
        'data' { @($all | Where-Object { $_.Kind -in 'folder', 'file', 'files', 'special' }) }
        default { $all }
    }
    if ($list.Count -eq 0) {
        $t = New-Text $(if ($script:Storage.Filter -eq 'game') { 'Keine Spiele über 500 MB auf diesem Laufwerk gefunden.' } else { 'Hier gibt es keine Einträge über 500 MB.' }) -Role 'small' -Color 'ink-muted' -Top 8
        $t.Margin = New-Thickness 8 8 8 8; [void]$p.Children.Add($t)
    } else {
        $sum = 0L; foreach ($e in $list) { $sum += $e.Size }
        $s = New-Text ('Die größten Brocken ab 500 MB, sortiert nach Größe: {0} Einträge, zusammen {1} ({2} des belegten Speichers).' -f $list.Count, (Format-Bytes $sum), (Format-Share ($sum / $total))) -Role 'small' -Color 'ink-muted'
        $s.Margin = New-Thickness 8 0 8 4; [void]$p.Children.Add($s)
        $rank = 0
        foreach ($e in @($list | Select-Object -First 60)) { $rank++; [void]$p.Children.Add((New-StorageBigRow $e $rank $total)) }
        if ($list.Count -gt 60) { $m = New-Text "… und $($list.Count - 60) weitere. Im Reiter Ordner findest du alles." -Role 'small' -Color 'ink-muted' -Top 8; $m.Margin = New-Thickness 8 8 8 0; [void]$p.Children.Add($m) }
    }

    # Zur Einordnung: Windows und System (nicht von Hand löschen)
    $sysList = @($script:Storage.SysEntries)
    if ($sysList.Count -and $script:Storage.Filter -in 'all', 'data') {
        $sp = New-Object Windows.Controls.StackPanel
        foreach ($h in $sysList) {
            $row = New-Object Windows.Controls.DockPanel; $row.Margin = New-Thickness 0 8 0 8
            if ($h.Action) {
                $act = New-SmallButton $h.ActionLabel {
                    param($a)
                    switch ($a) { 'cleanup' { $ui.Tabs.SelectedIndex = 4 } 'restore' { Show-RestorePointManager } }
                } $h.Action
                $act.Width = 180; $act.Margin = New-Thickness 16 0 0 0; $act.VerticalAlignment = 'Top'
                [Windows.Controls.DockPanel]::SetDock($act, 'Right'); [void]$row.Children.Add($act)
            }
            $sz = New-Text (Format-Bytes $h.Size) -Role 'metric-small'; $sz.Width = 96; $sz.TextAlignment = 'Right'; $sz.Margin = New-Thickness 16 0 0 0
            [Windows.Controls.DockPanel]::SetDock($sz, 'Right'); [void]$row.Children.Add($sz)
            $tx = New-Object Windows.Controls.StackPanel
            [void]$tx.Children.Add((New-Text $h.Title -Role 'title'))
            [void]$tx.Children.Add((New-Text $h.Note -Role 'small' -Color 'ink-muted'))
            [void]$row.Children.Add($tx)
            [void]$sp.Children.Add($row)
        }
        $x = New-ExpanderBox 'Windows und Programmdaten – zur Einordnung, nicht von Hand löschen' $sp 'info'
        $x.Margin = New-Thickness 8 16 8 0
        [void]$p.Children.Add($x)
    }
}

function Show-StorageFolder($Node) {
    if (-not $Node) { return }
    $script:Storage.Node = $Node
    $r = $script:Storage.Result
    $ui.StorageCrumbs.Children.Clear()
    $chain = New-Object System.Collections.ArrayList
    $n = $Node; while ($n) { [void]$chain.Insert(0, $n); $n = $n.Parent }
    for ($i = 0; $i -lt $chain.Count; $i++) {
        $c = $chain[$i]
        $label = if ($i -eq 0) { $c.Name.TrimEnd('\') } else { $c.Name }
        if ($i -gt 0) { $sep = New-LineIcon 'chevron' 'ink-muted' 14; $sep.Margin = New-Thickness 2 0 2 0; $sep.VerticalAlignment = 'Center'; [void]$ui.StorageCrumbs.Children.Add($sep) }
        if ($i -eq $chain.Count - 1) {
            $t = New-Text $label -Role 'title'; $t.VerticalAlignment = 'Center'; $t.Margin = New-Thickness 4 0 4 0
            [void]$ui.StorageCrumbs.Children.Add($t)
        } else {
            $btn = New-ActionButton $label { param($x) Show-StorageFolder $x } $c
            $btn.MinHeight = 28; $btn.Padding = New-Thickness 8 2 8 3; $btn.Margin = New-Thickness 0 2 0 2
            [void]$ui.StorageCrumbs.Children.Add($btn)
        }
    }
    $used = [Math]::Max(1L, $r.Size - $r.Free)
    $ui.StorageFolderInfo.Text = '{0}  ·  {1} Dateien  ·  {2} Unterordner  ·  {3} des belegten Speichers' -f (Format-Bytes $Node.Size), (Format-Count $Node.Files), (Format-Count $Node.Children.Count), (Format-Share ($Node.Size / $used))
    $ui.BtnStorageUp.IsEnabled = [bool]$Node.Parent

    $list = $ui.StorageList
    $list.Children.Clear()
    $total = [double][Math]::Max(1L, $Node.Size)
    $kids = @($Node.Children | Sort-Object Size -Descending)
    $show = [Math]::Min(100, $kids.Count)
    for ($i = 0; $i -lt $show; $i++) {
        $k = $kids[$i]
        $meta = if ($k.Denied) { 'kein Zugriff' } elseif ($k.Files -gt 0) { '{0} Dateien' -f (Format-Count $k.Files) } else { 'leer' }
        $do = if ($k.Children.Count -gt 0 -or $k.OwnFiles -gt 0) { { param($x) Show-StorageFolder $x } } else { $null }
        [void]$list.Children.Add((New-StorageRow -Name $k.Name -Size $k.Size -Share ($k.Size / $total) -Meta $meta -Icon 'folder' -Do $do -Data $k -Tip 'Ordner öffnen'))
    }
    if ($kids.Count -gt $show) {
        $rest = 0L; for ($i = $show; $i -lt $kids.Count; $i++) { $rest += $kids[$i].Size }
        [void]$list.Children.Add((New-StorageRow -Name ('{0} weitere Ordner' -f ($kids.Count - $show)) -Size $rest -Share ($rest / $total) -Icon 'folder' -BarToken 'ink-muted'))
    }
    if ($Node.OwnFiles -gt 0) {
        [void]$list.Children.Add((New-StorageRow -Name 'Dateien direkt in diesem Ordner' -Size $Node.OwnSize -Share ($Node.OwnSize / $total) -Meta ('{0} Dateien' -f (Format-Count $Node.OwnFiles)) -Icon 'file' -BarToken 'ink-muted' `
            -Do { param($x) Open-StoragePath $x } -Data $Node.Path -Tip 'Im Explorer öffnen'))
    }
    if ($Node.Denied) { [void]$list.Children.Add((New-ColoredLine 'Kein Zugriff: Windows schützt diesen Ordner. Sein Inhalt zählt zum Posten »Geschützt / nicht lesbar«.' 1 8)) }
    elseif ($list.Children.Count -eq 0) { [void]$list.Children.Add((New-Text 'Dieser Ordner ist leer.' -Role 'small' -Color 'ink-muted' -Top 8)) }
}

function Show-StorageTypes($r) {
    $p = $ui.StorageTypes; $p.Children.Clear()
    $total = [double][Math]::Max(1L, $r.Scan.Root.Size)
    $cat = @{}; $cnt = @{}
    foreach ($e in $r.Scan.Extensions) {
        $k = $script:StorageExtCat[$e.Ext]; if (-not $k) { $k = 'Sonstiges' }
        $cat[$k] = [long]$cat[$k] + $e.Size; $cnt[$k] = [long]$cnt[$k] + $e.Count
    }
    $l = New-Label 'Nach Kategorie'; $l.Margin = New-Thickness 8 0 0 8; [void]$p.Children.Add($l)
    foreach ($k in @($cat.Keys | Sort-Object { $cat[$_] } -Descending)) {
        if ($cat[$k] -le 0) { continue }
        [void]$p.Children.Add((New-StorageRow -Name $k -Size $cat[$k] -Share ($cat[$k] / $total) -Meta ('{0} Dateien' -f (Format-Count $cnt[$k])) -Icon 'file'))
    }
    $l = New-Label 'Häufigste Dateiendungen'; $l.Margin = New-Thickness 8 24 0 8; [void]$p.Children.Add($l)
    foreach ($e in @($r.Scan.Extensions | Select-Object -First 15)) {
        $name = if ($e.Ext) { '.' + $e.Ext } else { '(ohne Endung)' }
        [void]$p.Children.Add((New-StorageRow -Name $name -Size $e.Size -Share ($e.Size / $total) -Meta ('{0} Dateien' -f (Format-Count $e.Count)) -Icon 'file' -BarToken 'ink-muted'))
    }
}

# ---------------------------------------------------------------------------
#  Ereignisse
# ---------------------------------------------------------------------------
$ui.StorageEmptyIcon.Content = New-LineIcon 'drive' 'ink-muted' 40
$ui.BtnStorageViewBig.Add_Click({ Set-StorageView 'big' })
$ui.BtnStorageViewTree.Add_Click({ Set-StorageView 'tree' })
$ui.BtnStorageViewTypes.Add_Click({ Set-StorageView 'types' })
$ui.BtnStorageUp.Add_Click({ if ($script:Storage.Node -and $script:Storage.Node.Parent) { Show-StorageFolder $script:Storage.Node.Parent } })
$ui.BtnStorageOpen.Add_Click({ if ($script:Storage.Node) { Open-StoragePath $script:Storage.Node.Path } })
